package com.ddlad.student.ui.pic;


import com.ddlad.student.protocol.model.BaseInfo;

/**
 * 一个图片对象
 * 
 * @author Administrator
 * 
 */
public class ImageItem extends BaseInfo {
	public String imageId;
	public String thumbnailPath;
	public String thumbnailName;
	public String imagePath;
	public String imageName;
}
