package com.ddlad.student.service;

import android.app.IntentService;
import android.content.Intent;
import android.support.v4.content.WakefulBroadcastReceiver;

import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ApiUrlHelper;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.push.service.Push;

import java.io.IOException;

import ch.boye.httpclientandroidlib.HttpResponse;
import ch.boye.httpclientandroidlib.util.EntityUtils;

public class WorkerService extends IntentService {

    private static final String TAG = "WorkerService";

    public static final int START_PUSH_SERVICE = 0;

    public static final int BIND_GETUI_PUSH = 1;

    public WorkerService() {
        super(TAG);
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        int type = intent.getIntExtra(ProtocolConstants.PARAM_TYPE, -1);

        switch (type) {
            case START_PUSH_SERVICE:
                Push.getInstance().startPushService();
                break;
            case BIND_GETUI_PUSH:
                bindGetuiPush(intent);
                break;
        }
    }

    public static void startWork() {
        Intent intent = new Intent(AppContext.getContext(), WorkerService.class);
        intent.putExtra(ProtocolConstants.PARAM_TYPE, START_PUSH_SERVICE);
        AppContext.getContext().startService(intent);
    }

    private void bindGetuiPush(Intent intent) {

        RequestParams requestParams = new RequestParams();
        requestParams.put(ProtocolConstants.PARAM_PUSH_TOKEN, intent.getStringExtra(ProtocolConstants.PARAM_PUSH_TOKEN));

        ApiHttpClient apiHttpClient = ApiHttpClient.getInstance();

        String url = ApiUrlHelper.expandPath(ProtocolConstants.URL_PUSH_BIND,
                false, true, ApiUrlHelper.API_VERSION);

        HttpResponse httpResponse = apiHttpClient.post(url, requestParams);

        if (httpResponse != null && httpResponse.getStatusLine() != null
                && httpResponse.getStatusLine().getStatusCode() == 200) {

        }

        if (Log.DEBUG) {
            if (httpResponse != null && httpResponse.getStatusLine() != null) {
                Log.d(TAG, "Bind auth push. Response code for path: " + url + ", "
                        + httpResponse.getStatusLine().getStatusCode());
            }
        }
        if (httpResponse != null) {
            try {
                EntityUtils.consume(httpResponse.getEntity());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        WakefulBroadcastReceiver.completeWakefulIntent(intent);
    }

}
