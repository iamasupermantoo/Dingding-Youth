package com.ddlad.student.ui.account;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.R;
import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.request.BaseListRequest;
import com.ddlad.student.protocol.http.request.LLiveCourseListRequest;
import com.ddlad.student.protocol.http.request.LWithdrawalsRecordListRequest;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.CoursesLiveBean;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.choice.LiveCourseListAdapter;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.common.BaseListFragment;

/**
 * Created by chen007 on 2017/11/10 0010.
 */
public class WithdrawalsCashRecordFragment extends BaseListFragment<CoursesLiveBean> {

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_live_course_list;
    }

    @Override
    protected void onInitData(Bundle bundle) {

    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle("提现记录");
    }

    @Override
    protected BaseListRequest makeRequest(AbstractStreamingCallbacks<AbstractListResponse<CoursesLiveBean>> streamingApiCallbacks) {
        return new LWithdrawalsRecordListRequest(this, ViewUtil.generateUniqueId(), streamingApiCallbacks);
    }

    @Override
    protected void performRequest() {
        ((LWithdrawalsRecordListRequest)mDefaultRequest).perform();
    }

    @Override
    protected boolean isNeedFetch() {
        return true;
    }

    @Override
    protected AbstractAdapter getAdapter() {
        if(mAdapter == null){
            mAdapter = new WithdrawalsCashListAdapter(this);
        }
        return mAdapter;
    }


    @Override
    protected void showEmptyView() {

        if (mEmptyView == null) {
            mEmptyView = (ViewGroup) LayoutInflater.from(getActivity()).inflate(R.layout.layout_empty_footer, null);
            mListView.addFooterView(mEmptyView, null, false);
        }

        if (mAdapter == null || mAdapter.isEmpty()) {
            mEmptyView.setVisibility(View.VISIBLE);
        } else {
            hideEmptyView();
        }

    }

    @Override
    protected void hideEmptyView() {
        if (mEmptyView != null) {
            mListView.removeFooterView(mEmptyView);
        }
        mEmptyView = null;
    }
}
