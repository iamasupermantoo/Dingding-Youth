package com.ddlad.student.ui.course;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import com.ddlad.student.ui.widget.image.CircleImageView;
import com.ddlad.student.R;
import com.ddlad.student.protocol.model.EvaluateListInfo;

/**
 * Created by Administrator on 2017/3/17 0017.
 */
public class UserFeedBackAdapter extends RecyclerView.Adapter implements View.OnClickListener{

    private boolean mIsHasNext;
    private EvaluateListInfo mInfo;

    public UserFeedBackAdapter() {
    }

    public UserFeedBackAdapter(EvaluateListInfo mInfo) {
        this.mInfo = mInfo;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_feed_back_item,null);
        MyViewHolder holder = new MyViewHolder(view);
//        holder.mEvaluate.setOnClickListener(this);
        return holder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MyViewHolder viewHolder = (MyViewHolder) holder;

//        String url =  mInfo.getReactions().getList().get(position).getImage().getPattern();
//        viewHolder.mImage.setUrl(url.substring(url.indexOf("http"),url.indexOf(".png"))+".png");
//
//
//        viewHolder.mImage.setTag(position);
//        viewHolder.mImage.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.evaluate:
                //跳到评价详情
                if (mOnItemClickListener != null){
                    mOnItemClickListener.onItemImageClick(v, (Integer) v.getTag());
                }
                break;
            case R.id.evaluate_details:
                ;
            case R.id.evaluate_item_image:
                //跳到个人详情
                if (mOnItemClickListener != null){
                    mOnItemClickListener.onItemClick(v, (Integer) v.getTag());
                }
        }

    }

    public static interface OnRecyclerViewItemClickListener{
        void onItemClick(View view, int position);
        void onItemImageClick(View view, int position);
    }

    private OnRecyclerViewItemClickListener mOnItemClickListener = null;

    public void setmOnItemClickListener(OnRecyclerViewItemClickListener onItemClickListener){
        mOnItemClickListener = onItemClickListener;
    }


    @Override
    public int getItemCount() {
        return 10;
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        public TextView mUserName;
        public RatingBar mUserStar;
        public TextView mUserTime;
        public CircleImageView mImage;
        public TextView mUserEvaluate;
        public MyViewHolder(View itemView) {
            super(itemView);
            mUserName = (TextView) itemView.findViewById(R.id.item_user_name);
            mUserTime = (TextView) itemView.findViewById(R.id.item_user_time);
            mImage = (CircleImageView) itemView.findViewById(R.id.item_user_head_image);
            mUserEvaluate = (TextView) itemView.findViewById(R.id.item_user_evaluate);
            mUserStar = (RatingBar) itemView.findViewById(R.id.item_user_star);
        }
    }
}
