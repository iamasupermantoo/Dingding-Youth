package com.ddlad.student.ui.classtable;

import java.util.Calendar;

/**
 * Created by Albert
 * on 16-8-31.
 */
public interface DateChangeListener {

    public void onMonthChanged(Calendar date);

    public void onDateChanged(Calendar date);
}
