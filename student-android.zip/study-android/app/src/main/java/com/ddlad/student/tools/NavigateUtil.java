package com.ddlad.student.tools;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;
import com.ddlad.student.ui.agora.LiveRoomActivity;
import com.ddlad.student.ui.common.BaseActivity;
import com.ddlad.student.ui.common.NormalActivity;
import com.ddlad.student.ui.detail.DetailActivity;
import com.ddlad.student.ui.sign.SignActivity;
import com.ddlad.student.R;


public class NavigateUtil {

    private static final String TAG = "NavigateUtil";

    public static final String ARGUMENTS_KEY_NO_BACK_STACK = "noBackStack";

    public static void detachAndAdd(FragmentManager fragmentManager, Fragment fragmentDetach,
                                    Fragment fragmentAdd, Bundle bundle) {
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentAdd.setArguments(bundle);
        fragmentTransaction.detach(fragmentDetach);
        fragmentTransaction.add(R.id.layout_container_main, fragmentAdd);
        fragmentTransaction.commit();
        fragmentManager.executePendingTransactions();
    }

    public static void navigateWithAnimations(FragmentManager fragmentManager, Fragment fragment,
                                              Bundle bundle) {

        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        boolean noBackStack = Boolean.FALSE;
        if (bundle != null) {

            if (bundle.getBoolean(ARGUMENTS_KEY_NO_BACK_STACK)) {
                bundle.remove(ARGUMENTS_KEY_NO_BACK_STACK);
                noBackStack = Boolean.TRUE;
            }

            fragment.setArguments(bundle);
        }

        fragmentTransaction.replace(R.id.layout_container_main, fragment);

        if (Log.DEBUG) {
            Log.d(TAG, "navigateTo(), noBackStack=" + noBackStack);
        }

        if (!noBackStack) {
            fragmentTransaction.addToBackStack(null);
        }

        fragmentTransaction.commit();
        fragmentManager.executePendingTransactions();

    }

    public static Intent getNavigateIntent(Context context, Class cls, Fragment fragment, Bundle bundle) {

        Intent intent = new Intent(context, cls);

        if (bundle == null) {
            bundle = new Bundle();
        }

        if (bundle.getBoolean(ARGUMENTS_KEY_NO_BACK_STACK)) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        }

        intent.putExtra(BaseActivity.ARGUMENT_EXTRA_FRAGMENT_NAME, fragment.getClass()
                .getName());
        intent.putExtras(bundle);

        return intent;
    }

    public static void navigateToNewActivity(Activity activity, Class cls, Fragment fragment, Bundle bundle) {

        Intent intent = new Intent(activity, cls);

        if (bundle == null) {
            bundle = new Bundle();
        }

        if (bundle.getBoolean(ARGUMENTS_KEY_NO_BACK_STACK)) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        }

        intent.putExtra(BaseActivity.ARGUMENT_EXTRA_FRAGMENT_NAME, fragment.getClass()
                .getName());
        intent.putExtras(bundle);

        activity.startActivity(intent);
        activityAnimate(activity, bundle);
    }

    public static void navigateToSignActivity(Activity activity, Fragment fragment, Bundle bundle) {
        navigateToNewActivity(activity, SignActivity.class, fragment, bundle);
    }

    public static void navigateToDetailActivity(Activity activity, Fragment fragment, Bundle bundle) {
        navigateToNewActivity(activity, DetailActivity.class, fragment, bundle);
    }

    public static void navigateToPublishActivity(Activity activity, Fragment fragment, Bundle bundle) {
//        navigateToNewActivity(activity, PublishActivity.class, fragment, bundle);
    }

    public static void navigateToNormalActivity(Activity activity, Fragment fragment, Bundle bundle) {
        navigateToNewActivity(activity, NormalActivity.class, fragment, bundle);
    }

    public static void navigateToLiveRoomActivity(Activity activity, Fragment fragment, Bundle bundle) {
        navigateToNewActivity(activity, LiveRoomActivity.class, fragment, bundle);
    }
    public static void navigateToNormalActivityForResult(Fragment fragmentContext,
                                                         Fragment fragment, Bundle bundle, int requestCode) {

        Intent intent = new Intent(AppContext.getContext(), NormalActivity.class);
        intent.putExtra(BaseActivity.ARGUMENT_EXTRA_FRAGMENT_NAME, fragment.getClass()
                .getName());
        if (bundle == null) {
            bundle = new Bundle();
        }
        intent.putExtras(bundle);
        fragmentContext.startActivityForResult(intent, requestCode);
        activityAnimate(fragmentContext.getActivity(), bundle);
    }

    public static void activityAnimate(Activity activity, Bundle bundle) {

        boolean noAnimation = false;
        boolean isUpAnim = false;
        boolean isFade = false;
        boolean isCustom = false;

        if (bundle != null) {
            noAnimation = bundle.getBoolean(BaseActivity.ARGUMENT_EXTRA_NO_ANIMATION);
            isUpAnim = bundle.getBoolean(BaseActivity.ARGUMENT_EXTRA_ANIMATION_UP);
            isFade = bundle.getBoolean(BaseActivity.ARGUMENT_EXTRA_ANIMATION_FADE);
            isCustom = bundle.getBoolean(BaseActivity.ARGUMENT_EXTRA_ANIMATION_CUSTOM);
        }

        if (noAnimation || isCustom) {
            activity.overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        } else if (isUpAnim) {
            activity.overridePendingTransition(R.anim.down_in, R.anim.playlist_slide_out);
        } else if (isFade) {
            activity.overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        } else {
            activity.overridePendingTransition(R.anim.fragment_slide_left_enter,
                    R.anim.fragment_slide_left_exit);
        }
    }

    public static void removeAndAdd(FragmentManager fragmentManager, Fragment fragmentRemove,
                                    Fragment fragmentAdd, Bundle bundle) {
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentAdd.setArguments(bundle);
        fragmentTransaction.remove(fragmentRemove);
        fragmentTransaction.add(R.id.layout_container_main, fragmentAdd);
        fragmentTransaction.commit();
        fragmentManager.executePendingTransactions();
    }

    public static void replaceFragment(int fragmentId, FragmentManager fragmentManager, Fragment fragment, Bundle bundle) {

        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        Bundle arguments = fragment.getArguments();
        if (arguments == null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            fragment.setArguments(bundle);
        } else if (bundle != null) {
            fragment.getArguments().putAll(bundle);
        }

        fragmentTransaction.replace(fragmentId, fragment, fragment.getClass().getName());
        fragmentTransaction.commit();
        fragmentManager.executePendingTransactions();
    }

    public static void removeFragment(FragmentManager fragmentManager, Fragment fragment) {
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.remove(fragment);
        fragmentTransaction.commit();
        fragmentManager.executePendingTransactions();
    }

}
