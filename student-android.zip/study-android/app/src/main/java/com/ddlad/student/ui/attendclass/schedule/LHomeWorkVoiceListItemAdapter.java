package com.ddlad.student.ui.attendclass.schedule;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.model.LHomeWorkInfo;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.voice.MediaPlayerManager;

public class LHomeWorkVoiceListItemAdapter {

    public static View createView(ViewGroup viewGroup) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.pending_item_voice,
                null);

        VoiceViewHolder holder = new VoiceViewHolder(view);

        view.setTag(holder);

        return view;
    }

    public static void bindView(View view, final LHomeWorkInfo mInfo, final BaseFragment fragment, final int position,boolean mIsModify,int minWidth,int maxWidth,final LHomeWorkListAdapter.IRemoveAnswerListener listener) {

        if (mInfo == null) {
            return;
        }

        VoiceViewHolder voiceHolder = (VoiceViewHolder) view.getTag();

        if (voiceHolder == null) {
            return;
        }

        Bitmap temp = BitmapFactory.decodeResource(fragment.getActivity().getResources(), R.drawable.adj);
        int width = temp.getWidth();
        int height = temp.getHeight();
        //定义预转换成的图片的宽度和高度
        int newWidth = (int) ViewUtil.dpToPx(25);
        int newHeight = (int) ViewUtil.dpToPx(25);
        //计算缩放率，新尺寸除原始尺寸
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        // 创建操作图片用的matrix对象
        Matrix matrix = new Matrix();
        // 缩放图片动作
        matrix.postScale(scaleWidth, scaleHeight);
        matrix.postRotate(180);
        Bitmap bimap = Bitmap.createBitmap(temp,0,0,width,height,matrix,true);
        BitmapDrawable bmd = new BitmapDrawable(bimap);
        voiceHolder.mVoice.setBackgroundDrawable(bmd);
        if (mIsModify){
            voiceHolder.xx.setVisibility(View.VISIBLE);
            voiceHolder.xx.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.removeAnswer(position,mInfo.getId(),fragment);
                }
            });
        }else {
            voiceHolder.xx.setVisibility(View.GONE);
        }

//                WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
//                DisplayMetrics outMetrics = new DisplayMetrics();
//                wm.getDefaultDisplay().getMetrics(outMetrics);
//                voiceHolder.mTime.setText(Math.round(list.get(position).getTime()) + "\"");
        voiceHolder.mTime.setText(mInfo.getTime());
        voiceHolder.mVoidLength.setText(mInfo.getAudioLength()+"");
        final VoiceViewHolder finalVoiceHolder = voiceHolder;
        voiceHolder.mLength.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finalVoiceHolder.mVoice.setBackgroundResource(R.drawable.play_anim);
                AnimationDrawable animation = (AnimationDrawable) finalVoiceHolder.mVoice.getBackground();
                animation.start();
                // 播放录音
                MediaPlayerManager.playSound(mInfo.getAudio(),new MediaPlayer.OnCompletionListener() {

                    public void onCompletion(MediaPlayer mp) {
                        //播放完成后修改图片
                        finalVoiceHolder.mVoice.setBackgroundResource(R.drawable.adj);
                    }
                });
            }
        });

        ViewGroup.LayoutParams lp = voiceHolder.mLength.getLayoutParams();
        ///修改
        lp.width = (int) (minWidth + (maxWidth / 60f) * mInfo.getAudioLength());

    }


    public  interface OnRecyclerViewItemClickListener{
        void onItemClick(View view, int position);
        void onItemImageClick(View view, int position);
    }

    private static OnRecyclerViewItemClickListener mOnItemClickListener = null;

    public void setmOnItemClickListener(OnRecyclerViewItemClickListener onItemClickListener){
        mOnItemClickListener = onItemClickListener;
    }


    private static class VoiceViewHolder {
        private TextView mTime;
        private View mVoice;
        private ViewGroup mLength;
        private TextView mVoidLength;
        private ImageView xx;
        public VoiceViewHolder(View itemView) {
            mVoidLength = (TextView) itemView.findViewById(R.id.pending_item_voice_length);
            xx = (ImageView) itemView.findViewById(R.id.xx);
            mTime = (TextView) itemView.findViewById(R.id.item_time);
            mVoice =  itemView.findViewById(R.id.pending_item_voice);
            mLength = (ViewGroup) itemView.findViewById(R.id.pending_voice_length);


        }
    }


}
