package com.ddlad.student.ui.attendclass.student;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.model.LessonInfo;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.attendclass.evaluate.EvaluateAlreadyDetailsFragment;
import com.ddlad.student.ui.attendclass.lesson.LessonAdapter;
import com.ddlad.student.ui.attendclass.schedule.PendingFragment;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.request.BaseListRequest;
import com.ddlad.student.protocol.http.request.LScheduleLessonListRequest;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.course.TeacherReactionDetailFragment;
import com.ddlad.student.ui.widget.image.NetworkImageView;

/**
 * Created by chenjianing on 2017/5/12 0012.
 */
public class ScheduleLessonFragment extends BaseListFragment<LessonInfo> {

    private int mLessonLoaderId = ViewUtil.generateUniqueId();

    private NetworkImageView mImage;
    private TextView mCourse;
    private TextView mTotalLesson;
    private TextView mTimeTable;
    private TextView mLesson;
    private ViewGroup mCourseDetails;
    ////////////////////////////
    private TextView mLeeson;
    private TextView mTime;
    private TextView mStatus;
    private TextView mPlayback;
    private TextView mEvaluate;
    private TextView mHomework;
    private TextView mFeedBack;



    private String cid;
    private String lid;
    private String imageUrl;
    private String courseName;
    private int courseTime;

    @Override
    protected int getLayoutResource() {
        return R.layout.schedule_lesson_list;
    }

    @Override
    protected void onInitView(View contentView) {
        super.onInitView(contentView);

    }


    @Override
    protected int getHeaderResource() {
        return R.layout.schedule_lesson_header;
    }

    @Override
    protected void onInitHeader(View view) {
        mActionbar.setTitle("课程");
        mImage = (NetworkImageView) view.findViewById(R.id.curriculum_item_image);
        mCourse = (TextView) view.findViewById(R.id.curriculum_item_course);
        mTotalLesson = (TextView) view.findViewById(R.id.curriculum_item_total_lesson);
        mTimeTable = (TextView) view.findViewById(R.id.curriculum_item_timetable);
        mLesson = (TextView) view.findViewById(R.id.curriculum_item_lesson);
        mCourseDetails = (ViewGroup) view.findViewById(R.id.curriculum_item_detail_course_layout);
        mImage.setUrl(imageUrl.substring(imageUrl.indexOf("http"),imageUrl.indexOf("@{w}w")));
        mCourse.setText(courseName);
        mTotalLesson.setText(courseTime+"节课");
        //////////////////////////////////////////////////////////////////////////////////////////
//        mCourse.setText(curriculumInfo.getName());
//        mTotalLesson.setText(String.valueOf(curriculumInfo.getTotalCnt()));
//        if (curriculumInfo.getImage() != null){
//            mImage.setUrl(curriculumInfo.getImage().getImageSmall());
//        }
//        mLesson.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Bundle bundle = new Bundle();
//                bundle.putString(ProtocolConstants.PARAM_CID,curriculumInfo.getCid());
//                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new LessonFragment(), bundle);
//
//            }
//        });
//        mTimeTable.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Bundle bundle = new Bundle();
//                bundle.putString(ProtocolConstants.PARAM_CID,curriculumInfo.getCid());
//                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new ScheduleFragment(), bundle);
//            }
//        });
//        mCourseDetails.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Bundle bundle = new Bundle();
//                bundle.putString(ProtocolConstants.PARAM_CMID,curriculumInfo.getCmId());
//                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new CourseDetailsFragment(), bundle);
//            }
//        });

        ///////////////////////////////////////////////////////////////////////////////////////
        mLeeson = (TextView) view.findViewById(R.id.lesson_item_name);
        mTime = (TextView) view.findViewById(R.id.lesson_item_time);
        mStatus = (TextView) view.findViewById(R.id.lesson_item_status);
        mPlayback = (TextView) view.findViewById(R.id.lesson_item_playback);
        mEvaluate = (TextView) view.findViewById(R.id.lesson_item_evaluate);
        mHomework = (TextView) view.findViewById(R.id.lesson_item_homework);
        mFeedBack = (TextView) view.findViewById(R.id.lesson_item_feedback);
        /////////////////////////////////////////////////////////////////////////

    }

    @Override
    protected void onInitData(Bundle bundle) {
        cid = bundle.getString("cid");
        lid = bundle.getString("lid");
        imageUrl = bundle.getString("url");
        courseName = bundle.getString("course");
        courseTime = bundle.getInt("coursetime");
        super.onInitData(bundle);

    }

    @Override
    protected AbstractAdapter getAdapter() {
        if (mAdapter == null){
            mAdapter = new LessonAdapter(this);
        }
        return mAdapter;
    }

    @Override
    protected BaseListRequest makeRequest(AbstractStreamingCallbacks<AbstractListResponse<LessonInfo>> streamingApiCallbacks) {
        return new LScheduleLessonListRequest(this,mLessonLoaderId,streamingApiCallbacks);
    }


    @Override
    protected void afterCallbackSuccess() {

        mHomework.setText("提交作业");
        mHomework.setSelected(false);
        mHomework.setTextColor(Color.parseColor("#ffffff"));

        mFeedBack.setText("查看反馈");
        mFeedBack.setTextColor(Color.parseColor("#ffffff"));
        mFeedBack.setSelected(false);

        mEvaluate.setText("评价");
        mEvaluate.setTextColor(Color.parseColor("#ffffff"));
        mEvaluate.setSelected(false);


        mLeeson.setText(getmLessonInfo().getLabel());
        mTime.setText(String.valueOf(getmLessonInfo().getDate()+" "+getmLessonInfo().getTime()));
        if (getmLessonInfo().getStatus() == LessonInfo.LessonType.NoLesson.getValue()){
            mStatus.setText("未上课");
            mStatus.setTextColor(Color.parseColor("#fe8d25"));

        }else if (getmLessonInfo().getStatus() == LessonInfo.LessonType.AlreadyLesson.getValue()){
            mStatus.setText("正在上课");
            mStatus.setTextColor(Color.parseColor("#cccccc"));
        }else if (getmLessonInfo().getStatus() == 2){

            mStatus.setText("已上课");
            mStatus.setTextColor(Color.parseColor("#cccccc"));
            ///////////////////////////////////////////////
            mHomework.setText("提交作业");
            mHomework.setSelected(true);
            mHomework.setTextColor(Color.parseColor("#000000"));
            ///////////////////////////////////////////////////////////
            mPlayback.setSelected(true);
            mPlayback.setTextColor(Color.parseColor("#000000"));
            ///////////////////////////////////////////////
            if (getmLessonInfo().getHomeworkStatus() == 1){
                mHomework.setText("查看批改");
                mHomework.setSelected(true);
                mHomework.setTextColor(Color.parseColor("#000000"));
            }

            if (getmLessonInfo().getTeacherReactionStatus() == 1){
                mFeedBack.setText("查看反馈");
                mFeedBack.setTextColor(Color.parseColor("#000000"));
                mFeedBack.setSelected(true);
            }

            if (getmLessonInfo().getStudentReactionStatus() == 1){
                mEvaluate.setText("查看评价");
                mEvaluate.setTextColor(Color.parseColor("#000000"));
                mEvaluate.setSelected(true);
            }
        }

        mPlayback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getmLessonInfo().getStatus() == 2){
                    ////////////////////
                }
            }
        });
        mFeedBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getmLessonInfo().getStatus() == 2){
                    ///////////////////////////////
                    if(getmLessonInfo().getTeacherReactionStatus() == 1){
                        Bundle bundle = new Bundle();
                        bundle.putString("cid",getmLessonInfo().getCid());
                        bundle.putString("lid",getmLessonInfo().getLid());
                        NavigateUtil.navigateToNormalActivity(getActivity(), new TeacherReactionDetailFragment(),bundle);
                    }

                }else {

                }

            }
        });
        mEvaluate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getmLessonInfo().getStatus() == 2){
                    ///////////////////
                    Bundle bundle = new Bundle();
                    bundle.putString("lid",getmLessonInfo().getLid());
                    bundle.putString("cid",getmLessonInfo().getCid());
                    if (getmLessonInfo().getStudentReactionStatus() == 1){
                        NavigateUtil.navigateToNormalActivity(getActivity(), new EvaluateAlreadyDetailsFragment(), bundle);
                    }

                }else {

                }

            }
        });
        mHomework.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getmLessonInfo().getStatus() == 2){
                    ///////////////////////////////////
                    if (getmLessonInfo().getHomeworkStatus() == 1){
                        Bundle bundle = new Bundle();
                        bundle.putString("cid",getmLessonInfo().getCid());
                        bundle.putString("lid",getmLessonInfo().getLid());
                        NavigateUtil.navigateToNormalActivity(getActivity(), new PendingFragment(),bundle);
                    }
                }

            }
        });
        super.afterCallbackSuccess();
    }

    @Override
    protected void performRequest() {
        ((LScheduleLessonListRequest) mDefaultRequest).perform(cid,lid);
    }

    @Override
    protected boolean isNeedFetch() {
        return true;
    }
}
