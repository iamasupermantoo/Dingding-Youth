package com.ddlad.student.protocol.http.request;

import android.util.Log;


import com.ddlad.student.protocol.convert.DataCenter;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.model.PayParamsInfo;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-10-24.
 */
public class PayParamsRequest extends AbstractRequest<PayParamsInfo> {


    public PayParamsRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<PayParamsInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_PAY_PARAMS;
    }

    @Override
    public PayParamsInfo processInBackground(ApiResponse<PayParamsInfo> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, PayParamsInfo.class);
    }

    public void perform(String product, int type, int channel) {
        RequestParams params = getParams();
        Log.i("pppppp:", "ppppppppppppppppppppppp="+ DataCenter.getAccount().getZ());
        Log.i("pppppp:", "oid============================="+ product);
        params.put("oid", product);
        params.put("type", type);
        params.put("channel", channel);
        super.perform();
    }

}
