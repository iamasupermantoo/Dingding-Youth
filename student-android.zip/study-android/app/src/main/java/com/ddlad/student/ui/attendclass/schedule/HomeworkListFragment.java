package com.ddlad.student.ui.attendclass.schedule;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.request.BaseListRequest;
import com.ddlad.student.protocol.http.request.HomeworkRequest;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.HomeworkInfo;
import com.ddlad.student.ui.common.AbstractAdapter;

/**
 * Created by Administrator on 2017/2/4 0004.
 */

public class HomeworkListFragment extends BaseListFragment<HomeworkInfo> {



    private TextView mNumber;
    private ViewGroup head_layout;
    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_homework_list;
    }

    @Override
    protected int getHeaderResource() {
        return R.layout.homework_header;
    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle(R.string.homework_list);
    }

    @Override
    protected void onInitHeader(View header) {
        mNumber = (TextView) header.findViewById(R.id.homework_header_number);
        head_layout = (ViewGroup) header.findViewById(R.id.head_layout);
    }

    @Override
    protected AbstractAdapter getAdapter() {

        if (mAdapter == null){
            mAdapter = new HomeworkAdapter(this);
        }
        return mAdapter;
    }


    @Override
    protected void afterCallbackSuccess() {
        mNumber.setText(getWaitCommit()+"");
    }

    @Override
    protected BaseListRequest makeRequest(AbstractStreamingCallbacks<AbstractListResponse<HomeworkInfo>> streamingApiCallbacks) {
        return new HomeworkRequest(this,mDefaultLoaderId,streamingApiCallbacks);
    }

    @Override
    protected void performRequest() {
        ((HomeworkRequest)mDefaultRequest).perform(getNextCursorId());
    }

    @Override
    protected boolean isNeedFetch() {
        return true;
    }


    public TextView getmNumber() {
        return mNumber;
    }

    public void setmNumber(TextView mNumber) {
        this.mNumber = mNumber;
    }

    @Override
    protected void showEmptyView() {

        if (mEmptyView == null) {
            mEmptyView = (ViewGroup) LayoutInflater.from(getActivity()).inflate(R.layout.layout_empty_footer, null);
            TextView textView = (TextView) mEmptyView.findViewById(R.id.empty_text);
            textView.setText("您还没有作业");
            mListView.addFooterView(mEmptyView, null, false);
        }

        if (mAdapter == null || mAdapter.isEmpty()) {
            head_layout.setVisibility(View.GONE);
            mEmptyView.setVisibility(View.VISIBLE);
        } else {
            head_layout.setVisibility(View.VISIBLE);
            hideEmptyView();
        }

    }
//
//    @Override
//    protected void hideEmptyView() {
//        if (mEmptyView != null) {
//            mListView.removeFooterView(mEmptyView);
//        }
//        mEmptyView = null;
//    }

}
