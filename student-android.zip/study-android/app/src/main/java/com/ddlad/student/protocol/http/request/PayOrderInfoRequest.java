package com.ddlad.student.protocol.http.request;



import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.model.PayOrderInfo;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-11-15.
 */
public class PayOrderInfoRequest extends AbstractRequest<PayOrderInfo> {

    public PayOrderInfoRequest(BaseFragment fragment, int loaderId,
                               AbstractCallbacks<PayOrderInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url,
                                          RequestParams requestParams) {
        return httpClient.getRequest(url, requestParams);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_ORDER_INFO;
    }

    @Override
    public PayOrderInfo processInBackground(ApiResponse<PayOrderInfo> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, PayOrderInfo.class);
    }

    public void perform(String product, String type) {
        RequestParams params = getParams();
        params.put("product",product);
        params.put("type",type);
        super.perform();
    }
}