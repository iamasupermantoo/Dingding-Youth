package com.ddlad.student.protocol.model;

/**
 * Created by Administrator on 2016/12/20 0020.
 */

public class ChatInfo extends BaseInfo{

    public int _id;
    public String id;
    public String session;
    public String content;
    public String pattern;
    public String message;
    public String chatTime;
    public int type;
    public int isSender;

    public  ChatInfo(){

    }

    public ChatInfo(String id, String session, String content,String pattern,String message,String chatTime , int type , int isSender) {
        this.id = id;
        this.session = session;
        this.content = content;
        this.pattern = pattern;
        this.message = message;
        this.chatTime = chatTime;
        this.type = type;
        this.isSender = isSender;
    }
}
