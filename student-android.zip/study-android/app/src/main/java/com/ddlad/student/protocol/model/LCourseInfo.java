package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.ui.model.MultiImageInfo;

import java.io.IOException;

/**
 * Created by chenjianing on 2017/5/8 0008.
 */
public class LCourseInfo extends BaseInfo {
                private String course;
                private String hid;

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getLid() {
        return lid;
    }

    public void setLid(String lid) {
        this.lid = lid;
    }

    private String cid;
                private String lid;
                /**
                 * width : 200
                 * height : 200
                 * pattern : http://img.z.ziduan.com/FCNC-zHElhA9RzEFBVF2BQ.png@{w}w_{h}h_75q
                 * id : FCNC-zHElhA9RzEFBVF2BQ
                 */

                private MultiImageInfo courseImage;

    public MultiImageInfo getImage() {
        return image;
    }

    public void setImage(MultiImageInfo image) {
        this.image = image;
    }

    private MultiImageInfo image;
                private String time;
                private String date;
                private int status;
                private String student;
                private int cnt;
                private String teacher;
                private String title;

                public String getCourse() {
                    return course;
                }

                public void setCourse(String course) {
                    this.course = course;
                }

                public String getHid() {
                    return hid;
                }

                public void setHid(String hid) {
                    this.hid = hid;
                }

                public MultiImageInfo getCourseImage() {
                    return courseImage;
                }

                public void setCourseImage(MultiImageInfo courseImage) {
                    this.courseImage = courseImage;
                }

                public String getTime() {
                    return time;
                }

                public void setTime(String time) {
                    this.time = time;
                }

                public String getDate() {
                    return date;
                }

                public void setDate(String date) {
                    this.date = date;
                }

                public int getStatus() {
                    return status;
                }

                public void setStatus(int status) {
                    this.status = status;
                }

                public String getStudent() {
                    return student;
                }

                public void setStudent(String student) {
                    this.student = student;
                }

                public int getCnt() {
                    return cnt;
                }

                public void setCnt(int cnt) {
                    this.cnt = cnt;
                }

                public String getTeacher() {
                    return teacher;
                }

                public void setTeacher(String teacher) {
                    this.teacher = teacher;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

    public static LCourseInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        LCourseInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new LCourseInfo();
                }

                if ("date".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.date = jsonParser.getText();
                    continue;
                }
                if ("course".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.course = jsonParser.getText();
                    continue;
                }

                if ("courseImage".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.courseImage = MultiImageInfo.fromJsonParser(jsonParser);
                    continue;
                }
                if ("image".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.image = MultiImageInfo.fromJsonParser(jsonParser);
                    continue;
                }
                if ("hid".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.hid = jsonParser.getText();
                    continue;
                }
                if ("lid".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.lid = jsonParser.getText();
                    continue;
                }
                if ("cid".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.cid = jsonParser.getText();
                    continue;
                }
                if ("time".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.time = jsonParser.getText();
                    continue;
                }
                if ("ddlad".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.student = jsonParser.getText();
                    continue;
                }
                if ("status".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.status = jsonParser.getIntValue();
                    continue;
                }
                if ("cnt".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.cnt = jsonParser.getIntValue();
                    continue;
                }
                if ("teacher".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.teacher = jsonParser.getText();
                    continue;
                }
                if ("title".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.title = jsonParser.getText();
                    continue;
                }

            }
        }
        return info;
    }
}
