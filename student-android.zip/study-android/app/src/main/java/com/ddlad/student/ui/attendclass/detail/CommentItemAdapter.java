package com.ddlad.student.ui.attendclass.detail;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.ddlad.student.protocol.model.CommentInfo;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.image.CircleImageView;
import com.ddlad.student.R;
import com.ddlad.student.ui.common.AbstractAdapter;

/**
 * Created by Administrator on 2017/1/17 0017.
 */

public class CommentItemAdapter {

    public static View createView(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_lesson_layout, null);
        CommentHolder holder = new CommentHolder();
        holder.mAvatar = (CircleImageView) view.findViewById(R.id.comment_item_avatar);
        holder.mName = (TextView) view.findViewById(R.id.comment_item_name);
        holder.mTime = (TextView) view.findViewById(R.id.comment_item_time);
        holder.mFeedback = (TextView) view.findViewById(R.id.comment_item_feedback);
        holder.mStar1 = (ImageView) view.findViewById(R.id.comment_item_star1);
        holder.mStar2 = (ImageView) view.findViewById(R.id.comment_item_star2);
        holder.mStar3 = (ImageView) view.findViewById(R.id.comment_item_star3);
        holder.mStar4 = (ImageView) view.findViewById(R.id.comment_item_star4);
        holder.mStar5 = (ImageView) view.findViewById(R.id.comment_item_star5);

        view.setTag(holder);
        return view;
    }
    public static void bindView(View view, final CommentInfo commentInfo, final BaseFragment fragment, final AbstractAdapter adapter){
        if (commentInfo == null){
            return;
        }
        CommentHolder holder = (CommentHolder) view.getTag();
        if (holder == null){
            return;
        }

    }
    public static class CommentHolder{
        private CircleImageView mAvatar;
        private TextView mName;
        private TextView mTime;
        private TextView mFeedback;
        private ImageView mStar1;
        private ImageView mStar2;
        private ImageView mStar3;
        private ImageView mStar4;
        private ImageView mStar5;
    }
}
