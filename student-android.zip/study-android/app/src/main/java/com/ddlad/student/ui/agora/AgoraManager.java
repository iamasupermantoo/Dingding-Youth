package com.ddlad.student.ui.agora;

import android.content.Context;
import android.os.Environment;
import android.util.SparseArray;
import android.view.SurfaceView;

import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import io.agora.AgoraAPI;
import io.agora.AgoraAPIOnlySignal;
import io.agora.rtc.Constants;
import io.agora.rtc.IRtcEngineEventHandler;
import io.agora.rtc.RtcEngine;
import io.agora.rtc.video.VideoCanvas;


public class AgoraManager {

    private static final String TAG = "AgoraManager";

    public static AgoraManager sAgoraManager;

    private RtcEngine mRtcEngine;

    private AgoraAPIOnlySignal m_agoraAPI;;

    private OnPartyListener mOnPartyListener;
    private OnSignalListener mOnSignalListener;

    private int mLocalUid = 0;
    private String mChannelKey = null;
    private String mChannelName = null;

    private AgoraManager() {
        mSurfaceViews = new SparseArray<SurfaceView>();
    }

    private SparseArray<SurfaceView> mSurfaceViews;

    public static AgoraManager getInstance() {
        if (sAgoraManager == null) {
            synchronized (AgoraManager.class) {
                if (sAgoraManager == null) {
                    sAgoraManager = new AgoraManager();
                }
            }
        }
        return sAgoraManager;
    }

    private IRtcEngineEventHandler mRtcEventHandler = new IRtcEngineEventHandler() {

        @Override
        public void onError(int err) {
            Log.i("AgoraManager","--------------------------------------onerror--------"+err+"---------------------------------------");
            super.onError(err);
        }

        /**
         * 当获取用户uid的远程视频的回调
         */
        @Override
        public void onFirstRemoteVideoDecoded(int uid, int width, int height, int elapsed) {
            Log.e("print","123456");
            if (mOnPartyListener != null) {
                mOnPartyListener.onGetRemoteVideo(uid);
            }
        }

        @Override
        public void onRejoinChannelSuccess(String channel, int uid, int elapsed) {
            super.onRejoinChannelSuccess(channel, uid, elapsed);
            Log.i("AgoraManager","--------------------------------------onjoin------------------------------------------------");
        }

        /**
         * 加入频道成功的回调
         */
        @Override
        public void onJoinChannelSuccess(String channel, int uid, int elapsed) {
            Log.i("AgoraManager","--------------------------------------onjoin------------------------------------------------");
            if (mOnPartyListener != null) {
                mOnPartyListener.onJoinChannelSuccess(channel, uid);
            }
        }

        /**
         * 退出频道
         */
        @Override
        public void onLeaveChannel(RtcStats stats) {
            if (mOnPartyListener != null) {
                mOnPartyListener.onLeaveChannelSuccess();
            }
        }

        /**
         * 用户uid离线时的回调
         */
        @Override
        public void onUserOffline(int uid, int reason) {
            if (mOnPartyListener != null) {
                mOnPartyListener.onUserOffline(uid);
            }
        }

        @Override
        public void onFirstRemoteVideoFrame(int uid, int width, int height, int elapsed) {
            if (mOnPartyListener != null) {
                mOnPartyListener.onFirstRemoteVideoFrame(uid);
            }
        }
    };

    /**
     * 初始化RtcEngine
     */
    public void init(Context context) {
//        m_agoraAPI = AgoraAPIOnlySignal.getInstance(context, AppContext.getString(R.string.private_app_id));
        int result = -1;
        //创建RtcEngine对象，mRtcEventHandler为RtcEngine的回调
        mRtcEngine = RtcEngine.create(context, context.getString(R.string.private_app_id), mRtcEventHandler);
        //设置为直播模式
        result=mRtcEngine.setChannelProfile(Constants.CHANNEL_PROFILE_LIVE_BROADCASTING);
        //开启视频功能
        result=mRtcEngine.enableVideo();
        //视频配置，设置为360P
        result=mRtcEngine.setVideoProfile(Constants.VIDEO_PROFILE_720P, false);
//        result=mRtcEngine.setVideoProfile(Constants.VIDEO_PROFILE_180P_4, false);
        result=mRtcEngine.setClientRole(Constants.CLIENT_ROLE_AUDIENCE, "");
        result=mRtcEngine.setHighQualityAudioParameters(false,false,false);
        result=mRtcEngine. setVideoQualityParameters(false);

        File file = new File(Environment.getExternalStorageDirectory().getPath()
                + "/agora-rtc.log");
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        result=mRtcEngine.setLogFile(Environment.getExternalStorageDirectory().getPath()
                + "/agora-rtc.log");
        result=mRtcEngine.enableDualStreamMode(true);

    }

    public AgoraManager setRemoteRenderMode(int uid){
        mRtcEngine.setRemoteRenderMode(uid,Constants.RENDER_MODE_HIDDEN);
        return this;
    }

    /**
     * 设置本地视频，即前置摄像头预览
     */
    public AgoraManager setupLocalVideo(Context context) {
        //创建一个SurfaceView用作视频预览
        SurfaceView surfaceView = RtcEngine.CreateRendererView(context);
        //将SurfaceView保存起来在SparseArray中，后续会将其加入界面。key为视频的用户id，这里是本地视频, 默认id是0
        mSurfaceViews.put(mLocalUid, surfaceView);
        //设置本地视频，渲染模式选择VideoCanvas.RENDER_MODE_HIDDEN，如果选其他模式会出现视频不会填充满整个SurfaceView的情况，
        //具体渲染模式参考官方文档https://docs.agora.io/cn/user_guide/API/android_api.html#set-local-video-view-setuplocalvideo
        mRtcEngine.setupLocalVideo(new VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_HIDDEN, mLocalUid));
        mRtcEngine. enableDualStreamMode(true);
        return this;//返回AgoraManager以作链式调用
    }

//    SurfaceView teacherView,SurfaceView studentView,
    public AgoraManager setupLocalVideo(Context context,int teacherUid,int studentUid,int uid,String channelKey) {
        //创建一个SurfaceView用作视频预览
//        SurfaceView teacherView = RtcEngine.CreateRendererView(context);
//        SurfaceView studentView = RtcEngine.CreateRendererView(context);
//        mSurfaceViews.put(teacherUid, teacherView);
//        mSurfaceViews.put(studentUid, studentView);
        //将SurfaceView保存起来在SparseArray中，后续会将其加入界面。key为视频的用户id，这里是本地视频, 默认id是0
        mChannelKey = channelKey;
        mLocalUid = uid;
//        mLocalUid = studentUid;
//        mSurfaceViews.put(teacherUid, teacherView);
//        mSurfaceViews.put(studentUid, studentView);
        //设置本地视频，渲染模式选择VideoCanvas.RENDER_MODE_HIDDEN，如果选其他模式会出现视频不会填充满整个SurfaceView的情况，
        //具体渲染模式参考官方文档https://docs.agora.io/cn/user_guide/API/android_api.html#set-local-video-view-setuplocalvideo
//        mRtcEngine.setupLocalVideo(new VideoCanvas(teacherView, VideoCanvas.RENDER_MODE_HIDDEN, teacherUid));
//        mRtcEngine.setupLocalVideo(new VideoCanvas(studentView, VideoCanvas.RENDER_MODE_HIDDEN, studentUid));
//        mRtcEngine. enableDualStreamMode(true);
        return this;//返回AgoraManager以作链式调用
    }

    public AgoraManager setupRemoteVideo(Context context, int uid) {
        mRtcEngine.setRemoteVideoStreamType(uid,1);
        SurfaceView surfaceView = RtcEngine.CreateRendererView(context);
        mSurfaceViews.put(uid, surfaceView);
        mRtcEngine.setupRemoteVideo(new VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_HIDDEN, uid));
        return this;
    }

    public AgoraManager joinChannel(String channel) {
        int result = mRtcEngine.joinChannel(mChannelKey, channel, "",mLocalUid);
        return this;
    }
    public AgoraManager joinChannel(String channel,int uid) {
        int result = mRtcEngine.joinChannel(mChannelKey, channel, "",uid);
        return this;
    }
    public AgoraManager joinChannel(String channel,String channelKey) {
        int result = mRtcEngine.joinChannel(channelKey, channel, "",mLocalUid);
        return this;
    }

    public void startPreview() {
        int result = mRtcEngine.startPreview();
    }

    public void stopPreview() {
        mRtcEngine.stopPreview();
    }

    public void leaveChannel() {
        mRtcEngine.leaveChannel();
        mRtcEngine.stopPreview();
    }

    public void channelLeave(String channelName){
        m_agoraAPI.channelLeave(channelName);
    }
    public void channelLogin(String account,String key){
        m_agoraAPI.login(AppContext.getString(R.string.private_app_id),account , key, 0, "");
    }
    public void setCallBack() {
        m_agoraAPI.callbackSet(new AgoraAPI.CallBack() {
            @Override
            public void onLoginSuccess(int uid, int fd) {
                Log.i("sdk2", "login successfully");
                m_agoraAPI.channelJoin(mChannelName);
            }

            @Override
            public void onLoginFailed(int ecode) {
                Log.i("sdk2", "Login failed " + ecode);
            }

            @Override
            public void onLogout(int ecode) {
                if (ecode == m_agoraAPI.ECODE_LOGOUT_E_USER) {
                    Log.i("sdk2","Logout successfully ");
                } else {
                    Log.i("sdk2","Logout on " + ecode);
                }
            }

            @Override
            public void onLog(String txt) {
                Log.e("sdk2", txt);
            }

            @Override
            public void onChannelJoined(String chanID) {
                Log.i("sdk2","Join channel " + chanID + " successfully"); // + " docall " + doCall);
            }

            @Override
            public void onInviteReceived(String channleID, String account, int uid, String extra) {
                Log.i("sdk2","Received Invitation from " + account + ":" + uid + " to join " + channleID + " extra:"+extra);
                m_agoraAPI.channelInviteAccept(channleID, account, uid);
            }

            @Override
            public void onChannelUserJoined(String account, int uid) {
                Log.i("sdk2",account + ":" + (long) (uid & 0xffffffffl) + " joined");
            }

            @Override
            public void onChannelJoinFailed(String chanID, int ecode) {
                Log.i("sdk2","Join " + chanID + " failed : ecode " + ecode);
            }

            @Override
            public void onChannelUserLeaved(String account, int uid) {
                Log.i("sdk2",account + ":" + (long) (uid & 0xffffffffl) + " leaved");
            }

            @Override
            public void onChannelUserList(String[] accounts, int[] uids) {
                Log.i("sdk2","Channel user list:");
                for (int i = 0; i < accounts.length; i++) {
                    long uid = uids[i] & 0xffffffffl;
                    Log.i("sdk2",accounts[i] + ":" + (long) (uid & 0xffffffffl));
                }
            }

            @Override
            public void onInviteMsg(String channelID, String account, int uid, String msgType, String msgData, String extra) {
                Log.i("sdk2","Received msg from " + account + ":" + (long) (uid & 0xffffffffl) + " : " + msgType + " : " + msgData);
            }

            @Override
            public void onInviteReceivedByPeer(String channleID, String account, int uid) {
                Log.i("sdk2","Invitation received by " + account + ":" + (long) (uid & 0xffffffffl));
            }

            @Override
            public void onInviteEndByPeer(String channelID, String account, int uid, String extra) {
                Log.i("sdk2","Invitation end by " + account + ":" + (long) (uid & 0xffffffffl));
            }

            @Override
            public void onInviteEndByMyself(String channelID, String account, int uid) {
                Log.i("sdk2","Invitation end bymyself " + account + ":" + (long) (uid & 0xffffffffl));
            }

            @Override
            public void onInviteAcceptedByPeer(String channleID, String account, int uid, String extra) {
                Log.i("sdk2","Invitation accepted by " + account + ":" + (long) (uid & 0xffffffffl));
            }


            @Override
            public void onMessageChannelReceive(String channelID, String account, int uid, String msg) {
                Log.i("sdk2","recv channel msg " + channelID + " " + account + " : " + msg);
            }

            @Override
            public void onMessageInstantReceive(String account, int uid, String msg) {
                Log.i("sdk2","recv inst msg " + account + " : " + (long) (uid & 0xffffffffl) + " : " + msg);
            }

        });
    }

    public interface OnSignalListener {
        void onJoinChannelSuccess(String channel, int uid);

        void onGetRemoteVideo(int uid);

        void onLeaveChannelSuccess();

        void onUserOffline(int uid);
    }

    public AgoraManager setOnSignalListener(OnSignalListener listener) {
        mOnSignalListener = listener;
        return this;
    }


    public void removeSurfaceView(int uid) {
        mSurfaceViews.remove(uid);
    }

    public interface OnPartyListener {
        void onJoinChannelSuccess(String channel, int uid);

        void onGetRemoteVideo(int uid);

        void onLeaveChannelSuccess();

        void onUserOffline(int uid);

        void onFirstRemoteVideoFrame(int uid);
    }

    public AgoraManager setOnPartyListener(OnPartyListener listener) {
        mOnPartyListener = listener;
        return this;
    }

    public List<SurfaceView> getSurfaceViews() {
        List<SurfaceView> list = new ArrayList<SurfaceView>();
        for (int i = 0; i < mSurfaceViews.size(); i++) {
            SurfaceView surfaceView = mSurfaceViews.valueAt(i);
            list.add(surfaceView);
        }
        return list;
    }

    public SurfaceView getLocalSurfaceView() {
        return mSurfaceViews.get(mLocalUid);
    }

    public SurfaceView getSurfaceView(int uid) {
        return mSurfaceViews.get(uid);
    }
}