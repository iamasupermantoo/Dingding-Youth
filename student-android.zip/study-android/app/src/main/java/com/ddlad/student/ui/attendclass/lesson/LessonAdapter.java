package com.ddlad.student.ui.attendclass.lesson;

import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.protocol.model.LessonInfo;
import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.common.BaseFragment;

import java.util.List;

/**
 * Created by Administrator on 2017/1/17 0017.
 */

public class LessonAdapter extends AbstractAdapter<LessonInfo> {

    private boolean allowShare;
    public LessonAdapter(BaseFragment fragment) {
        super(fragment);
    }
    public LessonAdapter(BaseFragment fragment,boolean allowShare) {
        super(fragment);
        this.allowShare = allowShare;
    }
    @Override
    public LessonInfo getItem(int position) {
        return mList.get(position);
    }

    @Override
    protected View createView(int position, ViewGroup parent) {
        return LessonItemAdapter.createView(parent);
    }

    @Override
    protected void bindView(int position, View view) {
        LessonItemAdapter.bindView(view,getItem(position),mFragment,this,allowShare);
    }

    @Override
    public void clearItem() {
        mList.clear();
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public void addItem(LessonInfo lessonInfo) {
        mList.add(lessonInfo);
    }

    @Override
    public void addItem(List<LessonInfo> list) {
        if (!CollectionUtil.isEmpty(list)){
            mList.addAll(list);
        }
    }

    public void setAllowShare(boolean allowShare){
        this.allowShare = allowShare;
    }
}
