package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ddlad.student.ui.model.MultiImageInfo;

import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2016/12/20 0020.
 */

public class EvaluateListInfo extends BaseInfo{

        private ReactionsBean reactions;

        public ReactionsBean getReactions() {
            return reactions;
        }

        public void setReactions(ReactionsBean reactions) {
            this.reactions = reactions;
        }

        public static class ReactionsBean {
            private boolean hasNext;
            /**
             * course : Java super课
             * date : 2017-02-14
             * lid : OdkpIt-JBJ89RzEFBVF2BQ
             * time : 08:30 - 09:30
             * image : {"pattern":"http://img.z.ziduan.com/FCNC-zHElhA9RzEFBVF2BQ.png@{w}w_{h}h_75q","width":200,"height":200,"id":"FCNC-zHElhA9RzEFBVF2BQ"}
             * teacher : wangsch
             * cid : sh27hheflsE9RzEFBVF2BQ
             * cnt : 13
             */

            private List<ListBean> list;

            public boolean isHasNext() {
                return hasNext;
            }

            public void setHasNext(boolean hasNext) {
                this.hasNext = hasNext;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String course;
                private String date;
                private String lid;
                private String time;
                /**
                 * pattern : http://img.z.ziduan.com/FCNC-zHElhA9RzEFBVF2BQ.png@{w}w_{h}h_75q
                 * width : 200
                 * height : 200
                 * id : FCNC-zHElhA9RzEFBVF2BQ
                 */

                private MultiImageInfo image;
                private String teacher;
                private String cid;
                private int cnt;

                public String getCourse() {
                    return course;
                }

                public void setCourse(String course) {
                    this.course = course;
                }

                public String getDate() {
                    return date;
                }

                public void setDate(String date) {
                    this.date = date;
                }

                public String getLid() {
                    return lid;
                }

                public void setLid(String lid) {
                    this.lid = lid;
                }

                public String getTime() {
                    return time;
                }

                public void setTime(String time) {
                    this.time = time;
                }

                public MultiImageInfo getImage() {
                    return image;
                }

                public void setImage(MultiImageInfo image) {
                    this.image = image;
                }

                public String getTeacher() {
                    return teacher;
                }

                public void setTeacher(String teacher) {
                    this.teacher = teacher;
                }

                public String getCid() {
                    return cid;
                }

                public void setCid(String cid) {
                    this.cid = cid;
                }

                public int getCnt() {
                    return cnt;
                }

                public void setCnt(int cnt) {
                    this.cnt = cnt;
                }


                public static ListBean fromJsonParser(JsonParser jsonParser) throws IOException {

                    ListBean info = null;

                    if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

                        while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                            String fieldName = jsonParser.getCurrentName();

                            if (fieldName == null) {
                                continue;
                            }

                            if (info == null) {
                                info = new ListBean();
                            }

                            if ("cid".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.cid = jsonParser.getText();
                                continue;
                            }
                            if ("course".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.course = jsonParser.getText();
                                continue;
                            }
                            if ("cnt".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.cnt = jsonParser.getIntValue();
                                continue;
                            }
                            if ("teacher".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.teacher = jsonParser.getText();
                                continue;
                            }
                            if ("date".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.date = jsonParser.getText();
                                continue;
                            }
                            if ("lid".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.lid = jsonParser.getText();
                                continue;
                            }
                            if ("time".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.time = jsonParser.getText();
                                continue;
                            }
                            if ("image".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.image = MultiImageInfo.fromJsonParser(jsonParser);
                                continue;
                            }
                            jsonParser.skipChildren();
                        }
                    }
                    return info;
                }
            }

            public static ReactionsBean fromJsonParser(JsonParser jsonParser) throws IOException {

                ReactionsBean info = null;

                if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

                    while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                        String fieldName = jsonParser.getCurrentName();

                        if (fieldName == null) {
                            continue;
                        }

                        if (info == null) {
                            info = new ReactionsBean();
                        }

                        if ("reactions".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.hasNext = jsonParser.getBooleanValue();
                            continue;
                        }
                        if ("list".equals(fieldName)) {
                            jsonParser.nextToken();
                            ObjectMapper mapper = new ObjectMapper();
                            info.list = mapper.readValue(jsonParser, List.class);
////                            ObjectMapper
//                            JSON.parseArray(jsonParser,ListBean.class);
//                            info.list =  jsonParser.get

                            continue;
                        }
                        jsonParser.skipChildren();
                    }
                }
                return info;
            }
        }
    public static EvaluateListInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        EvaluateListInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new EvaluateListInfo();
                }

                if ("reactions".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.reactions = ReactionsBean.fromJsonParser(jsonParser);
                    continue;
                }


                jsonParser.skipChildren();
            }
        }
        return info;
    }

}

