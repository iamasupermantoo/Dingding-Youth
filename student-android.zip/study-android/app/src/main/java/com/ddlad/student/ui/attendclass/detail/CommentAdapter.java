package com.ddlad.student.ui.attendclass.detail;

import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.protocol.model.CommentInfo;
import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.common.BaseFragment;

import java.util.List;

/**
 * Created by Administrator on 2017/1/17 0017.
 */

public class CommentAdapter extends AbstractAdapter<CommentInfo> {

    public CommentAdapter(BaseFragment fragment) {
        super(fragment);
    }

    @Override
    public CommentInfo getItem(int position) {
        return mList.get(position);
    }

    @Override
    protected View createView(int position, ViewGroup parent) {
        return CommentItemAdapter.createView(parent);
    }

    @Override
    protected void bindView(int position, View view) {
        CommentItemAdapter.bindView(view,getItem(position),mFragment,this);
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public void clearItem() {
        mList.clear();
    }

    @Override
    public void addItem(CommentInfo commentInfo) {
        mList.add(commentInfo);
    }

    @Override
    public void addItem(List<CommentInfo> list) {
        if (CollectionUtil.isEmpty(list)){
            mList.addAll(list);
        }
    }
}
