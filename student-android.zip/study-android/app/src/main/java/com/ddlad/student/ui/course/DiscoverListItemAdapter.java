package com.ddlad.student.ui.course;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.protocol.model.CourseMetaListInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseFragment;


/**
 * Created by Albert
 * on 16-10-20.
 */
public class DiscoverListItemAdapter {
//    private float scale = 720.0f/ ViewUtil.getScreenWidthPixels();
//    private float imageW = ViewUtil.getScreenWidthPixels() - ViewUtil.dpToPx(40);
    private static float imageH = (ViewUtil.getScreenWidthPixels() - ViewUtil.dpToPx(40))*4/7;
//    13
    private static float bgH = imageH + ViewUtil.dpToPx(50) + ViewUtil.dpToPx(6);
    private static float itemH = imageH + ViewUtil.dpToPx(50);

    public static View createView(ViewGroup viewGroup) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.discover_item_layout,
                null);

        ViewHolder holder = new ViewHolder(view);

        view.setTag(holder);

        return view;
    }

    public static void bindView(View view, final CourseMetaListInfo mInfo, final BaseFragment fragment) {

        if (mInfo == null) {
            return;
        }

        ViewHolder holder = (ViewHolder) view.getTag();

        if (holder == null) {
            return;
        }



        RelativeLayout.LayoutParams paramsBg = (RelativeLayout.LayoutParams) holder.bg_shadow_layout.getLayoutParams();
        paramsBg.height = (int) bgH;
        holder.bg_shadow_layout.setLayoutParams(paramsBg);

        FrameLayout.LayoutParams paramsItem = (FrameLayout.LayoutParams) holder.card_item_layout.getLayoutParams();
        paramsItem.height = (int) itemH;
        holder.card_item_layout.setLayoutParams(paramsItem);

//        RelativeLayout.LayoutParams paramsImage = (RelativeLayout.LayoutParams) holder.mImage.getLayoutParams();
        LinearLayout.LayoutParams paramsImage = (LinearLayout.LayoutParams) holder.mImage.getLayoutParams();
        paramsImage.height = (int) imageH;
        holder.mImage.setLayoutParams(paramsImage);

//        holder.mImage.setUrl(mInfo.getImage().getImageMedium());
        String url =  mInfo.getImage().getPattern();
        Uri uri = Uri.parse(url.substring(url.indexOf("http"),url.indexOf("@{w}w")));
        holder.mImage.setImageURI(uri);
        holder.course_name.setText(mInfo.getName());
        holder.item_class_time.setText(mInfo.getTotalCnt()+"节课");
        holder.item_course_level.setText(mInfo.getLevel()+"");
        holder.desc.setText("简介："+mInfo.getDesc());
        holder.layout_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("cmid",mInfo.getCmId());
//                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new CourseDetailsFragment(), bundle);
//                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new NewCourseDetailsFragment(), bundle);
                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new LatestCourseDetailsFragment(), bundle);
            }
        });


    }

    private static class ViewHolder {

        public ViewGroup layout_item;
        public ViewGroup card_item_layout;
        public ViewGroup bg_shadow_layout;
        public TextView item_course_level;
        public TextView item_class_time;
        public TextView desc;
        public TextView course_name;
        public TextView join_cnt;
//        public NetworkImageView mImage;
//        public RoundImageView mImage;
        public com.facebook.drawee.view.SimpleDraweeView mImage;

        public ViewHolder(View itemView) {
//            mImage = (NetworkImageView) itemView.findViewById(R.id.item_image);
//            mImage = (RoundImageView) itemView.findViewById(R.id.item_image);
            mImage = (com.facebook.drawee.view.SimpleDraweeView) itemView.findViewById(R.id.item_image);
            item_course_level = (TextView) itemView.findViewById(R.id.item_course_level);
            item_class_time = (TextView) itemView.findViewById(R.id.item_class_time);
            desc = (TextView) itemView.findViewById(R.id.desc);
            course_name = (TextView) itemView.findViewById(R.id.course_name);

            layout_item = (ViewGroup) itemView.findViewById(R.id.layout_item);
            card_item_layout = (ViewGroup) itemView.findViewById(R.id.card_item_layout);
            bg_shadow_layout = (ViewGroup) itemView.findViewById(R.id.bg_shadow_layout);
//            join_cnt = (TextView) itemView.findViewById(R.id.join_cnt);
//            holder.join_cnt.setText(AppContext.getString(R.string.partake_num,"dd"));
        }
    }
}
