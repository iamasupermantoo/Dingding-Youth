package com.ddlad.student.primary;

import com.ddlad.student.tools.HttpUtil;
import com.ddlad.student.tools.NetworkUtil;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import ch.boye.httpclientandroidlib.HttpHost;
import ch.boye.httpclientandroidlib.HttpResponse;
import ch.boye.httpclientandroidlib.HttpVersion;
import ch.boye.httpclientandroidlib.client.HttpClient;
import ch.boye.httpclientandroidlib.client.methods.HttpGet;
import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;
import ch.boye.httpclientandroidlib.client.params.ClientPNames;
import ch.boye.httpclientandroidlib.conn.params.ConnRoutePNames;
import ch.boye.httpclientandroidlib.conn.scheme.PlainSocketFactory;
import ch.boye.httpclientandroidlib.conn.scheme.Scheme;
import ch.boye.httpclientandroidlib.conn.scheme.SchemeRegistry;
import ch.boye.httpclientandroidlib.conn.ssl.SSLSocketFactory;
import ch.boye.httpclientandroidlib.impl.client.DefaultHttpClient;
import ch.boye.httpclientandroidlib.impl.conn.tsccm.ThreadSafeClientConnManager;
import ch.boye.httpclientandroidlib.params.BasicHttpParams;
import ch.boye.httpclientandroidlib.params.CoreProtocolPNames;
import ch.boye.httpclientandroidlib.params.HttpConnectionParams;
import ch.boye.httpclientandroidlib.params.HttpProtocolParams;
import ch.boye.httpclientandroidlib.protocol.BasicHttpContext;
import ch.boye.httpclientandroidlib.protocol.HTTP;
import ch.boye.httpclientandroidlib.protocol.SyncBasicHttpContext;

public class CommonHttpClient {

    private String TAG = "CommonHttpClient";

    private static final int DEFAULT_CONNECTION_TIMEOUT = 10 * 1000;

    private static final int SOKET_TIMEOUT = 3 * 10 * 1000;

    private static CommonHttpClient mCommonHttpClient;

    private final HttpClient mHttpClient;

    private final SyncBasicHttpContext mHttpContext;

    public static CommonHttpClient getInstance() {

        if (mCommonHttpClient == null) {
            mCommonHttpClient = new CommonHttpClient();
        }

        if (mCommonHttpClient == null) {
            throw new IllegalStateException("CommonHttpClient not available");
        }

        return mCommonHttpClient;
    }

    //    public HttpClient getHttpClient() {
    //        return mHttpClient;
    //    }

    public CommonHttpClient() {
        BasicHttpParams basicHttpParams = new BasicHttpParams();
        HttpConnectionParams.setTcpNoDelay(basicHttpParams, true);
        HttpConnectionParams.setConnectionTimeout(basicHttpParams, DEFAULT_CONNECTION_TIMEOUT);
        HttpConnectionParams.setSoTimeout(basicHttpParams, SOKET_TIMEOUT);
        HttpProtocolParams.setVersion(basicHttpParams, HttpVersion.HTTP_1_1);
        HttpProtocolParams.setContentCharset(basicHttpParams, HTTP.UTF_8);

        SchemeRegistry registry = new SchemeRegistry();
        registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
        try {
            KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
            trustStore.load(null, null);
            SSLSocketFactory sf = new MySSLSocketFactory(trustStore);
            sf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            registry.register(new Scheme("https", sf, 443));

        } catch (Exception e) {
            e.printStackTrace();
        }

        ThreadSafeClientConnManager threadSafeClientConnManager = new ThreadSafeClientConnManager(
                registry);
        threadSafeClientConnManager.setDefaultMaxPerRoute(20);

        basicHttpParams.setParameter(ClientPNames.HANDLE_REDIRECTS, true); // 允许跳转

        HttpClient client = new DefaultHttpClient(threadSafeClientConnManager, basicHttpParams);

        mHttpClient = client;
        mHttpContext = new SyncBasicHttpContext(new BasicHttpContext());

        initProxySetting();
    }

    public HttpResponse sendRequest(HttpUriRequest httpUriRequest) {

        if (Log.DEBUG) {
            Log.d(TAG, "sendRequest(), httpUriRequest.getURI()=" + httpUriRequest.getURI());
        }

        if (NetworkUtil.hasConnection()) {
            try {
                return mHttpClient.execute(httpUriRequest, mHttpContext);
            } catch (javax.net.ssl.SSLPeerUnverifiedException SSLPeerUnverifiedException) {
                Log.d(TAG, "https 请求失败了");
            } catch (Exception e) {
                httpUriRequest.abort();
                Log.e(TAG, "Send request failed", e);
                return null;
            }
        }

        return null;
    }

    public void initProxySetting() {
        // 代理支持
        int netType = NetworkUtil.getAccessPointType(AppContext.getContext());
        if (netType == NetworkUtil.APN_PROXY) {
            try {
                HttpHost proxy = new HttpHost(NetworkUtil.getHostIp(), NetworkUtil.getHostPort());
                mHttpClient.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                mHttpClient.getParams().removeParameter(ConnRoutePNames.DEFAULT_PROXY);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // 测试抓包
        HttpUtil.captureRequest(mHttpClient);
    }

    public class MySSLSocketFactory extends SSLSocketFactory {

        SSLContext sslContext = SSLContext.getInstance("TLS");

        public MySSLSocketFactory(KeyStore truststore) throws NoSuchAlgorithmException,
                KeyManagementException, KeyStoreException, UnrecoverableKeyException {
            super(truststore);

            TrustManager tm = new X509TrustManager() {

                @Override
                public void checkClientTrusted(X509Certificate[] chain, String authType)
                        throws CertificateException {
                }

                @Override
                public void checkServerTrusted(X509Certificate[] chain, String authType)
                        throws CertificateException {
                }

                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
            };

            sslContext.init(null, new TrustManager[]{tm}, null);
        }

        @Override
        public Socket createSocket(Socket socket, String host, int port, boolean autoClose)
                throws IOException, UnknownHostException {
            return sslContext.getSocketFactory().createSocket(socket, host, port, autoClose);
        }

        @Override
        public Socket createSocket() throws IOException {
            return sslContext.getSocketFactory().createSocket();
        }
    }

    public HttpUriRequest getRedirects(String url) {
        HttpGet get = new HttpGet(url);
        BasicHttpParams params = new BasicHttpParams();
        params.setParameter(ClientPNames.HANDLE_REDIRECTS, Boolean.TRUE);
        params.setParameter(CoreProtocolPNames.HTTP_CONTENT_CHARSET, "UTF-8"); // 默认为ISO-8859-1
        params.setParameter(CoreProtocolPNames.HTTP_ELEMENT_CHARSET, "UTF-8"); // 默认为US-ASCII
        params.setIntParameter(ClientPNames.MAX_REDIRECTS, 100);
        get.setParams(params);
        return get;
    }
}
