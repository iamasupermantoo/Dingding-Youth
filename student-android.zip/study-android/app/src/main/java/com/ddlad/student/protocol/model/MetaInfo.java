package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.IOException;

/**
 * Created by chenjianing on 2017/3/25 0025.
 */
public class MetaInfo {

    /**
     * code : 1
     * timestamp : 1490415336609
     * cost : 19
     * hostname : dorado-serv
     * desc : 成功
     */
        private int code;
        private long timestamp;
        private int cost;
        private String hostname;
        private String desc;

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public long getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(long timestamp) {
            this.timestamp = timestamp;
        }

        public int getCost() {
            return cost;
        }

        public void setCost(int cost) {
            this.cost = cost;
        }

        public String getHostname() {
            return hostname;
        }

        public void setHostname(String hostname) {
            this.hostname = hostname;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

    public static MetaInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        MetaInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new MetaInfo();
                }

                if ("code".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.code = jsonParser.getIntValue();
                    continue;
                }
                if ("code".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.code = jsonParser.getIntValue();
                    continue;
                }
                if ("timestamp".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.timestamp = jsonParser.getLongValue();
                    continue;
                }
                if ("cost".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.cost = jsonParser.getIntValue();
                    continue;
                }
                if ("hostname".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.hostname = jsonParser.getText();
                    continue;
                }
                if ("desc".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.desc = jsonParser.getText();
                    continue;
                }

                jsonParser.skipChildren();
            }
        }

        return info;
    }
}
