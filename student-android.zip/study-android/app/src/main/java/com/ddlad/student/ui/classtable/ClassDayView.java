package com.ddlad.student.ui.classtable;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ddlad.student.ui.calendar.calendarview.CalendarUtils;
import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;

import java.util.Calendar;

/**
 * Created by Albert
 * on 16-8-31.
 */
public class ClassDayView extends RelativeLayout {

    private TextView text;

    private ImageView dot;

    private Calendar date = Calendar.getInstance();

    public ClassDayView(Context context) {
        super(context);
        init(context);
    }

    public ClassDayView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ClassDayView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        LayoutInflater.from(context).inflate(R.layout.layout_class_day, this, true);
        text = (TextView) findViewById(R.id.text);
        dot = (ImageView) findViewById(R.id.dot);
    }

    public boolean isToday() {

        Calendar today = CalendarUtils.getInstance();

        boolean sameYear = date.get(Calendar.YEAR) == today.get(Calendar.YEAR);
        boolean sameMonth = date.get(Calendar.MONTH) == today.get(Calendar.MONTH);
        boolean sameDay = date.get(Calendar.DAY_OF_MONTH) == today.get(Calendar.DAY_OF_MONTH);

        return sameYear && sameMonth && sameDay;
    }

    public void set(Calendar calendar) {
        CalendarUtils.copyDateTo(calendar, date);
        text.setText(String.valueOf(calendar.get(Calendar.DAY_OF_MONTH)));
        if (isToday()) {
            text.setTextColor(AppContext.getColor(R.color.white));
            text.setBackgroundResource(R.drawable.today_circle_bg);
        } else {
            text.setTextColor(AppContext.getColorStateList(R.color.day_view_text_color));
            text.setBackgroundResource(R.drawable.day_circle_bg);
        }
    }

    public Calendar getDate() {
        return date;
    }

    @Override
    public String toString() {
        return date.get(Calendar.YEAR) + "-" + (date.get(Calendar.MONTH) + 1) + "-"
                + date.get(Calendar.DAY_OF_MONTH);
    }

    public void clear() {
        text.setText("");
        text.setBackgroundResource(R.drawable.day_circle_bg);
        dot.setVisibility(INVISIBLE);
    }

    public void dot(boolean doted) {
        dot.setVisibility(doted ? VISIBLE : INVISIBLE);
    }
}
