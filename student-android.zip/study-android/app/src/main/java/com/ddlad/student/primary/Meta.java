package com.ddlad.student.primary;

import android.content.Context;
import android.text.TextUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.tools.NumberUtil;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;


import java.io.IOException;

/**
 * Created by Albert
 * on 16-6-2.
 */
public class Meta {

    private int code;

    private String request;

    private String desc;

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    public static Meta fromJsonParser(Context context, JsonParser jsonParser)
            throws JsonParseException, IOException {
        Meta meta = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {
            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {
                String fieldName = jsonParser.getCurrentName();

                if (!TextUtils.isEmpty(fieldName) && (meta == null)) {
                    meta = new Meta();
                }
                if (ProtocolConstants.JSON_FIELD_CODE.equals(fieldName)) {
                    jsonParser.nextToken();
                    meta.code = NumberUtil.toInt(jsonParser.getText());
                    continue;
                }
                if (ProtocolConstants.JSON_FIELD_REQUEST.equals(fieldName)) {
                    jsonParser.nextToken();
                    meta.request = jsonParser.getText();
                    continue;
                }
                if (ProtocolConstants.JSON_FIELD_DESC.equals(fieldName)) {
                    jsonParser.nextToken();
                    meta.desc = jsonParser.getText();
                    continue;
                }

                jsonParser.nextToken();
            }
        }

        return meta;
    }

    @Override
    public String toString() {
        return "Meta [request=" + request + ", desc=" + desc + "]";
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public static int META_CODE_OK = 1;
}
