package com.ddlad.student.ui.attendclass.evaluate;

import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.request.BaseListRequest;
import com.ddlad.student.protocol.http.request.EvaluateListRequest;
import com.ddlad.student.protocol.http.request.LCorrectNotListRequest;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.EvaluateListInfo;
import com.ddlad.student.protocol.model.LCorrectNotInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.ui.common.AbstractAdapter;

/**
 * Created by Administrator on 2017/3/17 0017.
 */
public class EvaluateNotFragment extends BaseListFragment<LCorrectNotInfo> {

    private int mLoaderId = ViewUtil.generateUniqueId();

    private RecyclerView mEvaluateRv;
    private boolean mselect = true;

    private EvaluateListInfo mInfo;
    private String lid;
    private String cid;

    EvaluateNotAdapter adapter;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_l_evaluate;
    }

    @Override
    protected void onInitView(View contentView) {

        //上方两个标题
//        mEvaluateRv = (RecyclerView) contentView.findViewById(R.id.evaluate_rv_not);
//        mEvaluateRv.setLayoutManager(new LinearLayoutManager(getContext()));
//
//        adapter= new EvaluateNotAdapter(getActivity());
//        mEvaluateRv.setAdapter(adapter);
    }

    @Override
    public void onResume() {
        super.onResume();
//        requestData();
    }

    @Override
    protected void onInitData(Bundle bundle) {
        super.onInitData(bundle);
    }


    @Override
    protected void performRequest() {
        ///////////////////////////////////////////正式 需要改成0
        ((LCorrectNotListRequest)mDefaultRequest).perform(0,getNextCursorId());
    }

    @Override
    protected BaseListRequest makeRequest(AbstractStreamingCallbacks<AbstractListResponse<LCorrectNotInfo>> streamingApiCallbacks) {
        return new LCorrectNotListRequest(this, mLoaderId, streamingApiCallbacks);
    }

    @Override
    protected boolean isNeedFetch() {
        return true;
    }

    @Override
    protected AbstractAdapter getAdapter() {
        if (mAdapter == null) {
            mAdapter = new LEvaluateNotListAdapter(this);
        }
        return mAdapter;
    }

    private void requestData() {
        startLoading();
        EvaluateListRequest request = new EvaluateListRequest(this, getDefaultLoaderId(), new AbstractCallbacks<EvaluateListInfo>() {
            @Override
            protected void onSuccess(EvaluateListInfo evaluateListInfo) {
                if (evaluateListInfo != null){
                    mInfo = evaluateListInfo;
                    adapter.setmInfo(evaluateListInfo);
                    adapter.notifyDataSetChanged();
                    adapter.setmOnItemClickListener(new EvaluateNotAdapter.OnRecyclerViewItemClickListener() {
                        @Override
                        public void onItemClick(View view, int position) {
                            //跳到个人详情

                        }

                        @Override
                        public void onItemImageClick(View view, int position) {
                            //去评价
                            lid = mInfo.getReactions().getList().get(position).getLid();
                            cid = mInfo.getReactions().getList().get(position).getCid();
                            navigateEvaluateDetailsFragment();
                        }
                    });
                    Log.i(TAG, "onSuccess: 请求成功oooooooooooooooooooooo");
                }

                stopLoading();
            }

            @Override
            protected void onFail(ApiResponse<EvaluateListInfo> response) {

                Log.i(TAG, "onFail: 请求失败^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                stopLoading();
            }
        });
        request.perform(0);
    }



    private void navigateEvaluateDetailsFragment() {
        EvaluateDetailsFragment fragment = new EvaluateDetailsFragment();
        Bundle bundle = new Bundle();
        bundle.putString("lid",lid);
        bundle.putString("cid",cid);
        NavigateUtil.navigateToNormalActivity(getActivity(), fragment, bundle);
    }
    private void navigateCourseDetailsFragment() {
        NavigateUtil.navigateToNormalActivity(getActivity(), new EvaluateDetailsFragment(), null);
    }



    
    @Override
    protected void showEmptyView() {

        if (mEmptyView == null) {
            mEmptyView = (ViewGroup) LayoutInflater.from(getActivity()).inflate(R.layout.layout_empty_footer, null);
            TextView empty_text = (TextView) mEmptyView.findViewById(R.id.empty_text);
            empty_text.setText("没有评价信息");
            mListView.addFooterView(mEmptyView, null, false);
        }

        if (mAdapter == null || mAdapter.isEmpty()) {
            mEmptyView.setVisibility(View.VISIBLE);
        } else {
            hideEmptyView();
        }

    }

    @Override
    protected void hideEmptyView() {
        if (mEmptyView != null) {
            mListView.removeFooterView(mEmptyView);
        }
        mEmptyView = null;
    }
}
