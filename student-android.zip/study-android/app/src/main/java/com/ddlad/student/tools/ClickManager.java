package com.ddlad.student.tools;

import android.app.Activity;
import android.os.Handler;
import android.support.v4.app.FragmentManager;
import android.widget.Toast;


/**
 * Created by Albert
 * on 16-6-2.
 */
public class ClickManager {

    private static ClickManager mInstance;

    // Multi click
    private static final int MAX_COUNT = 10;
    private long mMultiClickTime;
    private int mMultiClickCounts = MAX_COUNT;
    private Toast mLastToast;

    private Activity mCurrentActivity;

    private FragmentManager mFragmentManager;

    private Handler mHandler;

    public static ClickManager getInstance() {
        if (mInstance == null) {
            mInstance = new ClickManager();
        }
        return mInstance;
    }

    public Activity getCurrentActivity() {
        return this.mCurrentActivity;
    }

    public FragmentManager getCurrentFragmentManager() {
        return this.mFragmentManager;
    }

    public Handler getHandler() {
        return this.mHandler;
    }

    public void setCurrentActivity(Activity activity) {
        this.mCurrentActivity = activity;
    }

    public void setFragmentManager(FragmentManager fragmentManager) {
        this.mFragmentManager = fragmentManager;
    }

    public void setHandler(Handler handler) {
        this.mHandler = handler;
    }

    public void multiClick(MultiClickListener listener) {
        if (mMultiClickTime == 0) {
            resetMultiClick();
        } else {
            if (System.currentTimeMillis() - mMultiClickTime < 500) {
                mMultiClickCounts--;
                if (mMultiClickCounts > 0) {
                    mMultiClickTime = System.currentTimeMillis();
                    cancelLastAndToast(mMultiClickCounts);
                } else {
                    if (listener != null) {
                        listener.onMultiClick();
                    }
                    resetMultiClick();
                }
            } else {
                resetMultiClick();
            }
        }
    }

    private void resetMultiClick() {
        mMultiClickTime = System.currentTimeMillis();
        mMultiClickCounts = MAX_COUNT;
        mLastToast = null;
    }

    private void cancelLastAndToast(int count) {
        if (mLastToast != null) {
            mLastToast.cancel();
        }
//        mLastToast = Toaster.toastShort("再按" + count + "次就可以设置学校编码");
        Toaster.toastShort("再按" + count + "次就可以切换环境");
    }

    public interface MultiClickListener {
        void onMultiClick();
    }

}
