package com.ddlad.student.primary;

import com.ddlad.student.tools.Util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by Albert
 * on 16-6-2.
 */
public class InputStreamWrapper extends InputStream {

    private static final String TAG = "InputStreamWrapper";

    private BufferedOutputStream bufferedOutputStream;

    private final File mFile;

    private final InputStream mInputStream;

    public InputStreamWrapper(InputStream inputStream, File file) throws FileNotFoundException {
        this.mInputStream = inputStream;
        this.mFile = file;
        this.bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(this.mFile),
                Util.IO_BUFFER_SIZE);
    }

    @Override
    public int available() throws IOException {
        return this.mInputStream.available();
    }

    @Override
    public void close() throws IOException {
        this.bufferedOutputStream.close();
        this.mInputStream.close();
    }

    @Override
    public void mark(int readlimit) {
        //        Log.d(TAG, "mark()");
        throw new RuntimeException("Operation not supported");
    }

    @Override
    public boolean markSupported() {
        throw new RuntimeException("Operation not supported");
    }

    @Override
    public int read() throws IOException {
        int i = this.mInputStream.read();

        //        Log.d(TAG, "read(000000), i="+i);

        this.bufferedOutputStream.write(i);
        return i;
    }

    @Override
    public int read(byte[] buffer) throws IOException {
        int i = this.mInputStream.read(buffer);
        this.bufferedOutputStream.write(buffer, 0, i);
        return i;
    }

    @Override
    public int read(byte[] buffer, int offset, int length) throws IOException {
        int i = mInputStream.read(buffer, offset, length);
        this.bufferedOutputStream.write(buffer, offset, i);
        return i;
    }

    @Override
    public void reset() throws IOException {
        //        Log.d(TAG, "reset()");
        throw new RuntimeException("Operation not supported");
    }

    @Override
    public long skip(long byteCount) throws IOException {
        //        Log.d(TAG, "skip()");
        throw new RuntimeException("Operation not supported");
    }

}
