package com.ddlad.student.ui.common;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;

import com.ddlad.student.tools.Constants;
import com.umeng.analytics.MobclickAgent;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.widget.actionbar.Actionbar;

public abstract class BaseFragment extends Fragment implements OnClickListener {

    protected String TAG = getSimpleName();

    protected int mDefaultLoaderId = ViewUtil.generateUniqueId();

    protected int mShowImageLoaderId = ViewUtil.generateUniqueId();

    protected Handler mHandler;

    protected String mSimpleName;

    protected Actionbar mActionbar;

    protected View mLoadingView;

    private boolean mIsFirstCreated;

    private boolean mIsPermissionGranted;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initHandler();
        setFirstCreated(true);
        onInitData(getArguments());

        systemConfig();
    }

    protected void initHandler() {
        mHandler = new Handler();
    }

    protected void onInitData(Bundle bundle) {
        // Override in sub-class.
    }


    protected void systemConfig() {

    }

    protected void cameraPermission() {
        if (!mIsPermissionGranted) {
            requestCameraPermission();
            requestReadPermission();
            requestWritePermission();
            mIsPermissionGranted = true;
        }
    }

    private void requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, Constants.REQUEST_CODE_CAMERA_PERMISSION);
        }
    }

    private void requestReadPermission() {
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, Constants.REQUEST_CODE_READ_PERMISSION);
        }
    }

    private void requestWritePermission() {
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, Constants.REQUEST_CODE_WRITE_PERMISSION);
        }
    }

    public int getDefaultLoaderId() {
        return mDefaultLoaderId;
    }

    protected int getLayoutResource() {
        return 0;
    }
    View view;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        View view = inflater.inflate(getLayoutResource(), container, false);
        if (view == null){
            view = inflater.inflate(getLayoutResource(), container, false);
        }
        initActivityView();
        onInitView(view);
        if (isNeedFetch()) {
            fetchData();
        }
        return view;
    }

    protected void initActivityView() {
        mActionbar = getActionbar();
        if (isHideBackBtn()) {
            mActionbar.hideBackBtn();
        }
        mActionbar.setVisibility(isHideActionbar() ? View.GONE : View.VISIBLE);
        mLoadingView = getLoadingView();
    }

    protected void onInitView(View contentView) {
        // Override in sub-class.
    }

    protected void fetchData() {
        // Override in sub-class.
    }

    @Override
    public void onResume() {
        super.onResume();

        MobclickAgent.onPageStart(TAG);
    }

    @Override
    public void onPause() {
        super.onPause();

        setFirstCreated(false);
        MobclickAgent.onPageEnd(TAG);
    }

    protected boolean isHideBackBtn() {
        return false;
    }

    protected boolean isHideActionbar() {
        return false;
    }

    protected boolean isNeedFetch() {
        return false;
    }

    public void showKeyboard() {
        ((InputMethodManager) AppContext.getContext()
                .getSystemService(Context.INPUT_METHOD_SERVICE)).toggleSoftInput(0,
                InputMethodManager.SHOW_IMPLICIT);
    }

    public void hideKeyboard() {
        if (getView() != null) {
            ((InputMethodManager) AppContext.getContext().getSystemService(
                    Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getView()
                    .getWindowToken(), 0);
        }
    }

    public void onUpdate() {

    }

    public void onRefresh() {

    }

    public void startLoading() {
        if (mLoadingView != null) {
            mLoadingView.setVisibility(View.VISIBLE);
        }
    }

    public void stopLoading() {
        if (mLoadingView != null) {
            mLoadingView.setVisibility(View.GONE);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    public boolean onBackPressed() {
        return false;
    }

    public boolean isFirstCreated() {
        return mIsFirstCreated;
    }

    public void setFirstCreated(boolean mIsFirstCreated) {
        this.mIsFirstCreated = mIsFirstCreated;
    }

    public Handler getHandle() {
        return mHandler;
    }


    public String getSimpleName() {
        if (TextUtils.isEmpty(mSimpleName)) {
            mSimpleName = getClass().getSimpleName();
        }
        return mSimpleName;
    }

    protected void updateCreateView() {

    }

    @Override
    public void onClick(View v) {

    }

    protected Actionbar getActionbar() {
        return ((BaseActivity) getActivity()).getActionbar();
    }

    protected View getLoadingView() {
        return ((BaseActivity) getActivity()).getLoadingView();
    }

}
