package com.ddlad.student.ui.attendclass.schedule;



import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.model.LHomeWorkInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.image.NetworkImageView;


public class LHomeWorkImageListItemAdapter {

    public static View createView(ViewGroup viewGroup) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.pending_item_photo_image,
                null);

        ImageViewHolder holder = new ImageViewHolder(view);

        view.setTag(holder);

        return view;
    }

    public static void bindView(View view, final LHomeWorkInfo mInfo, final BaseFragment fragment, final int position, boolean mIsModify, final LHomeWorkListAdapter.IRemoveAnswerListener listener) {

        if (mInfo == null) {
            return;
        }

        ImageViewHolder photoHolder = (ImageViewHolder) view.getTag();

        if (photoHolder == null) {
            return;
        }
        if (mIsModify){
            photoHolder.xx.setVisibility(View.VISIBLE);
            photoHolder.xx.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.removeAnswer(position,mInfo.getId(),fragment);
                }
            });
        }else {
            photoHolder.xx.setVisibility(View.GONE);
        }
        if (mInfo.getImages().size() >= 1){
            String url =  mInfo.getImages().get(0).getPattern();
//            photoHolder.mPhotoImage1.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}")));
            photoHolder.mPhotoImage1.setUrl(mInfo.getImages().get(0).getImageSmall());
            photoHolder.mPhotoImage1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    listener.enlargeImage(position,0);
                    String url =  mInfo.getImages().get(0).getPattern();
                    Bundle bundle = new Bundle();
                    bundle.putString("url",url);
                    NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new BigImageFragment(), bundle);
                }
            });

            photoHolder.mPhotoImage2.setVisibility(View.GONE);
            photoHolder.mPhotoImage3.setVisibility(View.GONE);
            photoHolder.mPhotoImage1.setVisibility(View.VISIBLE);
            photoHolder.mTime.setText(mInfo.getTime());

        }
        if (mInfo.getImages().size() >= 2){
            String url1 =  mInfo.getImages().get(1).getPattern();
//            photoHolder.mPhotoImage2.setUrl(url1.substring(url1.indexOf("http"),url1.indexOf("@{w}")));
            photoHolder.mPhotoImage1.setUrl(mInfo.getImages().get(0).getImageSmall());

            photoHolder.mPhotoImage2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.enlargeImage(position,1);
                }
            });


            photoHolder.mPhotoImage2.setVisibility(View.VISIBLE);
            photoHolder.mPhotoImage3.setVisibility(View.GONE);
            photoHolder.mTime.setText(mInfo.getTime());
        }
        if (mInfo.getImages().size() == 3){

            String url2 =  mInfo.getImages().get(2).getPattern();
//            photoHolder.mPhotoImage3.setUrl(url2.substring(url2.indexOf("http"),url2.indexOf("@{w}")));
            photoHolder.mPhotoImage1.setUrl(mInfo.getImages().get(0).getImageSmall());

            photoHolder.mPhotoImage3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.enlargeImage(position,2);
                }
            });


            photoHolder.mPhotoImage3.setVisibility(View.VISIBLE);
            photoHolder.mTime.setText(mInfo.getTime());
        }
    }


    public  interface OnRecyclerViewItemClickListener{
        void onItemClick(View view, int position);
        void onItemImageClick(View view, int position);
    }

    private static OnRecyclerViewItemClickListener mOnItemClickListener = null;

    public void setmOnItemClickListener(OnRecyclerViewItemClickListener onItemClickListener){
        mOnItemClickListener = onItemClickListener;
    }


    private static class ImageViewHolder {
        private NetworkImageView mPhotoImage1;
        private NetworkImageView mPhotoImage2;
        private NetworkImageView mPhotoImage3;
        private TextView mText;
        private TextView mTime;
        private ImageView xx;
        public ImageViewHolder(View itemView) {
            xx = (ImageView) itemView.findViewById(R.id.xx);
            mTime = (TextView) itemView.findViewById(R.id.item_time);
            mPhotoImage1 = (NetworkImageView) itemView.findViewById(R.id.pending_item_photo_image1);
            mPhotoImage2 = (NetworkImageView) itemView.findViewById(R.id.pending_item_photo_image2);
            mPhotoImage3 = (NetworkImageView) itemView.findViewById(R.id.pending_item_photo_image3);


        }
    }

}
