package com.ddlad.student.tools;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.os.Build;

import com.google.webp.libwebp;

import java.nio.ByteBuffer;

public class LibWebpUtil {

    private static boolean isUseWebp = false;

    private static final byte[] SUPPORT_FORMAT = new byte[]{'W', 'E', 'B', 'P', 'V', 'P', '8',
            ' '};

    private static boolean mUseSystemLib = true;

    static {
        mUseSystemLib = Build.VERSION.SDK_INT < 14 || Build.VERSION.SDK_INT > 16;
        isUseWebp = Build.VERSION.SDK_INT >= 14;
        if (!mUseSystemLib) {
            try {
                System.loadLibrary("webp");
            } catch (Throwable ex) {
                ex.printStackTrace();
                //如果机子小于4.0 并且加载类库失败，不开启本地webp功能
                isUseWebp = false;
                mUseSystemLib = true;
            }
        }
    }

    /**
     * 检查是否满足调用WEBP格式要求
     *
     * @return
     */
    public static boolean isCanUseWebpFormat() {
        return isUseWebp;
    }

    public static Bitmap.CompressFormat getDefaultFormat() {
        //        return Bitmap.CompressFormat.PNG;
        if (Build.VERSION.SDK_INT >= 14) {
            return Bitmap.CompressFormat.WEBP;
        } else {
            return Bitmap.CompressFormat.JPEG;
        }
    }

    public static Bitmap decoderWebpToBitmap(byte[] encoded, Options options) {
        if (encoded == null) {
            return null;
        }

        do {
            if (Build.VERSION.SDK_INT >= 14 && Build.VERSION.SDK_INT <= 16) {

                boolean isUseSystem = true;
                if (encoded.length > 16) {
                    for (int i = 0; i < 8; i++) {
                        isUseSystem &= encoded[i + 8] == SUPPORT_FORMAT[i];
                    }
                }
                if (!isUseSystem) {
                    break;
                }
            } /*else if (Build.VERSION.SDK_INT < 14) {
                break;
              }*/

            if (options != null) {
                return BitmapFactory.decodeByteArray(encoded, 0, encoded.length, options);
            } else {
                return BitmapFactory.decodeByteArray(encoded, 0, encoded.length);
            }

        } while (false);

        int[] width = new int[]{0};
        int[] height = new int[]{0};
        byte[] decoded = null;
        int[] pixels = null;
        try {
            decoded = libwebp.WebPDecodeARGB(encoded, encoded.length, width, height);
            if (decoded == null) {
                return null;
            }
            pixels = new int[decoded.length / 4];
            ByteBuffer.wrap(decoded).asIntBuffer().get(pixels);
            return Bitmap.createBitmap(pixels, width[0], height[0], Bitmap.Config.ARGB_8888);
        } catch (OutOfMemoryError ex) {
            ex.printStackTrace();
            return null;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            if (decoded != null) {
                decoded = null;
            }
            if (pixels != null) {
                pixels = null;
            }
        }

    }

}
