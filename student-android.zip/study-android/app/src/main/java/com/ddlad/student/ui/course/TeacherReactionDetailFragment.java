package com.ddlad.student.ui.course;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.request.TeacherReactionDetailsRequest;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.RattingBar.RatingBar;
import com.ddlad.student.ui.widget.image.CircleImageView;
import com.ddlad.student.R;
import com.ddlad.student.protocol.model.TeacherReactionDetailInfo;

/**
 * Created by chenjianing on 2017/5/15 0015.
 */
public class TeacherReactionDetailFragment extends BaseFragment {


    private String mCid;
    private String mLid;

    private TextView mCourseTime;

    private TextView mCourseName;
    private TextView mCourseAddress;
    private TextView mStudentName;
    private TextView mTeacherName;
    private TextView mEvaluateTeacherText;
    private RadioGroup mQualityRG;
    private RadioGroup mAcceptanceRG;
    private RatingBar mStar;
    private TextView mRemark;
    private CircleImageView mTeacherHeadImage;
    private TextView mRadio1;
    private TextView mRadio2;
    private TextView mRadio3;
    private TextView mRadio4;
    private TextView mRadioAcceptance1;
    private TextView mRadioAcceptance2;
    private TextView mRadioAcceptance3;
    private TextView mRadioAcceptance4;

    private TeacherReactionDetailInfo mInfo;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_already_reaction_details;
    }



    @Override
    protected void onInitView(View contentView) {

        mActionbar.setTitle("老师反馈");
        mCourseTime = (TextView) contentView.findViewById(R.id.evaluate_attend_class_time);
        mCourseAddress = (TextView) contentView.findViewById(R.id.evaluate_course_address);
        mCourseName = (TextView) contentView.findViewById(R.id.evaluate_course_name);
        mStudentName = (TextView) contentView.findViewById(R.id.evaluate_student_name);
        mTeacherName = (TextView) contentView.findViewById(R.id.evaluate_teacher_name);
        mEvaluateTeacherText = (TextView) contentView.findViewById(R.id.evaluate_teacher_set_text);
        mStar = (RatingBar) contentView.findViewById(R.id.evaluate_rating_bar);
        mRemark = (TextView) contentView.findViewById(R.id.evaluate_remark);
        mTeacherHeadImage = (CircleImageView) contentView.findViewById(R.id.evaluate_teacher_head_image);

        mRadio1 = (TextView) contentView.findViewById(R.id.quality_1);
        mRadio2 = (TextView) contentView.findViewById(R.id.quality_2);
        mRadio3 = (TextView) contentView.findViewById(R.id.quality_3);
        mRadio4 = (TextView) contentView.findViewById(R.id.quality_4);

        mRadioAcceptance1 = (TextView) contentView.findViewById(R.id.acceptance_1);
        mRadioAcceptance2 = (TextView) contentView.findViewById(R.id.acceptance_2);
        mRadioAcceptance3 = (TextView) contentView.findViewById(R.id.acceptance_3);
        mRadioAcceptance4 = (TextView) contentView.findViewById(R.id.acceptance_4);

    }

    @Override
    protected void onInitData(Bundle bundle) {

        mCid = bundle.getString("cid");
        mLid = bundle.getString("lid");
        requestData();

    }

    private void requestData() {
        TeacherReactionDetailsRequest reactionDetailsRequest = new TeacherReactionDetailsRequest(this, getDefaultLoaderId(), new AbstractCallbacks<TeacherReactionDetailInfo>() {
            @Override
            protected void onSuccess(TeacherReactionDetailInfo teacherReactionDetailInfo) {
                mInfo = teacherReactionDetailInfo;
                refreshData();
            }
        });
        reactionDetailsRequest.perform(mCid,mLid);
    }

    private void refreshData() {
        if (mInfo != null) {
//            mActionbar.setTitle(mInfo.getReaction().getTeacher());
            mCourseTime.setText(mInfo.getReaction().getDate() + "  " + mInfo.getReaction().getTime());
//            mCourseAddress 设置地址
            mCourseName.setText(mInfo.getReaction().getCourse());
            mStudentName.setText(mInfo.getReaction().getStudent());
            mTeacherName.setText(mInfo.getReaction().getStudent());
            //备注
            mRemark.setText(mInfo.getReaction().getRemark());
            int fen = mInfo.getReaction().getStar()*20;
            mEvaluateTeacherText.setText( mInfo.getReaction().getStudent() + "同学获得"+fen+"分");
//            String url =  mInfo.getReaction().getStudentHeadImg().getPattern();
//            mTeacherHeadImage.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}w")));
            String url =  mInfo.getReaction().getStudentHeadImg().getImageSmall();
            mTeacherHeadImage.setUrl(url);
            mStar.setStar(mInfo.getReaction().getStar());
            switch (mInfo.getReaction().getBehavior()){
                case 1:
                    mRadio4.setVisibility(View.VISIBLE);
                    break;
                case 2:
                    mRadio3.setVisibility(View.VISIBLE);
                    break;
                case 3:
                    mRadio2.setVisibility(View.VISIBLE);
                    break;
                case 4:
                    mRadio1.setVisibility(View.VISIBLE);
                    break;
            }
            switch (mInfo.getReaction().getIdea()){
                case 1:
                    mRadioAcceptance4.setVisibility(View.VISIBLE);
                    break;
                case 2:
                    mRadioAcceptance3.setVisibility(View.VISIBLE);
                    break;
                case 3:
                    mRadioAcceptance2.setVisibility(View.VISIBLE);
                    break;
                case 4:
                    mRadioAcceptance1.setVisibility(View.VISIBLE);
                    break;
            }
        }
    }

}
