package com.ddlad.student.ui.listener;

/**
 * Created by Albert
 * on 16-6-3.
 */
public interface HomeNavigateListener {

    public void onChoiceClick(int id);

    public void onAccountClick(int id);

    public void onCourseClick(int id);

    public void onAttendClassClick(int id);

}
