package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.EvaluateDetailsInfo;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Administrator on 2017/1/19 0019.
 */

public class EvaluateDetailsRequest extends AbstractRequest<EvaluateDetailsInfo> {
    public EvaluateDetailsRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<EvaluateDetailsInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.getRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_EVALUATE_DETAILS;
    }

    @Override
    public EvaluateDetailsInfo processInBackground(ApiResponse<EvaluateDetailsInfo> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, EvaluateDetailsInfo.class);
//        String str = JSON.toJSONString(response);
//        return JSON.parseObject(str,EvaluateListInfo.class);
    }

    public void perform(String cid,String lid) {
        RequestParams params = getParams();
        params.put("cid", cid);
        params.put("lid", lid);
        super.perform();
    }
}
