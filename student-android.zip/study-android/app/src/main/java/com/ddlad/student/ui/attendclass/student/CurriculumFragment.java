package com.ddlad.student.ui.attendclass.student;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.request.CurriculumRequest;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.request.BaseListRequest;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.CurriculumInfo;
import com.ddlad.student.ui.common.AbstractAdapter;

public class CurriculumFragment extends BaseListFragment<CurriculumInfo> {

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_curriculum;
    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle(R.string.home_course);
    }

    @Override
    protected AbstractAdapter getAdapter() {
        if (mAdapter == null){
            mAdapter = new CurriculumAdapter(this);
        }
        return mAdapter;
    }

    @Override
    protected BaseListRequest makeRequest(AbstractStreamingCallbacks<AbstractListResponse<CurriculumInfo>> streamingApiCallbacks) {
        return new CurriculumRequest(this,mDefaultLoaderId,streamingApiCallbacks);
    }

    @Override
    protected boolean isNeedFetch() {
        return true;
    }


    @Override
    protected void showEmptyView() {

        if (mEmptyView == null) {
            mEmptyView = (ViewGroup) LayoutInflater.from(getActivity()).inflate(R.layout.layout_empty_footer, null);
            mListView.addFooterView(mEmptyView, null, false);
        }

        if (mAdapter == null || mAdapter.isEmpty()) {
            mEmptyView.setVisibility(View.VISIBLE);
        } else {
            hideEmptyView();
        }

    }

    @Override
    protected void hideEmptyView() {
        if (mEmptyView != null) {
            mListView.removeFooterView(mEmptyView);
        }
        mEmptyView = null;
    }
}
