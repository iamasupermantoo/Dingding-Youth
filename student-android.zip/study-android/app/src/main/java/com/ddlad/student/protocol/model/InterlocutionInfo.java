package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.IOException;

/**
 * Created by Administrator on 2016/12/7 0007.
 */

public class InterlocutionInfo extends BaseInfo{
//  "title":"第一个问答，如何学好Java？",
//  "bestAnswer":"今天的话题是，怎么才能把Java学好，有什么见解和妙招欢迎来这里讨论。",
//  "answerCount":999,
//  "id":"d4QOBPsPkMYM32EYjRVwMQ"

    private String title;
    private String bestAnswer;
    private String answerCount;
    private String id;
    private String time;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBestAnswer() {
        return bestAnswer;
    }

    public void setBestAnswer(String bestAnswer) {
        this.bestAnswer = bestAnswer;
    }

    public String getAnswerCount() {
        return answerCount;
    }

    public void setAnswerCount(String answerCount) {
        this.answerCount = answerCount;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public static InterlocutionInfo fromJsonParser(JsonParser jsonParser) throws IOException {
        InterlocutionInfo info = null;
        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new InterlocutionInfo();
                }

                if ("title".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.title = jsonParser.getText();
                    continue;
                }
                if ("bestAnswer".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.bestAnswer = jsonParser.getText();
                    continue;
                }
                if ("answerCount".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.answerCount = jsonParser.getText();
                    continue;
                }
                if ("id".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.id = jsonParser.getText();
                    continue;
                }
                if ("time".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.time = jsonParser.getText();
                    continue;
                }

                jsonParser.skipChildren();

            }
        }
        return info;
    }
}
