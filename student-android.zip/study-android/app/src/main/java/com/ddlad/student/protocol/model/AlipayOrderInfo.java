package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.IOException;

/**
 * Created by boge on 2017/3/2.
 */

public class AlipayOrderInfo {
    private String orderStr;

    public String getOrderStr() {
        return orderStr;
    }

    public void setOrderStr(String orderStr) {
        this.orderStr = orderStr;
    }

    public static AlipayOrderInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        AlipayOrderInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new AlipayOrderInfo();
                }

                if ("orderStr".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.orderStr = jsonParser.getText();
                    continue;
                }

                jsonParser.skipChildren();
            }
        }

        return info;
    }
}
