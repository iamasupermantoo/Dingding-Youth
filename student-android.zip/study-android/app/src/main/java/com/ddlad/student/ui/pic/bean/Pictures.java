package com.ddlad.student.ui.pic.bean;


public class Pictures {
	private String id;
	private String url;
	private String created_at;
	private String updated_at;
	private String uri_local;
	private String uri_local_origin;
	private double width;
	private double height;
	
	private boolean local = false;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getCreated_at() {
		return created_at;
	}

	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}

	public String getUpdated_at() {
		return updated_at;
	}

	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}

	public String getUri_local() {
		return uri_local;
	}

	public void setUri_local(String uri_local) {
		this.uri_local = uri_local;
	}

	public String getUri_local_origin() {
		return uri_local_origin;
	}

	public void setUri_local_origin(String uri_local_origin) {
		this.uri_local_origin = uri_local_origin;
	}

	public boolean isLocal() {
		return local;
	}

	public void setLocal(boolean local) {
		this.local = local;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}
}
