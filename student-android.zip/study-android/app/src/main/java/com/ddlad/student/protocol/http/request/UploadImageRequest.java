package com.ddlad.student.protocol.http.request;

import android.net.Uri;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.tools.PictureUtil;
import com.ddlad.student.ui.common.BaseFragment;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-8-11.
 */
public class UploadImageRequest extends AbstractRequest<String> {
    private static final String TAG = "UploadImageRequest";

    public UploadImageRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<String> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);

    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_HOMEWORK_COMMIT;
    }

    @Override
    public String processInBackground(ApiResponse<String> response) {
        return response.readRootValue(String.class);
    }

    public void perform(String hid, List<String> paths,String cid,String lid) {

        List<String> zipPaths = new ArrayList<>();
        for(String p:paths){
            try {
                zipPaths.add(Uri.parse(PictureUtil.bitmapToPath(p)).toString());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try {
            RequestParams param = getParams();
            param.setMultipart(true);
            param.put(ProtocolConstants.PARAM_HID, hid);
            param.put("cid", cid);
            param.put("lid", lid);
            param.put("type",1);
            param.setMulitFileWrapper("images[]","multipart/form-data",zipPaths);
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.perform();
    }
    public void perform(String hid, List<String> paths) {

        List<String> zipPaths = new ArrayList<>();
        for(String p:paths){
            try {
                zipPaths.add(Uri.parse(PictureUtil.bitmapToPath(p)).toString());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try {
            RequestParams param = getParams();
            param.setMultipart(true);
            if (hid != null && !hid.equals("")){
                param.put(ProtocolConstants.PARAM_HID, hid);
            }
            param.put("type",1);
            param.setMulitFileWrapper("images[]","multipart/form-data",zipPaths);
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.perform();
    }
}
