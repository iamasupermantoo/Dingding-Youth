package com.ddlad.student.ui.agora;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;
import com.ddlad.student.protocol.convert.DataCenter;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.request.LiveInfoRequest;
import com.ddlad.student.protocol.http.request.OneToManyLiveInfoRequest;
import com.ddlad.student.protocol.model.ChannelInfo;
import com.ddlad.student.protocol.model.LiveInfo;
import com.ddlad.student.protocol.model.MessageInfo;
import com.ddlad.student.tools.Constants;
import com.ddlad.student.tools.StringUtil;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseActivity;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.detail.DetailActivity;
import com.ddlad.student.ui.widget.popupwindow.CommonPopupWindow;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

import io.agora.AgoraAPI;
import io.agora.AgoraAPIOnlySignal;

/**
 * Created by chen007 on 2017/11/6 0006.
 */
public class OneToManyLiveFragment extends BaseFragment {

    private ViewGroup live_layout;
    private ViewGroup root_layout;
    private ViewGroup chat_record_layout;
    private ViewGroup no_teacher_layout;
    private ImageView close_image;
    private TextView see_num;
    private ViewGroup edit_layout;
    private EditText input_message;
    private TextView send_btn;

    private RecyclerView chat_record_list;
    private ChatRecordAdapter mAdapter;

    private CommonPopupWindow popupWindow;
    private ViewGroup back_transparent;

    private LiveInfo.LiveInfoBean.RoomInfoBean mRoomInfo;

    public static AgoraAPIOnlySignal m_agoraAPI;
    private static String channelName;

    private String myName;
    private int uidMy;
    private int uidTeacher;

    private String mSignalKey;
    private int account;

    private boolean getTeacherFail;

    private String mLmId;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_one_to_many_live;
    }

    @Override
    protected void onInitData(Bundle bundle) {
        mLmId = bundle.getString("lmid");
        myName = StringUtil.isEmpty(DataCenter.getUser().getName())?"name":DataCenter.getUser().getName();
        performRequest();
    }

    @Override
    protected boolean isHideActionbar() {
        return true;
    }

    @Override
    protected void onInitView(View contentView) {
        ((BaseActivity)getActivity()).intercept = true;
        if (m_agoraAPI == null){
            m_agoraAPI = AgoraAPIOnlySignal.getInstance(getActivity(), AppContext.getString(R.string.private_app_id));
        }

        AgoraManager.getInstance().setOnPartyListener(mOnPartyListener);

        live_layout = (ViewGroup) contentView.findViewById(R.id.live_layout);
        root_layout = (ViewGroup) contentView.findViewById(R.id.root_layout);
        close_image = (ImageView) contentView.findViewById(R.id.close_image);
        see_num = (TextView) contentView.findViewById(R.id.see_num);
        edit_layout = (ViewGroup) contentView.findViewById(R.id.edit_layout);
        input_message = (EditText) contentView.findViewById(R.id.input_message);
        send_btn = (TextView) contentView.findViewById(R.id.send_btn);
        no_teacher_layout = (ViewGroup) contentView.findViewById(R.id.no_teacher_layout);

        View view = LayoutInflater.from(getActivity()).inflate(R.layout.layout_live_input, null);
        popupWindow = new CommonPopupWindow(getActivity(),view,false);
        edit_layout = (ViewGroup) view.findViewById(R.id.edit_layout);
        back_transparent = (ViewGroup) view.findViewById(R.id.back_transparent);
        input_message = (EditText) view.findViewById(R.id.input_message);
        send_btn = (TextView) view.findViewById(R.id.send_btn);

        chat_record_list = (RecyclerView) view.findViewById(R.id.chat_record_list);
        LinearLayoutManager manager = new LinearLayoutManager(getActivity());
        manager.setOrientation(LinearLayoutManager.VERTICAL);
        manager.setStackFromEnd(true);
        if (mAdapter == null){
            mAdapter = new ChatRecordAdapter(getActivity());
        }
        chat_record_list.setLayoutManager(manager);
        chat_record_list.setAdapter(mAdapter);

        view.post(new Runnable() {
            @Override
            public void run() {
                popupWindow.show(root_layout);
            }
        });

        close_image.setOnClickListener(this);
        send_btn.setOnClickListener(this);
        edit_layout.setOnClickListener(this);
        back_transparent.setOnClickListener(this);
        input_message.setOnClickListener(this);

        setCallBack();
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back_transparent:
            case R.id.close_image:
                hideKeyboard();
                popupWindow.dismiss();
                ((BaseActivity)getActivity()).intercept = false;
                channelLeave();
                getActivity().onBackPressed();
                break;
            case R.id.send_btn:
                if (StringUtil.isEmpty(input_message.getText().toString())){
                    break;
                }
                sendMessage();
                break;
            case R.id.edit_layout:
            case R.id.input_message:
                showKeyboard();
                break;

        }
    }


    public void sendMessage(){
        String content = input_message.getText().toString().trim();
        MessageInfo info = new MessageInfo(1,myName,content);

        ObjectMapper mapper = new ObjectMapper();
        String json = "";
        try {
            json = mapper.writeValueAsString(info);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        m_agoraAPI.messageChannelSend(channelName,json,null);
        input_message.setText("");
    }


    private void setCallBack() {
        m_agoraAPI.callbackSet(new AgoraAPI.CallBack() {
            @Override
            public void onLoginSuccess(int uid, int fd) {
                Log.i("sdk2", "login successfully");
//                my_uid = uid;
                m_agoraAPI.channelJoin(channelName);
            }

            @Override
            public void onLoginFailed(int ecode) {
                Log.i("sdk2", "Login failed " + ecode);
            }

            @Override
            public void onLogout(int ecode) {
                if (ecode == m_agoraAPI.ECODE_LOGOUT_E_USER) {
                    Log.i("sdk2","Logout successfully ");
                } else {
                    Log.i("sdk2","Logout on " + ecode);
                }
            }

            @Override
            public void onLog(String txt) {
                //                ActivityLogin.this.log(txt);
                Log.e("sdk2", txt);
            }

            @Override
            public void onChannelJoined(String chanID) {
                Log.i("sdk2","Join channel " + chanID + " successfully"); // + " docall " + doCall);
            }

            @Override
            public void onInviteReceived(String channleID, String account, int uid, String extra) {
                Log.i("sdk2","Received Invitation from " + account + ":" + uid + " to join " + channleID + " extra:"+extra);
                m_agoraAPI.channelInviteAccept(channleID, account, uid);

//                doJoin();
//                set_state_incall();
            }

            @Override
            public void onChannelUserJoined(String account, int uid) {
                Log.i("sdk2",account + ":" + (long) (uid & 0xffffffffl) + " joined");
            }

            @Override
            public void onChannelJoinFailed(String chanID, int ecode) {
                Log.i("sdk2","Join " + chanID + " failed : ecode " + ecode);
            }

            @Override
            public void onMessageChannelReceive(String channelID, String account, int uid, String msg) {
//                currentReceiveUid = uid;
                Log.i("sdk2","---------------------------------------------recv channel msg " + channelID + " " + account + " : " + msg);

                ObjectMapper mapper = new ObjectMapper();
                try {
                    MessageInfo messageInfo = mapper.readValue(msg, MessageInfo.class);
                    if ((uidTeacher+"").equals(account)){
                        messageInfo.setUserType(1);
                    }else {
                        messageInfo.setUserType(0);
                    }
                    final  MessageInfo info = messageInfo;
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            updateUI(info);
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String name, int ecode, String desc) {
                Log.i("sdk2","---------------onError ------------------------------name   ecode desc=====" +name+"--"+ + ecode+"--"+desc);
                super.onError(name, ecode, desc);
            }

            @Override
            public void onMessageInstantReceive(String account, int uid, String msg) {
                Log.i("sdk2","---------------------------------------------recv inst msg " + account + " : " + (long) (uid & 0xffffffffl) + " : " + msg);
            }

            @Override
            public void onReconnecting(int nretry) {
                Log.i("sdk2","---------------------------------------------recv 丢失链接 msg ");
                m_agoraAPI.login(AppContext.getString(R.string.private_app_id),account+"" , mSignalKey, 0, "");

            }

        });
    }

    private void updateUI(MessageInfo messageInfo) {
        if (messageInfo != null){
            mAdapter.addItemInfo(messageInfo);
            mAdapter.notifyDataSetChanged();
        }
    }



    private void performRequest() {
        OneToManyLiveInfoRequest request = new OneToManyLiveInfoRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<LiveInfo>() {
            @Override
            protected void onSuccess(LiveInfo liveInfo) {
//                AgoraManager.getInstance().setupLocalVideo(getActivity(),mTeacherView,mStudentView,uidTeacher,uidStudent);
                LiveInfo.LiveInfoBean.RoomInfoBean bean = liveInfo.getLiveInfo().getRoomInfo();
                mRoomInfo = bean;
                uidTeacher = bean.getTeacherAccount();
                AgoraManager.getInstance().setupLocalVideo(getActivity(),bean.getTeacherAccount(),bean.getStudentAccount(), bean.getAccount(),bean.getChannelKey());



                channelName = liveInfo.getLiveInfo().getRoomInfo().getChannelName();
                Log.i("LiveRoomFragment","==============================channelName"+channelName);
                String key = liveInfo.getLiveInfo().getRoomInfo().getSignalingKey();
                mSignalKey = liveInfo.getLiveInfo().getRoomInfo().getSignalingKey();
                account = liveInfo.getLiveInfo().getRoomInfo().getAccount();
                AgoraManager.getInstance().joinChannel(channelName);
                m_agoraAPI.login(AppContext.getString(R.string.private_app_id),account+"" , key, 0, "");

            }
        });
        request.perform(mLmId);
    }


    private AgoraManager.OnPartyListener mOnPartyListener = new AgoraManager.OnPartyListener() {
        @Override
        public void onJoinChannelSuccess(String channel, final int uid) {
            uidMy = uid;
            AgoraManager.getInstance().setRemoteRenderMode(uid);
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    live_layout.removeAllViews();
                    AgoraManager.getInstance().setupRemoteVideo(getActivity(), uidTeacher);
                    live_layout.addView(AgoraManager.getInstance().getSurfaceView(uidTeacher));
                }
            });

        }

        @Override
        public void onGetRemoteVideo(final int uid) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    //注意SurfaceView要创建在主线程
//                    AgoraManager.getInstance().setupRemoteVideo(getActivity(), uid);
//                    mPartyRoomLayout.addView(AgoraManager.getInstance().getSurfaceView(uid));
                }
            });

        }

        @Override
        public void onLeaveChannelSuccess() {
            getActivity().finish();
        }

        @Override
        public void onUserOffline(final int uid) {

            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    AgoraManager.getInstance().removeSurfaceView(uidTeacher);
                }
            });
        }

        @Override
        public void onFirstRemoteVideoFrame(int uid) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    no_teacher_layout.setVisibility(View.GONE);
                }
            });
        }
    };

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public static void channelLeave(){
        m_agoraAPI.logout();
        m_agoraAPI.channelLeave(channelName);
        AgoraManager.getInstance().leaveChannel();
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {

        switch (requestCode) {
            case Constants.PERMISSION_REQ_ID_RECORD_AUDIO: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    checkSelfPermission(Manifest.permission.CAMERA, Constants.PERMISSION_REQ_ID_CAMERA);
                } else {
                    Toaster.toastShort("权限被拒绝");
                    onBackPressed();
                }
                break;
            }
            case Constants.PERMISSION_REQ_ID_CAMERA: {
                if (grantResults.length > 0 && grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                    Toaster.toastShort("权限被拒绝");
                    onBackPressed();
                }
                break;
            }
        }
    }

    public boolean checkSelfPermission(String permission, int requestCode) {
        if (ContextCompat.checkSelfPermission(getActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
            //如果没有权限，则申请
            ActivityCompat.requestPermissions(getActivity(), new String[]{permission}, requestCode);
            return false;
        }
        return true;
    }

}
