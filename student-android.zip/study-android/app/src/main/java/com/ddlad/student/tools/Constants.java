package com.ddlad.student.tools;

public class Constants {

    public static final String AUDIO_CACHE_DIR = "audios";

    public static final String IMAGE_CACHE_DIR = "images";

    public static final int REQUEST_CODE_CAMERA_PERMISSION = 1;

    public static final int REQUEST_CODE_READ_PERMISSION = 2;

    public static final int REQUEST_CODE_WRITE_PERMISSION = 3;

    public static final int REQUEST_CODE_CONNECT_PERMISSION = 40012;

    public static final int REQUEST_CODE_TAKE_PHOTO = 10001;

    public static final int REQUEST_CODE_CHOOSE_IMAGE = 10002;
    public static final int REQUEST_CHOOSE_IMAGE = 104;

    public static final int REQUEST_CODE_CROP_IMAGE = 10003;

    public static final int REQUEST_CODE_NAME = 10004;

    public static final int REQUEST_CODE_SIGNATURE = 10005;

    public static final int REQUEST_CODE_SEARCH_COLLEGE = 10006;

    public static final int REQUEST_CODE_SEARCH_SENIOR = 10007;

    public static final int REQUEST_CODE_SEARCH_ACADEMY = 10008;

    public static final int PERMISSION_REQ_ID_RECORD_AUDIO = 10009;

    public static final int PERMISSION_REQ_ID_CAMERA = 10010;

    public static final int PERMISSION_CALL_PHONE = 10011;

    public static final int SDK_PAY_FLAG = 1;

    public static final int HANDLE_STATE_PRESS = 90001;

    public static final String URL_VERIFY = "http://www.udan.cn/user/verity";

    public static String retainMinAmount;
    public static String servicePhone;
    public static String sharePlusAmount;

    public static enum WeekDay {

        SUNDAY(1, "周日"), //
        MONDAY(2, "周一"), //
        TUESDAY(3, "周二"), //
        WEDNESDAY(4, "周三"), //
        THURSDAY(5, "周四"), //
        FRIDAY(6, "周五"), //
        SATURDAY(7, "周六"); //

        WeekDay(int value, String text) {
            mValue = value;
            mText = text;
        }

        private int mValue;

        private String mText;

        public int getValue() {
            return mValue;
        }

        public String getText() {
            return mText;
        }

        public static String fromValue(int value) {

            String text = null;

            switch (value) {
                case 1:
                    text = SUNDAY.getText();
                    break;
                case 2:
                    text = MONDAY.getText();
                    break;
                case 3:
                    text = TUESDAY.getText();
                    break;
                case 4:
                    text = WEDNESDAY.getText();
                    break;
                case 5:
                    text = THURSDAY.getText();
                    break;
                case 6:
                    text = FRIDAY.getText();
                    break;
                case 7:
                    text = SATURDAY.getText();
                    break;
            }

            return text;
        }
    }

}
