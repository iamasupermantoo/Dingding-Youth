package com.ddlad.student.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import com.ddlad.student.primary.Log;


public class PollingService extends Service {
    public static final String ACTION = "com.udan.service.PollingService";
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public void onCreate() {
        Log.i("PollingThread","xianchengqidong");
    }
                                                                                                                                                                                                                           
    @Override
    public void onStart(Intent intent, int startId) {
        new PollingThread().start();
    }

    /**
     * Polling thread
     * 模拟向Server轮询的异步线程
     * @Author Ryan
     * @Create 2013-7-13 上午10:18:34
     */
    class PollingThread extends Thread {
        @Override
        public void run() {
            Log.i("PollingThread","xianzaikaishidayinma           1111");
        }
    }
                                                                                                                                                                                                                           
    @Override
    public void onDestroy() {
        super.onDestroy();
        System.out.println("Service:onDestroy");
    }
}
