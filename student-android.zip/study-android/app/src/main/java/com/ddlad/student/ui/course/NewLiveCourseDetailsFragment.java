package com.ddlad.student.ui.course;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.text.Html;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alipay.sdk.app.PayTask;
import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Prefs;
import com.ddlad.student.protocol.http.cache.NetworkImageCache;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.request.AliPayActionRequest;
import com.ddlad.student.protocol.http.request.BanlancePayRequest;
import com.ddlad.student.protocol.http.request.ConstantsRequest;
import com.ddlad.student.protocol.http.request.CourseDetailsRequest;
import com.ddlad.student.protocol.http.request.FreeLiveYueKeRequest;
import com.ddlad.student.protocol.http.request.MyAccountBalanceRequest;
import com.ddlad.student.protocol.http.request.OpenCourseDetailsRequest;
import com.ddlad.student.protocol.http.request.OrderSubmitRequest;
import com.ddlad.student.protocol.http.request.PayParamsRequest;
import com.ddlad.student.protocol.http.request.PayResultRequest;
import com.ddlad.student.protocol.http.request.ScholarWxShareOkRequest;
import com.ddlad.student.protocol.http.request.ScholarWxShareRequest;
import com.ddlad.student.protocol.http.request.WxpayRequest;
import com.ddlad.student.protocol.http.request.YueKeRequest;
import com.ddlad.student.protocol.model.AlipayOrderInfo;
import com.ddlad.student.protocol.model.ConstantsInfo;
import com.ddlad.student.protocol.model.CourseDetailsInfo;
import com.ddlad.student.protocol.model.GetChargeItemInfo;
import com.ddlad.student.protocol.model.HomeWorkDetailsInfo;
import com.ddlad.student.protocol.model.OrderSubmitInfo;
import com.ddlad.student.protocol.model.PayParamsInfo;
import com.ddlad.student.protocol.model.PayResultInfo;
import com.ddlad.student.protocol.model.ScholarshipInfo;
import com.ddlad.student.protocol.model.ShareWxIssueInfo;
import com.ddlad.student.protocol.model.WxpayOrderInfo;
import com.ddlad.student.tools.Constants;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.tools.PayUtil;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.account.MyAccountBalanceFragment;
import com.ddlad.student.ui.account.NewOrderMangerFragment;
import com.ddlad.student.ui.agora.LiveRoomFragment;
import com.ddlad.student.ui.agora.OneToManyLiveFragment;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.cropper.cropwindow.handle.Handle;
import com.ddlad.student.ui.widget.dialog.ConfirmPayDialogBuilder;
import com.ddlad.student.ui.widget.dialog.DialogBuilder;
import com.ddlad.student.ui.widget.dialog.IDialogClickListener;
import com.ddlad.student.ui.widget.dialog.ShareLessonDialogBuilder;
import com.ddlad.student.ui.widget.image.NetworkImageView;
import com.ddlad.student.wxapi.WXEntryActivity;
import com.ddlad.student.wxapi.WXPayEntryActivity;
import com.ddlad.student.wxapi.WechatHelper;

import java.util.Map;

/**
 * Created by chen007 on 2017/3/24 0024.
 */
public class NewLiveCourseDetailsFragment extends BaseFragment {

    private int mLoaderFeedBackId = ViewUtil.generateUniqueId();
    private int mYueKeBackId = ViewUtil.generateUniqueId();
    private String mCmId;

    private CourseDetailsInfo mInfo;

    private static float imageH = (ViewUtil.getScreenWidthPixels() - ViewUtil.dpToPx(40))*4/7;

    private static float bgH = imageH + ViewUtil.dpToPx(10);

//    private NetworkImageView mCourseImage;
    public com.facebook.drawee.view.SimpleDraweeView mImage;

    private TextView mCourseName;
    private TextView mCourseTime;
    private TextView mLevel;
    private TextView mIntroduction;
    private TextView appointment_course;
    private TextView suite_desc;
    private TextView live_course_name;
    private TextView join_cnt;
    private TextView open_time;
    private TextView live_end;

    private ImageView share_image;

    private TextView pay_desc;
    private String productId;

    private int mBalance;
    private int mPrice;
    private int type;
    private int states;

    public static boolean refreshBalancePay;

    private String lmId;

    private int payType;

    private ViewGroup bg_shadow_layout;
    private ViewGroup bottom_layout;

    private ConfirmPayDialogBuilder dialogBuilder;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_new_live_course_detail;
    }



    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle("课程详情");
        wechatHelper = new WechatHelper();

//        mCourseImage = (NetworkImageView) contentView.findViewById(R.id.item_image);
        mImage = (com.facebook.drawee.view.SimpleDraweeView) contentView.findViewById(R.id.item_image);
        mCourseName = (TextView) contentView.findViewById(R.id.course_name);
        live_course_name = (TextView) contentView.findViewById(R.id.live_course_name);
        join_cnt = (TextView) contentView.findViewById(R.id.join_cnt);
        open_time = (TextView) contentView.findViewById(R.id.open_time);
        live_end = (TextView) contentView.findViewById(R.id.live_end);

        share_image = (ImageView) contentView.findViewById(R.id.share_image);

        mCourseTime = (TextView) contentView.findViewById(R.id.item_class_time);
        mLevel = (TextView) contentView.findViewById(R.id.item_course_level);
        mIntroduction = (TextView) contentView.findViewById(R.id.course_desc);
        pay_desc = (TextView) contentView.findViewById(R.id.pay_desc);
        appointment_course = (TextView) contentView.findViewById(R.id.appointment_course);
        suite_desc = (TextView) contentView.findViewById(R.id.suite_desc);
        bg_shadow_layout = (ViewGroup) contentView.findViewById(R.id.bg_shadow_layout);
        bottom_layout = (ViewGroup) contentView.findViewById(R.id.bottom_layout);
        RelativeLayout.LayoutParams paramsImage = (RelativeLayout.LayoutParams) mImage.getLayoutParams();
        paramsImage.height = (int) imageH;
        mImage.setLayoutParams(paramsImage);

//        RelativeLayout.LayoutParams paramsBg = (RelativeLayout.LayoutParams)bg_shadow_layout.getLayoutParams();
//        paramsBg.height = (int) bgH;
//        bg_shadow_layout.setLayoutParams(paramsBg);
        bottom_layout.setOnClickListener(this);
        share_image.setOnClickListener(this);
        appointment_course.setOnClickListener(this);

        live_end.setVisibility(View.GONE);
    }



    @Override
    protected void onInitData(Bundle bundle) {
        mCmId = bundle.getString("cmid");
        requestData();
        requestBalanceData();
    }

    private void requestData() {
        OpenCourseDetailsRequest courseDetailsRequest = new OpenCourseDetailsRequest(this, getDefaultLoaderId(), new AbstractCallbacks<CourseDetailsInfo>() {
            @Override
            protected void onSuccess(CourseDetailsInfo courseDetailsInfo) {
                if (courseDetailsInfo != null && courseDetailsInfo.getCourse() != null){
                    mPrice = Integer.parseInt(courseDetailsInfo.getCourse().getPrice());
                    mInfo = courseDetailsInfo;
                    lmId = courseDetailsInfo.getCourse().getLmId();
                    type = courseDetailsInfo.getCourse().getType();
                    states = courseDetailsInfo.getCourse().getStatus();
                    String url =  mInfo.getCourse().getImage().getPattern();
                    Uri uri = Uri.parse(url.substring(url.indexOf("http"),url.indexOf("@{w}w")));
                    mImage.setImageURI(uri);
//                String url =  mInfo.getCourse().getImage().getPattern();
//                mCourseImage.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}w")));;
                    mCourseName.setText(mInfo.getCourse().getName());

//                mTeacherName.setText(mInfo.getCourse().getTeacher());
//                mPrice.setText(mInfo.getCourse().getPrice());
                    mLevel.setText(mInfo.getCourse().getLevel()+"");
                    mIntroduction.setText(mInfo.getCourse().getDesc());
                    mIntroduction.setText(Html.fromHtml(mInfo.getCourse().getDesc()));
                    //                mCourseTime  返回的数据中没有时间
                    mCourseTime.setText(mInfo.getCourse().getTotalCnt()+"节课");

                    suite_desc.setText(mInfo.getCourse().getSuitableCrowds()+"");

                    StringBuffer sb = new StringBuffer();
                    for (int i = 0;i<mInfo.getCourse().getSubNotes().size();i++){
                        sb.append(mInfo.getCourse().getSubNotes().get(i));
                    }
                    pay_desc.setText(sb.toString()+"");
                    mCourseName.setText(mInfo.getCourse().getName());
                    live_course_name.setText(mInfo.getCourse().getName());
                    open_time.setText(AppContext.getString(R.string.lesson_begin_time,mInfo.getCourse().getOpenTime()));
                    join_cnt.setText(AppContext.getString(R.string.partake_num,mInfo.getCourse().getJoinCnt()));


                    refreshBottomState();

                    if (mInfo.getCourse().getType() == 1){
                        //正常
                    }
                    if (mInfo.getCourse().getType() == 2){
                        //试听
                    }
                }

            }
        });
        courseDetailsRequest.perform(mCmId);
    }

    @Override
    public void onResume() {
        super.onResume();
        hideKeyboard();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
               hideKeyboard();
            }
        },500);
        if (isPay){
            modifyRequest();
        }
        if (WXEntryActivity.shareSuccess){
            WXEntryActivity.shareSuccess = false;
            perfromShareSuccess();
        }
        if (refreshBalancePay){
            requestBalanceData();
        }
        if (WXPayEntryActivity.payState){
            mChannel = 0;
            modifyRequest();
        }
    }

    public void refreshBottomState(){
        share_image.setVisibility(View.GONE);
        if (states > 1){
            if (mInfo.getCourse().getType() == 1){
                //正常，非试听
                share_image.setVisibility(View.VISIBLE);
            }
        }
        if (states == 0){
            //显示预约
            live_end.setVisibility(View.GONE);
            appointment_course.setVisibility(View.VISIBLE);
            appointment_course.setText("立即预约");
        }
        if (states == 1){
            //显示支付
            live_end.setVisibility(View.GONE);
            appointment_course.setVisibility(View.VISIBLE);
            appointment_course.setText(AppContext.getString(R.string.pay_num,mPrice));
        }
        if (states == 2){
            //显示进入直播
            live_end.setVisibility(View.GONE);
            appointment_course.setVisibility(View.VISIBLE);
            appointment_course.setText("进入直播间");
        }
        if (states == 3){
            //显示直播结束
            live_end.setVisibility(View.VISIBLE);
            appointment_course.setVisibility(View.GONE);

        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.bottom_layout:
                break;
            case R.id.share_image:
                showShareDialog();
                break;
            case R.id.appointment_course:
                if (states == 0){
                    //约课
                    performYueKe();
                    break;
                }
                if (states == 1){
                    showPayDialog();
                    break;
                }
                if (states == 2){
                    navigateToLive();
                    break;
                }
                break;
            case R.id.live_end:
                //课程结束
                break;
        }
    }

    public void performYueKe(){
        FreeLiveYueKeRequest request = new FreeLiveYueKeRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<OrderSubmitInfo>() {
            @Override
            protected void onSuccess(OrderSubmitInfo info) {
                states = 2;
                refreshBottomState();
            }
        });
        request.perform(lmId);
    }

    public void navigateToLive(){
        Bundle bundle = new Bundle();
        bundle.putString("lmid",lmId);
        NavigateUtil.navigateToDetailActivity(getActivity(),new OneToManyLiveFragment(),bundle);
    }

    public void showPayDialog(){
        if (dialogBuilder == null){
            dialogBuilder = new ConfirmPayDialogBuilder(this);
            dialogBuilder.setmListener(new IDialogClickListener() {
                @Override
                public void onClick(int type) {
                    payType = type;
                    if (type == 0 || type == 1){
//                        aliPay();
                        performOrderSubmit();
                        return;
                    }
                    if (type == 1){
//                        wxPay();
//                        return;
                    }

                    if (type == 2){
                        //余额
                        if (mPrice > mBalance){
                            navigateToMyAccountBalance();
                        }else {
                            performBalance();
                        }
                        return;
                    }
                }
            });
        }
        dialogBuilder.setPayNum(mPrice+"");
        dialogBuilder.setBalanceNum(mBalance+"");
        dialogBuilder.create().show();
    }

    public void navigateToMyAccountBalance(){
        Bundle bundle = new Bundle();
        bundle.putString("fromWhere","NewLiveCourseDetailsFragment");
        NavigateUtil.navigateToNormalActivity(getActivity(),new MyAccountBalanceFragment(),bundle);
    }

    private void performBalance(){
        BanlancePayRequest request = new BanlancePayRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<OrderSubmitInfo>() {
            @Override
            protected void onSuccess(OrderSubmitInfo info) {
                states = 2;
                Toaster.toastShort("支付成功",1);
                refreshBottomState();
                if (dialogBuilder != null){
                    dialogBuilder.dismiss();
                }
            }
        });
        request.perform(2,lmId);
    }

    private void requestBalanceData() {
        MyAccountBalanceRequest request = new MyAccountBalanceRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<GetChargeItemInfo>() {
            @Override
            protected void onSuccess(GetChargeItemInfo info) {
                if (info != null){
                    mBalance = info.getTotalAmount();
                    if (refreshBalancePay){
                        refreshBalancePay = false;
                        showPayDialog();
                    }
                }
            }
        });
        request.perform();
    }


    public void aliPay(PayParamsInfo payParamsInfo){
        PayUtil util = new PayUtil();
        util.AliPay(payParamsInfo.getParams().getAlipay().getOrderStr(), this, new IDialogClickListener() {
            @Override
            public void onClick(int type) {
                if (type == 1){
                    //支付成功
                    mChannel = 1;
                    modifyRequest();
                }
                if (type == 0){
                    //支付失败
                }
            }
        });
    }

    public void wxPay(PayParamsInfo payParamsInfo){
        mChannel = 0;
        PayUtil util = new PayUtil();
        util.WxPay(payParamsInfo,getActivity());
    }

    public static boolean isPay = false;
    public  String mOrderSn = "";
    public  int mChannel;
    private void modifyRequest() {
        isPay = false;
        PayResultRequest request = new PayResultRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<PayResultInfo>() {
            @Override
            protected void onSuccess(PayResultInfo wxpayOrderInfo) {
                if (wxpayOrderInfo.getResult() == 1){
                    Toaster.toastShort("支付成功");
//                    requestData();
                    states = 2;
                    refreshBottomState();
                }

            }

            @Override
            protected void onFail(ApiResponse<PayResultInfo> response) {
                Toaster.toastShort(response.getErrorDescription());
            }
        });
        request.perform(mOrderSn,payType);
    }


    public void performOrderSubmit(){
        if (mInfo == null){
            return;
        }
        OrderSubmitRequest request = new OrderSubmitRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<OrderSubmitInfo>() {
            @Override
            protected void onSuccess(OrderSubmitInfo info) {
               if (info != null){
                   payParamRequest(info.getOid());
               }

            }
        });
        request.perform(1,mInfo.getCourse().getLmId());
    }


    private void payParamRequest(String oid) {
        //请求预支付id
        PayParamsRequest request = new PayParamsRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<PayParamsInfo>() {
            @Override
            protected void onSuccess(PayParamsInfo payParamsInfo) {
                if (payParamsInfo == null){
                    return;
                }
                mOrderSn = payParamsInfo.getParams().getOrderSn();
                if (payType == 0){
                    wxPay(payParamsInfo);
                    return;
                }
                if (payType == 1){
                    aliPay(payParamsInfo);
                    return;
                }
            }

            @Override
            protected void onFail(ApiResponse<PayParamsInfo> response) {
                Toaster.toastShort(response.getErrorDescription());
            }
        });
        request.perform(oid,0,payType);
    }




    private ShareLessonDialogBuilder shareLessonDialogBuilder;
    private WechatHelper wechatHelper;

    public void showShareDialog(){
        if (shareLessonDialogBuilder == null){
            shareLessonDialogBuilder = new ShareLessonDialogBuilder(this);
            shareLessonDialogBuilder.setmListener(new IDialogClickListener() {
                @Override
                public void onClick(int type) {
                    if (type == 1){
                        getWxShareInfo();
                    }
                }
            });
            shareLessonDialogBuilder.setContent("5","100");
        }
        shareLessonDialogBuilder.create().show();
    }

    public void getWxShareInfo(){
        performConstants();
        ScholarWxShareRequest request = new ScholarWxShareRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<ShareWxIssueInfo>() {
            @Override
            protected void onSuccess(final ShareWxIssueInfo shareWxIssueInfo) {
                if (shareWxIssueInfo != null && shareWxIssueInfo.getInfo() != null){
                    String url = shareWxIssueInfo.getInfo().getPicUrl();
                    if (NetworkImageCache.getInstance().getBitmap(url) != null) {
                        NetworkImageCache.getInstance().removeBitmapAndRecycle(url);
                    }
                    NetworkImageView imageView = new NetworkImageView(getActivity());
                    imageView.setUrl(url);

                    imageView.setOnLoadListener(new NetworkImageView.OnLoadListener() {
                        @Override
                        public void onLoad(Bitmap bitmap, String url) {
                            ShareWxIssueInfo.InfoBean info = shareWxIssueInfo.getInfo();
                            wechatHelper.inviteWechatFriendUrl(info.getUrl(),info.getPicUrl(),info.getTitle(),info.getBrief(),false);
                        }
                    });
                }

            }
        });
        request.perform(lmId,"");
    }

    private void performConstants() {
        ConstantsRequest request = new ConstantsRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<ConstantsInfo>() {
            @Override
            protected void onSuccess(ConstantsInfo constantsInfo) {
            }
        });
        request.perform();
    }

    public void perfromShareSuccess(){
        ScholarWxShareOkRequest request = new ScholarWxShareOkRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<ShareWxIssueInfo>() {
            @Override
            protected void onSuccess(ShareWxIssueInfo shareWxIssueInfo) {

            }
        });
        request.perform(lmId," ","");
    }

}
