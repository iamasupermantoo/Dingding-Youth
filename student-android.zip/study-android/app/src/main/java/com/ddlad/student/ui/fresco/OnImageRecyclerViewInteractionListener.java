package com.ddlad.student.ui.fresco;


import com.ddlad.student.ui.fresco.models.ImageItem;

public interface OnImageRecyclerViewInteractionListener {
    void onImageItemInteraction(ImageItem item);
}