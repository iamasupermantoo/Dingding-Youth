package com.ddlad.student.ui.agora;

import com.ddlad.student.primary.AppContext;

import io.agora.rtc.IRtcEngineEventHandler;
import io.agora.rtc.RtcEngine;

/**
 * Created by chen007 on 2017/7/10 0010.
 */
public class SingletonRtcEngine {
    private SingletonRtcEngine(){

    }

    public static RtcEngine getmRtcEngine() {
        return mRtcEngine;
    }

    public static void setmRtcEngine(RtcEngine rtcEngine) {
        mRtcEngine = rtcEngine;
    }

    private static RtcEngine mRtcEngine;

    public static IRtcEngineEventHandler getHandler() {
        return handler;
    }

    public static void setHandler(IRtcEngineEventHandler handler) {
        SingletonRtcEngine.handler = handler;
        if (mRtcEngine == null){
            synchronized (SingletonRtcEngine.class){
                if (mRtcEngine == null){
                    mRtcEngine = RtcEngine.create(AppContext.getContext(),"",handler);
                }
            }
        }
    }

    private static IRtcEngineEventHandler handler;
}
