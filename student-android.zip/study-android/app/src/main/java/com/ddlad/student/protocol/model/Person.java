package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.IOException;

/**
 * Created by Albert
 * on 16-10-12.
 */
public class Person extends BaseInfo {
    protected com.ddlad.student.protocol.model.UserInfo user;
    protected String academy;
    protected String school;
    protected String year;
    protected int followStatus;
    protected String seniorSchool;
    protected String seniorYear;
    protected int seniorMajor = -1;
    protected int education = -1;
    protected  boolean isNew;

    public boolean isNew() {
        return isNew;
    }

    public void setNew(boolean aNew) {
        isNew = aNew;
    }

    public UserInfo getUser() {
        if (user == null) {
            user = new UserInfo();
        }
        return user;
    }

    public void setUser(UserInfo user) {
        this.user = user;
    }

    public String getAcademy() {
        return academy;
    }

    public void setAcademy(String academy) {
        this.academy = academy;
    }

    public String getSeniorSchool() {
        return seniorSchool;
    }

    public void setSeniorSchool(String seniorSchool) {
        this.seniorSchool = seniorSchool;
    }

    public String getSeniorYear() {
        return seniorYear;
    }

    public void setSeniorYear(String seniorYear) {
        this.seniorYear = seniorYear;
    }

    public int getSeniorMajor() {
        return seniorMajor;
    }

    public void setSeniorMajor(int seniorMajor) {
        this.seniorMajor = seniorMajor;
    }

    public int getEducation() {
        return education;
    }

    public void setEducation(int education) {
        this.education = education;
    }

    public int getFollowStatus() {
        return followStatus;
    }

    public void setFollowStatus(int followStatus) {
        this.followStatus = followStatus;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public static Person fromJsonParser(JsonParser jsonParser) throws IOException {

        Person info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new Person();
                }

                if ("user".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.user = com.ddlad.student.protocol.model.UserInfo.fromJsonParser(jsonParser);
                    continue;
                }
                if ("info".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.user = com.ddlad.student.protocol.model.UserInfo.fromJsonParser(jsonParser);
                    continue;
                }

                if ("academy".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.academy = jsonParser.getText();
                    continue;
                }

                if ("seniorSchool".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.seniorSchool = jsonParser.getText();
                    continue;
                }

                if ("seniorYear".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.seniorYear = jsonParser.getText();
                    continue;
                }

                if ("seniorMajor".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.seniorMajor = jsonParser.getIntValue();
                    continue;
                }

                if ("education".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.education = jsonParser.getIntValue();
                    continue;
                }

                if ("followStatus".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.followStatus = jsonParser.getIntValue();
                    continue;
                }

                if ("school".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.school = jsonParser.getText();
                    continue;
                }

                if ("year".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.year = jsonParser.getText();
                    continue;
                }

                if ("isNew".equals(fieldName)){
                    jsonParser.nextToken();
                    info.isNew = jsonParser.getBooleanValue();
                }


                jsonParser.skipChildren();
            }
        }

        return info;
    }
}
