package com.ddlad.student.protocol.http.request;


import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.request.BaseHomeworkRequest;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.HomeworkInfo;

/**
 * Created by Administrator on 2016/12/8 0008.
 */

public class HomeworkRequest extends BaseHomeworkRequest {
    public HomeworkRequest(BaseListFragment baseListFragment, int loaderId, AbstractStreamingCallbacks<AbstractListResponse<HomeworkInfo>> streamingApiCallbacks) {
        super(baseListFragment, loaderId, streamingApiCallbacks);
    }

    @Override
    protected String getBasePath() {
        return ProtocolConstants.URL_HOMEWORK_LIST;
    }

    public void perform(String cursor) {
        RequestParams param = getParams();
        super.perform();
    }
}
