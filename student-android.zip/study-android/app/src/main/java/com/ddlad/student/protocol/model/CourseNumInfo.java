package com.ddlad.student.protocol.model;

import java.util.List;

/**
 * Created by chen007 on 2017/5/27 0027.
 */
public class CourseNumInfo extends BaseInfo {

        /**
         * hasNext : false
         * list : [{"totalCnt":100,"cid":"sh27hheflsE9RzEFBVF2BQ","cmId":"FCNC-zHElhA9RzEFBVF2BQ","image":{"width":200,"height":200,"pattern":"http://img.z.ziduan.com/q9t_rHNh_qg9RzEFBVF2BQ.png@{w}w_{h}h_75q","id":"q9t_rHNh_qg9RzEFBVF2BQ"},"name":"雅思"}]
         */

        private CoursesBean courses;

        public CoursesBean getCourses() {
            return courses;
        }

        public void setCourses(CoursesBean courses) {
            this.courses = courses;
        }

        public static class CoursesBean {
            private boolean hasNext;
            /**
             * totalCnt : 100
             * cid : sh27hheflsE9RzEFBVF2BQ
             * cmId : FCNC-zHElhA9RzEFBVF2BQ
             * image : {"width":200,"height":200,"pattern":"http://img.z.ziduan.com/q9t_rHNh_qg9RzEFBVF2BQ.png@{w}w_{h}h_75q","id":"q9t_rHNh_qg9RzEFBVF2BQ"}
             * name : 雅思
             */

            private List<ListBean> list;

            public boolean isHasNext() {
                return hasNext;
            }

            public void setHasNext(boolean hasNext) {
                this.hasNext = hasNext;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private int totalCnt;
                private String cid;
                private String cmId;
                /**
                 * width : 200
                 * height : 200
                 * pattern : http://img.z.ziduan.com/q9t_rHNh_qg9RzEFBVF2BQ.png@{w}w_{h}h_75q
                 * id : q9t_rHNh_qg9RzEFBVF2BQ
                 */

                private ImageBean image;
                private String name;

                public int getTotalCnt() {
                    return totalCnt;
                }

                public void setTotalCnt(int totalCnt) {
                    this.totalCnt = totalCnt;
                }

                public String getCid() {
                    return cid;
                }

                public void setCid(String cid) {
                    this.cid = cid;
                }

                public String getCmId() {
                    return cmId;
                }

                public void setCmId(String cmId) {
                    this.cmId = cmId;
                }

                public ImageBean getImage() {
                    return image;
                }

                public void setImage(ImageBean image) {
                    this.image = image;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public static class ImageBean {
                    private int width;
                    private int height;
                    private String pattern;
                    private String id;

                    public int getWidth() {
                        return width;
                    }

                    public void setWidth(int width) {
                        this.width = width;
                    }

                    public int getHeight() {
                        return height;
                    }

                    public void setHeight(int height) {
                        this.height = height;
                    }

                    public String getPattern() {
                        return pattern;
                    }

                    public void setPattern(String pattern) {
                        this.pattern = pattern;
                    }

                    public String getId() {
                        return id;
                    }

                    public void setId(String id) {
                        this.id = id;
                    }
                }
            }
        }
}
