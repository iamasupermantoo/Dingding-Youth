package com.ddlad.student.ui.attendclass.student;

import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.protocol.model.CurriculumInfo;
import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.common.AbstractAdapter;

import java.util.List;

/**
 * Created by Administrator on 2017/1/16 0016.
 */

public class CurriculumAdapter extends AbstractAdapter<CurriculumInfo> {

    public CurriculumAdapter(BaseFragment fragment) {
        super(fragment);
    }

    @Override
    public CurriculumInfo getItem(int position) {

        return mList.get(position);
    }

    @Override
    protected View createView(int position, ViewGroup parent) {
//        return CurriculumItemAdapter.createView(parent);
        return NewCurriculumItemAdapter.createView(parent);
    }

    @Override
    protected void bindView(int position, View view) {
//        CurriculumItemAdapter.bindView(view, getItem(position),mFragment,this);
        NewCurriculumItemAdapter.bindView(view, getItem(position),mFragment,this);
    }

    @Override
    public void clearItem() {
        mList.clear();
    }

    @Override
    public void addItem(CurriculumInfo curriculumInfo) {
        mList.add(curriculumInfo);
    }

    @Override
    public void addItem(List<CurriculumInfo> list) {
        if (!CollectionUtil.isEmpty(list)){
            mList.addAll(list);
        }
    }

    @Override
    public int getCount() {
        return mList.size();
    }
}
