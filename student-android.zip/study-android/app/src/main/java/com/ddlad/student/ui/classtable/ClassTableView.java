package com.ddlad.student.ui.classtable;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.widget.LinearLayout;

import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.ui.attendclass.schedule.ScheduleFragment;
import com.ddlad.student.ui.calendar.calendarview.CalendarUtils;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.R;

import java.util.Calendar;
import java.util.HashSet;
import java.util.List;

/**
 * Created by Albert
 * on 16-8-31.
 */
public class ClassTableView extends LinearLayout {

    private ClassWeekView[] mWeeks = new ClassWeekView[6];

    private Calendar mMonth = CalendarUtils.getInstance();

    private HashSet<Integer> mDotedDays;

    private DateChangeListener mDateChangeListener;

    private ClassDayView mLastSelectedDay;

    private ClassDayView mTodayView;

    public ClassTableView(Context context) {
        super(context);
        init(context);
    }

    public ClassTableView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ClassTableView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        setOrientation(VERTICAL);
        LayoutInflater.from(context).inflate(R.layout.layout_class_table, this, true);
        mWeeks[0] = (ClassWeekView) findViewById(R.id.week0);
        mWeeks[1] = (ClassWeekView) findViewById(R.id.week1);
        mWeeks[2] = (ClassWeekView) findViewById(R.id.week2);
        mWeeks[3] = (ClassWeekView) findViewById(R.id.week3);
        mWeeks[4] = (ClassWeekView) findViewById(R.id.week4);
        mWeeks[5] = (ClassWeekView) findViewById(R.id.week5);
    }

    public void setDotedDays(List<Integer> days) {
        if (CollectionUtil.isEmpty(days)) {
            if (mDotedDays == null) {
                mDotedDays = new HashSet<>();
            } else {
                mDotedDays.clear();
            }
        } else {
            mDotedDays = new HashSet(days);
        }
    }

    public void setDateChangeListener(DateChangeListener listener) {
        this.mDateChangeListener = listener;
    }

    public void future() {
        int year = mMonth.get(Calendar.YEAR);
        int month = mMonth.get(Calendar.MONTH);
        if (month == 11) {
            month = 0;
            year += 1;
        } else {
            month += 1;
        }
        mMonth.set(year, month, 1);
        if (mDotedDays != null){
            mDotedDays.clear();
        }
        update(mMonth);
    }

    public void past() {
        int year = mMonth.get(Calendar.YEAR);
        int month = mMonth.get(Calendar.MONTH);
        if (month == 0) {
            month = 11;
            year -= 1;
        } else {
            month -= 1;
        }
        mMonth.set(year, month, 1);
        if (mDotedDays != null){
            mDotedDays.clear();
        }

        update(mMonth);
    }

    public Calendar getMonth() {
        return mMonth;
    }

    public void setToday() {
        update(Calendar.getInstance());
    }

    public void update(Calendar month) {

        final int currentYear = month.get(Calendar.YEAR);
        final int currentMonth = month.get(Calendar.MONTH);

        final Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(currentYear, currentMonth, 1);

        CalendarUtils.copyDateTo(calendar, mMonth);

        final int firstDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);

        int bottomEmptyCount = 0;
        boolean selected = false;

        for (int week = 0; week < mWeeks.length; week++) {
            ClassWeekView weekView = mWeeks[week];
            for (int day = 1; day < 8; day++) {
                final ClassDayView dayView = weekView.getDayView(day - 1);
                if (week == 0 && day < firstDayOfWeek) {
                    dayView.clear();
                } else if (calendar.get(Calendar.MONTH) > currentMonth
                        || calendar.get(Calendar.YEAR) > currentYear) {
                    dayView.clear();
                    bottomEmptyCount += 1;
                } else {
                    dayView.set(calendar);
                    dayView.dot(isDoted(calendar));
                    dayView.setOnClickListener(new OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            onDateSelected(dayView);
                            if (mDateChangeListener != null) {
                                mDateChangeListener.onDateChanged(dayView.getDate());
                            }
                        }
                    });
                    if (dayView.isToday()) {
                        selected = true;
                        mTodayView = dayView;
                        onDateSelected(dayView);
                    }
                    calendar.add(Calendar.DATE, 1);
                }
            }
        }

        mWeeks[5].setVisibility(bottomEmptyCount < 7 ? VISIBLE : GONE);
        if (mLastSelectedDay != null && !selected) {
            mLastSelectedDay.setSelected(false);
            mLastSelectedDay = null;
        }
    }

    public boolean isDoted(Calendar calendar) {
        return (mMonth.get(Calendar.MONTH) == calendar.get(Calendar.MONTH))
                && (CollectionUtil.isEmpty(mDotedDays) ? false
                        : mDotedDays.contains(calendar.get(Calendar.DAY_OF_MONTH)));
    }

    private void onDateSelected(ClassDayView selectedDay) {
        if (mLastSelectedDay == selectedDay) {
            return;
        }
        if (mLastSelectedDay != null) {
            mLastSelectedDay.setSelected(false);
        }
        selectedDay.setSelected(true);
        mLastSelectedDay = selectedDay;
    }

    public void selectToday() {
        if (mTodayView != null) {
            onDateSelected(mTodayView);
        }
    }


    private boolean hasJudged;
    private boolean ignore;
    private float startX;
    private float startY;
    private float lastX;
    private float lastY;
    int startScrollX;

    static float MOVE_JUDGE_DISTANCE = 20;
    public static final int DIRECTION_EXPAND = 0;
    public static final int DIRECTION_SHRINK = 1;

    private ScheduleFragment mFragment;


    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                disallowParentsInterceptTouchEvent(getParent());
                hasJudged = false;
                startX = ev.getX();
                startY = ev.getY();
                break;
            case MotionEvent.ACTION_MOVE:
                float curX = ev.getX();
                float curY = ev.getY();
                if (hasJudged == false) {
                    float dx = curX - startX;
                    float dy = curY - startY;
//                    Log.i("classtableview","dxdxdddddddddddxxxxx--==="+dx);
//                    Log.i("classtableview","dxdxdddddddddddyyyyy--==="+dy);

                    if ((dx * dx + dy * dy > 300)) {
                        if (Math.abs(dy) > Math.abs(dx)) {
                            allowParentsInterceptTouchEvent(getParent());
                        } else {
                            lastX = curX;
                            lastY = curY;
                        }
                        hasJudged = true;
                        ignore = true;
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
                break;
            default:
                break;
        }
        return super.dispatchTouchEvent(ev);
    }


    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        if (hasJudged) {
            return true;
        }
        return super.onInterceptTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
//                lastX = event.getX();
//                lastY = event.getY();
//                startScrollX = getScrollX();
                break;
            case MotionEvent.ACTION_MOVE:
//                if (ignore) {
//                    ignore = false;
//                    break;
//                }
//                float curX = event.getX();
//                float dX = curX - lastX;
//                lastX = curX;
//                if (hasJudged) {
//
//                }
                break;
            case MotionEvent.ACTION_UP:
                float finalX = event.getX();
//                Log.i("classtableview","finalX-----------================="+finalX);
//                Log.i("classtableview","startX-----------================="+startX);
                if (finalX < startX && (startX - finalX ) > 200) {
                    mFragment.nextMonth();
                }  else if ((finalX - startX) > 200){
                    mFragment.previousMonth();
                }
                break;
            default:
                break;
        }
        return true;
    }

    public void setFragment(BaseFragment fragment){
        mFragment = (ScheduleFragment) fragment;
    }

    private void disallowParentsInterceptTouchEvent(ViewParent parent) {
        if (null == parent) {
            return;
        }
        parent.requestDisallowInterceptTouchEvent(true);
        disallowParentsInterceptTouchEvent(parent.getParent());
    }

    private void allowParentsInterceptTouchEvent(ViewParent parent) {
        if (null == parent) {
            return;
        }
        parent.requestDisallowInterceptTouchEvent(false);
        allowParentsInterceptTouchEvent(parent.getParent());
    }

}
