package com.ddlad.student.ui.agora;

import android.app.Activity;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.ddlad.student.R;
import com.ddlad.student.protocol.model.MessageInfo;

import java.util.ArrayList;


/**
 * Created by chen007 on 2017/11/6 0006.
 */
public class ChatRecordAdapter extends RecyclerView.Adapter<ChatRecordAdapter.ViewHolder> {

    private Activity mActivity;

    private ArrayList<MessageInfo> mInfos;

    public ChatRecordAdapter(Activity activity){
        this.mActivity = activity;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mActivity).inflate(R.layout.layout_chat_record_item,null);
        return new ViewHolder(view);
    }

    public ArrayList<MessageInfo> getmInfos() {
        return mInfos;
    }

    public void setmInfos(ArrayList<MessageInfo> mInfos) {
        this.mInfos = mInfos;
    }

    public void addItemInfo(MessageInfo info){
        if (mInfos == null){
            mInfos = new ArrayList<>();
        }
        mInfos.add(info);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        String content = mInfos.get(position).getFromName()+": "+mInfos.get(position).getData();
        SpannableStringBuilder style=new SpannableStringBuilder(content);
        int begin = mInfos.get(position).getFromName().length() +1;
        if (mInfos.get(position).getUserType() == 1){
            style.setSpan(new ForegroundColorSpan(Color.parseColor("#ff5151")),0,begin+1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        if (mInfos.get(position).getUserType() == 0){
            style.setSpan(new ForegroundColorSpan(Color.parseColor("#fbdd04")),0,begin+1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        }
        style.setSpan(new ForegroundColorSpan(Color.WHITE),begin+1,content.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        holder.content.setText(style);
    }

    @Override
    public int getItemCount() {
        if (mInfos == null){
            return 0;
        }
        return mInfos.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder{

        TextView content;

        public ViewHolder(View view) {
            super(view);
            content = (TextView) view.findViewById(R.id.content);
        }
    }
}
