package com.ddlad.student.protocol.http.request;




import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.model.MyAccountInfo;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-10-13.
 */
public class MyAccountRequest extends AbstractRequest<MyAccountInfo> {

    private static final String TAG = "AccountRequest";

    public MyAccountRequest(BaseFragment fragment, int loaderId,
                            AbstractCallbacks<MyAccountInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url,
                                          RequestParams requestParams) {
        return httpClient.getRequest(url, requestParams);
    }



//    protected String getFieldKey() {
//        return ProtocolConstants.JSON_FIELD_PROFILE;
//    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_PROFILE;
    }

    //getFieldKey(),
    @Override
    public MyAccountInfo processInBackground(ApiResponse<MyAccountInfo> response) {
        MyAccountInfo account = response.readRootValue(ProtocolConstants.JSON_FIELD_DATA,
                MyAccountInfo.class);
//        if (account != null) {
//            Log.i(TAG, "saveProfile:account.getUser().getName() "+account.getUser().getName());
//            Log.i(TAG, "saveProfile:account.getUser().getGrade() "+account.getUser().getGrade());
//            Log.i(TAG, "saveProfile:account.getUser().getProvince() "+account.getUser().getProvince());
//            DataCenter.saveProfile(account);
//        }
        return account;
    }

    public void perform(String user) {
        RequestParams param = getParams();
//        param.put(ProtocolConstants.PARAM_USER, user);
        super.perform();
    }
}