package com.ddlad.student.tools;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;


/**
 * Created by Albert
 * on 16-6-2.
 */
public class Toaster {
    //新增单例，避免重复显示, 不太重要，未设置线程安全
    private static Toast mToast;

    private Toaster(Context context, CharSequence text, int duration) {

    }

    public static void toastShort(int resId, Object... args) {
        toast(AppContext.getString(resId, args), Toast.LENGTH_SHORT,0);
    }

    public static void toastShort(int resId) {
        toast(AppContext.getString(resId), Toast.LENGTH_SHORT,0);
    }

    public static void  toastShort(String msg) {
        toast(msg, Toast.LENGTH_SHORT,0);
    }
    public static void toastShort(String msg,int i) {
        toast(msg, Toast.LENGTH_SHORT,i);
    }
    public static void toastLong(int resId) {
        toast(AppContext.getString(resId), Toast.LENGTH_LONG,0);
    }

    public static void toastLong(String msg) {
        toast(msg, Toast.LENGTH_LONG,0);
    }

    public static void toast(int resId, int duration) {
        toast(AppContext.getString(resId), duration,0);
    }
    private  static TextView textView ;

    private  static ImageView toast_image ;
    public static void toast(CharSequence charSequence, int duration, int i) {
        if (mToast == null){
//            mToast = Toast.makeText(AppContext.getContext(), charSequence, duration);
            View v = LayoutInflater.from(AppContext.getContext()).inflate(R.layout.layout_toast, null);
            textView = (TextView) v.findViewById(R.id.text);
            toast_image = (ImageView) v.findViewById(R.id.toast_image);
            textView.setText(charSequence);
            mToast = new Toast(AppContext.getContext());
            mToast.setDuration(duration);
            mToast.setView(v);
            mToast.setGravity(Gravity.CENTER, 0, 0);
            mToast.makeText(AppContext.getContext(),charSequence,duration);
        }else {
//            mToast.setText(charSequence);
            mToast.setGravity(Gravity.CENTER, 0, 0);
            textView.setText(charSequence);
            mToast.makeText(AppContext.getContext(),charSequence,duration);
        }
        toast_image.setVisibility(View.VISIBLE);
        if (i == 0){
            toast_image.setSelected(false);
        }
        if (i == 1){
            toast_image.setSelected(true);
        }
        if (i == 2){
            toast_image.setVisibility(View.GONE);
        }
        mToast.show();

    }

    public static void toast(String format, Object[] args, int duration) {
        toast(String.format(format, args), duration,0);
    }



    public static Toast getmToast() {
        return mToast;
    }

    public static void setmToast(Toast mToast) {
        Toaster.mToast = mToast;
    }

    public static ImageView getToast_image() {
        return toast_image;
    }

    public static void setToast_image(ImageView toast_image) {
        Toaster.toast_image = toast_image;
    }
}
