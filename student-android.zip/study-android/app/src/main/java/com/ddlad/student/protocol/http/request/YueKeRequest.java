package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.HomeWorkDetailsInfo;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

public class YueKeRequest extends AbstractRequest<HomeWorkDetailsInfo> {
    public YueKeRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<HomeWorkDetailsInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
//        return "/order/commit";
        return "course/apply";
    }

    @Override
    public HomeWorkDetailsInfo processInBackground(ApiResponse<HomeWorkDetailsInfo> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, HomeWorkDetailsInfo.class);
    }

    public void perform(String product) {
        RequestParams param = getParams();
//        param.put("product", product);
        param.put("cmId", product);
        super.perform();
    }
}
