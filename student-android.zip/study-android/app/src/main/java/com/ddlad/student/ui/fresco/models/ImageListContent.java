package com.ddlad.student.ui.fresco.models;


import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.ui.fresco.SelectorSettings;

import java.util.ArrayList;
import java.util.List;

public class ImageListContent {

    private boolean mReachMaxNumber = false;

    private final ArrayList<ImageItem> mImages = new ArrayList<ImageItem>();

    public void clear() {
        mImages.clear();
    }

    public void addItem(ImageItem item) {
        mImages.add(item);
    }

    public void addAll(List<ImageItem> items) {
        mImages.addAll(items);
    }

    public ArrayList<ImageItem> getImages() {
        return mImages;
    }

    public int size() {
        return CollectionUtil.isEmpty(mImages) ? 0 : mImages.size();
    }

    public int selectedSize() {
        return CollectionUtil.isEmpty(mSelectedImages) ? 0 : mSelectedImages.size();
    }

    private final ArrayList<String> mSelectedImages = new ArrayList<>();

    public void selectImage(String item) {
        mSelectedImages.add(item);
    }

    public ArrayList<String> getSelectedImages() {
        return mSelectedImages;
    }

    public boolean isImageSelected(String filename) {
        return mSelectedImages.contains(filename);
    }

    public void toggleImageSelected(String filename) {
        if (mSelectedImages.contains(filename)) {
            mSelectedImages.remove(filename);
        } else {
            mSelectedImages.add(filename);
        }
    }

    public boolean isReachMaxNumber() {
        return mReachMaxNumber;
    }

    public void setReachMaxNumber(boolean reach) {
        mReachMaxNumber = reach;
    }

    public static final ImageItem cameraItem = new ImageItem("", SelectorSettings.CAMERA_ITEM_PATH, 0);
}
