package com.ddlad.student.protocol.http.request;


import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.RegisterVerifyInfo;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.protocol.http.internal.ApiResponse;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-7-6.
 */
public class RegisterVerifyRequest extends AbstractRequest<RegisterVerifyInfo> {

    public RegisterVerifyRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<RegisterVerifyInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_REGISTER_VERIFY;
    }

    @Override
    public RegisterVerifyInfo processInBackground(ApiResponse<RegisterVerifyInfo> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, RegisterVerifyInfo.class);
    }

    public void perform(Object mobile, Object code) {
        RequestParams params = getParams();
        params.put("mobile", mobile);
        params.put("code", code);
        super.perform();
    }
}
