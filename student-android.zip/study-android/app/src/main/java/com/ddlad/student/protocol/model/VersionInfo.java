package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.primary.Log;

import java.io.IOException;

/**
 * Created by Albert
 * on 16-11-2.
 */
public class VersionInfo extends BaseInfo {

    private static final String TAG = "VersionInfo";

    private String mDownloadUrl;
    private String mNewVersion;
    private String mDate;
    private String desc;
    private String url;
    private String title;
    private boolean force;


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public boolean isForce() {
        return force;
    }

    public void setForce(boolean force) {
        this.force = force;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }


    public String getDownloadUrl() {
        return mDownloadUrl;
    }

    public void setDownloadUrl(String url) {
        this.mDownloadUrl = url;
    }

    public String getNewVersion() {
        return mNewVersion;
    }

    public void setNewVersion(String version) {
        this.mNewVersion = version;
    }

    public String getDate() {
        return mDate;
    }

    public void setDate(String date) {
        this.mDate = date;
    }

    public static VersionInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        VersionInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new VersionInfo();
                }

                if ("url".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.url = jsonParser.getText();
                    continue;
                }
                if ("desc".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.desc = jsonParser.getText();
                    continue;
                }
                if ("title".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.title = jsonParser.getText();
                    continue;
                }
                if ("force".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.force = jsonParser.getBooleanValue();
                    continue;
                }

                if ("id".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.id = jsonParser.getText();
                    continue;
                }

                if ("downloadUrl".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.mDownloadUrl = jsonParser.getText();
                    continue;
                }

                if ("date".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.mDate = jsonParser.getText();
                    continue;
                }

                if ("newVersion".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.mNewVersion = jsonParser.getText();
                    continue;
                }


                jsonParser.skipChildren();
            }
        }

        return info;
    }

    public static boolean compare(String newVersion, String oldVersion) {
        StringBuilder newBuilder = new StringBuilder(newVersion.replaceAll("\\.", "")).insert(1, '.');
        StringBuilder oldBuilder = new StringBuilder(oldVersion.replaceAll("\\.", "")).insert(1, '.');
        float newFloat = Float.parseFloat(newBuilder.toString());
        float oldFloat = Float.parseFloat(oldBuilder.toString());
        if (Log.DEBUG) {
            Log.d(TAG, "new version : " + newFloat + ", old version : " + oldFloat);
        }
        return newFloat > oldFloat;
    }

    public static enum ClientType {

        Android("android"), IOS("ios"),;

        private ClientType(String value) {
            this.mValue = value;
        }

        private String mValue;

        public String getValue() {
            return mValue;
        }
    }

}
