package com.ddlad.student.ui.course;

import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.request.CourseDetailsRequest;
import com.ddlad.student.protocol.http.request.YueKeRequest;
import com.ddlad.student.protocol.model.CourseDetailsInfo;
import com.ddlad.student.protocol.model.HomeWorkDetailsInfo;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.dialog.DialogBuilder;

/**
 * Created by chen007 on 2017/3/24 0024.
 */
public class LatestCourseDetailsFragment extends BaseFragment {

    private int mLoaderFeedBackId = ViewUtil.generateUniqueId();
    private int mYueKeBackId = ViewUtil.generateUniqueId();
    private String mCmId;

    private CourseDetailsInfo mInfo;

    private static float imageH = (ViewUtil.getScreenWidthPixels() - ViewUtil.dpToPx(40))*4/7;

    private static float bgH = imageH + ViewUtil.dpToPx(10);

//    private NetworkImageView mCourseImage;
    public com.facebook.drawee.view.SimpleDraweeView mImage;

    private TextView mCourseName;
    private TextView mCourseTime;
    private TextView mLevel;
    private TextView mIntroduction;
    private TextView appointment_course;
    private TextView suite_desc;

    private TextView pay_desc;
    private String productId;

    private ViewGroup bg_shadow_layout;


    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_latest_course_detail;
    }



    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle("课程详情");

//        mCourseImage = (NetworkImageView) contentView.findViewById(R.id.item_image);
        mImage = (com.facebook.drawee.view.SimpleDraweeView) contentView.findViewById(R.id.item_image);
        mCourseName = (TextView) contentView.findViewById(R.id.course_name);

        mCourseTime = (TextView) contentView.findViewById(R.id.item_class_time);
        mLevel = (TextView) contentView.findViewById(R.id.item_course_level);
        mIntroduction = (TextView) contentView.findViewById(R.id.course_desc);
        pay_desc = (TextView) contentView.findViewById(R.id.pay_desc);
        appointment_course = (TextView) contentView.findViewById(R.id.appointment_course);
        suite_desc = (TextView) contentView.findViewById(R.id.suite_desc);
        bg_shadow_layout = (ViewGroup) contentView.findViewById(R.id.bg_shadow_layout);
        RelativeLayout.LayoutParams paramsImage = (RelativeLayout.LayoutParams) mImage.getLayoutParams();
        paramsImage.height = (int) imageH;
        mImage.setLayoutParams(paramsImage);

//        RelativeLayout.LayoutParams paramsBg = (RelativeLayout.LayoutParams)bg_shadow_layout.getLayoutParams();
//        paramsBg.height = (int) bgH;
//        bg_shadow_layout.setLayoutParams(paramsBg);
    }




    @Override
    protected void onInitData(Bundle bundle) {
        mCmId = (String) bundle.get(ProtocolConstants.PARAM_CMID);
        requestData();
        super.onInitData(bundle);
    }

    private void requestData() {
        CourseDetailsRequest courseDetailsRequest = new CourseDetailsRequest(this, getDefaultLoaderId(), new AbstractCallbacks<CourseDetailsInfo>() {
            @Override
            protected void onSuccess(CourseDetailsInfo courseDetailsInfo) {
                mInfo = courseDetailsInfo;
                String url =  mInfo.getCourse().getImage().getPattern();
                Uri uri = Uri.parse(url.substring(url.indexOf("http"),url.indexOf("@{w}w")));
                mImage.setImageURI(uri);
//                String url =  mInfo.getCourse().getImage().getPattern();
//                mCourseImage.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}w")));;
                mCourseName.setText(mInfo.getCourse().getName());

//                mTeacherName.setText(mInfo.getCourse().getTeacher());
//                mPrice.setText(mInfo.getCourse().getPrice());
                mLevel.setText(mInfo.getCourse().getLevel()+"");
                mIntroduction.setText(mInfo.getCourse().getDesc());
                mIntroduction.setText(Html.fromHtml(mInfo.getCourse().getDesc()));
                //                mCourseTime  返回的数据中没有时间
                mCourseTime.setText(mInfo.getCourse().getTotalCnt()+"节课");

                suite_desc.setText(mInfo.getCourse().getSuitableCrowds()+"");

                StringBuffer sb = new StringBuffer();
                for (int i = 0;i<mInfo.getCourse().getSubNotes().size();i++){
                    sb.append(mInfo.getCourse().getSubNotes().get(i));
                }
                pay_desc.setText(sb.toString()+"");

                appointment_course.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        yueke();

                    }
                });
            }
        });
        courseDetailsRequest.perform(mCmId);
    }

    public void yueke(){
        YueKeRequest request = new YueKeRequest(this, mYueKeBackId, new AbstractCallbacks<HomeWorkDetailsInfo>() {
            @Override
            protected void onSuccess(HomeWorkDetailsInfo info) {
                showDialog();
            }

            @Override
            protected void onFail(ApiResponse<HomeWorkDetailsInfo> response) {
                Toaster.toastShort(response.getErrorDescription());
            }
        });
        request.perform(mInfo.getCourse().getCmId());
    }

    private void showDialog() {
        final DialogBuilder dialogBuilder = new DialogBuilder(getActivity());

        dialogBuilder.setCanceledOnTouchOutside(false);
        dialogBuilder.setTitle("提示")
                .setMessage("您已约课成功，稍后我们的工作人员将会联系您进行确认!")
                .setMessageGravity(Gravity.CENTER)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogBuilder.dismiss();
                    }
                });
        dialogBuilder.create().show();
    }


}
