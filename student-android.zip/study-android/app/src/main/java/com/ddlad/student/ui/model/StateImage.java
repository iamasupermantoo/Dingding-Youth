package com.ddlad.student.ui.model;

/**
 * Created by Albert
 * on 16-10-27.
 */
public class StateImage {

    private String id;
    private ImageState state = ImageState.Pending;

    public StateImage(String id, ImageState state) {
        this.id = id;
        this.state = state;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ImageState getState() {
        return state;
    }

    public void setState(ImageState state) {
        this.state = state;
    }

    public enum ImageState {
        Uploading, Uploaded, Pending;
    }
}
