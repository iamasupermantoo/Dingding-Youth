package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ddlad.student.ui.model.MultiImageInfo;
import com.ddlad.student.protocol.http.internal.CustomObjectMapper;

import java.io.IOException;
import java.io.Serializable;

/**
 * Created by chenjianing on 2017/3/20 0020.
 */
public class Info implements Serializable{

    private int gender;

    private String id;

    private MultiImageInfo headImage;

    private String name;

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String signature;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public MultiImageInfo getHeadImage() {
        return headImage;
    }

    public void setHeadImage(MultiImageInfo headImage) {
        this.headImage = headImage;
    }

    public String serialize() {
        try {
            ObjectMapper mapper = CustomObjectMapper.getInstance();
            return mapper.writeValueAsString(this);
        } catch (JsonGenerationException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static Info deserialize(String accountJson) {

        try {
            return CustomObjectMapper.getInstance().readValue(accountJson, Info.class);
        } catch (Throwable t) {
            t.printStackTrace();
        }

        return null;
    }
}
