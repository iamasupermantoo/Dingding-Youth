package com.ddlad.student.protocol.convert;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;

import com.ddlad.student.primary.Prefs;
import com.ddlad.student.protocol.model.Account;
import com.ddlad.student.protocol.model.UserInfo;
import com.ddlad.student.push.service.Push;
import com.ddlad.student.tools.StringUtil;
import com.ddlad.student.ui.common.BaseActivity;
import com.ddlad.student.ui.sign.SignActivity;


/**
 * Created by Albert
 * on 16-7-8.
 */
public class DataCenter {

    private static final String TAG = "DATA_CENTER";
    private static Account sAccount;

    private static Account createAccountIfEmpty() {

        if (sAccount == null) {
            sAccount = new Account();
        }

        return sAccount;
    }

    public static void saveProfile(Account account) {
        sAccount.setUser(account.getUser());
        sAccount.getUser().setProvince(account.getUser().getProvince());
        sAccount.getUser().setGender(account.getUser().getGender());
        sAccount.getUser().setGrade(account.getUser().getGrade());
        sAccount.getUser().setName(account.getUser().getName());
        sAccount.getUser().setRegion(account.getUser().getRegion());
        sAccount.getUser().setSignature(account.getUser().getSignature());
        Log.i(TAG, "saveProfile:account.getUser().getName() "+account.getUser().getName());
        Log.i(TAG, "saveProfile:account.getUser().getGrade() "+account.getUser().getGrade());
        Log.i(TAG, "saveProfile:account.getUser().getProvince() "+account.getUser().getProvince());
        if (account.getZ() != null){
            sAccount.setZ(account.getZ());
        }
        saveAccount(sAccount);
    }

    public static boolean saveAccount(Account account) {
        if (account != null) {
            sAccount = account;
        }
        sAccount = createAccountIfEmpty();
        String accountJson = sAccount.serialize();
        if (TextUtils.isEmpty(accountJson)) {
            return false;
        } else {
            return Prefs.getInstance().saveAccount(accountJson);
        }
    }

    public static Account getAccount() {

        if (sAccount == null) {
            sAccount = Account.deserialize(Prefs.getInstance().getAccount());
        }

        return createAccountIfEmpty();
    }

    public static UserInfo getUser() {
        return getAccount().getUser();
    }

    private static void clearAccount() {
        Prefs.getInstance().clearAccount();
        sAccount = null;
    }

    public static void saveLogin() {
        Prefs.getInstance().saveLogin(true);
        saveAccount(null);
    }

    public static void saveLogin(Account account) {
        Prefs.getInstance().saveLogin(true);
        saveAccount(account);
    }

    public static boolean isLogin() {
        return Prefs.getInstance().isLogin();
    }

    private static void clearLogin() {
        Prefs.getInstance().clearLogin();
    }

    public static boolean isCurrentUser(String userId) {
        if (StringUtil.isEmpty(userId) || !isLogin()) {
            return false;
        } else {
            return StringUtil.equals(userId, getAccount().getUser().getId());
        }
    }

    public static void logout(Context context) {
        Push.getInstance().unbindPush();
        clearAccount();
        clearLogin();
        context.sendBroadcast(new Intent(BaseActivity.ACTION_FINISH_ME));
        SignActivity.show(context, Intent.FLAG_ACTIVITY_NEW_TASK);
    }
}
