package com.ddlad.student.ui.choice;

import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.protocol.model.CoursesLiveBean;
import com.ddlad.student.ui.common.AbstractAdapter;


/**
 * Created by Albert
 * on 17-6-2.
 */

public class LiveCourseListAdapter extends AbstractAdapter<CoursesLiveBean> {

    private LiveCourseListItemAdapter mItemAdapter;
    private LiveCourseListFragment mFragment;
    private int type;

    public LiveCourseListAdapter(LiveCourseListFragment fragment) {
        super(fragment);
        mFragment = fragment;
        mItemAdapter = new LiveCourseListItemAdapter(mFragment);
    }

    public LiveCourseListAdapter(LiveCourseListFragment fragment, int type) {
        super(fragment);
        mFragment = fragment;
        mItemAdapter = new LiveCourseListItemAdapter(mFragment);
        this.type = type;
    }

    @Override
    public CoursesLiveBean getItem(int position) {
        return mList.get(position);
    }

    @Override
    protected View createView(int position, ViewGroup parent) {
        return mItemAdapter.createView(parent);
    }

    @Override
    protected void bindView(int position, View view) {
        mItemAdapter.bindView(view, getItem(position), 0,position,type);
    }


}
