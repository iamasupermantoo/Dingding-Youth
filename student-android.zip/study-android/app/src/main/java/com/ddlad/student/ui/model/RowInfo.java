package com.ddlad.student.ui.model;

import android.view.View;

import com.ddlad.student.protocol.model.BaseInfo;
import com.ddlad.student.tools.CollectionUtil;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class RowInfo<T extends BaseInfo> {

    private List<T> mList;

    private int mType;

    private String mSeparatorText;
    private String mSeparatorBtnText;

    private View.OnClickListener mOnClickListener;

    public RowInfo() {
        mList = new ArrayList<T>(2);
    }

    public RowInfo(int count) {
        mList = new ArrayList<T>(count);
    }

    public RowInfo(int count, int type) {
        mList = new ArrayList<T>(count);
        mType = type;
    }

    public RowInfo(String separatorText, int type) {
        mSeparatorText = separatorText;
        mType = type;
    }

    public RowInfo(String separatorText, String btnText, int type) {
        mSeparatorText = separatorText;
        mSeparatorBtnText = btnText;
        mType = type;
    }

    public RowInfo(T info) {
        mList = new ArrayList<T>(1);
        mList.add(info);
        mType = info.getType();
    }

    public RowInfo(List<T> list) {
        mList = list;
        if (!CollectionUtil.isEmpty(list)) {
            mType = list.get(0).getType();
        }
    }

    public View.OnClickListener getOnClickListener() {
        return mOnClickListener;
    }

    public void setOnClickListener(View.OnClickListener listener) {
        this.mOnClickListener = listener;
    }

    public T get(int i) {
        return CollectionUtil.isEmpty(mList) ? null : mList.get(i);
    }


    public int getType() {
        return mType;
    }

    public void setType(int mType) {
        this.mType = mType;
    }

    public String getSeparatorText() {
        return mSeparatorText;
    }

    public void setSeparatorText(String text) {
        this.mSeparatorText = text;
    }

    public String getSeparatorBtnText() {
        return mSeparatorBtnText;
    }

    public void setSeparatorBtnText(String mSeparatorBtnText) {
        this.mSeparatorBtnText = mSeparatorBtnText;
    }

    public List<T> getList() {
        return mList;
    }

    public void setList(List<T> list) {
        this.mList = list;
    }

    public void add(T info) {
        mList.add(info);
    }

    public void addAll(Collection<T> list) {
        mList.addAll(list);
    }

    public int listSize() {
        return mList.size();
    }

    public boolean isEmpty() {
        return CollectionUtil.isEmpty(mList);
    }

}
