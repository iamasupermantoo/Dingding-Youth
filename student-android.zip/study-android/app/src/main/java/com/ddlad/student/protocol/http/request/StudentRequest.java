package com.ddlad.student.protocol.http.request;


import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.request.AccountRequest;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.protocol.model.Account;

/**
 * Created by Albert
 * on 16-11-15.
 */
public class StudentRequest extends AccountRequest {

    public StudentRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<Account> apiCallbacks) {
        super(fragment, loaderId, apiCallbacks);
    }

    @Override
    protected String getFieldKey() {
        return ProtocolConstants.PARAM_INFO;
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_STUDENT;
    }
}
