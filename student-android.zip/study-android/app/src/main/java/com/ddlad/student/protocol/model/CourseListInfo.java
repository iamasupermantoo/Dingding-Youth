package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.List;

/**
 * Created by chenjianing on 2017/3/29 0029.
 */
public class CourseListInfo {

        private LessonsBean lessons;

        public LessonsBean getLessons() {
            return lessons;
        }

        public void setLessons(LessonsBean lessons) {
            this.lessons = lessons;
        }

        public static class LessonsBean {
            private boolean hasNext;

            private List<ListBean> list;

            public boolean isHasNext() {
                return hasNext;
            }

            public void setHasNext(boolean hasNext) {
                this.hasNext = hasNext;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private String time;
                private String date;
                private int status;
                private String course;
                private String student;
                private int studentReactionStatus;
                private int homeworkStatus;
                private String label;
                private String lid;
                private String cid;
                private int teacherReactionStatus;

                public String getTime() {
                    return time;
                }

                public void setTime(String time) {
                    this.time = time;
                }

                public String getDate() {
                    return date;
                }

                public void setDate(String date) {
                    this.date = date;
                }

                public int getStatus() {
                    return status;
                }

                public void setStatus(int status) {
                    this.status = status;
                }

                public String getCourse() {
                    return course;
                }

                public void setCourse(String course) {
                    this.course = course;
                }

                public String getStudent() {
                    return student;
                }

                public void setStudent(String student) {
                    this.student = student;
                }

                public int getStudentReactionStatus() {
                    return studentReactionStatus;
                }

                public void setStudentReactionStatus(int studentReactionStatus) {
                    this.studentReactionStatus = studentReactionStatus;
                }

                public int getHomeworkStatus() {
                    return homeworkStatus;
                }

                public void setHomeworkStatus(int homeworkStatus) {
                    this.homeworkStatus = homeworkStatus;
                }

                public String getLabel() {
                    return label;
                }

                public void setLabel(String label) {
                    this.label = label;
                }

                public String getLid() {
                    return lid;
                }

                public void setLid(String lid) {
                    this.lid = lid;
                }

                public String getCid() {
                    return cid;
                }

                public void setCid(String cid) {
                    this.cid = cid;
                }

                public int getTeacherReactionStatus() {
                    return teacherReactionStatus;
                }

                public void setTeacherReactionStatus(int teacherReactionStatus) {
                    this.teacherReactionStatus = teacherReactionStatus;
                }
                public static ListBean fromJsonParser(JsonParser jsonParser) throws IOException {

                    ListBean info = null;

                    if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

                        while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                            String fieldName = jsonParser.getCurrentName();

                            if (fieldName == null) {
                                continue;
                            }

                            if (info == null) {
                                info = new ListBean();
                            }

                            if ("status".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.status = jsonParser.getIntValue();
                                continue;
                            }
                            if ("studentReactionStatus".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.studentReactionStatus = jsonParser.getIntValue();
                                continue;
                            }
                            if ("homeworkStatus".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.homeworkStatus = jsonParser.getIntValue();
                                continue;
                            }
                            if ("teacherReactionStatus".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.teacherReactionStatus = jsonParser.getIntValue();
                                continue;
                            }
                            if ("time".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.time = jsonParser.getText();
                                continue;
                            }
                            if ("date".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.date = jsonParser.getText();
                                continue;
                            }
                            if ("course".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.course = jsonParser.getText();
                                continue;
                            }
                            if ("ddlad".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.student = jsonParser.getText();
                                continue;
                            }
                            if ("label".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.label = jsonParser.getText();
                                continue;
                            }
                            if ("lid".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.lid = jsonParser.getText();
                                continue;
                            }
                            if ("cid".equals(fieldName)) {
                                jsonParser.nextToken();
                                info.cid = jsonParser.getText();
                                continue;
                            }
                            jsonParser.skipChildren();
                        }
                    }
                    return info;
                }
            }
            public static LessonsBean fromJsonParser(JsonParser jsonParser) throws IOException {

                LessonsBean info = null;

                if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

                    while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                        String fieldName = jsonParser.getCurrentName();

                        if (fieldName == null) {
                            continue;
                        }

                        if (info == null) {
                            info = new LessonsBean();
                        }

                        if ("hasNext".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.hasNext = jsonParser.getBooleanValue();
                            continue;
                        }
                        if ("list".equals(fieldName)) {
                            jsonParser.nextToken();
                            ObjectMapper mapper = new ObjectMapper();
                            info.list = mapper.readValue(jsonParser, List.class);
                            continue;
                        }
                        jsonParser.skipChildren();
                    }
                }
                return info;
            }
        }

    public static CourseListInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        CourseListInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new CourseListInfo();
                }

                if ("lessons".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.lessons = LessonsBean.fromJsonParser(jsonParser);
                    continue;
                }
                jsonParser.skipChildren();
            }
        }
        return info;
    }
}
