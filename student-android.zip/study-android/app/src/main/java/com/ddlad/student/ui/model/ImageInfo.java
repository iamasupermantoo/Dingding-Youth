package com.ddlad.student.ui.model;

import android.graphics.Bitmap;
import android.net.Uri;
import android.text.TextUtils;


import com.ddlad.student.protocol.model.BaseInfo;

import java.util.UUID;

public class ImageInfo extends BaseInfo {

    public ImageInfo() {

    }

    public ImageInfo(String imageId, int progress) {
        setId(imageId);
        setProgress(progress);
        setState(ImageState.Uploaded);
    }

    public ImageInfo(Uri uri) {
        setUri(uri);
        setId(UUID.randomUUID().toString());
    }

    public ImageInfo(String path) {
        setPath(path);
        setId(UUID.randomUUID().toString());
    }

    private int mWidth;

    private int mHeight;

    private Bitmap mBitmap;

    private Uri mUri;

    private String mPath;

    private int mProgress;

    private ImageState mState = ImageState.Pending;

    public Bitmap getBitmap() {
        return mBitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.mBitmap = bitmap;
    }

    public int getWidth() {
        return mWidth;
    }

    public void setWidth(int mWidth) {
        this.mWidth = mWidth;
    }

    public int getHeight() {
        return mHeight;
    }

    public void setHeight(int height) {
        this.mHeight = height;
    }

    public void setUri(Uri uri) {
        this.mUri = uri;
        this.mPath = uri.getPath();
    }

    public Uri getUri() {
        return mUri;
    }

    public String getPath() {
        return mPath;
    }

    public void setPath(String path) {
        this.mPath = path;
    }

    public int getProgress() {
        return mProgress;
    }

    public void setProgress(int progress) {
        this.mProgress = progress;
    }

    public ImageState getState() {
        return mState;
    }

    public void setState(ImageState state) {
        this.mState = state;
    }

    public boolean isFull() {
        return !TextUtils.isEmpty(id) && mState == ImageState.Uploaded;
    }

    public void release() {
        if (mBitmap != null && !mBitmap.isRecycled()) {
            mBitmap.recycle();
        }
        mBitmap = null;
        mUri = null;
    }

    public enum ImageState {
        Uploading, Uploaded, Pending;
    }
}
