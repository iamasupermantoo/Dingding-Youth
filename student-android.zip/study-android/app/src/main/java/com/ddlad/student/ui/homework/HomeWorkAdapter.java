package com.ddlad.student.ui.homework;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.R;

/**
 * Created by Administrator on 2017/3/17 0017.
 */
public class HomeWorkAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {



    public static interface OnRecyclerViewItemClickListener{
        void onItemClick(View view, int position);
    }

    private OnRecyclerViewItemClickListener mOnItemClickListener = null;

    public void setmOnItemClickListener(OnRecyclerViewItemClickListener onItemClickListener){
        mOnItemClickListener = onItemClickListener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_job_list_item,null);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 10;
    }
    class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView mJobName;
        private TextView mLessonName;
        private TextView mTeacher;
        private TextView mJobType;
        private TextView mPending;

        private OnRecyclerViewItemClickListener onItemClickListener;

        public MyViewHolder(View itemView) {
            super(itemView);
            mJobName = (TextView) itemView.findViewById(R.id.job_item_name);
            mLessonName = (TextView) itemView.findViewById(R.id.lesson_item_name);
            mJobType = (TextView) itemView.findViewById(R.id.job_type);
            mPending = (TextView) itemView.findViewById(R.id.pending_job);
            mTeacher = (TextView) itemView.findViewById(R.id.lessons_item_teacher);
        }

    }
}
