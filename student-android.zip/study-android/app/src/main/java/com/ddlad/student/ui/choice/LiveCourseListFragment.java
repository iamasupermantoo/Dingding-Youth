package com.ddlad.student.ui.choice;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.R;
import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.request.BaseListRequest;
import com.ddlad.student.protocol.http.request.LCourseMetaListRequest;
import com.ddlad.student.protocol.http.request.LLiveCourseListRequest;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.CoursesLiveBean;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.common.BaseListFragment;

/**
 * Created by chen007 on 2017/11/7 0007.
 */
public class LiveCourseListFragment extends BaseListFragment<CoursesLiveBean> {


    private int type;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_live_course_list;
    }

    @Override
    protected void onInitData(Bundle bundle) {
        if (bundle != null){
            type = bundle.getInt("type");
        }
        if (getArguments() != null){
            String fromWhere = getArguments().getString("fromWhere");
            if ("DiscoverFragment".equals(fromWhere)){
                type = 4;
            }
        }


    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setNewSwitchSelect(false);
        if (type == 1){
            mActionbar.setTitle("试听课程");
        }
        if (type == 2){
            mActionbar.setTitle("开课信息");
        }
        if (type == 3){
            mActionbar.setTitle("资讯");
        }


    }

    @Override
    protected BaseListRequest makeRequest(AbstractStreamingCallbacks<AbstractListResponse<CoursesLiveBean>> streamingApiCallbacks) {
        return new LLiveCourseListRequest(this, ViewUtil.generateUniqueId(), streamingApiCallbacks){
            @Override
            protected String getBasePath() {
                if (type == 1){
                    return "/recommend/trials";
                }
                if (type == 2){
                    return "/recommend/opencourses";
                }
                if (type == 3){
                    return "/recommend/informations";
                }
                if (type == 4){
                    return "opencourse/meta/list";
                }
                return super.getBasePath();
            }

            @Override
            protected String getFieldKey() {
                if (type == 1){
                    return "trials";
                }
                if (type == 2){
                    return "opencourses";
                }
                if (type == 3){
                    return "informations";
                }
                if (type == 3){
                    return "opencourses";
                }
                return super.getFieldKey();
            }
        };
    }

    @Override
    protected void performRequest() {
        ((LLiveCourseListRequest)mDefaultRequest).perform();
    }

    @Override
    protected boolean isNeedFetch() {
        return true;
    }

    @Override
    protected AbstractAdapter getAdapter() {
        if(mAdapter == null){
            mAdapter = new LiveCourseListAdapter(this,type);
        }
        return mAdapter;
    }


    @Override
    protected void showEmptyView() {

        if (mEmptyView == null) {
            mEmptyView = (ViewGroup) LayoutInflater.from(getActivity()).inflate(R.layout.layout_empty_footer, null);
            mListView.addFooterView(mEmptyView, null, false);
        }

        if (mAdapter == null || mAdapter.isEmpty()) {
            mEmptyView.setVisibility(View.VISIBLE);
        } else {
            hideEmptyView();
        }

    }

    @Override
    protected void hideEmptyView() {
        if (mEmptyView != null) {
            mListView.removeFooterView(mEmptyView);
        }
        mEmptyView = null;
    }

}
