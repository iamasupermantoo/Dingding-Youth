package com.ddlad.student.tools;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;
import android.telephony.TelephonyManager;
import android.text.TextUtils;


import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ApiUrlHelper;

import java.io.IOException;
import java.io.InputStream;

import ch.boye.httpclientandroidlib.HttpEntity;
import ch.boye.httpclientandroidlib.HttpResponse;
import ch.boye.httpclientandroidlib.HttpStatus;
import ch.boye.httpclientandroidlib.entity.mime.FormBodyPart;
import ch.boye.httpclientandroidlib.entity.mime.MultipartEntity;
import ch.boye.httpclientandroidlib.entity.mime.content.InputStreamBody;
import ch.boye.httpclientandroidlib.util.EntityUtils;

/**
 * Created by Albert
 * on 16-6-2.
 */
public class NetworkUtil {
    private static final String TAG = "Network";

    /**
     * 接入方式：0 NONE
     */
    public static final int APN_NONE = 0;

    /**
     * 接入方式：1 CMWAP
     */
    public static final int APN_PROXY = 1;

    /**
     * 接入方式：2 CMNET
     */
    public static final int APN_DIRECT = 2;

    public enum NetworkType {
        NETWORK_UNKNOWN, NETWORK_NONE, NETWORK_WIFI, NETWORK_MOBILE, NETWORK_2G, NETWORK_3G
    }

    private static String hostIp = null;

    private static int hostPort = 0;

    //    private static final Uri PREFERRED_APN_URI = Uri
    //            .parse("content://telephony/carriers/preferapn");

    /**
     * 获取接入点的相关信息：1、CMWAP，2、CMNET
     */
    public static int getAccessPointType(Context context) {

        ConnectivityManager mConnectivity = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        // 区分是WIFI网络还是移动手机网络
        NetworkInfo info = mConnectivity.getActiveNetworkInfo();

        if ((info != null) && info.isAvailable()) {
            if (StringUtil.equalsIgnoreCase(info.getTypeName(), "mobile")) {

                if (Util.hasHoneycomb()) {
                    hostIp = System.getProperty("http.proxyHost");
                    String port = System.getProperty("http.proxyPort");
                    hostPort = !TextUtils.isEmpty(port) ? NumberUtil.toInt(port) : -1;
                } else {
                    hostIp = Proxy.getHost(context);
                    hostPort = Proxy.getPort(context);
                }

                // 使用代理了
                if (!TextUtils.isEmpty(hostIp) && (hostPort != 0)) {
                    // 客户端是否使用代理
                    return APN_PROXY;
                } else {
                    return APN_DIRECT;
                }
                //            } else if (info.getTypeName().toLowerCase().equals("wifi")) {
                //                return APN_DIRECT;
            } else {
                return APN_DIRECT;
            }
        }
        return APN_NONE;
    }

    public static String getHostIp() {
        return hostIp;
    }

    public static int getHostPort() {
        return hostPort;
    }

    /**
     * 获取网络类型：-1、未知，0、无网络，1、WiFi，2、移动网络，3、2G（移动网络），4、3G（移动网络）
     */
    public static NetworkType getNetworkType(Context context) {

        NetworkType networkType = NetworkType.NETWORK_UNKNOWN;

        ConnectivityManager mConnectivity = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        // 区分是WIFI网络还是移动手机网络
        NetworkInfo info = mConnectivity.getActiveNetworkInfo();

        if ((info != null) && info.isAvailable()) {
            if (StringUtil.equalsIgnoreCase(info.getTypeName(), "wifi")) {
                networkType = NetworkType.NETWORK_WIFI;
            } else if (StringUtil.equalsIgnoreCase(info.getTypeName(), "mobile")) {
                networkType = NetworkType.NETWORK_MOBILE;
                // 然后根据TelephonyManager来获取网络类型，判断当前是2G还是3G网络
                TelephonyManager mTelephonyManager = (TelephonyManager) context
                        .getSystemService(Context.TELEPHONY_SERVICE);
                int netType = mTelephonyManager.getNetworkType();
                if (netType == TelephonyManager.NETWORK_TYPE_UNKNOWN) {
                    networkType = NetworkType.NETWORK_UNKNOWN;
                }
                if ((netType == TelephonyManager.NETWORK_TYPE_GPRS)
                        || (netType == TelephonyManager.NETWORK_TYPE_EDGE)) {
                    networkType = NetworkType.NETWORK_2G;
                } else {
                    networkType = NetworkType.NETWORK_3G;
                }
            }
        } else {
            networkType = NetworkType.NETWORK_NONE;
        }
        return networkType;
    }

    public static boolean isWiFi() {
        return (getNetworkType(AppContext.getContext()) == NetworkType.NETWORK_WIFI);
    }

    public static boolean isMobileNetwork() {
        return (getNetworkType(AppContext.getContext()) == NetworkType.NETWORK_MOBILE);
    }

    public static String getNetworkStringByType(NetworkType networkType) {
        String networkString = "Unknown";
        switch (networkType) {
            case NETWORK_NONE:
                networkString = "None";
                break;
            case NETWORK_WIFI:
                networkString = "WiFi";
                break;
            case NETWORK_MOBILE:
                networkString = "Mobile";
                break;
            case NETWORK_2G:
                networkString = "2G";
                break;
            case NETWORK_3G:
                networkString = "3G";
                break;
            default:
                networkString = "Unknown";
                break;
        }
        return networkString;
    }

    //    public void getApn(Context context) {
    //        Uri PREFERRED_APN_URI = Uri.parse("content://telephony/carriers/preferapn");
    //        Cursor cursor = context.getContentResolver().query(PREFERRED_APN_URI,
    //                new String[] { "_id", "apn", "type" }, null, null, null);
    //        cursor.moveToFirst();
    //
    //        long id = cursor.getLong(0);
    //        String apn = cursor.getString(1);
    //        String type = cursor.getString(2);
    //        Log.v(TAG, "" + id);
    //        Log.v(TAG, "" + apn);
    //        Log.v(TAG, "" + type);
    //    }

    //    public ApnNode getCurApnNode(Context context) {
    //        String id = "";
    //        String apn = "";
    //        String proxy = "";
    //        String name = "";
    //        String port = "";
    //        String mcc = "";
    //        String mnc = "";
    //        String numeric = "";
    //        String type = "";
    //        ApnNode apnNode = new ApnNode();
    //        Cursor mCursor = context.getContentResolver().query(PREFERRED_APN_URI, null, null, null,
    //                null);
    //        if (mCursor == null) {
    //            return null;
    //        }
    //        while ((mCursor != null) && mCursor.moveToFirst()) {
    //            id = mCursor.getString(mCursor.getColumnIndex("_id"));
    //            name = mCursor.getString(mCursor.getColumnIndex("name"));
    //            apn = mCursor.getString(mCursor.getColumnIndex("apn")).toLowerCase();
    //            proxy = mCursor.getString(mCursor.getColumnIndex("proxy"));
    //            port = mCursor.getString(mCursor.getColumnIndex("port"));
    //            mcc = mCursor.getString(mCursor.getColumnIndex("mcc"));
    //            mnc = mCursor.getString(mCursor.getColumnIndex("mnc"));
    //            numeric = mCursor.getString(mCursor.getColumnIndex("numeric"));
    //            type = mCursor.getString(mCursor.getColumnIndex("type"));
    //        }
    //        apnNode.setId(id);
    //        apnNode.setApn(apn);
    //        apnNode.setName(name);
    //        apnNode.setProxy(proxy);
    //        apnNode.setPort(port);
    //        apnNode.setMcc(mcc);
    //        apnNode.setMnc(mnc);
    //        apnNode.setNumeric(numeric);
    //        apnNode.setNumeric(type);
    //        return apnNode;
    //    }

    //    public static class ApnNode {
    //
    //        String id = "";
    //
    //        String apn = "";
    //
    //        String proxy = "";
    //
    //        String name = "";
    //
    //        String port = "";
    //
    //        String mcc = "";
    //
    //        String mnc = "";
    //
    //        String numeric = "";
    //
    //        String type = "";
    //
    //        ApnNode() {
    //
    //        }
    //
    //        public String getType() {
    //            return type;
    //        }
    //
    //        public void setType(String type) {
    //            if ((type == null) || "".equals(type)) {
    //                this.type = "null";
    //            } else {
    //                this.type = type;
    //            }
    //        }
    //
    //        public String getId() {
    //            return id;
    //        }
    //
    //        public void setId(String id) {
    //            if ((id == null) || "".equals(id)) {
    //                this.id = "null";
    //            } else {
    //                this.id = id;
    //            }
    //        }
    //
    //        public String getApn() {
    //            return apn;
    //        }
    //
    //        public void setApn(String apn) {
    //            if ((apn == null) || "".equals(apn)) {
    //                this.apn = "null";
    //            } else {
    //                this.apn = apn;
    //            }
    //        }
    //
    //        public String getProxy() {
    //            return proxy;
    //        }
    //
    //        public void setProxy(String proxy) {
    //            if ((proxy == null) || "".equals(proxy)) {
    //                this.proxy = "null";
    //            } else {
    //                this.proxy = proxy;
    //            }
    //        }
    //
    //        public String getName() {
    //            return name;
    //        }
    //
    //        public void setName(String name) {
    //            if ((name == null) || "".equals(name)) {
    //                this.name = "null";
    //            } else {
    //                this.name = name;
    //            }
    //        }
    //
    //        public String getPort() {
    //            return port;
    //        }
    //
    //        public void setPort(String port) {
    //            if ((port == null) || "".equals(port)) {
    //                this.port = "null";
    //            } else {
    //                this.port = port;
    //            }
    //        }
    //
    //        public String getMcc() {
    //            return mcc;
    //        }
    //
    //        public void setMcc(String mcc) {
    //            if ((mcc == null) || "".equals(mcc)) {
    //                this.mcc = "null";
    //            } else {
    //                this.mcc = mcc;
    //            }
    //        }
    //
    //        public String getMnc() {
    //            return mnc;
    //        }
    //
    //        public void setMnc(String mnc) {
    //            if ((mnc == null) || "".equals(mnc)) {
    //                this.mnc = "null";
    //            } else {
    //                this.mnc = mnc;
    //            }
    //        }
    //
    //        public String getNumeric() {
    //            return numeric;
    //        }
    //
    //        public void setNumeric(String numeric) {
    //            if ((numeric == null) || "".equals(numeric)) {
    //                this.numeric = "null";
    //            } else {
    //                this.numeric = numeric;
    //            }
    //        }
    //
    //    }

    /**
     * Workaround for bug pre-Froyo, see here for more info:
     * http://android-
     * developers.blogspot.com/2011/09/androids-http-clients.html
     */
    public static void disableConnectionReuseIfNecessary() {
        // HTTP connection reuse which was buggy pre-froyo
        if (!Util.hasFroyo()) {
            System.setProperty("http.keepAlive", "false");
        }
    }

    public static boolean is3GOrWifi(Context context) {
        NetworkType networkType = NetworkUtil.getNetworkType(context);
        return ((networkType == NetworkType.NETWORK_3G) || (networkType == NetworkType.NETWORK_WIFI));
    }

    public static boolean sendGzipWithRSA(String key, String fileName, String url)
            throws IllegalStateException, IOException {
        ApiHttpClient apiHttpClient = ApiHttpClient.getInstance();
        InputStream input = AppContext.getContext().openFileInput(fileName);

        InputStreamBody inputStreamBody = new InputStreamBody(input, fileName);
        //        inputStreamBody.
        FormBodyPart part = new FormBodyPart(key, inputStreamBody);

        part.getHeader().removeFields("Content-Transfer-Encoding");
        part.addField("Content-Transfer-Encoding", "x-gzip");

        MultipartEntity gzipHttpEntity = new MultipartEntity();
        gzipHttpEntity.addPart(part);

        HttpResponse httpResponse = apiHttpClient.post(ApiUrlHelper.expandPath(url, false, false),
                gzipHttpEntity);

        try {

            if (httpResponse == null) {
                return false;
            }

            if (isResponseError(httpResponse)) {
                HttpEntity httpEntity = httpResponse.getEntity();
                EntityUtils.consume(httpEntity);
                return false;
            }

            HttpEntity httpEntity = httpResponse.getEntity();
            String json = EntityUtils.toString(httpEntity);
            EntityUtils.consume(httpEntity);
            if (Log.DEBUG) {
                Log.d(TAG, "json=" + json);
            }

            return true;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (input != null) {
                input.close();
            }
        }

        return false;
    }

    /**
     * 发送File目录下文件
     *
     * @param key
     * @param fileName
     * @param url
     * @param ssl
     */
    public static boolean sendGzip(String key, String fileName, String url, boolean ssl)
            throws IllegalStateException, IOException {
        ApiHttpClient apiHttpClient = ApiHttpClient.getInstance();
        InputStream input = AppContext.getContext().openFileInput(fileName);

        InputStreamBody inputStreamBody = new InputStreamBody(input, fileName);
        FormBodyPart part = new FormBodyPart(key, inputStreamBody);

        part.getHeader().removeFields("Content-Transfer-Encoding");
        part.addField("Content-Transfer-Encoding", "x-gzip");

        MultipartEntity gzipHttpEntity = new MultipartEntity();
        gzipHttpEntity.addPart(part);

        HttpResponse httpResponse = apiHttpClient.post(ApiUrlHelper.expandPath(url, ssl, ssl),
                gzipHttpEntity);

        try {

            if (httpResponse == null) {
                return false;
            }

            if (isResponseError(httpResponse)) {
                HttpEntity httpEntity = httpResponse.getEntity();
                EntityUtils.consume(httpEntity);
                return false;
            }

            HttpEntity httpEntity = httpResponse.getEntity();
            String json = EntityUtils.toString(httpEntity);
            EntityUtils.consume(httpEntity);
            if (Log.DEBUG) {
                Log.d(TAG, "json=" + json);
            }

            return true;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (input != null) {
                input.close();
            }
        }

        return false;
    }

    public static boolean isResponseError(HttpResponse httpResponse) {
        if (httpResponse.getStatusLine() == null
                || (httpResponse.getStatusLine() != null && httpResponse.getStatusLine()
                .getStatusCode() != HttpStatus.SC_OK)) {
            return true;
        }
        return false;
    }

    public static boolean hasConnection() {

        final ConnectivityManager cm = (ConnectivityManager) AppContext.getContext()
                .getSystemService(Context.CONNECTIVITY_SERVICE);

        final NetworkInfo networkInfo = cm.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnectedOrConnecting()) {
            Log.i(TAG, "No connection found");
            return false;
        }

        return true;
    }
}
