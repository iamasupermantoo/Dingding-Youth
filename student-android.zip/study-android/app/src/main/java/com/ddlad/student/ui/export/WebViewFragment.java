package com.ddlad.student.ui.export;

import android.os.Bundle;
import android.view.View;

import com.ddlad.student.ui.widget.webview.BaseWebView;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.tools.StringUtil;
import com.ddlad.student.ui.common.BaseFragment;

/**
 * Created by Albert
 * on 16-11-2.
 */
public class WebViewFragment extends BaseFragment implements BaseWebView.WebListener {

    private String mLink;

    private String mTitle;

    private BaseWebView mWebView;

    @Override
    protected void onInitData(Bundle bundle) {
        mTitle = bundle.getString(ProtocolConstants.PARAM_TITLE);
        mLink = bundle.getString(ProtocolConstants.PARAM_URL);
    }

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_web_view;
    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle(R.string.web_loading);
        mWebView = (BaseWebView) contentView.findViewById(R.id.web_view);
        mWebView.setWebListener(this);
        if (!StringUtil.isEmpty(mLink)) {
            mWebView.openLink(mLink);
        }
    }

    @Override
    public void updateTitle(String title) {
        mActionbar.setTitle(title);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        mWebView.clear();
    }
}
