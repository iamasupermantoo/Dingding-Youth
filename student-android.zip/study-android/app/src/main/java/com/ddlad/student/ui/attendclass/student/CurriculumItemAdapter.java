package com.ddlad.student.ui.attendclass.student;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.model.CurriculumInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.ui.attendclass.lesson.LessonFragment;
import com.ddlad.student.ui.attendclass.schedule.ScheduleFragment;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.image.NetworkImageView;

/**
 * Created by Administrator on 2017/1/16 0016.
 */

public class CurriculumItemAdapter {

    public static View createView(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.curriculum_item_layout, null);
        CurriculumHolder holder = new CurriculumHolder();
        holder.mImage = (NetworkImageView) view.findViewById(R.id.curriculum_item_image);
        holder.mCourse = (TextView) view.findViewById(R.id.curriculum_item_course);
        holder.mTotalLesson = (TextView) view.findViewById(R.id.curriculum_item_total_lesson);
        holder.mTimeTable = (TextView) view.findViewById(R.id.curriculum_item_timetable);
        holder.mLesson = (TextView) view.findViewById(R.id.curriculum_item_lesson);
        holder.mCourseDetails = (ViewGroup) view.findViewById(R.id.curriculum_item_detail_course_layout);
        view.setTag(holder);

        return view;
    }

    public static void bindView(View view, final CurriculumInfo curriculumInfo, final BaseFragment fragment, final AbstractAdapter adapter){
        if (curriculumInfo == null){
            return;
        }
        CurriculumHolder holder = (CurriculumHolder) view.getTag();
        if (holder == null){
            return;
        }
        holder.mCourse.setText(curriculumInfo.getName());
        holder.mTotalLesson.setText(String.valueOf(curriculumInfo.getTotalCnt())+"节课");
        if (curriculumInfo.getImage() != null){
            holder.mImage.setUrl(curriculumInfo.getImage().getImageMedium());
        }
        holder.mLesson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString(ProtocolConstants.PARAM_CID,curriculumInfo.getCid());
                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new LessonFragment(), bundle);

            }
        });
        holder.mTimeTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString(ProtocolConstants.PARAM_CID,curriculumInfo.getCid());
                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new ScheduleFragment(), bundle);
//                HomeActivity.show(fragment.getActivity(), Intent.FLAG_ACTIVITY_CLEAR_TASK);
//                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new ChoiceFragment(), bundle);
            }
        });
        holder.mCourseDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Bundle bundle = new Bundle();
//                bundle.putString(ProtocolConstants.PARAM_CMID,curriculumInfo.getCmId());
//                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new CourseDetailsFragment(), bundle);
                Bundle bundle = new Bundle();
                bundle.putString(ProtocolConstants.PARAM_CID,curriculumInfo.getCid());
                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new LessonFragment(), bundle);
            }
        });


    }

    public static class CurriculumHolder{
        private NetworkImageView mImage;
        private TextView mCourse;
        private TextView mTotalLesson;
        private TextView mTimeTable;
        private TextView mLesson;
        private ViewGroup mCourseDetails;
    }
}
