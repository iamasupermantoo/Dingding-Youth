package com.ddlad.student.protocol.model;

import com.ddlad.student.ui.model.MultiImageInfo;

import java.util.List;

/**
 * Created by chen007 on 2017/11/7 0007.
 */
public class NewBannerInfo extends BaseInfo {

        /**
         * desc :
         * image : {"width":640,"height":640,"pattern":"http://img.z.ziduan.com/pB5jWyBGbj49RzEFBVF2BQ.jpeg@{w}w_{h}h_75q","id":"pB5jWyBGbj49RzEFBVF2BQ"}
         * gotoPage : {"type":0,"params":{"dataId":"_yDRRBYacPY9RzEFBVF2BQ,"}}
         */

        private List<BannerInfo> banners;

        public List<BannerInfo> getBanners() {
            return banners;
        }

        public void setBanners(List<BannerInfo> banners) {
            this.banners = banners;
        }
}
