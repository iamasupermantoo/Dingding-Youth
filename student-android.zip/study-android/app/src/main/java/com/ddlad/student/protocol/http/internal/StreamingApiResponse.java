package com.ddlad.student.protocol.http.internal;

import android.text.TextUtils;

import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.HttpResponseCode;
import com.fasterxml.jackson.databind.JsonNode;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Meta;
import com.ddlad.student.R;

public class StreamingApiResponse<T> extends ApiResponse<T> {

    public static final String TAG = "StreamingApiResponse";

    private String mErrorTitle;

    private String mError;

    private String mErrorDescription;

    private boolean mNetworkRequest;

    private boolean mNotModified;

    private int mStatus;

    private String mStatusMessage;

    T mSuccessObject;

    public StreamingApiResponse() {
    }

    public static <T> StreamingApiResponse<T> createWithError(String error) {

        StreamingApiResponse<T> streamingApiResponse = new StreamingApiResponse<T>();

        streamingApiResponse.createWithError();

        if (!TextUtils.isEmpty(error)) {
            streamingApiResponse.setError(error);
            streamingApiResponse.setErrorDescription(error);
        }

        return streamingApiResponse;
    }

    public void createWithError() {

        if (TextUtils.isEmpty(mErrorTitle)) {
            mErrorTitle = AppContext.getContext().getString(R.string.error);
        }

        if (TextUtils.isEmpty(mError)) {
            mError = TextUtils.isEmpty(mStatusMessage) ? NETWORK_ERROR_MESSAGE : mStatusMessage;
        }

        if (TextUtils.isEmpty(mErrorDescription)) {
            mErrorDescription = TextUtils.isEmpty(mStatusMessage) ? NETWORK_ERROR_MESSAGE
                    : mStatusMessage;
        }

    }

    @Override
    public String getStatusMessage() {
        return mStatusMessage;
    }

    @Override
    public T getSuccessObject() {
        return mSuccessObject;
    }

    @Override
    public boolean hasRootValue(String paramString) {
        return false;
    }

    @Override
    public boolean isNetworkRequest() {
        return mNetworkRequest;
    }

    @Override
    public boolean isOk() {
        if (mErrorDescription != null) {
            return false;
        }

        Integer responseCode = getResponseCode();

        if (responseCode != null && responseCode.intValue() == HttpResponseCode.STATUS_CODE_OK && getCode() == Meta.META_CODE_OK) {
            return true;
        }

        return false;
    }

    @Override
    public int getStatus() {
        return mStatus;
    }

    public void setStatus(int status) {
        this.mStatus = status;
    }

    @Override
    public T readRootValue(String paramString, Class<T> classz) {
        return null;
    }

    @Override
    public void setIsNetworkResponse(boolean networkRequest) {
        mNetworkRequest = networkRequest;
    }


    public void setStatusMessage(String statusMessage) {
        mStatusMessage = statusMessage;
    }

    @Override
    public void setSuccessObject(T t) {
        mSuccessObject = t;
    }

    public void setErrorTitle(String errorTitle) {
        mErrorTitle = errorTitle;
    }

    @Override
    public String getErrorTitle() {
        return mErrorTitle;
    }

    @Override
    public String getErrorDescription() {
        return mErrorDescription;
    }

    public void setErrorDescription(String errorDescription) {
        this.mErrorDescription = errorDescription;
    }

    public void setError(String error) {
        mError = error;
    }

    @Override
    public String getError() {
        return mError;
    }

    @Override
    public T readRootValue(Class<T> classz) {
        return null;
    }

    @Override
    public JsonNode getRootNode() {
        return null;
    }

    @Override
    public T readRootValue(String key, String childKey, Class<T> clazz) {
        return null;
    }

    @Override
    public boolean isNotModified() {
        return mNotModified;
    }

    public void setNotModified(boolean mNotModified) {
        this.mNotModified = mNotModified;
    }
}
