package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.ui.model.MultiImageInfo;

import java.io.IOException;

/**
 * Created by chenjianing on 2017/3/26 0026.
 */
public class MyAccountInfo {

        /**
         * province : 河北
         * gender : 1
         * grade : 1
         * headImage : {"width":1080,"height":1080,"pattern":"http://img.z.ziduan.com/VO7QRFHF1LU9RzEFBVF2BQ.jpeg@{w}w_{h}h_75q","id":"VO7QRFHF1LU9RzEFBVF2BQ"}
         * name : cjn
         * signature : 9ooooooooooo
         * region : 唐山
         */

        private InfoBean info;

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public static class InfoBean {
            private String province;
            private int gender;
            private String grade;
            /**
             * width : 1080
             * height : 1080
             * pattern : http://img.z.ziduan.com/VO7QRFHF1LU9RzEFBVF2BQ.jpeg@{w}w_{h}h_75q
             * id : VO7QRFHF1LU9RzEFBVF2BQ
             */

            private MultiImageInfo headImage;
            private String name;
            private String signature;
            private String region;
            private String birthday;

            public String getBirthday() {
                return birthday;
            }

            public void setBirthday(String birthday) {
                this.birthday = birthday;
            }

            public String getProvince() {
                return province;
            }

            public void setProvince(String province) {
                this.province = province;
            }

            public int getGender() {
                return gender;
            }

            public void setGender(int gender) {
                this.gender = gender;
            }

            public String getGrade() {
                return grade;
            }

            public void setGrade(String grade) {
                this.grade = grade;
            }

            public MultiImageInfo getHeadImage() {
                return headImage;
            }

            public void setHeadImage(MultiImageInfo headImage) {
                this.headImage = headImage;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getSignature() {
                return signature;
            }

            public void setSignature(String signature) {
                this.signature = signature;
            }

            public String getRegion() {
                return region;
            }

            public void setRegion(String region) {
                this.region = region;
            }

            public static InfoBean fromJsonParser(JsonParser jsonParser) throws IOException {

                InfoBean info = null;

                if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

                    while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                        String fieldName = jsonParser.getCurrentName();

                        if (fieldName == null) {
                            continue;
                        }

                        if (info == null) {
                            info = new InfoBean();
                        }

                        if ("province".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.province = jsonParser.getText();
                            continue;
                        }
                        if ("gender".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.gender = jsonParser.getIntValue();
                            continue;
                        }
                        if ("grade".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.grade = jsonParser.getText();
                            continue;
                        }
                        if ("name".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.name = jsonParser.getText();
                            continue;
                        }
                        if ("signature".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.signature = jsonParser.getText();
                            continue;
                        }
                        if ("region".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.region = jsonParser.getText();
                            continue;
                        }
                        if ("headImage".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.headImage = MultiImageInfo.fromJsonParser(jsonParser);
                            continue;
                        }
//                        if ("region".equals(fieldName)) {
//                            jsonParser.nextToken();
//                            info.region = jsonParser.getText();
//                            continue;
//                        }

                        jsonParser.skipChildren();
                    }
                }

                return info;
            }
        }
        public static MyAccountInfo fromJsonParser(JsonParser jsonParser) throws IOException {

            MyAccountInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new MyAccountInfo();
                }

                if ("info".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.info = InfoBean.fromJsonParser(jsonParser);
                    continue;
                }


                jsonParser.skipChildren();
            }
        }

        return info;
    }
}
