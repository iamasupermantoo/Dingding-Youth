package com.ddlad.student.ui.account;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.protocol.model.LOrderInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.course.NewCourseDetailsFragment;
import com.ddlad.student.ui.course.NewPayModeFragment;
import com.ddlad.student.ui.widget.image.NetworkImageView;
import com.ddlad.student.R;


/**
 * Created by Albert
 * on 16-10-20.
 */
public class OrderListItemAdapter {

    public static View createView(ViewGroup viewGroup) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.order_item,
                null);

        ViewHolder holder = new ViewHolder(view);

        view.setTag(holder);

        return view;
    }

    public static void bindView(View view, final LOrderInfo mInfo, final BaseFragment fragment) {

        if (mInfo == null) {
            return;
        }

        ViewHolder myViewHolder = (ViewHolder) view.getTag();

        if (myViewHolder == null) {
            return;
        }
        String url =  mInfo.getImage().getPattern();
        myViewHolder.image.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}w")));

        int yuan = mInfo.getPrice()/100;

        int fen = mInfo.getPrice()%100;

        if (fen == 0){
            myViewHolder.mMoney.setText(yuan+"");
        }else {
            myViewHolder.mMoney.setText(yuan+"."+fen+"");
        }
        myViewHolder.mCourse.setText(mInfo.getCourse());
        myViewHolder.mCourseHour.setText(mInfo.getTotalCnt()+"");
        myViewHolder.mOrderTime.setText(mInfo.getCreateTime());
        myViewHolder.mTeacher.setText(mInfo.getLevel()+"");

        if (mInfo.getPayStatus() == 1){
            //已支付
            myViewHolder.mPay.setText("已付款");
            myViewHolder.mPay.setSelected(false);
            myViewHolder.mPay.setTextColor(Color.parseColor("#ffffff"));
        }
        if (mInfo.getPayStatus() == 0){
            //未支付
            myViewHolder.mPay.setText("去支付");
            myViewHolder.mPay.setSelected(true);
            myViewHolder.mPay.setTextColor(Color.parseColor("#000000"));

        }

        myViewHolder.mPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mInfo.getPayStatus() == 1){
                    //已支付
                }else {
                    Bundle bundle = new Bundle();
                    bundle.putString("sub",mInfo.getOid());
                    bundle.putInt("price",mInfo.getPrice());
                    bundle.putString("coursename",mInfo.getCourse());
                    NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new NewPayModeFragment(), bundle);
                }

            }
        });
        myViewHolder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ////调课程详情
                Bundle bundle = new Bundle();
//                bundle.putString("cmid",mInfo.get());
                bundle.putString("cmid",mInfo.getCmId());
                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new NewCourseDetailsFragment(), bundle);
            }
        });
    }

    private static class ViewHolder {
        private TextView mOrderTime;
        private TextView mCourse;
        //总课时
        private TextView mCourseHour;
        private TextView mTeacher;
        private TextView mCourseTime;
        private TextView mMoney;
        private TextView mPay;
        private ViewGroup layout;
        private NetworkImageView image;


        public ViewHolder(View itemView) {
            mOrderTime = (TextView) itemView.findViewById(R.id.order_time);
            mCourse = (TextView) itemView.findViewById(R.id.order_course);
            mCourseHour = (TextView) itemView.findViewById(R.id.order_course_hour);
            mTeacher = (TextView) itemView.findViewById(R.id.order_techer);
            mCourseTime = (TextView) itemView.findViewById(R.id.order_course_time);
            mMoney = (TextView) itemView.findViewById(R.id.money);
            mPay = (TextView) itemView.findViewById(R.id.pay_btn);
            image = (NetworkImageView) itemView.findViewById(R.id.order_icon);
            layout = (ViewGroup) itemView.findViewById(R.id.item_layout);
        }

    }
}
