package com.ddlad.student.ui.account;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.ddlad.student.primary.Log;
import com.ddlad.student.primary.Prefs;
import com.ddlad.student.protocol.convert.DataCenter;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiUrlHelper;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.protocol.http.request.ConfigGetRequest;
import com.ddlad.student.protocol.http.request.ConfigSaveRequest;
import com.ddlad.student.tools.ClickManager;
import com.ddlad.student.tools.DataCleanManager;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.tools.Util;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.ResponseMessage;
import com.ddlad.student.protocol.http.request.LogoutRequest;
import com.ddlad.student.protocol.model.Config;
import com.ddlad.student.tools.FileUtil;
import com.ddlad.student.tools.StringUtil;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseFragment;

/**
 * Created by Albert
 * on 16-9-29.
 */
public class SettingFragment extends BaseFragment implements ClickManager.MultiClickListener {

    private int mPushConfigLoaderId = ViewUtil.generateUniqueId();

    private TextView mExitBtn;
    private TextView caidan;
    private ViewGroup mPushLayout;
    private View mPushSwitcher;
    private ViewGroup mBindAccount;
    private ViewGroup mResetPassword;
    private ViewGroup mAccountInfo;
    private ViewGroup mClearCacheLayout;
    private ViewGroup mImprintLayout;
    private ViewGroup alipayLayout;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_setting;
    }

    @Override
    protected void onInitView(View contentView) {

        mActionbar.setTitle("设置");

        mPushLayout = (ViewGroup) contentView.findViewById(R.id.push_layout);
//        mBindAccount = (ViewGroup) contentView.findViewById(R.id.bind_account_layout);
        mResetPassword = (ViewGroup) contentView.findViewById(R.id.reset_password_layout);
//        mAccountInfo = (ViewGroup) contentView.findViewById(R.id.account_info_layout);
        //清除缓存
        mClearCacheLayout = (ViewGroup) contentView.findViewById(R.id.clear_cache_layout);
        //版本说明
        mImprintLayout = (ViewGroup) contentView.findViewById(R.id.imprint_layout);
        caidan = (TextView) contentView.findViewById(R.id.caidan);
//        alipayLayout = (ViewGroup) contentView.findViewById(R.id.alipay);

        //推送开关
        mPushSwitcher = initItemView(mPushLayout, R.string.push_notice, R.drawable.switcher_bg, new OnClickListener() {
            @Override
            public void onClick(View view) {
                switchPush(view);
            }
        });
        mPushSwitcher.setSelected(Prefs.getInstance().getPushConfig());
//        initItemView(mBindAccount, R.string.bind_account, R.drawable.arrow_right, null);
//        initItemView(mResetPassword, R.string.reset_password, R.drawable.arrow_right, null);
//        initItemView(mAccountInfo, R.string.account_info, R.drawable.arrow_right, null);
        ////清除缓存与历史记录
        initItemView(mClearCacheLayout, R.string.clear_cache);
        //版本说明
        initItemView(mImprintLayout, R.string.imprint_desc, Util.getVersionName());
//        initItemView(alipayLayout, R.string.alipay);

        mExitBtn = (TextView) contentView.findViewById(R.id.exit);
        mExitBtn.setOnClickListener(this);
        caidan.setOnClickListener(this);
    }

    @Override
    public void onMultiClick() {
//        Log.DEBUG = !Log.DEBUG;
//        ProtocolConstants.setDOMAIN();
//        ApiUrlHelper.API_HOST = String.format("api.%s", ProtocolConstants.DOMAIN);
//        String url = ApiUrlHelper.API_HOST;
//        String domain = ProtocolConstants.DOMAIN;
//
//        Log.i("SettingFragment","---------------Log.DEBUG------------------"+Log.DEBUG);
//        Log.i("SettingFragment","---------------d0iamin------------------"+ProtocolConstants.DOMAIN);
//        Log.i("SettingFragment","---------------url------------------"+url);
//        AbstractRequest.domainChange = true;
//        exit();
    }

    private View initItemView(ViewGroup itemLayout, int textRes, int imageRes, OnClickListener rightListener) {

        itemLayout.setOnClickListener(this);
        ImageView image = (ImageView) itemLayout.findViewById(R.id.right_image);

        if (imageRes != 0) {
            image.setImageResource(imageRes);
            image.setOnClickListener(rightListener);
        }

        if (textRes != 0) {
            TextView label = (TextView) itemLayout.findViewById(R.id.label);
            label.setText(textRes);
        }

        return image;
    }

    private void initItemView(ViewGroup itemLayout, int textRes) {

        itemLayout.setOnClickListener(this);
        ImageView image = (ImageView) itemLayout.findViewById(R.id.right_image);
        image.setVisibility(View.GONE);

        if (textRes != 0) {
            TextView label = (TextView) itemLayout.findViewById(R.id.label);
            label.setText(textRes);
        }
    }

    private void initItemView(ViewGroup itemLayout, int textRes, String rightText) {

        ImageView image = (ImageView) itemLayout.findViewById(R.id.right_image);
        image.setVisibility(View.GONE);

        if (textRes != 0) {
            TextView label = (TextView) itemLayout.findViewById(R.id.label);
            label.setText(textRes);
        }

        if (!StringUtil.isEmpty(rightText)) {
            TextView text = (TextView) itemLayout.findViewById(R.id.right_text);
            text.setVisibility(View.VISIBLE);
            text.setText(rightText);
        }
    }

    @Override
    protected void fetchData() {

        ConfigGetRequest request = new ConfigGetRequest(this, mDefaultLoaderId, new AbstractCallbacks<Config>() {

            @Override
            protected void onSuccess(Config config) {
                Prefs.getInstance().savePushConfig(config.isPushAllowed());
                mPushSwitcher.setSelected(config.isPushAllowed());
            }
        });

        //设置是否推送
//        request.perform();
    }

    @Override
    protected boolean isNeedFetch() {
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
//            case R.id.bind_account_layout:
//                //绑定账户
//                break;
//
            case R.id.reset_password_layout:
                //更改密码
                break;
//            case R.id.account_info_layout:
//                //账户信息
//                break;

            case R.id.clear_cache_layout:
                //清除缓存
                try {
                    Toaster.toastShort("清除缓存成功,清除了"+ DataCleanManager.getCacheSize(getActivity().getCacheDir())+"");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                FileUtil.cleanDirectoryContainSonDir(getActivity().getCacheDir());
                break;

            case R.id.exit:
                //退出
                exit();
                break;
            case R.id.caidan:
//                ClickManager.getInstance().multiClick(this);
                break;

        }
    }



    private void switchPush(final View switcher) {
        if (switcher.isSelected()) {
            switcher.setSelected(false);
        } else {
            switcher.setSelected(true);
        }
        ConfigSaveRequest request = new ConfigSaveRequest(this, mPushConfigLoaderId, new AbstractCallbacks<String>() {

            @Override
            public void onRequestStart() {
                startLoading();
            }

            @Override
            public void onRequestFinished() {
                stopLoading();
            }

            @Override
            protected void onSuccess(String s) {
                Prefs.getInstance().savePushConfig(switcher.isSelected());
            }

            @Override
            protected void onFail(ApiResponse<String> response) {
                ResponseMessage.show(response);
            }
        });
        request.perform(ProtocolConstants.PARAM_PUSH, switcher.isSelected());
    }

    private void exit() {
        LogoutRequest request = new LogoutRequest(this, mDefaultLoaderId, new AbstractCallbacks<String>() {

            @Override
            public void onRequestStart() {
                startLoading();
            }

            @Override
            public void onRequestFinished() {
                stopLoading();
            }

            @Override
            protected void onSuccess(String s) {
                DataCenter.logout(getActivity());
            }

            @Override
            protected void onFail(ApiResponse<String> response) {
                ResponseMessage.show(response);
            }
        });
        request.perform();
    }

    private void wxpay() {
        //清除缓存与历史记录
        Toast.makeText(getActivity(), "微信支付测试", Toast.LENGTH_SHORT).show();

    }

    private void alipay() {
        Toast.makeText(getActivity(), "支付宝支付测试", Toast.LENGTH_SHORT).show();
    }


    private static final int SDK_PAY_FLAG = 1;
    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {
        @SuppressWarnings("unused")
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SDK_PAY_FLAG: {
                    /**
                     * 同步返回的结果必须放置到服务端进行验证（验证的规则请看https://doc.open.alipay.com/doc2/
                     * detail.htm?spm=0.0.0.0.xdvAU6&treeId=59&articleId=103665&
                     * docType=1) 建议商户依赖异步通知
                     */
                    Toast.makeText(getActivity(), (String) msg.obj, Toast.LENGTH_SHORT).show();
                    break;
                }
                default:
                    break;
            }
        }

    };
}
