package com.ddlad.student.protocol.http.callbacks;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.content.Loader;

import com.ddlad.student.R;
import com.ddlad.student.primary.ImmediateAsyncTaskLoaderAsyncTask;
import com.ddlad.student.primary.ZebraApp;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ObjectMappedApiResponse;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.tools.Toaster;

import ch.boye.httpclientandroidlib.HttpResponse;

public class ApiRequestLoaderCallbacks<T> extends com.ddlad.student.protocol.http.callbacks.BaseApiLoaderCallbacks<T> {

    private final AbstractRequest<T> mApiRequest;

    public ApiRequestLoaderCallbacks(Context context, AbstractRequest<T> request,
                                     AbstractCallbacks<T> apiCallbacks) {
        super(apiCallbacks, context, request);

        mApiRequest = request;
    }

    protected void onApiResponseObjectCreated(ApiResponse<T> apiResponse) {
    }

    @Override
    public Loader<ApiResponse<T>> onCreateLoader(int loaderId, Bundle bundle) {

        if (getApiCallbacks() != null) {
            getApiCallbacks().onRequestStart();
        }

        return new ImmediateAsyncTaskLoaderAsyncTask<ApiResponse<T>>(mContext) {

            @Override
            public void deliverResult(ApiResponse<T> response) {
                super.deliverResult(response);
            }

            @Override
            public ApiResponse<T> loadInBackground() {

                ObjectMappedApiResponse<T> response;

                try {
                    mApiRequest.preProcessInBackground();

                    HttpResponse httpResponse = ApiHttpClient.getInstance().sendRequest(
                            mApiRequest.getRequest());
                    response = ObjectMappedApiResponse.parseResponse(getContext(), httpResponse);
                    if (response.isNotModified()) {
                        return response;
                    } else if (response.isOk()) {
                        response.setSuccessObject(mApiRequest.processInBackground(response));
                        response.setIsNetworkResponse(true);
                        onApiResponseObjectCreated(response);
                    }else {
                        if (response != null && response.getErrorDescription() != null){

                            final ObjectMappedApiResponse<T> finalResponse = response;
                            ZebraApp.mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    Toaster.toastShort(finalResponse.getErrorDescription()+ R.string.errorcode+finalResponse.getCode());

                                }
                            });
                        }
                    }
                } catch (AbstractRequest.PreProcessException e) {

                    e.printStackTrace();

                    response = ObjectMappedApiResponse.createWithError(e.getMessage());

                    mApiRequest.handleErrorInBackground(response);
                }

                return response;
            }

            @Override
            protected void onStartLoading() {
                super.onStartLoading();
            }

            @Override
            protected void onStopLoading() {
                super.onStopLoading();
            }
        };
    }

    @Override
    public void onLoadFinished(Loader<ApiResponse<T>> loader, ApiResponse<T> response) {
        super.onLoadFinished(loader, response);
        mApiRequest.getLoaderManager().destroyLoader(mApiRequest.getLoaderId());
    }

}
