package com.ddlad.student.ui.common;

import android.os.Bundle;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.ListView;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;
import com.ddlad.student.protocol.http.cache.DiskCache;
import com.ddlad.student.protocol.http.cache.DiskCacheLoader;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ResponseMessage;
import com.ddlad.student.protocol.http.request.BaseListRequest;
import com.ddlad.student.protocol.http.response.LooseListResponse;
import com.ddlad.student.protocol.model.BaseInfo;
import com.ddlad.student.protocol.model.LHomeWorkDetailInfo;
import com.ddlad.student.protocol.model.LessonInfo;
import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.tools.NetworkUtil;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.tools.Util;
import com.ddlad.student.ui.listener.InternalScrollListener;
import com.ddlad.student.ui.widget.pulltorefresh.PullToRefreshBase;
import com.ddlad.student.ui.widget.pulltorefresh.PullToRefreshListView;
import com.ddlad.student.ui.widget.pulltorefresh.extras.SoundPullEventListener;

import java.io.File;
import java.util.List;

public abstract class BaseListFragment<T extends BaseInfo> extends BaseFragment implements InternalScrollListener {

    protected PullToRefreshListView mListView;

    protected View mTopBlank;
    protected ViewGroup mEmptyView;

    protected boolean mIsLoading = false;

    protected AbstractAdapter mAdapter;

    protected BaseListRequest mDefaultRequest;

    public static final int DEFAULT_REQUEST_COUNT = 20;

    private String mNextCursorId;

    private boolean mNeedLoadMore;

    protected boolean allowShare;



    protected int waitCommit;

    public int getWaitCommit() {
        return waitCommit;
    }

    public void setWaitCommit(int waitCommit) {
        this.waitCommit = waitCommit;
    }

    public LHomeWorkDetailInfo getmHomeWorkDetailInfo() {
        return mHomeWorkDetailInfo;
    }

    public void setmHomeWorkDetailInfo(LHomeWorkDetailInfo mHomeWorkDetailInfo) {
        this.mHomeWorkDetailInfo = mHomeWorkDetailInfo;
    }

    private LHomeWorkDetailInfo mHomeWorkDetailInfo;

    public LessonInfo getmLessonInfo() {
        return mLessonInfo;
    }

    public void setmLessonInfo(LessonInfo mLessonInfo) {
        this.mLessonInfo = mLessonInfo;
    }

    private LessonInfo mLessonInfo;


    private boolean mNeedLoadRequest;

    private long mRequestTimeStamp;

    protected StreamingCallbacks mRequestCallbacks;

    private InternalScrollListener mInternalScrollListener;

    protected int mItemCountPerPage = DEFAULT_REQUEST_COUNT;

    protected TextView mNoResult;

    public int getItemCountPerPage() {
        return mItemCountPerPage;
    }

    public void handleRequest(boolean clearOnAdd) {

        if (getActivity() == null) {
            Log.d(getSimpleName(), "Fragment not attached to Activity");
            return;
        }

        if (!isNeedFetch()) {
            mListView.reset();
            return;
        }

        if (!NetworkUtil.hasConnection()) {
            Toaster.toastLong(R.string.network_error_message);
            mListView.reset();
            return;
        }

        if (isLoading()) {
            Log.d(getSimpleName(), "Is loading already set, not performing request");
            return;
        }

        if (mRequestCallbacks == null) {
            mRequestCallbacks = getRequestCallbacks();
        }

        if (mDefaultRequest == null) {
            mDefaultRequest = makeRequest(mRequestCallbacks);
        }

        mDefaultRequest.setClearOnAdd(clearOnAdd);
        mDefaultRequest.setNeedCache(clearOnAdd);
        mRequestCallbacks.setClearOnAdd(clearOnAdd);

        performRequest();
    }

    protected boolean isLoading() {
        return mIsLoading;
    }

    protected void performRequest() {
        mDefaultRequest.perform();
    }

    protected StreamingCallbacks getRequestCallbacks() {
        return new StreamingCallbacks();
    }

    protected BaseListRequest makeRequest(
            AbstractStreamingCallbacks<AbstractListResponse<T>> streamingApiCallbacks) {

        return new BaseListRequest(this, mDefaultLoaderId, streamingApiCallbacks) {

            private File file;

            @Override
            protected String getBasePath() {
                return "";
            }

            @Override
            public File cacheResponseFile() {
                if (file == null) {
                    file = new File(getContext().getCacheDir(), getCacheFilename());
                }
                return file;
            }
        };
    }

    protected class StreamingCallbacks extends AbstractStreamingCallbacks<AbstractListResponse<T>> {

        private boolean mClearOnAdd;

        public void setClearOnAdd(boolean clearOnAdd) {
            mClearOnAdd = clearOnAdd;
        }

        protected boolean shouldClearOnAdd() {
            return mClearOnAdd;
        }

        @Override
        protected void onFail(ApiResponse<AbstractListResponse<T>> apiResponse) {
            ResponseMessage.show(apiResponse);
            getAdapter().notifyDataSetChanged();
            mListView.showLoadMoreView(isNeedLoadMore());
            showEmptyView();
        }

        @Override
        public void onRequestFinished() {
            updateLoadingState();
            mListView.onRefreshComplete();
        }

        @Override
        public void onRequestStart() {
            updateLoadingState();
        }

        @Override
        protected void onSuccess(AbstractListResponse<T> response) {

            if (isResumed()) {

                if (mClearOnAdd) {
                    getAdapter().clearItem();
                    afterClearItems();
                    mClearOnAdd = false;
                }

                if (response != null) {
                    LooseListResponse<T> data = response.getLooseListResponse();
                    mHomeWorkDetailInfo = response.getmHomeWorkDetail();
                    mLessonInfo = response.getmLessonInfo();
                    waitCommit = response.getWaitCommit();
                    allowShare = response.isAllowShare();

                    if (data != null) {
                        List<T> infoList = data.getList();
                        if (!CollectionUtil.isEmpty(infoList)) {
                            getAdapter().addItem(infoList);
                        }
                        setNextCursorId(data.getNextCursorId());
                        setNeedLoadMore(data.getHasMore());
                    }
                }

                getAdapter().notifyDataSetChanged();
                mListView.showLoadMoreView(false);

                afterCallbackSuccess();

                showEmptyView();
            }
        }
    }

    protected void afterClearItems() {

    }

    protected void afterCallbackSuccess() {

    }

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_empty_list;
    }

    protected int getHeaderResource() {
        return 0;
    }

    protected int getFooterResource() {
        return 0;
    }

    protected boolean loadDefaultContent() {
        return false;
    }

    protected void addHeaderViews(LayoutInflater inflater) {
        int headerRes = getHeaderResource();
        if (headerRes != 0) {
            View header = inflater.inflate(headerRes, null);
            mListView.addHeaderView(header, null, false);
            onInitHeader(header);
        }
    }

    protected void onInitHeader(View header) {
        // Handle header event here.
    }

    protected void addFooterViews(LayoutInflater inflater) {
        int footerRes = getFooterResource();
        if (footerRes != 0) {
            View footer = inflater.inflate(footerRes, null);
            mListView.addFooterView(footer, null, false);
            onInitFooter(footer);
        }
    }

    protected void onInitFooter(View footer) {
        // Handle footer event here.
    }

    protected void showFooterLoadingViews() {
        boolean isNeedShowFooter = getAdapter().getCount() > 0 && !isLoadMoreVisible();
        mListView.showLoadMoreView(isNeedFetch() && !isNeedShowFooter);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initLoader();
        initInternalScrollListener();
    }

    protected void initLoader() {
        if (getActivity() != null) {
            getActivity().getSupportLoaderManager().initLoader(getDefaultLoaderId(), null,
                    new ReadCacheCallbacks());
        }
    }

    private void initInternalScrollListener() {
        if (isInternalScrollListenerOn()) {
            mInternalScrollListener = this;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle bundle) {

        View view = inflater.inflate(getLayoutResource(), container, false);

        initActivityView();

        // Basic init.
        mListView = (PullToRefreshListView) view.findViewById(R.id.list);
        mTopBlank = view.findViewById(R.id.top_blank);
        mEmptyView = (ViewGroup) view.findViewById(R.id.empty_view);

        if (mTopBlank != null) {
            mTopBlank.getLayoutParams().height = AppContext.getScreenHeight() / 5;
        }

        if (mEmptyView != null) {
            customEmpty();
        }

        // Override init.
        onInitView(view);
        addFooterViews(inflater);
        addHeaderViews(inflater);
        initListAdapter();
        showFooterLoadingViews();
        setSoundEventListener();
        setOnScrollListener();

        if (isNeedPreLoad() || getUserVisibleHint()) {
            mNeedLoadRequest = false;
            updateCreateView();
        } else {
            mNeedLoadRequest = true;
        }

        return view;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser && mNeedLoadRequest) {
            mNeedLoadRequest = false;
            updateCreateView();
        }
    }

    protected int getEmptyTextRes() {
        return R.string.empty;
    }

    protected void customEmpty() {
        TextView emptyText = (TextView) mEmptyView.findViewById(R.id.empty_text);
        emptyText.setText(getEmptyTextRes());
    }

    protected void showEmptyView() {
        if (mEmptyView != null) {
            if (mAdapter == null || mAdapter.isEmpty()) {
                mEmptyView.setVisibility(View.VISIBLE);
            } else {
                hideEmptyView();
            }
        }
    }

    protected void hideEmptyView() {
        mEmptyView.setVisibility(View.GONE);
    }

    protected void setSoundEventListener() {
        if (mListView != null) {
            SoundPullEventListener<ListView> soundListener = new SoundPullEventListener<ListView>();
            soundListener.addSoundEvent(PullToRefreshBase.State.PULL_TO_REFRESH, R.raw.pull);
            soundListener.addSoundEvent(PullToRefreshBase.State.RESET, R.raw.release);
            mListView.setOnPullEventListener(soundListener);
        }
    }

    @Override
    protected void updateCreateView() {

        requestListAdapter();

        requestArticleListAdapter();

        setOnItemClickListener();

        setOnItemLongClickListener();

        setPullDownRefreshListener();

        setLoadMoreListener();
    }

    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        if (!Util.hasIceCreamSandwich()) {
            if (mListView != null) {
                mListView.getRefreshableView().setScrollingCacheEnabled(Boolean.FALSE);
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();

        if (mListView != null) {
            mListView.getRefreshableView().setFastScrollEnabled(Boolean.FALSE);
        }
    }

    protected void updateLoadingState() {
        if (mIsLoading) {
            mIsLoading = false;
        } else {
            mIsLoading = true;
        }
    }

    public void scrollToTop() {

        if (getView() != null && mListView != null) {
            if (!mListView.getRefreshableView().isStackFromBottom()) {
                mListView.getRefreshableView().setStackFromBottom(true);
            }
            mListView.getRefreshableView().setStackFromBottom(false);
        }
    }

    public void allowScrollingWhileRefreshing(boolean allowScrollingWhileRefreshing) {
        if (mListView != null) {
            mListView.setScrollingWhileRefreshingEnabled(allowScrollingWhileRefreshing);
        }
    }

    protected void setOnItemClickListener() {

    }

    protected void setOnItemLongClickListener() {

    }

    protected boolean autoLoadMore() {
        return Boolean.TRUE;
    }

    protected void setOnScrollListener() {
        if (mListView != null) {
            mListView.setOnScrollListener(new OnScrollListener() {

                @Override
                public void onScrollStateChanged(AbsListView view, int scrollState) {

                    switch (scrollState) {

                        case OnScrollListener.SCROLL_STATE_IDLE:
                            if (mInternalScrollListener != null) {
                                mInternalScrollListener.onIdle();
                            }
                            break;

                        case SCROLL_STATE_FLING:
                            if (mInternalScrollListener != null) {
                                mInternalScrollListener.onFling();
                            }
                            break;

                        case SCROLL_STATE_TOUCH_SCROLL:
                            if (mInternalScrollListener != null) {
                                mInternalScrollListener.beforeScroll(view.getFirstVisiblePosition());
                            }
                            break;

                    }
                }

                @Override
                public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount,
                                     int totalItemCount) {
                    if (mInternalScrollListener != null) {
                        mInternalScrollListener.onScroll(view, firstVisibleItem, visibleItemCount,
                                totalItemCount);
                    }
                }
            });
        }
    }

    protected void setPullDownRefreshListener() {

        if (mListView != null) {
            mListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {

                @Override
                public void onRefresh(PullToRefreshBase<ListView> refreshView) {
                    handleRequest(true);

                }
            });
        }
    }

    protected void setLoadMoreListener() {

        if (mListView != null) {
            mListView.setOnLastItemVisibleListener(new PullToRefreshBase.OnLastItemVisibleListener() {

                @Override
                public void onLastItemVisible() {
                    if (autoLoadMore() && isLoadMoreVisible()) {
                        loadMore();
                    }
                }
            });
        }
    }

    protected void initListAdapter() {
        if (mListView != null) {
            mListView.setAdapter(getAdapter());
            mListView.showLoadMoreView(false);
            if (isNeedRefreshOnSizeChanged()) {
                mListView.setNeedRefreshOnSizeChanged(Boolean.TRUE);
            }
        }
    }

    protected void requestListAdapter() {
        if (getAdapter().getCount() <= 0) {
            readCacheOrRequest();
        }
    }
    protected void requestArticleListAdapter() {
        if (getAdapter().getCount() > 0) {
            readCacheOrRequest();
        }
    }

    protected void onDataLoadFinished() {

    }

    protected void readCacheOrRequest() {

        if (getActivity() == null) {
            return;
        }

        if (TextUtils.isEmpty(getCacheFilename())) {
            //检查如果 getCacheFilename是空的，说明没有缓存，直接发送请求
            handleRequest(true);
        } else {
            restartLoader();
        }
    }

    protected void restartLoader() {
        Bundle bundle = new Bundle();
        bundle.putBoolean("deliverOnly", false);
        getActivity().getSupportLoaderManager().restartLoader(getDefaultLoaderId(), bundle,
                new ReadCacheCallbacks());
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    protected class ReadCacheCallbacks implements LoaderManager.LoaderCallbacks<DiskCache> {

        @Override
        public Loader<DiskCache> onCreateLoader(int loadId, Bundle bundle) {

            DiskCacheLoader cacheLoader = new DiskCacheLoader(getActivity()) {

                @Override
                public DiskCache loadInBackground() {

                    AbstractListResponse cacheLooseListResponse = loadCacheContent();

                    if (cacheLooseListResponse != null) {
                        DiskCache cache = new DiskCache();

                        cache.setResponse(cacheLooseListResponse);

                        return cache;
                    }

                    return null;
                }
            };

            if (bundle != null && !bundle.getBoolean("deliverOnly")) {
                cacheLoader.setDeliverOnly(false);
            }

            return cacheLoader;
        }

        @Override
        public void onLoadFinished(Loader<DiskCache> loader, DiskCache diskCacheResult) {

            if (getActivity() == null) {
                return;
            }

            getActivity().getSupportLoaderManager().destroyLoader(loader.getId());

            cacheLoadFinished(diskCacheResult);
        }

        @Override
        public void onLoaderReset(Loader<DiskCache> loader) {

        }

    }

    protected void cacheLoadFinished(DiskCache diskCacheResult) {

        if (!hasDiskCache(diskCacheResult)) {
            loadDefaultContent();
            handleRequest(true);
        } else {
            List<BaseInfo> list = diskCacheResult.getResponse().getLooseListResponse().getList();
            getAdapter().addItem(list);
            setNextCursorId(diskCacheResult.getResponse().getLooseListResponse().getNextCursorId());
            setNeedLoadMore(diskCacheResult.getResponse().getLooseListResponse().getHasMore());
            getAdapter().notifyDataSetChanged();
            onDataLoadFinished();
            if (mListView != null) {
                mListView.showLoadMoreView(isNeedLoadMore());
            }
        }

    }

    protected boolean hasDiskCache(DiskCache cache) {
        if (cache != null && cache.getResponse() != null
                && cache.getResponse().getLooseListResponse() != null
                && !CollectionUtil.isEmpty(cache.getResponse().getLooseListResponse().getList())) {

            return true;
        }
        return false;
    }

    public boolean hasResponse(AbstractListResponse response) {
        if (response != null && response.getLooseListResponse() != null
                && !CollectionUtil.isEmpty(response.getLooseListResponse().getList())) {
            return true;
        }
        return false;
    }

    protected AbstractListResponse loadCacheContent() {
        return null;
    }

    protected void resetAdapter() {
        mAdapter = new BaseMultiAdapter(this);

        if (mListView != null) {
            mListView.getRefreshableView().setAdapter(mAdapter);
        }
    }

    protected AbstractAdapter getAdapter() {
        if (mAdapter == null) {
            mAdapter = new BaseMultiAdapter(this);
        }
        
        return mAdapter;
    }

    protected boolean isNeedRefreshOnSizeChanged() {
        return Boolean.FALSE;
    }

    protected boolean isInternalScrollListenerOn() {
        return Boolean.FALSE;
    }

    protected boolean isLoadMoreVisible() {

        if (!mIsLoading && isNeedLoadMore()) {
            return Boolean.TRUE;
        }

        return Boolean.FALSE;

    }

    protected void loadMore() {
        handleRequest(false);
    }

    protected String getCacheFilename() {
        return "";
    }

    public boolean isNeedLoadMore() {
        return mNeedLoadMore;
    }

    public void setNeedLoadMore(boolean mNeedLoadMore) {
        this.mNeedLoadMore = mNeedLoadMore;
    }

    public String getNextCursorId() {
        return mNextCursorId;
    }

    public void setNextCursorId(String mNextCursorId) {
        this.mNextCursorId = mNextCursorId;
    }

    public void listRefreshing() {
        if (mIsLoading && mListView.getState() != PullToRefreshBase.State.RESET) {
            return;
        }
        scrollToTop();
        mListView.setRefreshing();
    }

    protected void showNoResult() {

        if (mNoResult == null) {
            return;
        }

        if (getAdapter().isEmpty()) {
            mNoResult.setText(getNoResultText());
            mNoResult.setVisibility(View.VISIBLE);
        } else {
            mNoResult.setVisibility(View.GONE);
        }
    }

    protected int getNoResultText() {
        return R.string.empty;
    }

    public long getRequestTimeStamp() {
        return mRequestTimeStamp;
    }

    public void setRequestTimeStamp(long mRequestTimeStamp) {
        if (mRequestTimeStamp != 0) {
            this.mRequestTimeStamp = mRequestTimeStamp;
        }
    }

    public boolean isNeedPreLoad() {
        return false;
    }

    @Override
    public void beforeScroll(int firstVisibleItem) {

    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount,
                         int totalItemCount) {

    }

    @Override
    public void onFling() {

    }

    @Override
    public void onIdle() {

    }

}
