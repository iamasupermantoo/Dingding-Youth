package com.ddlad.student.ui.attendclass.schedule;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.R;

import uk.co.senab.photoview.PhotoView;
import uk.co.senab.photoview.PhotoViewAttacher;

/**
 * Created by chenjianing on 2017/5/6 0006.
 */
public class BigImageFragment extends BaseFragment {

    private String url;
    private PhotoView mBigImage;
    private ViewGroup mBigImageBg;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_layout_big_image;
    }

    @Override
    protected void onInitView(View contentView) {

        mBigImage = (PhotoView) contentView.findViewById(R.id.big_image);
        mBigImageBg = (ViewGroup) contentView.findViewById(R.id.big_iamge_layout);
        Glide.with(getActivity()).load(url.substring(url.indexOf("http"),url.indexOf("@{w}"))).into(mBigImage);
        mBigImage.setOnPhotoTapListener(new PhotoViewAttacher.OnPhotoTapListener() {
            @Override
            public void onPhotoTap(View view, float v, float v1) {
                mBigImageBg.setVisibility(View.GONE);
                getActivity().onBackPressed();
            }
        });

    }

    @Override
    protected void onInitData(Bundle bundle) {
        url = bundle.getString("url");
    }
}
