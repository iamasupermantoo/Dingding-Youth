package com.ddlad.student.protocol.http.cache;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class AudioFileResource implements ch.boye.httpclientandroidlib.client.cache.Resource {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private long fileLength;

    private final File file;

    public AudioFileResource(File file) {
        this.file = file;
        if (file != null && file.exists()) {
            this.fileLength = file.length();
        }
    }

    public File getFile() {
        return file;
    }

    @Override
    public void dispose() {

    }

    @Override
    public synchronized FileInputStream getInputStream() throws IOException {
        if (file != null && file.exists()) {
            this.fileLength = file.length();
            return new FileInputStream(this.file);
        }
        return null;
    }

    @Override
    public long length() {
        return fileLength;
    }

}
