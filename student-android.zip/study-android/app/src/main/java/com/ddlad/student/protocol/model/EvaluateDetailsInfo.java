package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.ui.model.MultiImageInfo;

import java.io.IOException;

/**
 * Created by Administrator on 2016/12/20 0020.
 */

public class EvaluateDetailsInfo extends BaseInfo{


    /**
     * reaction : {"teacher":"wangsch","date":"2017-02-14","teacherHeadImg":{"pattern":"http://img.z.ziduan.com/FCNC-zHElhA9RzEFBVF2BQ.png@{w}w_{h}h_75q","width":200,"height":200,"id":"FCNC-zHElhA9RzEFBVF2BQ"},"time":"08:30 - 09:30","remark":"å\u0093\u0088å\u0093\u0088å\u0093\u0088å\u0093\u0088","course":"Java super课","star":5,"acceptance":4,"quality":4}
     */
        private ReactionBean reaction;

        public ReactionBean getReaction() {
            return reaction;
        }

        public void setReaction(ReactionBean reaction) {
            this.reaction = reaction;
        }

        public static class ReactionBean {
            private String teacher;
            private String date;
            /**
             * pattern : http://img.z.ziduan.com/FCNC-zHElhA9RzEFBVF2BQ.png@{w}w_{h}h_75q
             * width : 200
             * height : 200
             * id : FCNC-zHElhA9RzEFBVF2BQ
             */

            private MultiImageInfo teacherHeadImg;
            private String time;
            private String remark;
            private String course;
            private int star;
            private int acceptance;
            private int quality;

            public String getTeacher() {
                return teacher;
            }

            public void setTeacher(String teacher) {
                this.teacher = teacher;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public MultiImageInfo getTeacherHeadImg() {
                return teacherHeadImg;
            }

            public void setTeacherHeadImg(MultiImageInfo teacherHeadImg) {
                this.teacherHeadImg = teacherHeadImg;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getRemark() {
                return remark;
            }

            public void setRemark(String remark) {
                this.remark = remark;
            }

            public String getCourse() {
                return course;
            }

            public void setCourse(String course) {
                this.course = course;
            }

            public int getStar() {
                return star;
            }

            public void setStar(int star) {
                this.star = star;
            }

            public int getAcceptance() {
                return acceptance;
            }

            public void setAcceptance(int acceptance) {
                this.acceptance = acceptance;
            }

            public int getQuality() {
                return quality;
            }

            public void setQuality(int quality) {
                this.quality = quality;
            }

            public static ReactionBean fromJsonParser(JsonParser jsonParser) throws IOException {

                ReactionBean info = null;

                if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

                    while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                        String fieldName = jsonParser.getCurrentName();

                        if (fieldName == null) {
                            continue;
                        }

                        if (info == null) {
                            info = new ReactionBean();
                        }
                        if ("date".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.date = jsonParser.getText();
                            continue;
                        }

                        if ("teacher".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.teacher = jsonParser.getText();
                            continue;
                        }

                        if ("remark".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.remark = jsonParser.getText();
                            continue;
                        }
                        if ("time".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.time = jsonParser.getText();
                            continue;
                        }
                        if ("teacherHeadImg".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.teacherHeadImg = MultiImageInfo.fromJsonParser(jsonParser);
                            continue;
                        }
                        if ("course".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.course = jsonParser.getText();
                            continue;
                        }
                        if ("star".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.star = jsonParser.getIntValue();
                            continue;
                        }
                        if ("acceptance".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.acceptance = jsonParser.getIntValue();
                            continue;
                        }
                        if ("quality".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.quality = jsonParser.getIntValue();
                            continue;
                        }
                        jsonParser.skipChildren();
                    }
                }
                return info;
            }
        }

    public static EvaluateDetailsInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        EvaluateDetailsInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new EvaluateDetailsInfo();
                }

                if ("reaction".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.reaction =  ReactionBean.fromJsonParser(jsonParser);
                    continue;
                }
                jsonParser.skipChildren();
            }
        }
        return info;
    }
}



