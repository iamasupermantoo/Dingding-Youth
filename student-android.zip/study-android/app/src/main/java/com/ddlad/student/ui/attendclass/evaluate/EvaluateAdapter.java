package com.ddlad.student.ui.attendclass.evaluate;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.model.EvaluateListInfo;
import com.ddlad.student.ui.widget.image.NetworkImageView;

/**
 * Created by Administrator on 2017/3/17 0017.
 */
public class EvaluateAdapter extends RecyclerView.Adapter implements View.OnClickListener{

    private boolean mIsHasNext;
    private EvaluateListInfo mInfo;

    public EvaluateAdapter(EvaluateListInfo mInfo) {
        this.mInfo = mInfo;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.evaluate_item_layout,null);
        MyViewHolder holder = new MyViewHolder(view);
        holder.mEvaluate.setOnClickListener(this);
        return holder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MyViewHolder viewHolder = (MyViewHolder) holder;
        viewHolder.mCourse.setText( mInfo.getReactions().getList().get(position).getCourse());
        viewHolder.mTeacher.setText(mInfo.getReactions().getList().get(position).getTeacher());
        viewHolder.mTime.setText(mInfo.getReactions().getList().get(position).getTime());
        viewHolder.mClassTime.setText(mInfo.getReactions().getList().get(position).getDate());
        String url =  mInfo.getReactions().getList().get(position).getImage().getPattern();
        viewHolder.mImage.setUrl(url.substring(url.indexOf("http"),url.indexOf(".png"))+".png");
        viewHolder.mEvaluate.setText("已评价");
        viewHolder.mEvaluate.setBackgroundResource(R.drawable.gray_round_rect_btn);

        viewHolder.mEvaluate.setTag(position);
        viewHolder.mEvaluate.setOnClickListener(this);

        viewHolder.mImage.setTag(position);
        viewHolder.mImage.setOnClickListener(this);
        viewHolder.mEvluateDetails.setTag(position);
        viewHolder.mEvluateDetails.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.evaluate:
                //跳到评价详情
                if (mOnItemClickListener != null){
                    mOnItemClickListener.onItemImageClick(v, (Integer) v.getTag());
                }
                break;
            case R.id.evaluate_details:
                ;
            case R.id.evaluate_item_image:
                //跳到个人详情
                if (mOnItemClickListener != null){
                    mOnItemClickListener.onItemClick(v, (Integer) v.getTag());
                }
        }

    }

    public static interface OnRecyclerViewItemClickListener{
        void onItemClick(View view, int position);
        void onItemImageClick(View view, int position);
    }

    private OnRecyclerViewItemClickListener mOnItemClickListener = null;

    public void setmOnItemClickListener(OnRecyclerViewItemClickListener onItemClickListener){
        mOnItemClickListener = onItemClickListener;
    }


    @Override
    public int getItemCount() {
        return mInfo.getReactions().getList().size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        public TextView mCourse;
        public TextView mClassTime;
        public TextView mTeacher;
        public TextView mTime;
        public NetworkImageView mImage;
        public TextView mEvaluate;
        public ViewGroup mEvluateDetails;
        public MyViewHolder(View itemView) {
            super(itemView);
            mCourse = (TextView) itemView.findViewById(R.id.evaluate_item_course);
            mClassTime = (TextView) itemView.findViewById(R.id.evaluate_item_class_time);
            mTeacher = (TextView) itemView.findViewById(R.id.evaluate_item_teacher);
            mTime = (TextView) itemView.findViewById(R.id.evaluate_item_time);
            mImage = (NetworkImageView) itemView.findViewById(R.id.evaluate_item_image);
            mEvaluate = (TextView) itemView.findViewById(R.id.evaluate);
            mEvluateDetails = (ViewGroup) itemView.findViewById(R.id.evaluate_details);
        }
    }
}
