package com.ddlad.student.tools;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.alipay.sdk.app.PayTask;
import com.ddlad.student.AliPay.AuthResult;
import com.ddlad.student.AliPay.PayResult;
import com.ddlad.student.protocol.model.AlipayOrderInfo;
import com.ddlad.student.protocol.model.PayParamsInfo;
import com.ddlad.student.protocol.model.WxpayOrderInfo;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.dialog.IDialogClickListener;
import com.ddlad.student.wxapi.WechatHelper;
import com.tencent.mm.sdk.modelpay.PayReq;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;

import java.util.Map;

/**
 * Created by chen007 on 2017/11/10 0010.
 */
public class PayUtil {

    private final String TAG = "PayUtil";
    /////WX
    private static final int MY_WX_PAY = 222;
    private IWXAPI api;

    private WechatHelper mWechatHelper;

    /////支付宝
    /** 商户私钥，pkcs8格式 */
    /** 如下私钥，RSA2_PRIVATE 或者 RSA_PRIVATE 只需要填入一个 */
    /** 如果商户两个都设置了，优先使用 RSA2_PRIVATE */
    /** RSA2_PRIVATE 可以保证商户交易在更加安全的环境下进行，建议使用 RSA2_PRIVATE */
    /** 获取 RSA2_PRIVATE，建议使用支付宝提供的公私钥生成工具生成， */



    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == MY_WX_PAY) {


            }
            super.handleMessage(msg);
        }
    };

    public void WxPay(PayParamsInfo payParamsInfo, Context context){
        PayParamsInfo.ParamsBean.WeiXinBean mWXInfo = payParamsInfo.getParams().getWeiXin();
        Log.i(TAG, "handleMessage: Handler获取到网络返回的数据");
        Log.i(TAG, "handleMessage: "+mWXInfo.getAppid()+mWXInfo.getPrepayid()+mWXInfo.getTimestamp());
        mWechatHelper = new WechatHelper();
        api = WXAPIFactory.createWXAPI(context, mWechatHelper.getAppId(),false);
        boolean login = api.registerApp(mWechatHelper.getAppId());
        Log.i(TAG, "handleMessage: login is Success???"+login);
        PayReq request = new PayReq();
        request.packageValue = "Sign=WXPay";
        request.appId = mWXInfo.getAppid();
        request.sign= mWXInfo.getSign();
        request.partnerId = mWXInfo.getPartnerid();
        request.prepayId= mWXInfo.getPrepayid();
        request.nonceStr= mWXInfo.getNoncestr();
        request.timeStamp= mWXInfo.getTimestamp();
        boolean sucess = api.sendReq(request);
        Log.i(TAG, "handleMessage: sendreq is Success???"+sucess);
    }


/////////////////////////////////////////////////////////////////////////////////////////////////////


    public void AliPay(String orderStr, final BaseFragment fragment, final IDialogClickListener listener){
        final String mAliPayOrderInfo = orderStr;

        Runnable payRunnable = new Runnable() {
            @Override
            public void run() {
                PayTask alipay = new PayTask(fragment.getActivity());
                Map<String, String> result = alipay.payV2(mAliPayOrderInfo, true);
                Log.i("msp", result.toString());


                PayResult payResult = new PayResult(result);
                String resultInfo = payResult.getResult();// 同步返回需要验证的信息
                String resultStatus = payResult.getResultStatus();
                // 判断resultStatus 为9000则代表支付成功
                Message msg = new Message();
                msg.what = Constants.SDK_PAY_FLAG;
                if (TextUtils.equals(resultStatus, "9000")) {
                    // 该笔订单是否真实支付成功，需要依赖服务端的异步通知。
                    //进入验证页面去和服务器验证是否支付成功
//            navigateToPayResult();
                    if (listener != null){
                        listener.onClick(1);
                    }
                    msg.obj = true;
                } else {
                    if (listener != null){
                        listener.onClick(0);
                    }
                    // 该笔订单真实的支付结果，需要依赖服务端的异步通知。
                    msg.obj = false;
                }
//                fragment.getHandle().sendMessage(msg);
            }
        };
        // 必须异步调用
        Thread payThread = new Thread(payRunnable);
        payThread.start();
    }

    public boolean payResultState(PayResult payResult){
        @SuppressWarnings("unchecked")
        /**
         对于支付结果，请商户依赖服务端的异步通知结果。同步通知结果，仅作为支付结束的通知。
         */
        String resultInfo = payResult.getResult();// 同步返回需要验证的信息
        String resultStatus = payResult.getResultStatus();
        // 判断resultStatus 为9000则代表支付成功
        if (TextUtils.equals(resultStatus, "9000")) {
            // 该笔订单是否真实支付成功，需要依赖服务端的异步通知。
            //进入验证页面去和服务器验证是否支付成功
//            navigateToPayResult();
            return true;
        } else {
            // 该笔订单真实的支付结果，需要依赖服务端的异步通知。
            return false;
        }

    }

    /**
     * get the sdk version. 获取支付宝SDK版本号
     *
     */
    public void getSDKVersion(Activity context) {
        PayTask payTask = new PayTask(context);
        String version = payTask.getVersion();
        Toast.makeText(context, version, Toast.LENGTH_SHORT).show();
    }
}
