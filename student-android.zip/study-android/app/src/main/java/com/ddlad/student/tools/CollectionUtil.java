package com.ddlad.student.tools;

import java.util.Collection;
import java.util.Map;

/**
 * Created by Albert
 * on 16-6-2.
 */
public class CollectionUtil {
    /**
     * Return <code>true</code> if the supplied Collection is
     * <code>null</code> or empty. Otherwise, return <code>false</code>.
     *
     * @param collection the Collection to check
     * @return whether the given Collection is empty
     */
    public static boolean isEmpty(Collection<?> collection) {
        return ((collection == null) || collection.isEmpty());
    }


    public static boolean hasData(Collection<?> collection) {
        return !isEmpty(collection);
    }

    public static int getSize(Collection<?> collection) {
        return collection == null ? 0 : collection.size();
    }

    public static boolean hasItem(Collection<?> collection, int index) {
        return 0 <= index && index < getSize(collection);
    }


    /**
     * Return <code>true</code> if the supplied Map is <code>null</code> or
     * empty. Otherwise, return <code>false</code>.
     *
     * @param map the Map to check
     * @return whether the given Map is empty
     */
    public static boolean isEmpty(Map<?, ?> map) {
        return ((map == null) || map.isEmpty());
    }
}
