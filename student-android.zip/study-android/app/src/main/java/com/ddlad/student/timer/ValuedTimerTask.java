package com.ddlad.student.timer;

import java.util.TimerTask;

/**
 * Created by Albert
 * on 16-10-18.
 */
public class ValuedTimerTask extends TimerTask {

    protected long mValue;
    protected long mDelay;
    protected long mPeriod;
    protected String mTag;
    protected TimerListener mListener;

    public ValuedTimerTask() {
        this.mDelay = 1000;
        this.mPeriod = 1000;
        this.mValue = 60 * this.mPeriod;
    }

    public ValuedTimerTask(long value, long delay, long period, String tag) {
        this.mValue = value;
        this.mDelay = delay;
        this.mPeriod = period;
        this.mTag = tag;
    }

    public ValuedTimerTask(long value, long delay, long period, String tag, TimerListener listener) {
        this.mValue = value;
        this.mDelay = delay;
        this.mPeriod = period;
        this.mTag = tag;
        this.mListener = listener;
    }

    public long getValue() {
        return mValue;
    }

    public void setValue(long value) {
        this.mValue = value;
    }

    public long getDelay() {
        return mDelay;
    }

    public void setDelay(long delay) {
        this.mDelay = delay;
    }

    public long getPeriod() {
        return mPeriod;
    }

    public void setPeriod(long period) {
        this.mPeriod = period;
    }

    public String getTag() {
        return mTag;
    }

    public void setTag(String tag) {
        this.mTag = tag;
    }

    public TimerListener getListener() {
        return mListener;
    }

    public void setListener(TimerListener mListener) {
        this.mListener = mListener;
    }

    @Override
    public void run() {

        if (mValue > mPeriod) {
            mValue -= mPeriod;
            if (mListener != null) {
                mListener.onSchedule(mValue, true);
            }
        } else {
            TimerController.release();
            mListener.onSchedule(mValue, false);
        }

    }
}
