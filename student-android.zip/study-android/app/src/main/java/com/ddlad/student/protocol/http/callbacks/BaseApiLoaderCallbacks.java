package com.ddlad.student.protocol.http.callbacks;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.text.TextUtils;

import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.AsyncTaskDataLoader;
import com.ddlad.student.primary.ClickManager;
import com.ddlad.student.primary.Log;
import com.ddlad.student.protocol.convert.DataCenter;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.HttpResponseCode;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.ui.common.AlertDialogFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.request.AbstractRequest;


public class BaseApiLoaderCallbacks<T> implements LoaderManager.LoaderCallbacks<ApiResponse<T>> {

    private static final String TAG = "BaseApiLoaderCallbacks";

    private final AbstractCallbacks<T> mApiCallbacks;

    protected final Context mContext;

    private AbstractRequest<T> mRequest;

    public BaseApiLoaderCallbacks(AbstractCallbacks<T> apiCallbacks, Context context,
                                  AbstractRequest<T> request) {

        mContext = context.getApplicationContext();
        mApiCallbacks = apiCallbacks;
        mRequest = request;
    }

    public static void handleRequestServerErrorMessage(final String errorTitle,
                                                       final String errorMessage) {

        Handler handler = ClickManager.getInstance().getHandler();
        final FragmentManager fragmentManager = ClickManager.getInstance()
                .getCurrentFragmentManager();

        if ((handler != null) && (fragmentManager != null)) {
            handler.post(new Runnable() {

                @Override
                public void run() {
                    AlertDialogFragment.newInstance(errorTitle, errorMessage).show(fragmentManager,
                            TAG);
                }
            });
        }
    }

    public AbstractCallbacks<T> getApiCallbacks() {
        return this.mApiCallbacks;
    }

    public Context getContext() {
        return this.mContext;
    }

    @Override
    public Loader<ApiResponse<T>> onCreateLoader(int loadId, Bundle bundle) {
        return new AsyncTaskDataLoader<ApiResponse<T>>(mContext);
    }

    @Override
    public void onLoadFinished(Loader<ApiResponse<T>> loader, ApiResponse<T> response) {

        if (response != null) {

            if (mApiCallbacks != null) {
                mApiCallbacks.onRequestFinished();

                String error = response.getError();
                String errorDescription = response.getErrorDescription();

                if (Log.DEBUG) {
                    Log.d(TAG, "response.getResponseCode()=" + response.getResponseCode()
                            + ", response.getStatus()=" + response.getStatus()
                            + ", errorDescription=" + errorDescription);
                }

                if (response.getCode() == HttpResponseCode.STATUS_CODE_TOKEN_INVALID) {
                    Toaster.toastShort(AppContext.getString(R.string.token_invalid, response.getCode()));
                    DataCenter.logout(getContext());
                    return;
                }

                if (response.isNotModified()) {
                    if (Log.DEBUG) {
                        Log.d(TAG, "response.getResponseCode()=" + response.getResponseCode());
                    }
                    mApiCallbacks.onSuccessNotModify();
                    return;
                }

                if (!TextUtils.isEmpty(errorDescription)) {

                    error = response.getError();
                    if (Log.DEBUG) {
                        Log.d(TAG,
                                "error:" + error + ",errorDescription="
                                        + response.getErrorDescription()
                                        + ", response.getResponseCode()="
                                        + response.getResponseCode());
                    }

                    if ((response.getResponseCode() != null && response.getResponseCode() == HttpResponseCode.STATUS_CODE_SERVICE_UNAVAILABLE)
                            || mRequest.shouldShowAlertForRequest(response)) {
                        handleRequestServerErrorMessage(response.getErrorTitle(),
                                response.getErrorDescription());
                    } else {
                        mApiCallbacks.onFail(response);
                    }

                    response.setErrorStatusIfFailedToLoad();

                } else if (response.isOk()) {

                    mApiCallbacks.onSuccess(response.getSuccessObject());
                }
            }

        }
    }

    @Override
    public void onLoaderReset(Loader<ApiResponse<T>> loader) {

    }

}
