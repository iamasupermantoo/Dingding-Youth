package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ddlad.student.ui.model.MultiImageInfo;

import java.io.IOException;
import java.util.List;

/**
 * Created by chenjianing on 2017/3/28 0028.
 */
public class HomeWorkDetailsInfo {

        private DetailsBean details;

        private List<AnswersBean> answers;

        public DetailsBean getDetails() {
            return details;
        }

        public void setDetails(DetailsBean details) {
            this.details = details;
        }

        public List<AnswersBean> getAnswers() {
            return answers;
        }

        public void setAnswers(List<AnswersBean> answers) {
            this.answers = answers;
        }

        public static class DetailsBean {
            private String content;
            private String course;
            private String date;
            private String hid;
            private int status;
            private String student;
            private String teacher;
            private String time;
            private String title;


            private String correctDate;
            private String remark;
            private boolean intime;
            private int complete;
            private int quality;




            public String getCorrectDate() {
                return correctDate;
            }

            public void setCorrectDate(String correctDate) {
                this.correctDate = correctDate;
            }
            public String getRemark() {
                return remark;
            }

            public void setRemark(String remark) {
                this.remark = remark;
            }

            public boolean isIntime() {
                return intime;
            }

            public void setIntime(boolean intime) {
                this.intime = intime;
            }

            public int getComplete() {
                return complete;
            }

            public void setComplete(int complete) {
                this.complete = complete;
            }


            public int getQuality() {
                return quality;
            }

            public void setQuality(int quality) {
                this.quality = quality;
            }



            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getCourse() {
                return course;
            }

            public void setCourse(String course) {
                this.course = course;
            }

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getHid() {
                return hid;
            }

            public void setHid(String hid) {
                this.hid = hid;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public String getStudent() {
                return student;
            }

            public void setStudent(String student) {
                this.student = student;
            }

            public String getTeacher() {
                return teacher;
            }

            public void setTeacher(String teacher) {
                this.teacher = teacher;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }
            public static DetailsBean fromJsonParser(JsonParser jsonParser) throws IOException {

                DetailsBean info = null;

                if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

                    while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                        String fieldName = jsonParser.getCurrentName();

                        if (fieldName == null) {
                            continue;
                        }

                        if (info == null) {
                            info = new DetailsBean();
                        }

                        if ("date".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.date = jsonParser.getText();
                            continue;
                        }
                        if ("hid".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.hid = jsonParser.getText();
                            continue;
                        }
                        if ("time".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.time = jsonParser.getText();
                            continue;
                        }
                        if ("course".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.course = jsonParser.getText();
                            continue;
                        }
                        if ("ddlad".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.student = jsonParser.getText();
                            continue;
                        }
                        if ("teacher".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.teacher = jsonParser.getText();
                            continue;
                        }
                        if ("title".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.title = jsonParser.getText();
                            continue;
                        }
                        if ("content".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.content = jsonParser.getText();
                            continue;
                        }
                        if ("status".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.status = jsonParser.getIntValue();
                            continue;
                        }
                        jsonParser.skipChildren();
                    }
                }
                return info;
            }
        }

        public static class AnswersBean {
            private String id;
            private String text;
            private String time;
            private int audioLength;
            private String audio;
            private List<MultiImageInfo> images;

            public int getAudioLength() {
                return audioLength;
            }

            public void setAudioLength(int audioLength) {
                this.audioLength = audioLength;
            }

            public String getAudio() {
                return audio;
            }

            public void setAudio(String audio) {
                this.audio = audio;
            }

            public List<MultiImageInfo> getImages() {
                return images;
            }

            public void setImages(List<MultiImageInfo> images) {
                this.images = images;
            }

            private int type;

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getText() {
                return text;
            }

            public void setText(String text) {
                this.text = text;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public static AnswersBean fromJsonParser(JsonParser jsonParser) throws IOException {

                AnswersBean info = null;

                if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

                    while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                        String fieldName = jsonParser.getCurrentName();

                        if (fieldName == null) {
                            continue;
                        }

                        if (info == null) {
                            info = new AnswersBean();
                        }

                        if ("audio".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.audio = jsonParser.getText();
                            continue;
                        }
                        if ("text".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.text = jsonParser.getText();
                            continue;
                        }
                        if ("id".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.id = jsonParser.getText();
                            continue;
                        }
                        if ("time".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.time = jsonParser.getText();
                            continue;
                        }
                        if ("audioLength".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.audioLength = jsonParser.getIntValue();
                            continue;
                        }
                        if ("type".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.type = jsonParser.getIntValue();
                            continue;
                        }
                        if ("images".equals(fieldName)) {
                            jsonParser.nextToken();
                            ObjectMapper mapper = new ObjectMapper();
                            info.images = mapper.readValue(jsonParser, List.class);
                            continue;
                        }

                        jsonParser.skipChildren();
                    }
                }
                return info;
            }
        }
    public static HomeWorkDetailsInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        HomeWorkDetailsInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new HomeWorkDetailsInfo();
                }

                if ("details".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.details = DetailsBean.fromJsonParser(jsonParser);
                    continue;
                }
                if ("answers".equals(fieldName)) {
                    jsonParser.nextToken();
                    ObjectMapper mapper = new ObjectMapper();
                    info.answers = mapper.readValue(jsonParser, List.class);
                    continue;
                }
                jsonParser.skipChildren();
            }
        }
        return info;
    }
}
