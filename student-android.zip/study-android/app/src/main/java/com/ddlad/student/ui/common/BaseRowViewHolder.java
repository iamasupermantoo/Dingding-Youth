package com.ddlad.student.ui.common;

public class BaseRowViewHolder {

    public static final int NUM_IMAGES_PER_ROW = 2;

}
