package com.ddlad.student.protocol.http.internal;


import com.ddlad.student.primary.Log;

public class ProtocolConstants {

//    private static final String DOMAIN_DEBUG = "z.ziduan.com";
    private static final String DOMAIN_DEBUG = "ddlad.com";

    private static final String DOMAIN_RELEASE = "ddlad.com";

    //    public static final String DOMAIN = Log.DEBUG ? DOMAIN_DEBUG : DOMAIN_RELEASE;
    //加彩蛋，去点了final
    public static  String DOMAIN = Log.DEBUG ? DOMAIN_DEBUG : DOMAIN_RELEASE;

    public static void setDOMAIN() {
        DOMAIN = Log.DEBUG ? DOMAIN_DEBUG : DOMAIN_RELEASE;
    }

    public static final String HTTP_METHOD_GET = "GET";

    public static final String HTTP_METHOD_POST = "POST";

    public static final String HTTP_METHOD_DELETE = "DELETE";

    //--------------------------------- Urls ---------------------------------//

    public static final String URL_REGISTER_CODE = "register/getCode";

    public static final String URL_REGISTER_VERIFY = "register/verifyCode";

    public static final String URL_MOBILE_SIGN_UP = "register/mobile";
    //第三方注册，点击注册接口
    public static final String URL_MOBILE_SIGN_CONNECT = "register/connect";

    public static final String URL_WECHAT_SIGN_UP = "register/weixin";

    public static final String URL_QQ_SIGN_UP = "register/qq";

    public static final String URL_REFINE_COLLEGE = "ddlad/college/add";

    public static final String URL_REFINE_SENIOR = "ddlad/senior/add";

    public static final String URL_PASSWORD_CODE = "password/getCode";
    //第三方登录失败时获取绑定手机号获取验证码
    public static final String URL_CONNECT_CODE = "connect/getCode";
    //绑定第三方账号
    public static final String URL_LOGIN_BIND = "connect/login/bind";

    public static final String URL_CONNECT_BIND = "connect/bind";

    public static final String URL_PASSWORD_RESET = "password/reset";

    public static final String URL_PASSWORD_CHANGE = "/password/change";

    public static final String URL_HOMEWORK_ANSWER_REMOVE = "/homework/answer/remove";
    //账号登陆接口
    public static final String URL_MOBILE_SIGN_IN = "login/mobile";

    public static final String URL_WECHAT_SIGN_IN = "login/weixin";

    public static final String URL_QQ_SIGN_IN = "login/qq";
    //动态页面的接口
    public static final String URL_FEED_LIST = "/feed/list";

    //问答页面接口
    public static final String URL_QUESTIONS_LIST = "/question/list";

    //学生课程列表接口
    public static final String URL_CURRICULUM_LIST = "course/list";
    //学生课程列表接口
    public static final String URL_LESSON_LIST = "lesson/list";
    //作业列表接口
    public static final String URL_HOMEWORK_LIST = "homework/list";

    //学生课程列表接口
    public static final String URL_SCHEDULE_LIST = "calendar/reminders";
    public static final String URL_LESSON_CALENDAR_LIST = "lesson/calendar/list";

    //课程详细信息
    public static final String URL_COURSE_META_DETAILS = "course/meta/details";
    //老师详细信息
    public static final String URL_TEACHER_DETAILS = "teacher/details";

    //评价列表
    public static final String URL_EVALUATE_LIST = "/reaction/list";
    public static final String URL_EVALUATE_DETAILS = "/reaction/details";
    public static final String URL_REACTION_DETAILS_BYTEACHER = "reaction/details/byteacher";




    public static final String URL_HOMEWORK_DETAILS = "homework/details";

    public static final String URL_HOMEWORK_COMMIT = "homework/answer/commit";

    public static final String URL_SCHEDULE_POINTS = "calendar/points";

    public static final String URL_LOG_OUT = "logout";

    public static final String URL_RECOMMEND_FEED_LIST = "recommend/feed/list";

    public static final String URL_RECOMMEND_USER_LIST = "recommend/user/list";

    public static final String URL_RECOMMEND_BANNERS = "recommend/banners";

    public static final String URL_MESSAGE_LIST = "message/list";

    public static final String URL_PUBLISH_ARTICLE = "post/publish/article";

    public static final String URL_ANSWER_ARTICLE = "/answer/publish";

    public static final String URL_PUBLISH_PICTURE = "post/publish/picture";

//    public static final String URL_PROFILE = "profile";
    public static final String URL_PROFILE = "/mine/info";

    public static final String URL_CONSTANTS = "constants";

    public static final String URL_CONNECT = "login/connect";

    public static final String URL_ORDER_INFO = "order/info";

    public static final String URL_PAY_PARAMS = "pay/params";

    public static final String URL_UNBIND = "connect/unbind";

    public static final String URL_STUDENT = "ddlad/get";

    public static final String URL_PROFILE_POST_LIST = "profile/post/list";

    public static final String URL_PROFILE_FAVOR_LIST = "profile/fav/list";

    public static final String URL_POST_DETAILS = "post/details";

    public static final String URL_POST_FAV = "post/fav";

    public static final String URL_POST_PRAISE = "/answer/up";

    public static final String URL_POST_TREAD = "/answer/down";

    public static final String URL_POST_UNFAV = "post/unfav";

    public static final String URL_COMMENT_LIST = "post/comment/list";
    public static final String URL_ANSWER_COMMENT_LIST = "answer/comment/list";

    public static final String URL_IMAGE_UPLOAD = "/image/upload";

    public static final String URL_RELATION_FOLLOW = "relation/follow";

    public static final String URL_RELATION_UNFOLLOW = "relation/unfollow";

    public static final String URL_FOLLOWING_LIST = "relation/following/list";

    public static final String URL_FANS_LIST = "relation/follower/list";

    public static final String URL_SEARCH_USER = "user/search";

    public static final String URL_SEARCH_COLLEGE = "college/suggest";

    public static final String URL_SEARCH_ACADEMY = "college/academys";

    public static final String URL_SEARCH_SENIOR = "senior/suggest";

//    public static final String URL_COLLEGE_UPDATE = "ddlad/college/update";
    public static final String URL_COLLEGE_UPDATE = "/mine/update";

    public static final String URL_SENIOR_UPDATE = "ddlad/senior/update";

    public static final String URL_PUSH_BIND = "push/bind";

    public static final String URL_TIP_OFF = "tipoff";

    public static final String URL_CONFIG_SAVE = "config/save";

    //评价提交
    public static final String URL_EVALUATE_SUBMIT = "reaction/commit";

    public static final String URL_CONFIG_GET = "config/get";

    public static final String URL_CONNETCT_BIND_LIST = "connect/bind/list";

    public static final String URL_FEEDBACK = "feedback";

    public static final String URL_PROFILE_UPDATE_BACK_IMAGE = "profile/update/backimage";

    public static final String URL_POST_DEL = "post/del";

    public static final String URL_COMMENT_DEL = "comment/del";
    //删除问答详情页的评论
    public static final String URL_ANSWER_COMMENT_DEL = "answer/comment/del";

    public static final String URL_CHECK_VERSION = "client/version/check";

    //--------------------------------- Params ---------------------------------//

    public static final String PARAM_X_TIMESTAMP = "X-Timestamp";

    public static final String PARAM_ACCEPT_LANGUAGE = "Accept-Language";

    public static final String PARAM_USER_AGENT = "User-Agent";

    public static final String PARAM_DEVICE_ID = "Device-Id";

    public static final String PARAM_DEVICE_MAC = "Device-MAC";

    public static final String PARAM_PUSH_TOKEN = "token";

    public static final String PARAM_ACCESS_TOKEN = "access_token";

    public static final String PARAM_REFRESH_TOKEN = "refresh_token";

    public static final String PARAM_OPEN_ID = "openid";

    public static final String PARAM_CURSOR = "cursor";

    public static final String PARAM_COUNT = "count";

    public static final String PARAM_TAB_ID = "tab_id";

    public static final String PARAM_ID = "id";

    public static final String PARAM_QID = "qid";

    public static final String PARAM_HID = "hid";

    public static final String PARAM_MOBILE = "mobile";

    public static final String PARAM_ANSWERID = "answerId";

    public static final String PARAM_TYPE = "type";

    public static final String PARAM_CID = "cid";

    public static final String PARAM_DAY = "day";

    public static final String PARAM_CMID = "cmid";

    public static final String PARAM_MONTH = "month";

    public static final String PARAM_TID = "tid";

    public static final String PARAM_FEED = "feed";

    public static final String PARAM_POST = "post";

    public static final String PARAM_TITLE = "title";

    public static final String PARAM_FILE = "file";

    public static final String PARAM_USER = "user";
//    public static final String PARAM_USER = "/mine/info"
        ;
    //QQ的openId
    public static final String PARAM_EXTERNAL_USERID = "externalUserId";
    //QQ的accessToken
    public static final String PARAM_ACCESSTOKEN = "accessToken";

    public static final String PARAM_NICKNAME = "nickname";

    public static final String PARAM_QUESTION = "question";

    public static final String PARAM_SESSUON = "session";

    public static final String PARAM_TO_USER = "toUser";

    public static final String PARAM_TO_USER_ID = "touser";

    public static final String PARAM_CONTENT = "content";

    public static final String PARAM_URI = "uri";

    public static final String PARAM_URL = "url";

    public static final String PARAM_TEXT = "text";

    public static final String PARAM_IMAGE = "image";

    public static final String PARAM_TAGS = "tags";

    public static final String PARAM_NAME = "name";

    public static final String PARAM_AVATAR = "avatar";

    public static final String PARAM_VALUE = "value";

    public static final String PARAM_KEYWORD = "keyword";

    public static final String PARAM_CODE = "code";

    public static final String PARAM_COLLEGE = "college";

    public static final String PARAM_MESSAGE = "message";

    public static final String PARAM_PUSH = "push";

    public static final String PARAM_TARGET = "target";

    public static final String PARAM_HEAD_IMAGE = "headImage";

    public static final String PARAM_SCROLL = "scroll";

    public static final String PARAM_INFO = "info";

    //--------------------------------- Json Field ---------------------------------//

    public static final String JSON_FIELD_META = "meta";

    public static final String JSON_FIELD_CODE = "code";

    public static final String JSON_FIELD_STATUS = "status";

    public static final String JSON_FIELD_DESC = "desc";

    public static final String JSON_FIELD_REQUEST = "request";

    public static final String JSON_FIELD_ID = "id";

    public static final String JSON_FIELD_DATA = "data";

    public static final String JSON_FIELD_DOTS = "dots";

    public static final String JSON_FIELD_ERROR = "error";

    public static final String JSON_FIELD_ERROR_DESCRIPTION = "error_description";

    public static final String JSON_FIELD_LIST = "list";

    public static final String JSON_FIELD_NEXT_CURSOR = "nextCursor";

    public static final String JSON_FIELD_HAS_NEXT = "hasNext";

    public static final String JSON_FIELD_TIMESTAMP = "timestamp";

    public static final String JSON_FIELD_BLOCK_AUTH = "blockAuth";

    public static final String JSON_FIELD_RESULT = "result";

    public static final String JSON_FIELD_FEEDS = "feeds";
    //会话界面 数据
    public static final String JSON_FIELD_SESSIONS = "sessions";
    //聊天界面 数据
    public static final String JSON_FIELD_CHAT = "pms";

    public static final String JSON_FIELD_QUESTIONS = "questions";
    //学生课程列表  数据  key
    public static final String JSON_FIELD_COURSES = "courses";

    public static final String JSON_FIELD_COURSE = "course";
    //课次列表查询  key
    public static final String JSON_FIELD_LESSONS = "lessons";

    public static final String JSON_FIELD_HOMEWORKS = "homeworks";
    //问答界面  问题数据  key
    public static final String JSON_FIELD_QUESTIONS_DETAILS = "details";

    public static final String JSON_FIELD_POSTS = "posts";

    public static final String JSON_FIELD_FAVS = "favs";

    public static final String JSON_FIELD_DETAILS = "details";

    public static final String JSON_FIELD_USERS = "users";

    public static final String JSON_FIELD_COLLEGES = "colleges";

    public static final String JSON_FIELD_SENIORS = "seniors";

    public static final String JSON_FIELD_ACADEMYS = "academys";

    public static final String JSON_FIELD_MESSAGES = "messages";

    public static final String JSON_FIELD_COMMENTS = "comments";

    public static final String JSON_FIELD_BANNERS = "banners";

    public static final String JSON_FIELD_PROFILE = "profile";

    public static final String JSON_FIELD_REACTIONS = "reactions";

    public static final String JSON_FIELD_ANSWERS = "answers";

    public static final String JSON_FIELD_FOLLOWERS = "followers";

    public static final String JSON_FIELD_FOLLOWINGS = "followings";

    public static final String JSON_FIELD_CONFIG = "config";

    public static final String JSON_FIELD_VERSION = "version";

    //--------------------------------- Http Error String ---------------------------------//

    public static final String ERROR_INVALID_TOKEN = "invalid_token";

    public static final String ERROR_INVALID_GRANT = "invalid_grant";

    public static final String ERROR_UNAUTHORIZED = "unauthorized";

}
