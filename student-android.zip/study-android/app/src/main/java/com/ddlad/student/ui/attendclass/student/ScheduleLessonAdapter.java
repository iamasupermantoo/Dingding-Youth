package com.ddlad.student.ui.attendclass.student;

import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.protocol.model.LessonInfo;
import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.ui.attendclass.lesson.LessonItemAdapter;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.common.AbstractAdapter;

import java.util.List;

/**
 * Created by Administrator on 2017/1/17 0017.
 */

public class ScheduleLessonAdapter extends AbstractAdapter<LessonInfo> {

    public ScheduleLessonAdapter(BaseFragment fragment) {
        super(fragment);
    }

    @Override
    public LessonInfo getItem(int position) {
        return mList.get(position);
    }

    @Override
    protected View createView(int position, ViewGroup parent) {
        return LessonItemAdapter.createView(parent);
    }

    @Override
    protected void bindView(int position, View view) {
        LessonItemAdapter.bindView(view,getItem(position),mFragment,this,false);
    }

    @Override
    public void clearItem() {
        mList.clear();
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public void addItem(LessonInfo lessonInfo) {
        mList.add(lessonInfo);
    }

    @Override
    public void addItem(List<LessonInfo> list) {
        if (!CollectionUtil.isEmpty(list)){
            mList.addAll(list);
        }
    }
}
