package com.ddlad.student.ui.choice;

import android.app.Activity;
import android.graphics.Paint;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.model.DiscoverTeacherInfo;
import com.ddlad.student.ui.common.BaseActivity;
import com.facebook.drawee.view.SimpleDraweeView;

import java.util.ArrayList;

/**
 * Created by chen007 on 2017/11/6 0006.
 */
public class DiscoverTeacherAdapter extends RecyclerView.Adapter<DiscoverTeacherAdapter.MyViewHolder> {

    private Activity mActivity;

    private ArrayList<DiscoverTeacherInfo.TeachersBean.ListBean> mInfos;

    public DiscoverTeacherAdapter(Activity activity){
        this.mActivity = activity;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
       View view =  LayoutInflater.from(mActivity).inflate(R.layout.layout_discover_teacher_item,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.teacher_name.setText(mInfos.get(position).getName());
        holder.teacher_age.setText(mInfos.get(position).getAge()+"岁");
        holder.teacher_desc.setText(mInfos.get(position).getDesc());
        Paint textViewPaint =  holder.teacher_desc.getPaint();
        textViewPaint.measureText( holder.teacher_desc.getText().toString());
        if (mInfos.get(position).getImage() != null){
            String url =  mInfos.get(position).getImage().getPattern();
            Uri uri = Uri.parse(url.substring(url.indexOf("http"),url.indexOf("@{w}w")));
            holder.mImage.setImageURI(uri);
        }

    }


    public ArrayList<DiscoverTeacherInfo.TeachersBean.ListBean> getmInfos() {
        return mInfos;
    }

    public void setmInfos(ArrayList<DiscoverTeacherInfo.TeachersBean.ListBean> mInfos) {
        this.mInfos = mInfos;
    }

    @Override
    public int getItemCount() {
        if (mInfos != null){
            return mInfos.size();
        }
        return 0;
    }

    static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView teacher_name;
        TextView teacher_age;
        TextView teacher_desc;
        public com.facebook.drawee.view.SimpleDraweeView mImage;
        public MyViewHolder(View view) {
            super(view);
            teacher_name = (TextView) view.findViewById(R.id.teacher_name);
            teacher_age = (TextView) view.findViewById(R.id.teacher_age);
            teacher_desc = (TextView) view.findViewById(R.id.teacher_desc);
            mImage = (SimpleDraweeView) view.findViewById(R.id.item_image);
        }
    }
}
