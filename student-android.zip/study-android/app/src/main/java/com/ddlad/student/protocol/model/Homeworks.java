package com.ddlad.student.protocol.model;

/**
 * Created by Administrator on 2017/1/19 0019.
 */

public class Homeworks extends BaseInfo {

}
