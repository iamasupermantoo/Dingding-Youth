package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.ui.model.MultiImageInfo;

import java.io.IOException;

/**
 * Created by chen007 on 2017/6/12 0012.
 */
public class LOrderInfo extends BaseInfo{

                private String course;
                private String createTime;
                /**
                 * height : 200
                 * id : Qsksj7PLFa89RzEFBVF2BQ
                 * pattern : http://img.z.ziduan.com/Qsksj7PLFa89RzEFBVF2BQ.png@{w}w_{h}h_75q
                 * width : 200
                 */

                private MultiImageInfo image;
                private int level;
                private String oid;
                private String orderSn;


               private String cmId;
                private int payStatus;
                private int price;
                private int status;
                private int totalCnt;


    public String getCmId() {
        return cmId;
    }

    public void setCmId(String cmId) {
        this.cmId = cmId;
    }
                public String getCourse() {
                    return course;
                }

                public void setCourse(String course) {
                    this.course = course;
                }

                public String getCreateTime() {
                    return createTime;
                }

                public void setCreateTime(String createTime) {
                    this.createTime = createTime;
                }

                public MultiImageInfo getImage() {
                    return image;
                }

                public void setImage(MultiImageInfo image) {
                    this.image = image;
                }

                public int getLevel() {
                    return level;
                }

                public void setLevel(int level) {
                    this.level = level;
                }

                public String getOid() {
                    return oid;
                }

                public void setOid(String oid) {
                    this.oid = oid;
                }

                public String getOrderSn() {
                    return orderSn;
                }

                public void setOrderSn(String orderSn) {
                    this.orderSn = orderSn;
                }

                public int getPayStatus() {
                    return payStatus;
                }

                public void setPayStatus(int payStatus) {
                    this.payStatus = payStatus;
                }

                public int getPrice() {
                    return price;
                }

                public void setPrice(int price) {
                    this.price = price;
                }

                public int getStatus() {
                    return status;
                }

                public void setStatus(int status) {
                    this.status = status;
                }

                public int getTotalCnt() {
                    return totalCnt;
                }

                public void setTotalCnt(int totalCnt) {
                    this.totalCnt = totalCnt;
                }

    public static LOrderInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        LOrderInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new LOrderInfo();
                }

                if ("course".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.course = jsonParser.getText();
                    continue;
                }
                if ("createTime".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.createTime = jsonParser.getText();
                    continue;
                }
                if ("oid".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.oid = jsonParser.getText();
                    continue;
                }

                if ("cmId".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.cmId = jsonParser.getText();
                    continue;
                }

                if ("orderSn".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.orderSn = jsonParser.getText();
                    continue;
                }
                if ("level".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.level = jsonParser.getIntValue();
                    continue;
                }
                if ("payStatus".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.payStatus = jsonParser.getIntValue();
                    continue;
                }
                if ("price".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.price = jsonParser.getIntValue();
                    continue;
                }
                if ("status".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.status = jsonParser.getIntValue();
                    continue;
                }
                if ("totalCnt".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.totalCnt = jsonParser.getIntValue();
                    continue;
                }
                if ("image".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.image = MultiImageInfo.fromJsonParser(jsonParser);
                    continue;
                }
                jsonParser.skipChildren();
            }
        }
        return info;
    }


}
