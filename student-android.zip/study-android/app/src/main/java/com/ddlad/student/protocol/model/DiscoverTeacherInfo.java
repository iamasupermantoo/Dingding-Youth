package com.ddlad.student.protocol.model;

import com.ddlad.student.ui.model.MultiImageInfo;

import java.util.List;

/**
 * Created by chen007 on 2017/11/9 0009.
 */
public class DiscoverTeacherInfo extends BaseInfo {


        /**
         * list : [{"hours":187,"tid":"xnGnmHqcrp89RzEFBVF2BQ"},{"hours":187,"tid":"-4b3jqNBRAA9RzEFBVF2BQ"},{"gender":1,"hours":187,"desc":"这是描述，这个是必填的哦哦哦哦","image":{"pattern":"http://img.z.ziduan.com/JKF_D_zLFXU9RzEFBVF2BQ.jpeg@{w}w_{h}h_75q","width":1920,"height":1082,"id":"JKF_D_zLFXU9RzEFBVF2BQ"},"tid":"92j8PbJCYQY9RzEFBVF2BQ","name":"wangsch老师"},{"hours":187,"tid":"-rYpb9A0BQQ9RzEFBVF2BQ"},{"gender":0,"hours":187,"desc":"这是一个教数学的老师，大家请多关照","tid":"cqhaguWdeNU9RzEFBVF2BQ","name":"数学老师_马大哈"},{"hours":187,"tid":"Kd-TaS-dnc49RzEFBVF2BQ"},{"hours":187,"tid":"3bizmoOVLmk9RzEFBVF2BQ"},{"hours":187,"tid":"6Ocd5WOmdzM9RzEFBVF2BQ"},{"hours":187,"tid":"5Sd__TiBeGI9RzEFBVF2BQ"},{"hours":187,"tid":"PWkMQd3dv1Y9RzEFBVF2BQ"},{"hours":187,"tid":"TXLwlW2zYYE9RzEFBVF2BQ"},{"hours":187,"tid":"v-mjQEF9ULI9RzEFBVF2BQ"},{"hours":187,"tid":"_jFYq-PO7g49RzEFBVF2BQ"},{"hours":187,"tid":"0l6ZGaVkqhc9RzEFBVF2BQ"},{"hours":187,"tid":"Yw4vkAQHS-w9RzEFBVF2BQ"},{"hours":187,"tid":"-rxePNs64Bg9RzEFBVF2BQ"}]
         * hasNext : false
         */

        private TeachersBean teachers;

        public TeachersBean getTeachers() {
            return teachers;
        }

        public void setTeachers(TeachersBean teachers) {
            this.teachers = teachers;
        }

        public static class TeachersBean {
            private boolean hasNext;
            /**
             * hours : 187
             * tid : xnGnmHqcrp89RzEFBVF2BQ
             */

            private List<ListBean> list;

            public boolean isHasNext() {
                return hasNext;
            }

            public void setHasNext(boolean hasNext) {
                this.hasNext = hasNext;
            }

            public List<ListBean> getList() {
                return list;
            }

            public void setList(List<ListBean> list) {
                this.list = list;
            }

            public static class ListBean {
                private int gender;
                private int hours;
                private int age;
                private String tid;
                private String name;
                private String desc;

                private MultiImageInfo image;

                public int getHours() {
                    return hours;
                }

                public void setHours(int hours) {
                    this.hours = hours;
                }

                public String getTid() {
                    return tid;
                }

                public void setTid(String tid) {
                    this.tid = tid;
                }

                public int getGender() {
                    return gender;
                }

                public void setGender(int gender) {
                    this.gender = gender;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public String getDesc() {
                    return desc;
                }

                public void setDesc(String desc) {
                    this.desc = desc;
                }

                public MultiImageInfo getImage() {
                    return image;
                }

                public void setImage(MultiImageInfo image) {
                    this.image = image;
                }

                public int getAge() {
                    return age;
                }

                public void setAge(int age) {
                    this.age = age;
                }
            }
        }
}
