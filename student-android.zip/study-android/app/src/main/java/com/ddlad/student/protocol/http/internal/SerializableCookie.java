package com.ddlad.student.protocol.http.internal;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Date;

import ch.boye.httpclientandroidlib.cookie.Cookie;
import ch.boye.httpclientandroidlib.impl.cookie.BasicClientCookie;

public class SerializableCookie implements Serializable {

    private static final long serialVersionUID = 4190413739219907439L;

    private transient BasicClientCookie clientCookie;

    private final transient Cookie cookie;

    public SerializableCookie(Cookie cookie) {
        this.cookie = cookie;
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException,
            ClassNotFoundException {
        this.clientCookie = new BasicClientCookie((String) objectInputStream.readObject(),
                (String) objectInputStream.readObject());
        this.clientCookie.setComment((String) objectInputStream.readObject());
        this.clientCookie.setDomain((String) objectInputStream.readObject());
        this.clientCookie.setExpiryDate((Date) objectInputStream.readObject());
        this.clientCookie.setPath((String) objectInputStream.readObject());
        this.clientCookie.setVersion(objectInputStream.readInt());
        this.clientCookie.setSecure(objectInputStream.readBoolean());
    }

    private void writeObject(ObjectOutputStream objectInputStream) throws IOException {
        objectInputStream.writeObject(this.cookie.getName());
        objectInputStream.writeObject(this.cookie.getValue());
        objectInputStream.writeObject(this.cookie.getComment());
        objectInputStream.writeObject(this.cookie.getDomain());
        objectInputStream.writeObject(this.cookie.getExpiryDate());
        objectInputStream.writeObject(this.cookie.getPath());
        objectInputStream.writeInt(this.cookie.getVersion());
        objectInputStream.writeBoolean(this.cookie.isSecure());
    }

    public Cookie getCookie() {
        return (this.clientCookie != null) ? this.clientCookie : this.cookie;
    }
}
