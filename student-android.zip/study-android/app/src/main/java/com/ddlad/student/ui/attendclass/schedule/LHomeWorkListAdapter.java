package com.ddlad.student.ui.attendclass.schedule;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import com.ddlad.student.protocol.model.LHomeWorkInfo;
import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.common.BaseFragment;

import java.util.List;

/**
 * Created by Albert
 * on 16-10-20.
 */
public class LHomeWorkListAdapter extends AbstractAdapter<LHomeWorkInfo> {
    final int TYPE_1 = 0;
    final int TYPE_2 = 1;
    final int TYPE_3 = 2;
    final int TYPE_4 = 3;

    //item的最小宽度
    private int mMinWidth;
    //item的最大宽度
    private int mMaxWidth;


    public IRemoveAnswerListener getListener() {
        return listener;
    }

    public void setListener(IRemoveAnswerListener listener) {
        this.listener = listener;
    }

    private static IRemoveAnswerListener listener = null;

    public static interface IRemoveAnswerListener{
        void removeAnswer(int position,String id,BaseFragment fragment);
        void enlargeImage(int position,int i);
    }

    private static boolean mIsModify;
    public boolean ismIsModify() {
        return mIsModify;
    }

    public void setmIsModify(boolean mIsModify) {
        this.mIsModify = mIsModify;
    }

    public LHomeWorkListAdapter(BaseFragment fragment) {
        super(fragment);
        //获取屏幕的宽度
        WindowManager wm = (WindowManager) fragment.getActivity().getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        //最大宽度为屏幕宽度的百分之七十
        mMaxWidth = (int) (outMetrics.widthPixels * 0.7f);
        //最小宽度为屏幕宽度的百分之十五
        mMinWidth = (int) (outMetrics.widthPixels * 0.15f);
    }

    @Override
    public LHomeWorkInfo getItem(int position) {
        return mList.get(position);
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public int getItemViewType(int position) {
        return getItem(position).getType();
    }

    @Override
    protected View createView(int position, ViewGroup parent) {
        if (getItemViewType(position) == TYPE_1) {
            return LHomeWorkTextListItemAdapter.createView(parent);
        } else if (getItemViewType(position) == TYPE_2){
            return LHomeWorkImageListItemAdapter.createView(parent);
        }else{
            return LHomeWorkVoiceListItemAdapter.createView(parent);
        }
    }

    @Override
    protected void bindView(int position, View view) {
        LHomeWorkInfo feed = getItem(position);
        if (feed.getType() == TYPE_1) {
            LHomeWorkTextListItemAdapter.bindView(view, feed, mFragment,position,mIsModify,listener);
        } else if (feed.getType() == TYPE_2){
            LHomeWorkImageListItemAdapter.bindView(view, feed, mFragment,position,mIsModify,listener);
        }else{
            LHomeWorkVoiceListItemAdapter.bindView(view, feed, mFragment,position,mIsModify,mMinWidth,mMaxWidth,listener);
        }

    }

    @Override
    public void clearItem() {
        mList.clear();
    }


    @Override
    public void addItem(LHomeWorkInfo info) {
        mList.add(info);
    }

    @Override
    public void addItem(List<LHomeWorkInfo> list) {
        if (!CollectionUtil.isEmpty(list)) {
            mList.addAll(list);
        }
    }

    @Override
    public int getCount() {
        return mList.size();
    }

//    public enum ProfileViewType {
//
//        Article(0), Image(1);
//
//        private ProfileViewType(int value) {
//            this.mValue = value;
//        }
//
//        private int mValue;
//
//        public int getValue() {
//            return mValue;
//        }
//    }

}

