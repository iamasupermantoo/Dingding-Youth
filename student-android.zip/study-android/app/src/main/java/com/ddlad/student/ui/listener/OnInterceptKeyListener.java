package com.ddlad.student.ui.listener;

import android.view.KeyEvent;

public interface OnInterceptKeyListener {

    public boolean isInterceptKey(KeyEvent event);
}