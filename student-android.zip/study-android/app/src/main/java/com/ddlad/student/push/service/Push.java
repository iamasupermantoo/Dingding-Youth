package com.ddlad.student.push.service;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.text.TextUtils;

import com.igexin.sdk.PushManager;
import com.ddlad.student.protocol.convert.DataCenter;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.model.GoToPage;
import com.ddlad.student.push.PushClientGetui;
import com.ddlad.student.push.PushType;
import com.ddlad.student.push.model.PushInfo;
import com.ddlad.student.tools.RunnableHelper;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.protocol.http.internal.CustomObjectMapper;
import com.ddlad.student.push.PushClient;
import com.ddlad.student.tools.StringUtil;

public class Push {

    public static final String PUSH_SERVICE = "com.udan.push";

    private Context mContext;

    private int mPushAction;

    private String mPushContent;

    public Push(Context context) {
        this.mContext = context;
    }

    public static Push getInstance() {
        Push pushService = (Push) AppContext.getContext().getSystemService(
                PUSH_SERVICE);
        if (pushService == null) {
            throw new IllegalStateException("Push not available");
        }

        return pushService;
    }

    public void bindPush() {
        PushClient pushInterface = new PushClientGetui();
        pushInterface.bindPush();
    }

    public void unbindPush() {
        PushClient pushInterface = new PushClientGetui();
        pushInterface.unbindPush();
    }

    public PushInfo json2PushInfo(String json) {
        PushInfo info = null;
        CustomObjectMapper mapper = CustomObjectMapper.getInstance();
        try {
            info = mapper.readValue(json, PushInfo.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return info;
    }

    public void showPush(String message) {
        PushInfo push = json2PushInfo(message);
        push.putCustomData(ProtocolConstants.PARAM_MESSAGE, message);
        if (isValidPush(push)) {
            showNotification(push);
        }
    }

    private boolean isValidPush(PushInfo pushInfo) {
        return pushInfo != null && StringUtil.equals(pushInfo.getUser(), DataCenter.getUser().getId());
    }

    private void showNotification(final PushInfo push) {

        boolean isValidPushType = isValidPushType(push);
        if (!isValidPushType) {
            return;
        }

        mPushAction = push.getAction();
        mPushContent = push.getAps().getAlert();

        if (TextUtils.isEmpty(mPushContent)) {
            return;
        }

        RunnableHelper.runInUIThread(new Runnable() {

            @Override
            public void run() {

                NotificationManager manager = (NotificationManager) mContext
                        .getSystemService(Context.NOTIFICATION_SERVICE);

                manager.cancel(mPushAction);

                mPushContent = buildPushContent(mPushAction, mPushContent);
                Notification notification = buildNotification(AppContext.getString(R.string.app_name),
                        mPushContent, mPushContent);

                notification.contentIntent = resultPendingIntent(push);

                try {
                    manager.notify(push.getAction(), notification);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        });
    }

    private PendingIntent resultPendingIntent(PushInfo pushInfo) {

        Intent intent = GoToPage.getIntent(pushInfo.getGotoPage(), mContext);
        if (intent == null) {
            return null;
        } else {
            return PendingIntent.getActivity(mContext, ViewUtil.generateUniqueId(), intent,
                    PendingIntent.FLAG_UPDATE_CURRENT);
        }

    }

    private Notification buildNotification(String title, String tickerText, String content) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(mContext)
                .setContentTitle(title).setContentText(content)
                .setSmallIcon(R.drawable.ic_launcher).setAutoCancel(true).setTicker(tickerText);

        Notification notification = builder.build();

        return notification;
    }

    private String buildPushContent(int pushAction, String pushContent) {
        return pushContent;
    }

    private boolean isValidPushType(final PushInfo pushInfo) {
        PushType[] values = PushType.values();
        boolean isValidPushType = false;
        for (PushType type : values) {
            if (type.getValue() == pushInfo.getAction()) {
                isValidPushType = true;
                break;
            }
        }
        return isValidPushType;
    }

    public void startPushService() {
        try {
            PushManager.getInstance().initialize(AppContext.getContext());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
