package com.ddlad.student.ui.account;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.request.SaveBankCardRequest;
import com.ddlad.student.protocol.model.OrderSubmitInfo;
import com.ddlad.student.tools.StringUtil;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseFragment;

/**
 * Created by chen007 on 2017/11/9 0009.
 */
public class BindBankCardFragment extends BaseFragment {

    private EditText card_name;
    private EditText card_num;
    private EditText bank_acoount;
    private EditText contact_num;

    private ViewGroup layout_1;
    private ViewGroup layout_2;
    private ViewGroup layout_3;
    private ViewGroup layout_4;

    private TextView edit_btn;

    private String cardName;
    private String cardNum;
    private String bankAcoount;
    private String contactNum;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_bind_bankcard;
    }

    @Override
    protected void onInitData(Bundle bundle) {
        cardName = bundle.getString("bankUser");
        cardNum = bundle.getString("bankCardNum");
        bankAcoount = bundle.getString("bankName");
        contactNum = bundle.getString("bankUserMobile");
    }

    @Override
    protected void onInitView(View contentView) {

        mActionbar.setTitle("银行卡");

        card_name = (EditText) contentView.findViewById(R.id.card_name);
        card_num = (EditText) contentView.findViewById(R.id.card_num);
        bank_acoount = (EditText) contentView.findViewById(R.id.bank_acoount);
        contact_num = (EditText) contentView.findViewById(R.id.contact_num);

        layout_1 = (ViewGroup) contentView.findViewById(R.id.layout_1);
        layout_2 = (ViewGroup) contentView.findViewById(R.id.layout_2);
        layout_3 = (ViewGroup) contentView.findViewById(R.id.layout_3);
        layout_4 = (ViewGroup) contentView.findViewById(R.id.layout_4);

        edit_btn = (TextView) contentView.findViewById(R.id.edit_btn);

        edit_btn.setOnClickListener(this);

        if (StringUtil.isEmpty(cardName)){
            edit_btn.setText("完成");
            layout_1.setSelected(false);
            layout_2.setSelected(false);
            layout_3.setSelected(false);
            layout_4.setSelected(false);
        }else{
            edit_btn.setText("编辑");
            layout_1.setSelected(true);
            layout_2.setSelected(true);
            layout_3.setSelected(true);
            layout_4.setSelected(true);
            card_name.setText(cardName+"");
            card_num.setText(cardNum+"");
            bank_acoount.setText(bankAcoount+"");
            contact_num.setText(contactNum+"");
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.edit_btn:
                save();
                break;
        }
    }

    private void save() {
         cardName = card_name.getText().toString().trim();
         cardNum = card_num.getText().toString().trim();
         bankAcoount = bank_acoount.getText().toString().trim();
         contactNum = contact_num.getText().toString().trim();

        if (StringUtil.isEmpty(cardName)){
            Toaster.toastShort("持卡人不能为空");
            return;
        }
        if (StringUtil.isEmpty(cardNum)){
            Toaster.toastShort("卡号不能为空");
            return;
        }
        if (StringUtil.isEmpty(bankAcoount)){
            Toaster.toastShort("开户行不能为空");
            return;
        }
        if (StringUtil.isEmpty(contactNum)){
            Toaster.toastShort("联系电话不能为空");
            return;
        }

        SaveBankCardRequest request = new SaveBankCardRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<OrderSubmitInfo>() {
            @Override
            protected void onSuccess(OrderSubmitInfo info) {

            }
        });
        request.perform(cardName,cardNum,bankAcoount,contactNum);
    }
}
