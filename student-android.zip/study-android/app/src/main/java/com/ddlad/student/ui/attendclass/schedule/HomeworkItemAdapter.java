package com.ddlad.student.ui.attendclass.schedule;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.model.HomeworkInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.course.CorrectPendingFragment;

/**
 * Created by Administrator on 2017/2/6 0006.
 */

public class HomeworkItemAdapter {

    public static View createView(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_homework_list, null);
        HomeworkHolder holder = new HomeworkHolder();

        holder.mLessonName = (TextView) view.findViewById(R.id.homework_lesson_name);
        holder.mLessonTime = (TextView) view.findViewById(R.id.homework_lesson_time);
        holder.mTeacher = (TextView) view.findViewById(R.id.homework_teacher);
        holder.mLesson = (TextView) view.findViewById(R.id.homework_lesson);
        holder.mState = (TextView) view.findViewById(R.id.homework_state);
        holder.mLayout = (ViewGroup) view.findViewById(R.id.homework_layout);

        view.setTag(holder);

        return view;
    }

    public static void bindView(View view, final HomeworkInfo homeworkInfo, final BaseFragment fragment, final AbstractAdapter adapter) {
        if (homeworkInfo == null) {
            return;
        }
        HomeworkHolder holder = (HomeworkHolder) view.getTag();
        if (holder == null) {
            return;
        }
        holder.mLessonName.setText(homeworkInfo.getTitle());
        holder.mLessonTime.setText(homeworkInfo.getTime());
        holder.mTeacher.setText(homeworkInfo.getTeacher());
        holder.mLesson.setText(homeworkInfo.getCourse());
        if (homeworkInfo.getStatus() == 0 ){
            holder.mState.setText("待提交");
            holder.mState.setTextColor(Color.parseColor("#de0303"));
        }else if(homeworkInfo.getStatus() == 1){
            holder.mState.setText("待批改");
            holder.mState.setTextColor(Color.parseColor("#fe8d25"));
        }else {
            holder.mState.setText("已批改");
            holder.mState.setTextColor(Color.parseColor("#999999"));
        }
        holder.mLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(homeworkInfo.getStatus() == 2){
                    Bundle bundle = new Bundle();
                    bundle.putString(ProtocolConstants.PARAM_QID,homeworkInfo.getHid());
                    NavigateUtil.navigateToNormalActivity(fragment.getActivity(),new CorrectPendingFragment(),bundle);

                }else {
                    Bundle bundle = new Bundle();
                    bundle.putString(ProtocolConstants.PARAM_QID,homeworkInfo.getHid());
                    NavigateUtil.navigateToNormalActivity(fragment.getActivity(),new PendingFragment(),bundle);
//                NavigateUtil.navigateToNormalActivity(fragment.getActivity(),new MyPendingFragment(),bundle);
                }

            }
        });

    }

    public static class HomeworkHolder{
        private TextView mLessonName;
        private TextView mLessonTime;
        private TextView mTeacher;
        private TextView mLesson;
        private TextView mState;

        private ViewGroup mLayout;

    }

}
