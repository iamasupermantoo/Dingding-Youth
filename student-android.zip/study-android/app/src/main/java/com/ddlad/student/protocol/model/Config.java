package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.IOException;

/**
 * Created by Albert
 * on 16-11-7.
 */
public class Config extends BaseInfo {

    private String mPush;

    public String getPush() {
        return mPush;
    }

    public void setPush(String push) {
        this.mPush = push;
    }

    public static Config fromJsonParser(JsonParser jsonParser) throws IOException {

        Config info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new Config();
                }

                if ("push".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.mPush = jsonParser.getText();
                    continue;
                }

                jsonParser.skipChildren();
            }
        }

        return info;
    }

    public boolean isPushAllowed() {
        return Boolean.parseBoolean(mPush);
    }

}
