package com.ddlad.student.protocol.http.internal;

import com.fasterxml.jackson.databind.JsonNode;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.protocol.http.request.ApiResponseStatus;
import com.ddlad.student.R;

import ch.boye.httpclientandroidlib.StatusLine;

public abstract class ApiResponse<T> {

    public static String NETWORK_ERROR_MESSAGE = AppContext.getContext().getString(
            R.string.network_error_message);

    public static String UNKNOWN_SERVER_ERROR_MESSAGE = AppContext.getContext().getString(
            R.string.unknown_server_error_message);

    private boolean mFailedToLoad;

    protected StatusLine mStatusLine;

    protected int mCode;

    public int getCode() {
        return mCode;
    }

    public void setCode(int mCode) {
        this.mCode = mCode;
    }

    public ApiResponseStatus getApiResponseStatus() {

        if (isOk()) {
            return ApiResponseStatus.ApiResponseStatusOk;
        }

        Integer responseCode = getResponseCode();

        if (responseCode != null) {
            if (responseCode.intValue() == HttpResponseCode.STATUS_CODE_NOT_FOUND) {
                return ApiResponseStatus.ApiResponseStatusObjectNotFound;
            }
            return ApiResponseStatus.ApiResponseStatusError;
        }

        if (mFailedToLoad) {
            return ApiResponseStatus.ApiResponseStatusError;
        }

        return ApiResponseStatus.ApiResponseStatusLoading;

    }

    public void setErrorStatusIfFailedToLoad() {
        if (getApiResponseStatus() == ApiResponseStatus.ApiResponseStatusLoading) {
            mFailedToLoad = true;
        } else {
            mFailedToLoad = false;
        }
    }

    public Integer getResponseCode() {
        if (getStatusLine() != null) {
            return Integer.valueOf(getStatusLine().getStatusCode());
        }

        return null;
    }


    public abstract int getStatus();

    public StatusLine getStatusLine() {
        return mStatusLine;
    }

    public void setStatusLine(StatusLine statusLine) {
        mStatusLine = statusLine;
    }

    public abstract JsonNode getRootNode();

    public abstract String getErrorTitle();

    public abstract String getError();

    public abstract String getErrorDescription();

    public abstract String getStatusMessage();

    public abstract T getSuccessObject();

    public abstract boolean hasRootValue(String paramString);

    public abstract boolean isNetworkRequest();

    public abstract boolean isNotModified();

    public abstract boolean isOk();

    public abstract T readRootValue(Class<T> classz);

    public abstract T readRootValue(String fieldName, Class<T> classz);

    public abstract T readRootValue(String key, String childKey, Class<T> clazz);

    public abstract void setIsNetworkResponse(boolean networkRequest);

    public abstract void setSuccessObject(T t);
}
