package com.ddlad.student.ui.agora;

import com.ddlad.student.R;
import com.ddlad.student.ui.common.NormalActivity;


/**
 * Created by chen007 on 2017/7/10 0010.
 */
public class LiveRoomActivity extends NormalActivity {

    @Override
    protected int getLayoutResource() {
        return R.layout.activity_live;
    }

    /**
     * 返回时退出频道
     */
    @Override
    public void onBackPressed() {
        LiveRoomFragment.channelLeave();
        AgoraManager.getInstance().leaveChannel();
    }
}
