package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.ui.model.MultiImageInfo;
import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;

import java.io.IOException;

/**
 * Created by Albert
 * on 16-10-8.
 */
public class UserInfo extends BaseInfo {

    private String mobile;
    private String password;
    private String code;
    private String signature;


    private String name;
    private MultiImageInfo headImage;
    private int gender = -1;
    private String province;
    private String region;
    private boolean verified;
    private String verifiedInfo;
    private String grade;

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public MultiImageInfo getHeadImage() {
        return headImage;
    }

    public void setHeadImage(MultiImageInfo headImage) {
        this.headImage = headImage;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public boolean isVerified() {
        return verified;
    }

    public void setVerified(boolean verified) {
        this.verified = verified;
    }

    public String getVerifiedInfo() {
        return verifiedInfo;
    }

    public void setVerifiedInfo(String verifiedInfo) {
        this.verifiedInfo = verifiedInfo;
    }

    public static UserInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        UserInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new UserInfo();
                }

                if ("id".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.id = jsonParser.getText();
                    continue;
                }

                if ("name".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.name = jsonParser.getText();
                    continue;
                }

                if ("signature".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.signature = jsonParser.getText();
                    continue;
                }

                if ("region".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.region = jsonParser.getText();
                    continue;
                }

                if ("grade".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.grade = jsonParser.getText();
                    continue;
                }

                if ("gender".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.gender = jsonParser.getIntValue();
                    continue;
                }

                if ("verified".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.verified = jsonParser.getBooleanValue();
                    continue;
                }

                if ("verifiedInfo".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.verifiedInfo = jsonParser.getText();
                    continue;
                }


                if ("headImage".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.headImage = MultiImageInfo.fromJsonParser(jsonParser);
                    continue;
                }


                if ("province".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.province = jsonParser.getText();
                    continue;
                }

                jsonParser.skipChildren();
            }
        }

        return info;
    }

    public enum Gender {

        Male(0, AppContext.getString(R.string.male)),
        Female(1, AppContext.getString(R.string.female));

        private Gender(int value, String text) {
            this.mValue = value;
            this.mText = text;
        }

        public static String[] textArray() {
            return new String[]{Male.getText(), Female.getText()};
        }

        public static long[] valueArray() {
            return new long[]{Male.getValue(), Female.getValue()};
        }

        private int mValue;
        private String mText;

        public int getValue() {
            return mValue;
        }

        public String getText() {
            return mText;
        }

        public static String fromValue(int value) {
            String gender = "";

            switch (value) {
                case 0:
                    gender = AppContext.getString(R.string.male);
                    break;
                case 1:
                    gender = AppContext.getString(R.string.female);
                    break;
            }

            return gender;
        }
    }

    public enum UserType {

        Senior(0, AppContext.getString(R.string.senior_type)),
        College(1, AppContext.getString(R.string.college_type));

        private UserType(int value, String text) {
            this.mValue = value;
            this.mText = text;
        }

        private int mValue;
        private String mText;

        public static String[] textArray() {
            return new String[]{Senior.getText(), College.getText()};
        }

        public static long[] valueArray() {
            return new long[]{Senior.getValue(), College.getValue()};
        }

        public int getValue() {
            return mValue;
        }

        public String getText() {
            return mText;
        }

        public static String fromValue(int value) {

            String type = null;

            switch (value) {
                case 0:
                    type = AppContext.getString(R.string.senior_type);
                    break;
                case 1:
                    type = AppContext.getString(R.string.college_type);
                    break;
            }

            return type;
        }

    }

    public enum FollowStatus {

        NA(0), Follow(1), Followed(2), FollowBoth(3);

        private FollowStatus(int value) {
            this.mValue = value;
        }

        private int mValue;

        public int getValue() {
            return mValue;
        }
    }

}
