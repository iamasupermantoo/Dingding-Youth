package com.ddlad.student.protocol.model;

import com.ddlad.student.ui.model.MultiImageInfo;

/**
 * Created by chenjianing on 2017/5/15 0015.
 */
public class TeacherReactionDetailInfo extends BaseInfo {

        /**
         * date : 2017-02-14
         * time : 08:30 - 09:30
         * studentHeadImg : {"width":750,"height":750,"pattern":"http://img.z.ziduan.com/VdxWaPl1Ykg9RzEFBVF2BQ.jpeg@{w}w_{h}h_75q","id":"VdxWaPl1Ykg9RzEFBVF2BQ"}
         * course : Java super课
         */

        private ReactionBean reaction;

        public ReactionBean getReaction() {
            return reaction;
        }

        public void setReaction(ReactionBean reaction) {
            this.reaction = reaction;
        }

        public static class ReactionBean {
            private String date;
            private String time;



            private String student;
            /**
             * width : 750
             * height : 750
             * pattern : http://img.z.ziduan.com/VdxWaPl1Ykg9RzEFBVF2BQ.jpeg@{w}w_{h}h_75q
             * id : VdxWaPl1Ykg9RzEFBVF2BQ
             */

            private MultiImageInfo studentHeadImg;
            private String course;

            private String remark;
            private int behavior;
            private int star;
            private int idea;

            public String getRemark() {
                return remark;
            }

            public void setRemark(String remark) {
                this.remark = remark;
            }

            public int getIdea() {
                return idea;
            }

            public void setIdea(int idea) {
                this.idea = idea;
            }

            public int getStar() {
                return star;
            }

            public void setStar(int star) {
                this.star = star;
            }

            public int getBehavior() {
                return behavior;
            }

            public void setBehavior(int behavior) {
                this.behavior = behavior;
            }

            public String getStudent() {
                return student;
            }

            public void setStudent(String student) {
                this.student = student;
            }
            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public MultiImageInfo getStudentHeadImg() {
                return studentHeadImg;
            }

            public void setStudentHeadImg(MultiImageInfo studentHeadImg) {
                this.studentHeadImg = studentHeadImg;
            }

            public String getCourse() {
                return course;
            }

            public void setCourse(String course) {
                this.course = course;
            }

            public static class StudentHeadImgBean {
                private int width;
                private int height;
                private String pattern;
                private String id;

                public int getWidth() {
                    return width;
                }

                public void setWidth(int width) {
                    this.width = width;
                }

                public int getHeight() {
                    return height;
                }

                public void setHeight(int height) {
                    this.height = height;
                }

                public String getPattern() {
                    return pattern;
                }

                public void setPattern(String pattern) {
                    this.pattern = pattern;
                }

                public String getId() {
                    return id;
                }

                public void setId(String id) {
                    this.id = id;
                }
            }
        }
}
