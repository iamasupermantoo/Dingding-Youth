package com.ddlad.student.ui.account;

import android.app.Activity;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.model.DiscoverTeacherInfo;
import com.ddlad.student.protocol.model.GetChargeItemInfo;
import com.facebook.drawee.view.SimpleDraweeView;

import java.util.ArrayList;

/**
 * Created by chen007 on 2017/11/6 0006.
 */
public class MyAccountBalanceAdapter extends RecyclerView.Adapter<MyAccountBalanceAdapter.MyViewHolder> {

    private Activity mActivity;

    private ArrayList<GetChargeItemInfo.ItemsBean> mInfos;

    public MyAccountBalanceAdapter(Activity activity){
        this.mActivity = activity;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
       View view =  LayoutInflater.from(mActivity).inflate(R.layout.layout_myaccount_balance_item,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.text_money.setText(20+"元");
        holder.text_dd.setText(20+"鼎币");
    }


    public ArrayList<GetChargeItemInfo.ItemsBean> getmInfos() {
        return mInfos;
    }

    public void setmInfos(ArrayList<GetChargeItemInfo.ItemsBean> mInfos) {
        this.mInfos = mInfos;
        this.mInfos.addAll(mInfos);
        this.mInfos.addAll(mInfos);
        this.mInfos.addAll(mInfos);
    }

    @Override
    public int getItemCount() {
        if (mInfos != null){
            return mInfos.size();
        }
        return 0;
    }

    static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView text_money;
        TextView text_dd;
        public SimpleDraweeView mImage;
        public MyViewHolder(View view) {
            super(view);
            text_money = (TextView) view.findViewById(R.id.text_money);
            text_dd = (TextView) view.findViewById(R.id.text_dd);
        }
    }
}
