package com.ddlad.student.ui.cropper.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.PointF;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;


import com.ddlad.student.ui.cropper.tool.CropperViewTouchEvent;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.cropper.tool.CropperImageInfo;

import java.util.Arrays;

public class CropperView extends View {

    private Context mContext;

    private float x_down = 0;

    private float y_down = 0;

    private PointF[] mDownVertex;

    private PointF mid = new PointF();

    private float oldDist = 1f;

    private float oldRotation = 0;

    private float mScaledScale;

    private float mRevertScale = 1;

    /**
     * 最终要显示的角度
     */
    private float mCurrentScale = 1.0f;

    /**
     * 绘制的图片宽度
     */
    private float mCurrentImageWidth;

    /**
     * 绘制的图片高度
     */
    private float mCurrentImageHeight;

    private float mOriginalImageWidth;

    private float mOriginalImageHeight;

    private Matrix matrix = new Matrix();

    private Matrix matrixTemp = new Matrix();

    private Matrix savedMatrix = new Matrix();

    private static final int NONE = 0;

    private static final int DRAG = 1;

    private static final int ZOOM = 2;

    private int mode = NONE;

    private int mCroperViewWidth;

    private int mCroperViewHeight;

    private PointF mCroperViewCenter;

    private Bitmap mImageBitmap;

    private PointF[] mCropOverlayVertexs;

    private int mDownCount = 1;

    private boolean isFullImage = Boolean.FALSE;

    private boolean isPointsTooMore = Boolean.FALSE;

    private boolean hasEventMoved = Boolean.FALSE;

    private boolean isBgcolorChange = Boolean.TRUE;

    private CropperViewTouchEvent mCropperViewTouchEvent;

    private boolean isVerticalImage = Boolean.TRUE;

    private final static int V1 = 0;

    private final static int V2 = 1;

    private final static int V3 = 2;

    private final static int V4 = 3;

    private final static byte UP = 0x1;

    private final static byte RIGHT = UP << 1;

    private final static byte DOWN = RIGHT << 1;

    private final static byte LEFT = DOWN << 1;

    private Paint mWhitePaint;

    private PaintFlagsDrawFilter mPaintFlagsDrawFilter;

    private PointF mChaneBgcolorDown = new PointF();

    private int mActionClickZone;

    private long mChaneBgcolorTime;

    private final static long CHANE_BGCOLOR_TIME_ZONE = 500;

    public void setCropperViewTouchEvent(CropperViewTouchEvent mCropperViewTouchEvent) {
        this.mCropperViewTouchEvent = mCropperViewTouchEvent;
    }

    public CropperView(Context context) {
        super(context);
        init(context);

    }

    public CropperView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public CropperView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    protected void onDraw(Canvas canvas) {
        if (mImageBitmap != null) {
            canvas.save();
            if (isFullImage && isBgcolorChange) {
                canvas.drawRect(mCropOverlayVertexs[V1].x, mCropOverlayVertexs[V1].y,
                        mCropOverlayVertexs[V4].x, mCropOverlayVertexs[V4].y, mWhitePaint);
            }
            canvas.setDrawFilter(mPaintFlagsDrawFilter);
            canvas.drawBitmap(mImageBitmap, matrix, null);
            canvas.restore();

        }
    }

    private void init(Context context) {
        this.mContext = context;
        mWhitePaint = new Paint();
        mPaintFlagsDrawFilter = new PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG
                | Paint.FILTER_BITMAP_FLAG);
        mWhitePaint.setColor(Color.WHITE);
        mActionClickZone = (int) ViewUtil.dpToPx(10);
        mCroperViewWidth = AppContext.getScreenWidth();
        mCroperViewHeight = AppContext.getScreenHeight();
        setCropOverlayVertexs();
        matrix = new Matrix();
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent event) {

        if (isFullImage || mImageBitmap == null) {
            switch (event.getAction() & MotionEvent.ACTION_MASK) {
                case MotionEvent.ACTION_DOWN:
                    mChaneBgcolorDown.x = event.getX();
                    mChaneBgcolorDown.y = event.getY();
                    mChaneBgcolorTime = System.currentTimeMillis();
                    break;
                case MotionEvent.ACTION_UP:
                    long now = System.currentTimeMillis();
                    float x = event.getX();
                    float y = event.getY();
                    if (x > mCropOverlayVertexs[V1].x && x < mCropOverlayVertexs[V2].x
                            && y > mCropOverlayVertexs[V1].y && y < mCropOverlayVertexs[V4].y
                            && Math.abs(x - mChaneBgcolorDown.x) < mActionClickZone
                            && Math.abs(y - mChaneBgcolorDown.y) < mActionClickZone
                            && now - mChaneBgcolorTime < CHANE_BGCOLOR_TIME_ZONE) {
                        changeBgcolor();
                    }
                    break;
            }
            //锁定
            return Boolean.TRUE;
        }

        switch (event.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
                mode = DRAG;
                hasEventMoved = Boolean.FALSE;
                isPointsTooMore = Boolean.FALSE;
                x_down = event.getX();
                y_down = event.getY();
                mDownVertex = getImageVertex();
                savedMatrix.set(matrix);
                mDownCount = 1;
                if (mCropperViewTouchEvent != null) {
                    mCropperViewTouchEvent.onTouchEventDown();
                }
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                mode = ZOOM;
                mDownCount++;
                mCurrentScale = mScaledScale;
                if (mDownCount > 2) {
                    if (!isPointsTooMore && hasEventMoved) {
                        //第一次3个手指以上，并且move过了。恢复原来的状态
                        adjustImage();
                    }
                    isPointsTooMore = Boolean.TRUE;
                } else {
                    oldDist = spacing(event);
                    oldRotation = rotation(event);
                    savedMatrix.set(matrix);
                    midPoint(mid, event);
                }
                hasEventMoved = Boolean.FALSE;
                break;
            case MotionEvent.ACTION_MOVE:
                if (!isPointsTooMore) {
                    hasEventMoved = Boolean.TRUE;
                    if (mode == ZOOM) {
                        float rotation = rotation(event);
                        float mMovedRotation = rotation - oldRotation;
                        //                        float tempRotatedRotation = mMovedRotation + mCurrentRotation;
                        float newDist = spacing(event);
                        float mMovedScale = newDist / oldDist;
                        float tempScaledScale = mMovedScale * mCurrentScale;
                        if (isVerticalImage
                                && tempScaledScale * mOriginalImageWidth <= mCroperViewWidth) {
                            mMovedScale = mCroperViewWidth / (mOriginalImageWidth * mCurrentScale);
                        } else if (!isVerticalImage
                                && tempScaledScale * mOriginalImageHeight <= mCroperViewWidth) {
                            mMovedScale = mCroperViewWidth / (mOriginalImageHeight * mCurrentScale);
                        }
                        matrixTemp.set(savedMatrix);
                        mScaledScale = mMovedScale * mCurrentScale;
                        matrixTemp.postScale(mMovedScale, mMovedScale, mid.x, mid.y);// 縮放
                        matrixTemp.postRotate(mMovedRotation, mid.x, mid.y);// 旋轉
                        matrix.set(matrixTemp);
                        invalidate();
                    } else if (mode == DRAG) {
                        //                        PointF v[] = getImageVertex();
                        byte v1Dir = getV1Direction(mDownVertex);
                        float dx = getDx(event, mDownVertex, v1Dir);
                        float dy = getDy(event, mDownVertex, v1Dir);
                        matrixTemp.set(savedMatrix);
                        matrixTemp.postTranslate(dx, dy);// 平移
                        matrix.set(matrixTemp);
                        invalidate();
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
                mode = NONE;
                hasEventMoved = Boolean.FALSE;
                if (mCropperViewTouchEvent != null) {
                    mCropperViewTouchEvent.onTouchEventUp();
                }
                break;
            case MotionEvent.ACTION_POINTER_UP:
                mode = NONE;
                scaleCurrentImage(mScaledScale);
                if (mDownCount <= 2) {
                    if (hasEventMoved) {
                        adjustImage();
                    }
                    isPointsTooMore = Boolean.FALSE;
                }
                mDownCount--;
                hasEventMoved = Boolean.FALSE;
                break;
        }
        return Boolean.TRUE;
    }

    private float getDx(MotionEvent event, PointF[] v, byte v1Dir) {
        float dx = event.getX() - x_down;
        if (dx > 0) {
            if (((v1Dir & LEFT) == LEFT) && v[V1].x + dx >= mCropOverlayVertexs[V1].x) {
                dx = mCropOverlayVertexs[V1].x - v[V1].x;
            } else if (((v1Dir & RIGHT) == RIGHT) && v[V4].x + dx >= mCropOverlayVertexs[V1].x) {
                dx = mCropOverlayVertexs[V1].x - v[V4].x;
            }
        } else if (dx < 0) {
            if (((v1Dir & LEFT) == LEFT) && v[V4].x + dx <= mCropOverlayVertexs[V4].x) {
                dx = mCropOverlayVertexs[V4].x - v[V4].x;

            } else if (((v1Dir & RIGHT) == RIGHT) && v[V1].x + dx <= mCropOverlayVertexs[V4].x) {
                dx = mCropOverlayVertexs[V4].x - v[V1].x;

            }
        }
        return dx;
    }

    private float getDy(MotionEvent event, PointF[] v, byte v1Dir) {
        float dy = event.getY() - y_down;
        if (dy > 0) {
            if (((v1Dir & UP) == UP) && v[V1].y + dy > mCropOverlayVertexs[V1].y) {
                dy = mCropOverlayVertexs[V1].y - v[V1].y;
            } else if (((v1Dir & DOWN) == DOWN) && v[V4].y + dy > mCropOverlayVertexs[V1].y) {
                dy = mCropOverlayVertexs[V1].y - v[V4].y;
            }
        } else if (dy < 0) {
            if (((v1Dir & UP) == UP) && v[V4].y + dy < mCropOverlayVertexs[V4].y) {
                dy = mCropOverlayVertexs[V4].y - v[V4].y;
            } else if (((v1Dir & DOWN) == DOWN) && v[V1].y + dy < mCropOverlayVertexs[V4].y) {
                dy = mCropOverlayVertexs[V4].y - v[V1].y;
            }
        }
        return dy;
    }

    private void adjustImage() {
        float rotate = clacAdjustRotation();
        matrix.postRotate(rotate, mid.x, mid.y);// 旋轉
        PointF[] v = getImageVertex();
        float vx[] = {v[V1].x, v[V2].x, v[V3].x, v[V4].x};
        int max = vx.length - 1;
        Arrays.sort(vx);
        float dx = 0;
        if (vx[0] > mCropOverlayVertexs[V1].x) {
            dx = mCropOverlayVertexs[V1].x - vx[0];
        } else if (vx[max] < mCropOverlayVertexs[V4].x) {
            dx = mCropOverlayVertexs[V4].x - vx[max];
        }
        float vy[] = {v[V1].y, v[V2].y, v[V3].y, v[V4].y};
        Arrays.sort(vy);
        float dy = 0;
        if (vy[0] > mCropOverlayVertexs[V1].y) {
            dy = mCropOverlayVertexs[V1].y - vy[0];
        } else if (vy[max] < mCropOverlayVertexs[V4].y) {
            dy = mCropOverlayVertexs[V4].y - vy[max];
        }
        matrix.postTranslate(dx, dy);

        invalidate();
    }

    /**
     * 计算应该调整多少角度
     *
     * @return
     */
    private float clacAdjustRotation() {
        float rotatedRotation = getRotatedRotation();

        if (rotatedRotation > 45) {
            rotatedRotation -= 90;
        } else if (rotatedRotation < -45) {
            rotatedRotation += 90;
        }
        return rotatedRotation;
    }

    /**
     * 得到当前图片的4个顶点
     *
     * @return
     */
    private PointF[] getImageVertex() {
        float[] f = new float[9];
        matrix.getValues(f);
        // 图片4个顶点的坐标
        float x1 = f[0] * 0 + f[1] * 0 + f[2];
        float y1 = f[3] * 0 + f[4] * 0 + f[5];
        float x2 = f[0] * mImageBitmap.getWidth() + f[1] * 0 + f[2];
        float y2 = f[3] * mImageBitmap.getWidth() + f[4] * 0 + f[5];
        float x3 = f[0] * 0 + f[1] * mImageBitmap.getHeight() + f[2];
        float y3 = f[3] * 0 + f[4] * mImageBitmap.getHeight() + f[5];
        float x4 = f[0] * mImageBitmap.getWidth() + f[1] * mImageBitmap.getHeight() + f[2];
        float y4 = f[3] * mImageBitmap.getWidth() + f[4] * mImageBitmap.getHeight() + f[5];
        return new PointF[]{new PointF(x1, y1), new PointF(x2, y2), new PointF(x3, y3),
                new PointF(x4, y4)};
    }

    /**
     * 获取V1的位置
     *
     * @return
     */
    private byte getV1Direction() {
        PointF[] v = getImageVertex();
        return getV1Direction(v);
    }

    /**
     * 获取V1的位置
     *
     * @return
     */
    private byte getV1Direction(PointF v[]) {
        byte v1Direction;
        if (v[V1].x < v[V4].x) {
            v1Direction = LEFT;
        } else {
            v1Direction = RIGHT;
        }
        if (v[V1].y < v[V4].y) {
            v1Direction |= UP;
        } else {
            v1Direction |= DOWN;
        }
        return v1Direction;
    }

    private float getCurrentRotation() {
        byte dir = getV1Direction();
        float mCurrentRotation = 0;
        if (dir == (LEFT | UP)) {
            mCurrentRotation = 0;
        } else if (dir == (LEFT | DOWN)) {
            mCurrentRotation = 90;
        } else if (dir == (RIGHT | UP)) {
            mCurrentRotation = 270;
        } else {
            mCurrentRotation = 180;
        }
        return mCurrentRotation;
    }

    /**
     * 当前图片的横竖
     *
     * @return
     */
    private boolean isCurrentImageVertical(PointF v[]) {
        byte dir = getV1Direction(v);
        if (isVerticalImage && (dir == (LEFT | UP) || dir == (RIGHT | DOWN))
                || (!isVerticalImage && (dir == (LEFT | DOWN) || dir == (RIGHT | UP)))) {
            return true;
        }
        return false;
    }

    /**
     * 当前图片的中点
     *
     * @return
     */
    private PointF getImageVextexCenter() {
        PointF vertex[] = getImageVertex();
        return new PointF((vertex[V2].x + vertex[V3].x) / 2, (vertex[V1].y + vertex[V4].y) / 2);
    }

    /**
     * 得到当前与Y轴的夹角(度)
     *
     * @return
     */
    private float getRotatedRotation() {
        PointF[] v = getImageVertex();
        return (float) ((Math.atan((v[V3].x - v[V1].x) / (v[V3].y - v[V1].y)) * 180) / Math.PI);
    }

    /**
     * 触碰两点间距离
     *
     * @param event
     * @return
     */
    private float spacing(MotionEvent event) {
        float x = event.getX(0) - event.getX(1);
        float y = event.getY(0) - event.getY(1);
        return (float) Math.sqrt(x * x + y * y);
    }

    /**
     * 取手势中心点
     *
     * @param point
     * @param event
     */
    private void midPoint(PointF point, MotionEvent event) {
        float x = event.getX(0) + event.getX(1);
        float y = event.getY(0) + event.getY(1);
        point.set(x / 2, y / 2);
    }

    /**
     * 取旋转角度，手触两点的连线与x轴的夹角
     *
     * @param event
     * @return
     */
    private float rotation(MotionEvent event) {
        double delta_x = (event.getX(0) - event.getX(1));
        double delta_y = (event.getY(0) - event.getY(1));
        double radians = Math.atan2(delta_y, delta_x);
        return (float) Math.toDegrees(radians);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        setImageViewHeight(getHeight());
    }

    private void setImageViewHeight(int mImageViewHeight) {
        this.mCroperViewHeight = mImageViewHeight;
        setCropOverlayVertexs();
        invalidate();
    }

    private void setCropOverlayVertexs() {
        int mCropperLineFirstY = (mCroperViewHeight - mCroperViewWidth) / 2;
        mCroperViewCenter = new PointF(mCroperViewWidth / 2, mCroperViewHeight / 2);
        mCropOverlayVertexs = new PointF[]{new PointF(0, mCropperLineFirstY),
                new PointF(mCroperViewWidth, mCropperLineFirstY),
                new PointF(0, mCropperLineFirstY + mCroperViewWidth),
                new PointF(mCroperViewWidth, mCropperLineFirstY + mCroperViewWidth)};
    }

    /**
     * 展示全图按钮
     *
     * @param isFullImage
     */
    public void setFullImageAction(boolean isFullImage) {
        this.isFullImage = isFullImage;
        //        if (!isFullImage) {
        //            isBgcolorChange = false;
        //        }
        adjustImageCenter(!isFullImage);
    }

    /**
     * 将移动，缩放以及旋转后的图层保存为新图片
     *
     * @return
     */
    public Bitmap getCroppedImage() {

        int max = Math.max(mImageBitmap.getWidth(), mImageBitmap.getHeight());
        int min = Math.min(mImageBitmap.getWidth(), mImageBitmap.getHeight());
        int size = isFullImage ? max : min;
        Bitmap bitmap = Bitmap.createBitmap(size, size, Config.ARGB_8888); // 背景图片
        Canvas canvas = new Canvas(bitmap); // 新建画布
        canvas.save(Canvas.ALL_SAVE_FLAG); // 保存画布
        canvas.setDrawFilter(mPaintFlagsDrawFilter);
        if (isBgcolorChange) {
            canvas.drawColor(Color.WHITE);
        }
        if (isFullImage) {
            Rect src = new Rect(0, 0, mImageBitmap.getWidth(), mImageBitmap.getHeight());
            Rect dst = new Rect((max - min) / 2, 0, (max + min) / 2, max);
            if (isVerticalImage) {
                dst.set((max - min) / 2, 0, (max + min) / 2, max);
            } else {
                dst.set(0, (max - min) / 2, max, (max + min) / 2);
            }
            float rotation = getCurrentRotation();
            canvas.rotate(-rotation, max / 2, max / 2);
            canvas.drawBitmap(mImageBitmap, src, dst, null);
        } else {
            matrix.postScale(mRevertScale, mRevertScale);
            matrix.postTranslate(0, -mCropOverlayVertexs[V1].y * mRevertScale);
            canvas.drawBitmap(mImageBitmap, matrix, null); // 画图片
        }
        canvas.restore();
        return bitmap;
    }

    public void setImageBitmap(CropperImageInfo image) {

        Bitmap bitmap = image.getBitmap();

        if (bitmap == null) {
            return;
        }

        initImage(bitmap, image.getWidth(), image.getHeight());

    }

    private void initImage(Bitmap bitmap, int w, int h) {
        mImageBitmap = bitmap;
        mCurrentImageWidth = mOriginalImageWidth = w;
        mCurrentImageHeight = mOriginalImageHeight = h;
        if (w <= h) {
            isVerticalImage = Boolean.TRUE;
        } else {
            isVerticalImage = Boolean.FALSE;
        }
        adjustImageCenter(true);
    }

    /**
     * @param isFullCrop 是否需要全屏剪切
     */
    private void adjustImageCenter(boolean isFullCrop) {
        float scale = 1;
        if ((isVerticalImage && !isFullCrop) || (!isVerticalImage && isFullCrop)) {
            scale = 1f * mCroperViewWidth / mCurrentImageHeight;
        } else {
            scale = 1f * mCroperViewWidth / mCurrentImageWidth;
        }
        mScaledScale = scale * mCurrentScale;
        mRevertScale = 1 / mScaledScale;
        matrix.postScale(scale, scale);
        scaleCurrentImage(mScaledScale);
        PointF vertexCenter = getImageVextexCenter();
        matrix.postTranslate((mCroperViewCenter.x - vertexCenter.x),
                (mCroperViewCenter.y - vertexCenter.y));
        invalidate();
    }

    private void scaleCurrentImage(float scale) {
        mCurrentScale = scale;
        mCurrentImageWidth = mOriginalImageWidth * mCurrentScale;
        mCurrentImageHeight = mOriginalImageHeight * mCurrentScale;
    }

    public void changeBgcolor() {
        if (isFullImage) {
            isBgcolorChange = !isBgcolorChange;
            invalidate();
        } else {
            isBgcolorChange = true;
        }
    }

}
