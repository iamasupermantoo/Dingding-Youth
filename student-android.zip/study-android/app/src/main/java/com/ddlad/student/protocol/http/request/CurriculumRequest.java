package com.ddlad.student.protocol.http.request;


import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.request.BaseCurriculumRequest;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.CurriculumInfo;

/**
 * Created by Administrator on 2016/12/8 0008.
 */

public class CurriculumRequest extends BaseCurriculumRequest {
    public CurriculumRequest(BaseListFragment baseListFragment, int loaderId, AbstractStreamingCallbacks<AbstractListResponse<CurriculumInfo>> streamingApiCallbacks) {
        super(baseListFragment, loaderId, streamingApiCallbacks);
    }

    @Override
    protected String getBasePath() {
        return ProtocolConstants.URL_CURRICULUM_LIST;
    }

}
