package com.ddlad.student.tools;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by Albert on 2016/8/23.
 */
public class DateUtils {

    public static String[] getLatestThirtyYears() {

        String[] years = new String[30];

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());

        for (int i = 0; i < years.length; i++) {
            years[i] = displayYear(calendar);
            calendar.add(Calendar.YEAR, -1);
        }

        return years;
    }

    public static long[] getLatestThirtyYearsInMillis() {

        long[] years = new long[30];

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_YEAR, 1);
        calendar.setTimeInMillis(System.currentTimeMillis());

        for (int i = 0; i < years.length; i++) {
            years[i] = calendar.getTimeInMillis();
            calendar.add(Calendar.YEAR, -1);
        }

        return years;
    }

    public static long[] getNextMonthMillis() {

        long[] days = new long[30];

        long millis = System.currentTimeMillis();

        for (int i = 0; i < days.length; i++) {
            days[i] = millis;
            millis += 86400000;
        }

        return days;
    }

    public static String[] getNextMonthText() {

        String[] days = new String[30];

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());

        for (int i = 0; i < days.length; i++) {
            days[i] = displayDate(calendar);
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }

        return days;
    }

    public static String displayYear(Calendar calendar) {

        StringBuilder date = new StringBuilder();

        date.append(calendar.get(Calendar.YEAR)).append("年");

        return date.toString();
    }

    public static String displayMonth(Calendar calendar) {

        StringBuilder date = new StringBuilder();

        date.append(calendar.get(Calendar.YEAR)).append("年");
        date.append(calendar.get(Calendar.MONTH) + 1).append("月");

        return date.toString();
    }

    public static String displayDate(Calendar calendar) {

        StringBuilder date = new StringBuilder();

        //        date.append(calendar.get(Calendar.YEAR)).append("年");
        date.append(calendar.get(Calendar.MONTH) + 1).append("月");
        date.append(calendar.get(Calendar.DAY_OF_MONTH)).append("日");
        date.append(" ").append(Constants.WeekDay.fromValue(calendar.get(Calendar.DAY_OF_WEEK)));

        return date.toString();
    }

    public static String displayFormatted(String formatted) {

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = format.parse(formatted);
            calendar.setTime(date);
        } catch (Throwable t) {
            t.printStackTrace();
        }

        return displayDate(calendar);
    }

    public static String formattedDate(Calendar calendar) {

        StringBuilder date = new StringBuilder();

        date.append(calendar.get(Calendar.YEAR)).append("-");
        date.append(calendar.get(Calendar.MONTH) + 1).append("-");
        date.append(calendar.get(Calendar.DAY_OF_MONTH));

        return date.toString();
    }
}
