package com.ddlad.student.ui.pic;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.bumptech.glide.Glide;
import com.ddlad.student.R;
import com.ddlad.student.ui.common.BaseActivity;
import com.ddlad.student.ui.model.MultiImageInfo;
import com.ddlad.student.ui.widget.image.NetworkImageView;

import java.util.ArrayList;

import uk.co.senab.photoview.PhotoView;


/**
 *
 * @Title:发布商品选大图
 * @Description:
 * @Author:xuke
 * @Since:2017年3月10日
 * @Version:2.0.0
 */
public class BigPhotoUriAcitivity extends BaseActivity implements OnClickListener {

    private static final String TAG = "BigPhotoAcitivity2";
    private MyViewPager2 vp;
    private TextView activity_choose_bigphoto_upload_count;
    private LinearLayout activity_choose_bigphoto_back,
            activity_choose_bigphoto_confirm;
    private RelativeLayout choose;
    private RelativeLayout v2_pic_bigphotot2_title;

    ArrayList<MultiImageInfo> dataList;
    private boolean descIsVisible = true;
    private int position;
//    private Animation mTopIn;
//    private Animation mTopOut;

    private MyAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.v2_pic_activity_bigphoto2_uri);
        choose = (RelativeLayout) findViewById(R.id.choose);
        choose.setOnClickListener(this);
        activity_choose_bigphoto_upload_count = (TextView) findViewById(R.id.activity_choose_bigphoto_upload_count);
        activity_choose_bigphoto_back = (LinearLayout) findViewById(R.id.activity_choose_bigphoto_back);
        activity_choose_bigphoto_confirm = (LinearLayout) findViewById(R.id.activity_choose_bigphoto_confirm);
        v2_pic_bigphotot2_title = (RelativeLayout) findViewById(R.id.v2_pic_bigphotot2_title);
        activity_choose_bigphoto_confirm.setOnClickListener(this);
        activity_choose_bigphoto_back.setOnClickListener(this);



        Bundle bundle = getIntent().getExtras();
        dataList = (ArrayList<MultiImageInfo>) bundle.getSerializable("images");
        position = bundle.getInt("position", 0);
        boolean isSelected = getIntent().getBooleanExtra("isSelected", false);

//        mTopIn = AnimationUtils.loadAnimation(this, R.anim.top_enter_anim);
//        mTopOut = AnimationUtils.loadAnimation(this, R.anim.top_out_anim);
//        mTopIn.setFillAfter(true);
//        mTopOut.setFillAfter(true);

        vp = (MyViewPager2) findViewById(R.id.vp);
        adapter = new MyAdapter();
        vp.setAdapter(adapter);

        vp.setCurrentItem(position);
//        vp.setOnPageChangeListener(new LazyViewPager.OnPageChangeListener() {
//
//            @Override
//            public void onPageSelected(int arg0) {
////                if (dataList.size() > 0) {
////                    ImageItem item2 = dataMap.get(dataList.get(arg0));
////                    if (imgItems.get(item2.imageId) != null) {
////                        choose_iv.setVisibility(View.VISIBLE);
////                    } else {
////                        choose_iv.setVisibility(View.GONE);
////                    }
////                }
//            }
//
//            @Override
//            public void onPageScrolled(int arg0, float arg1, int arg2) {
//
//            }
//
//            @Override
//            public void onPageScrollStateChanged(int arg0) {
//
//            }
//        });

        vp.setCurrentItem(position);
    }

    private class MyAdapter extends PagerAdapter {

        @Override
        public int getCount() {
            return dataList.size();
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            PhotoView photoView = new PhotoView(BigPhotoUriAcitivity.this);
            String url = dataList.get(position).getPattern();
            Log.e("BigPhoto","image_url ======"+url.substring(url.indexOf("http"),url.indexOf("@{w}")));
            Glide.with(BigPhotoUriAcitivity.this).load(url.substring(url.indexOf("http"),url.indexOf("@{w}"))).into(photoView);
//            NetworkImageView im = new NetworkImageView(BigPhotoUriAcitivity.this);
//            im.setUrl(dataList.get(position).getImageLarge());
//            im.setOnClickListener(new OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    if (descIsVisible){
//                        descIsVisible = false;
//                        v2_pic_bigphotot2_title.startAnimation(mTopOut);
//                    }else {
//                        descIsVisible = true;
//                        v2_pic_bigphotot2_title.startAnimation(mTopIn);
//                    }
//                }
//            });
            container.addView(photoView);

            return photoView;

        }

        @Override
        public void destroyItem(View container, int position, Object object) {
            ((MyViewPager2) container).removeView((View) object);
        }

    }

    private Bitmap getimage(String srcPath) {
        BitmapFactory.Options newOpts = new BitmapFactory.Options();
        // 开始读入图片，此时把options.inJustDecodeBounds 设回true了
        newOpts.inJustDecodeBounds = true;
        Bitmap bitmap = BitmapFactory.decodeFile(srcPath, newOpts);// 此时返回bm为空
        newOpts.inJustDecodeBounds = false;
        int w = newOpts.outWidth;
        int h = newOpts.outHeight;
        // 现在主流手机比较多是800*480分辨率，所以高和宽我们设置为
        float hh = (getColumnWidth())[1];// 这里设置高度为800f
        float ww = (getColumnWidth())[0];// 这里设置宽度为480f
        // float hh = 800f;
        // float ww = 480f;
        // 缩放比。由于是固定比例缩放，只用高或者宽其中一个数据进行计算即可
        int be = 1;// be=1表示不缩放
        if (w < h && w > ww) {// 如果宽度大的话根据宽度固定大小缩放
            be = (int) (newOpts.outWidth / ww) + 1;
        } else if (w > h && h > hh) {// 如果高度高的话根据宽度固定大小缩放
            be = (int) (newOpts.outHeight / hh) + 1;
        }
        if (be <= 0)
            be = 1;
        newOpts.inSampleSize = be;// 设置缩放比例
        newOpts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        // 重新读入图片，注意此时已经把options.inJustDecodeBounds 设回false了
        bitmap = BitmapFactory.decodeFile(srcPath, newOpts);
        return bitmap;// 压缩好比例大小后再进行质量压缩
    }

    @Override
    public void onClick(View v) {
        int item_position = vp.getCurrentItem();
        switch (v.getId()) {
            case R.id.choose:

                break;

            case R.id.activity_choose_bigphoto_back:
                Intent intent2 = new Intent();
                Bundle bundle = new Bundle();
                bundle.putSerializable("dataList", dataList);
                intent2.putExtras(bundle);
                setResult(RESULT_OK, intent2);
                finish();
                break;
            case R.id.activity_choose_bigphoto_confirm:

                break;
            default:
                break;
        }
    }

    /**
     * 获取屏幕宽高
     */
    private int[] getColumnWidth() {

        int[] wh = new int[2];
        DisplayMetrics dm = new DisplayMetrics();
        // 获取屏幕信息
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int screenWidth = dm.widthPixels;
        wh[0] = screenWidth;
        int screenHeigh = dm.heightPixels;
        wh[1] = screenHeigh;

        return wh;
    }

}
