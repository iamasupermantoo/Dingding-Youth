package com.ddlad.student.primary;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.ddlad.student.primary.DBHelper;

/**
 * Created by Administrator on 2016/12/20 0020.
 */

public class DBManager {

    private DBHelper helper;
    private SQLiteDatabase db;

    public DBManager(Context context) {
        helper = new DBHelper(context);
        //因为getWritableDatabase内部调用了mContext.openOrCreateDatabase(mName, 0, mFactory);
        //所以要确保context已初始化,我们可以把实例化DBManager的步骤放在Activity的onCreate里
        db = helper.getWritableDatabase();
    }

//    public void add(List<ChatInfo> list) {
//        db.beginTransaction();  //开始事务
//        try {
//            for (ChatInfo chatInfo : list) {
//                db.execSQL("INSERT INTO chatInfo(id,session,content,pattern,message,chatTime,type,isSender) VALUES(?, ?, ?, ?, ?, ?, ?, ?)", new Object[]{chatInfo.id, chatInfo.session,chatInfo.content,chatInfo.pattern,chatInfo.message,chatInfo.chatTime,chatInfo.type,chatInfo.isSender});
//            }
//            db.setTransactionSuccessful();  //设置事务成功完成
//        } finally {
//            db.endTransaction();    //结束事务
//        }
//    }

    public String getChatIdFromId(String sessionId)throws Exception {
        Cursor c = db.rawQuery("SELECT id FROM chatInfo where session = ? order by _id desc limit 1",  new String[]{sessionId});
        String chatId = null;
        while (c.moveToNext()){
            chatId = c.getString(c.getColumnIndex("id"));
        }
        c.close();
        return chatId;
    }
//
//    public void updateAge(ChatInfo chatInfo) {
//        ContentValues cv = new ContentValues();
//        cv.put("id", chatInfo.id);
//        cv.put("session", chatInfo.session);
//        cv.put("content", chatInfo.content);
//        cv.put("pattern", chatInfo.pattern);
//        cv.put("message", chatInfo.message);
//        cv.put("chatTime", chatInfo.chatTime);
//        cv.put("isSender", chatInfo.isSender);
//
//        db.update("chatInfo", cv, "id = ?", new String[]{chatInfo.id});
//        db.update("chatInfo", cv, "session = ?", new String[]{chatInfo.session});
//        db.update("chatInfo", cv, "content = ?", new String[]{chatInfo.content});
//        db.update("chatInfo", cv, "pattern = ?", new String[]{chatInfo.pattern});
//        db.update("chatInfo", cv, "message = ?", new String[]{chatInfo.message});
//        db.update("chatInfo", cv, "chatTime = ?", new String[]{chatInfo.chatTime});
////        db.update("chatInfo", cv, "isSender = ?", new boolean[]{chatInfo.isSender});
//    }
//
//    public void deleteOldPerson(ChatInfo chatInfo) {
//        db.delete("chatInfo", "id >= ?", new String[]{String.valueOf(chatInfo.id)});
//        db.delete("chatInfo", "session>= ?", new String[]{String.valueOf(chatInfo.session)});
//        db.delete("chatInfo", "content >= ?", new String[]{String.valueOf(chatInfo.content)});
//        db.delete("chatInfo", "pattern >= ?", new String[]{String.valueOf(chatInfo.pattern)});
//        db.delete("chatInfo", "message >= ?", new String[]{String.valueOf(chatInfo.message)});
//        db.delete("chatInfo", "chatTime >= ?", new String[]{String.valueOf(chatInfo.chatTime)});
//        db.delete("chatInfo", "type >= ?", new String[]{String.valueOf(chatInfo.type)});
////        db.delete("chatInfo", "isSender >= ?", new boolean[]{Boolean.valueOf(chatInfo.isSender)});
//
//    }
//
//    public void delete(){
//        db.execSQL("delete from chatInfo");
//    }
//
//    public List<ChatInfo> query(String sessionId , int _id) {
//        ArrayList<ChatInfo> chatInfos = new ArrayList<>();
//        Cursor c = queryTheCursor(sessionId , _id);
//            while (c.moveToNext()) {
//                ChatInfo chatInfo = new ChatInfo();
//                chatInfo._id = c.getInt(c.getColumnIndex("_id"));
//                chatInfo.id = c.getString(c.getColumnIndex("id"));
//                chatInfo.session = c.getString(c.getColumnIndex("session"));
//                chatInfo.content = c.getString(c.getColumnIndex("content"));
//                chatInfo.pattern = c.getString(c.getColumnIndex("pattern"));
//                chatInfo.message = c.getString(c.getColumnIndex("message"));
//                chatInfo.chatTime = c.getString(c.getColumnIndex("chatTime"));
//                chatInfo.type = c.getInt(c.getColumnIndex("type"));
//                chatInfo.isSender = c.getInt(c.getColumnIndex("isSender"));
//                chatInfos.add(chatInfo);
//            }
//        c.close();
//        return chatInfos;
//    }

    public Cursor queryTheCursor(String sessionId, int _id) {
        String sql = "SELECT * FROM chatInfo where session = ? order by _id desc limit 10";
        if(_id > 0){
            sql = "SELECT * FROM chatInfo where _id < " + _id + " and  session = ? order by _id desc limit 10";
        }
        Cursor c = db.rawQuery(sql ,  new String[]{sessionId});
        return c;
    }

    public void closeDB() {
        db.close();
    }

}
