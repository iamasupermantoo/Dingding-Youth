package com.ddlad.student.protocol.model;

import com.ddlad.student.ui.model.MultiImageInfo;

import java.util.List;

/**
 * Created by chen007 on 2017/7/10 0010.
 */
public class LiveInfo extends BaseInfo {

        /**
         * roomInfo : {"channelName":"ddca94c7bb651a9ec61ceae0d316a7f8","account":4294967295,"studentAccount":18,"teacherAccount":4,"role":2,"channelKey":"005AQAoAEY3MTA3RjAzNkFEMjRBOEUxRTc1QzJEQTk3MDYwODcwQkUzNDk0NjEQAIHQSqNIKkJhocz5tzZ+sxI3vWVZuQoyZbexaVkAAA==","signalingKey":"1:81d04aa3482a4261a1ccf9b7367eb312:1499850599:84d6634525d8910ae27e83529859e5ed"}
         * framesInfo : {"version":"1.0","frames":[{"idx":0,"type":0,"image":{"id":"duWOsDlUhOumtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/duWOsDlUhOumtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":1,"type":0,"image":{"id":"X1ABnBaoij6mtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/X1ABnBaoij6mtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":2,"type":0,"image":{"id":"CQQ7Ic8ZhuumtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/CQQ7Ic8ZhuumtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":3,"type":0,"image":{"id":"VNojLibQ-tqmtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/VNojLibQ-tqmtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":4,"type":0,"image":{"id":"tVGdxAKvOZWmtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/tVGdxAKvOZWmtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":5,"type":0,"image":{"id":"jmF_WnZjy9umtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/jmF_WnZjy9umtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":6,"type":0,"image":{"id":"5Uvv4e2pTOimtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/5Uvv4e2pTOimtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":7,"type":0,"image":{"id":"zOmfijkA4BGmtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/zOmfijkA4BGmtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":8,"type":0,"image":{"id":"XTXbZqgjJBumtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/XTXbZqgjJBumtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":9,"type":0,"image":{"id":"Fx8EbOF_0J2mtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/Fx8EbOF_0J2mtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":10,"type":0,"image":{"id":"N6RjfP-f4sKmtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/N6RjfP-f4sKmtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":11,"type":0,"image":{"id":"PJW7p59eCI-mtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/PJW7p59eCI-mtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":12,"type":0,"image":{"id":"S_0MQhhPArOmtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/S_0MQhhPArOmtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":13,"type":0,"image":{"id":"W-NYw-Hc2UymtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/W-NYw-Hc2UymtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":14,"type":0,"image":{"id":"DVfzNQi1HHamtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/DVfzNQi1HHamtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":15,"type":0,"image":{"id":"iKTxSzkxItCmtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/iKTxSzkxItCmtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}}]}
         * rejoinInfo : {}
         */

        private LiveInfoBean liveInfo;

        public LiveInfoBean getLiveInfo() {
            return liveInfo;
        }

        public void setLiveInfo(LiveInfoBean liveInfo) {
            this.liveInfo = liveInfo;
        }

        public static class LiveInfoBean {
            /**
             * channelName : ddca94c7bb651a9ec61ceae0d316a7f8
             * account : 4294967295
             * studentAccount : 18
             * teacherAccount : 4
             * role : 2
             * channelKey : 005AQAoAEY3MTA3RjAzNkFEMjRBOEUxRTc1QzJEQTk3MDYwODcwQkUzNDk0NjEQAIHQSqNIKkJhocz5tzZ+sxI3vWVZuQoyZbexaVkAAA==
             * signalingKey : 1:81d04aa3482a4261a1ccf9b7367eb312:1499850599:84d6634525d8910ae27e83529859e5ed
             */

            private RoomInfoBean roomInfo;
            /**
             * version : 1.0
             * frames : [{"idx":0,"type":0,"image":{"id":"duWOsDlUhOumtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/duWOsDlUhOumtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":1,"type":0,"image":{"id":"X1ABnBaoij6mtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/X1ABnBaoij6mtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":2,"type":0,"image":{"id":"CQQ7Ic8ZhuumtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/CQQ7Ic8ZhuumtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":3,"type":0,"image":{"id":"VNojLibQ-tqmtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/VNojLibQ-tqmtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":4,"type":0,"image":{"id":"tVGdxAKvOZWmtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/tVGdxAKvOZWmtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":5,"type":0,"image":{"id":"jmF_WnZjy9umtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/jmF_WnZjy9umtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":6,"type":0,"image":{"id":"5Uvv4e2pTOimtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/5Uvv4e2pTOimtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":7,"type":0,"image":{"id":"zOmfijkA4BGmtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/zOmfijkA4BGmtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":8,"type":0,"image":{"id":"XTXbZqgjJBumtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/XTXbZqgjJBumtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":9,"type":0,"image":{"id":"Fx8EbOF_0J2mtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/Fx8EbOF_0J2mtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":10,"type":0,"image":{"id":"N6RjfP-f4sKmtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/N6RjfP-f4sKmtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":11,"type":0,"image":{"id":"PJW7p59eCI-mtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/PJW7p59eCI-mtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":12,"type":0,"image":{"id":"S_0MQhhPArOmtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/S_0MQhhPArOmtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":13,"type":0,"image":{"id":"W-NYw-Hc2UymtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/W-NYw-Hc2UymtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":14,"type":0,"image":{"id":"DVfzNQi1HHamtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/DVfzNQi1HHamtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}},{"idx":15,"type":0,"image":{"id":"iKTxSzkxItCmtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/iKTxSzkxItCmtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}}]
             */

            private FramesInfoBean framesInfo;
            private RejoinInfoBean rejoinInfo;

            public RoomInfoBean getRoomInfo() {
                return roomInfo;
            }

            public void setRoomInfo(RoomInfoBean roomInfo) {
                this.roomInfo = roomInfo;
            }

            public FramesInfoBean getFramesInfo() {
                return framesInfo;
            }

            public void setFramesInfo(FramesInfoBean framesInfo) {
                this.framesInfo = framesInfo;
            }

            public RejoinInfoBean getRejoinInfo() {
                return rejoinInfo;
            }

            public void setRejoinInfo(RejoinInfoBean rejoinInfo) {
                this.rejoinInfo = rejoinInfo;
            }

            public static class RoomInfoBean {
                private String channelName;
                private int account;
                private int studentAccount;
                private int teacherAccount;
                private int role;
                private String channelKey;
                private String signalingKey;

                public String getChannelName() {
                    return channelName;
                }

                public void setChannelName(String channelName) {
                    this.channelName = channelName;
                }

                public int getAccount() {
                    return account;
                }

                public void setAccount(int account) {
                    this.account = account;
                }

                public int getStudentAccount() {
                    return studentAccount;
                }

                public void setStudentAccount(int studentAccount) {
                    this.studentAccount = studentAccount;
                }

                public int getTeacherAccount() {
                    return teacherAccount;
                }

                public void setTeacherAccount(int teacherAccount) {
                    this.teacherAccount = teacherAccount;
                }

                public int getRole() {
                    return role;
                }

                public void setRole(int role) {
                    this.role = role;
                }

                public String getChannelKey() {
                    return channelKey;
                }

                public void setChannelKey(String channelKey) {
                    this.channelKey = channelKey;
                }

                public String getSignalingKey() {
                    return signalingKey;
                }

                public void setSignalingKey(String signalingKey) {
                    this.signalingKey = signalingKey;
                }
            }

            public static class FramesInfoBean {
                /**
                 * idx : 0
                 * type : 0
                 * image : {"id":"duWOsDlUhOumtNwJIdJiCA","width":1400,"height":1000,"format":"jpeg","pattern":"http://img.src.ddlad.com/duWOsDlUhOumtNwJIdJiCA.jpeg@{w}w_{h}h_75q"}
                 */

                private List<FramesBean> frames;

                public List<FramesBean> getFrames() {
                    return frames;
                }

                public void setFrames(List<FramesBean> frames) {
                    this.frames = frames;
                }

                public static class FramesBean {
                    private int idx;

                    private int type;

                    private MultiImageInfo image;

                    private List<ChildrenBean> children;

                    public List<ChildrenBean> getChildren() {
                        return children;
                    }

                    public void setChildren(List<ChildrenBean> children) {
                        this.children = children;
                    }

                    public int getType() {
                        return type;
                    }

                    public void setType(int type) {
                        this.type = type;
                    }

                    public int getIdx() {
                        return idx;
                    }

                    public void setIdx(int idx) {
                        this.idx = idx;
                    }
                    public MultiImageInfo getImage() {
                        return image;
                    }

                    public void setImage(MultiImageInfo image) {
                        this.image = image;
                    }

                    public static class ChildrenBean{
                        private int idx;
                        private int type;
                        private String audio;
                        private String video;

                        public String getVideo() {
                            return video;
                        }

                        public void setVideo(String video) {
                            this.video = video;
                        }

                        public String getAudio() {
                            return audio;
                        }

                        public void setAudio(String audio) {
                            this.audio = audio;
                        }

                        public int getType() {
                            return type;
                        }

                        public void setType(int type) {
                            this.type = type;
                        }

                        public int getIdx() {
                            return idx;
                        }

                        public void setIdx(int idx) {
                            this.idx = idx;
                        }

                    }

                }
            }

            public static class RejoinInfoBean {

                private int currentFrameX;
                private int currentFrameY;

                public int getCurrentFrameX() {
                    return currentFrameX;
                }

                public void setCurrentFrameX(int currentFrameX) {
                    this.currentFrameX = currentFrameX;
                }

                public int getCurrentFrameY() {
                    return currentFrameY;
                }

                public void setCurrentFrameY(int currentFrameY) {
                    this.currentFrameY = currentFrameY;
                }
            }

        }
}
