package com.ddlad.student.ui.account;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.request.AliPayResultRequest;
import com.ddlad.student.protocol.http.request.WxpayResultRequest;
import com.ddlad.student.protocol.model.AlipayOrderInfo;
import com.ddlad.student.protocol.model.WxpayOrderInfo;
import com.ddlad.student.ui.common.BaseFragment;


/**
 * Created by Administrator on 2017/3/17 0017.
 */
public class PayResultFragment extends BaseFragment {

    private TextView mPayResul;

    private boolean mVerfication = false;

    private int mState;



    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_pay_result;
    }

    @Override
    protected void onInitView(View contentView) {

        mActionbar.setTitle("支付结果");

        mPayResul = (TextView) contentView.findViewById(R.id.pay_result_tv);

        if (mVerfication){
            mPayResul.setText("支付成功！");
        }
    }

    @Override
    protected void onInitData(Bundle bundle) {
        super.onInitData(bundle);
        //验证WX支付结果
        WxpayResultRequest request = new WxpayResultRequest(this, getDefaultLoaderId(), new AbstractCallbacks<WxpayOrderInfo>() {
            @Override
            protected void onSuccess(WxpayOrderInfo wxpayOrderInfo) {
                mVerfication = true;
                Log.i(TAG, "onSuccess: 微信支付支付成功");
            }

            @Override
            protected void onFail(ApiResponse<WxpayOrderInfo> response) {
                Log.i(TAG, "onFail: 验证微信支付失败！！！");

            }
        });
        request.perform();
        //验证支付宝支付结果
        AliPayResultRequest request1 = new AliPayResultRequest(this, getDefaultLoaderId(), new AbstractCallbacks<AlipayOrderInfo>() {
            @Override
            protected void onSuccess(AlipayOrderInfo alipayOrderInfo) {
                mVerfication = true;
                Log.i(TAG, "onSuccess: 支付宝支付支付成功");
            }

            @Override
            protected void onFail(ApiResponse<AlipayOrderInfo> response) {
                Log.i(TAG, "onFail: 验证支付宝支付失败！！！");

            }
        });
        request1.perform();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
        super.onClick(v);
    }
}

