package com.ddlad.student.ui.model;

import android.text.TextUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.tools.LibWebpUtil;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

public class MultiImageInfo implements Serializable {

    private static final long serialVersionUID = 3398829608730445788L;

    private ArrayList<String> mType;

    private ArrayList<String> mHostname;

    private String pattern;

    private String mId;

    private int mWidth;

    private int mHeight;

    private String mImageTiny;

    private String mImageSmall;

    private String mImageMedium;

    private String mImageLarge;

    public String getImageTiny() {
        if (TextUtils.isEmpty(mImageTiny)) {
            mImageTiny = createImageUrlSize(ImageSize.Image_66);
        }
        return mImageTiny;
    }


    public String getImageSmall() {
        if (TextUtils.isEmpty(mImageSmall)) {
            mImageSmall = createImageUrlSize(ImageSize.Image_100);
        }
        return mImageSmall;
    }

    public String getImageMedium() {
        if (TextUtils.isEmpty(mImageMedium)) {
            mImageMedium = createImageUrlSize(ImageSize.Image_290);
        }
        return mImageMedium;
    }

    public String getImageLarge() {
        if (TextUtils.isEmpty(mImageLarge)) {
            mImageLarge = createImageUrlSize(ImageSize.Image_640);
        }
        return mImageLarge;
    }

    public String createImageUrlSize(MultiImageType priorityType, ImageSize imageSize) {
        return createImageUrlSize(priorityType, imageSize.getValue());
    }

    public String createImageUrlSize(MultiImageType priorityType, int size) {
        return createImageUrl(priorityType, size, size);
    }

    public String createImageUrlSize(ImageSize imageSize) {
        return createImageUrlSize(imageSize.getValue());
    }

    public String createImageUrlSize(int size) {
        return createImageUrl(size, size);
    }

    public String createImageUrl(int width, int height) {
        return createImageUrl(LibWebpUtil.isCanUseWebpFormat() ? MultiImageType.WEBP
                : MultiImageType.JPEG, width, height);
    }

    /**
     * @param priorityType 如果系统不支持WEBP格式，优先使用的图片格式[只有在系统在不支持webp格式的情况下有效]
     * @param width
     * @param height
     * @return
     */
    private String createImageUrl(MultiImageType priorityType, int width, int height) {

        if (!TextUtils.isEmpty(pattern)) {
            String[] lines = pattern.split("[{}]");
            if (lines.length < 1) {
                return null;
            }
            StringBuffer url = new StringBuffer();
            for (String line : lines) {
                if ("id".equals(line)) {
                    url.append(getId());
                } else if ("w".equals(line)) {
                    url.append(width);
                } else if ("h".equals(line)) {
                    url.append(height);
                } else {
                    url.append(line);
                }

            }
            return url.toString();
        }
        return null;
    }


    public ArrayList<String> getType() {
        return mType;
    }

    public ArrayList<String> getHostname() {
        return mHostname;
    }

    public void setType(ArrayList<String> format) {
        this.mType = format;
    }

    public void setHostname(ArrayList<String> hostname) {
        this.mHostname = hostname;
    }

    public String getPattern() {
        return pattern;
    }

    public String getId() {
        return mId;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    public void setId(String id) {
        this.mId = id;
    }

    public static MultiImageInfo fromJsonParser(JsonParser jsonParser) throws JsonParseException,
            IOException {
        MultiImageInfo info = null;
        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            if (info == null) {
                info = new MultiImageInfo();
            }
            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }
                if ("pattern".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.pattern = jsonParser.getText();
                    continue;
                }
                if ("id".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.mId = jsonParser.getText();
                    continue;
                }
                if ("width".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.mWidth = jsonParser.getIntValue();
                    continue;
                }
                if ("height".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.mHeight = jsonParser.getIntValue();
                    continue;
                }

                jsonParser.skipChildren();
            }
        }
        return info;
    }

    public int getWidth() {
        return mWidth;
    }

    public void setWidth(int width) {
        this.mWidth = width;
    }

    public int getHeight() {
        return mHeight;
    }

    public void setHeight(int height) {
        this.mHeight = height;
    }

    public static enum MultiImageType {

        WEBP("webp"), JPEG("jpeg"), PNG("png");

        private String value;

        MultiImageType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public static enum ImageSize {
        Image_640(640), Image_480(480), Image_290(290), Image_200(200), Image_120(120), Image_110(110), Image_100(
                100), Image_66(66);

        private int size;

        ImageSize(int size) {
            this.size = size;
        }

        public int getValue() {
            return size;
        }

    }

}
