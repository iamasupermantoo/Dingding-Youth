package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.Account;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.protocol.http.internal.ApiResponse;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-10-13.
 */
public class ConnectLoginRequest extends AbstractRequest<Account> {

    public ConnectLoginRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<Account> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_CONNECT;
    }

    @Override
    public Account processInBackground(ApiResponse<Account> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA,Account.class);
    }

    public void perform(String user,int type) {
        RequestParams param = getParams();
        if (type != 0){
            param.put(ProtocolConstants.PARAM_TYPE, type);
        }else {
            param.put(ProtocolConstants.PARAM_TYPE, 1);
        }
        param.put(ProtocolConstants.PARAM_EXTERNAL_USERID, user);
        super.perform();
    }
}