package com.ddlad.student.ui.course;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.model.CourseMetaListInfo;
import com.ddlad.student.ui.widget.image.NetworkImageView;


/**
 * Created by Albert
 * on 16-10-20.
 */
public class CourseListItemAdapter {

    public static View createView(ViewGroup viewGroup) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.course_item_layout,
                null);

        ViewHolder holder = new ViewHolder(view);

        view.setTag(holder);

        return view;
    }

    public static void bindView(View view, final CourseMetaListInfo mInfo, final BaseFragment fragment) {

        if (mInfo == null) {
            return;
        }

        ViewHolder myViewHolder = (ViewHolder) view.getTag();

        if (myViewHolder == null) {
            return;
        }
        myViewHolder.mImage.setUrl(mInfo.getImage().getImageMedium());
        myViewHolder.mCourse.setText(mInfo.getName());
        myViewHolder.mClassTime.setText(mInfo.getTotalCnt()+"节课");
        myViewHolder.mTeacher.setText(mInfo.getLevel()+"");
        myViewHolder.mTime.setText(mInfo.getDesc());
        myViewHolder.mLayoutItme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("cmid",mInfo.getCmId());
//                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new CourseDetailsFragment(), bundle);
                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new NewCourseDetailsFragment(), bundle);
            }
        });

    }

    private static class ViewHolder {
        public TextView mCourse;
        public TextView mClassTime;
        public TextView mTeacher;
        public TextView mTime;
        public NetworkImageView mImage;
        public TextView mEvaluate;
        public ViewGroup mEvluateDetails;
        public ViewGroup mLayoutItme;
        public ViewHolder(View itemView) {
            mCourse = (TextView) itemView.findViewById(R.id.evaluate_item_course);
            mClassTime = (TextView) itemView.findViewById(R.id.evaluate_item_class_time);
            mTeacher = (TextView) itemView.findViewById(R.id.evaluate_item_teacher);
            mTime = (TextView) itemView.findViewById(R.id.evaluate_item_time);
            mImage = (NetworkImageView) itemView.findViewById(R.id.evaluate_item_image);
            mEvaluate = (TextView) itemView.findViewById(R.id.evaluate);
            mEvluateDetails = (ViewGroup) itemView.findViewById(R.id.evaluate_details);
            mLayoutItme = (ViewGroup) itemView.findViewById(R.id.layout_item);

        }
    }
}
