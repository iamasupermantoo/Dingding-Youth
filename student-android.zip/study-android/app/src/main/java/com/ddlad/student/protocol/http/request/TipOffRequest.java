package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-11-7.
 */
public class TipOffRequest extends AbstractRequest<String> {

    public TipOffRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<String> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_TIP_OFF;
    }

    @Override
    public String processInBackground(ApiResponse<String> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, String.class);
    }

    public void perform(String target, int type, String reason) {
        RequestParams params = getParams();
        params.put("target", target);
        params.put("type", type);
        params.put("reason", reason);
        super.perform();
    }

    public enum ReportType {

        Feed(0), User(1);

        private ReportType(int value) {
            this.mValue = value;
        }

        private int mValue;

        public int getValue() {
            return mValue;
        }
    }
}
