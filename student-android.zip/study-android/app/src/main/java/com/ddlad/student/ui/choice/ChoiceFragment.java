package com.ddlad.student.ui.choice;


import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewPager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.OvershootInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.TextView;

import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;
import com.ddlad.student.protocol.convert.DataCenter;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.request.ClientVersionRequest;
import com.ddlad.student.protocol.http.request.HomeIntroRequest;
import com.ddlad.student.protocol.model.BannerInfo;
import com.ddlad.student.protocol.model.IntroInfo;
import com.ddlad.student.protocol.model.VersionInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.tools.StringUtil;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.attendclass.VideoPlayerActivityy;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.export.WebViewFragment;
import com.ddlad.student.ui.widget.dialog.DialogBuilder;
import com.ddlad.student.ui.widget.image.CircleImageView;
import com.ddlad.student.R;
import com.ddlad.student.ui.widget.image.NetworkImageView;
import com.ddlad.student.ui.widget.pager.CommonPager;
import com.ddlad.student.ui.widget.pager.PagerPointer;
import com.ddlad.student.ui.widget.scroll.HomePageScroller;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;


public class ChoiceFragment extends BaseFragment {

    private int mUpdateLoaderId = ViewUtil.generateUniqueId();
    private ImageView mDingImage;
    private ImageView mHomePoint;
    private CircleImageView mHeadIamge;
    private TextView mName;
    private TextView mTime;
    private TextView mCount;
    private ViewGroup bottom_learn_layout;
    private ViewGroup introduce;
    private TranslateAnimation animation;

    private ViewGroup try_listen;
    private ViewGroup lesson_begin_info;
    private ViewGroup information;

    private boolean isFirstCreate = true;
    private boolean isTouch = false;
    private List<BannerInfo> mInfoList;
    private int bannerCount = 1;

    private boolean isNeedPost = false;
    private TimerTask  timerTask = new TimerTask() {
        @Override
        public void run() {
            handler.sendEmptyMessage(0511);
        }
    };

    private Timer timer = new Timer();

    private String mVideoUrl;

    private boolean isForceUpdate = false;
    private VersionInfo mVersionInfo;

    private int imageCount = 1;
    private int count = 0;

    private Runnable task = new Runnable() {
        @Override
        public void run() {
            handler.sendEmptyMessage(0511);
            handler.postDelayed(this, 3 * 1000);
        }
    };
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 0511){
                mDingImage.startAnimation(animation);
            }

            super.handleMessage(msg);
        }
    };


    @Override
    protected int getLayoutResource() {
//        return R.layout.fragment_choice;
        return R.layout.fragment_choice_new;
    }

    @Override
    protected void onInitView(View contentView) {

        mActionbar.hideEvaluateTitle();
        mActionbar.setTitle("首页");
//        mActionbar.setBottomDividerGone();
        mActionbar.hideLeftLayout();

        try_listen = (ViewGroup) contentView.findViewById(R.id.try_listen);
        lesson_begin_info = (ViewGroup) contentView.findViewById(R.id.lesson_begin_info);
        information = (ViewGroup) contentView.findViewById(R.id.information);


        mDingImage = (ImageView) contentView.findViewById(R.id.ding_iamge);
        mHomePoint = (ImageView) contentView.findViewById(R.id.home_point);
        mHeadIamge = (CircleImageView) contentView.findViewById(R.id.head_image);
        mName = (TextView) contentView.findViewById(R.id.name);
        mTime = (TextView) contentView.findViewById(R.id.time);
        bottom_learn_layout = (ViewGroup) contentView.findViewById(R.id.bottom_learn_layout);
        introduce = (ViewGroup) contentView.findViewById(R.id.introduce);
        introduce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ///跳到视频播放页
                if (!StringUtil.isEmpty(mVideoUrl)){
                    seeVideo(mVideoUrl);
                }
            }
        });


                animation = new TranslateAnimation(3, -3, 0, 0);
        animation.setInterpolator(new OvershootInterpolator());
        animation.setDuration(50);
        animation.setRepeatCount(5);
        animation.setRepeatMode(Animation.REVERSE);
        mHomePoint.setImageResource(R.drawable.home_point);
        AnimationDrawable animationDrawable = (AnimationDrawable) mHomePoint.getDrawable();
        animationDrawable.start();
//        Glide.with(getActivity()).load(R.drawable.home_shengluehao2x).diskCacheStrategy(DiskCacheStrategy.NONE).into(new GlideDrawableImageViewTarget(mHomePoint,1));
        if (isNeedPost){
            handler.postDelayed(task,0);
            isNeedPost = false;
        }
//        if (timer == null){
//            timer.schedule(timerTask,0,5000);
//        }
//
//        Animation rotate = AnimationUtils.loadAnimation(getActivity(), R.anim.home_ding);
//        mDingImage.startAnimation(rotate);
        String url = DataCenter.getUser().getHeadImage().getImageSmall();
        mHeadIamge.setUrl(DataCenter.getUser().getHeadImage().getImageSmall(),true);
        mName.setText(DataCenter.getUser().getName()+"");

    }

    private void initLabelGroup(ViewGroup groupItem, int textRes) {
        TextView label_name = (TextView) groupItem.findViewById(R.id.label_name);
        TextView more = (TextView) groupItem.findViewById(R.id.more);
        ViewGroup item_layout = (ViewGroup) groupItem.findViewById(R.id.item_layout);

        initLabelItem(item_layout);


        label_name.setText("");
        more.setText("");

        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        groupItem.setOnClickListener(this);
    }

    private void initLabelItem(ViewGroup itemLayout) {
        View labelItem;
        for(int i = 0; i < 5 ; i++ ){
            labelItem = LayoutInflater.from(getActivity()).inflate(R.layout.layout_home_label_item,itemLayout);
            TextView title = (TextView) labelItem.findViewById(R.id.title);
            TextView partake_num = (TextView) labelItem.findViewById(R.id.partake_num);
            TextView begin_time = (TextView) labelItem.findViewById(R.id.begin_time);
            NetworkImageView image = (NetworkImageView) labelItem.findViewById(R.id.image);
            title.setText("");
            image.setUrl("");
            partake_num.setText(AppContext.getString(R.string.partake_num, "zifuc"));
            begin_time.setText(AppContext.getString(R.string.lesson_begin_time, "zifuc"));
            itemLayout.addView(labelItem);
        }

    }




    private void checkUpdate() {
//        BaseActivity.isNeedInterceptBack = false;
        ClientVersionRequest request = new ClientVersionRequest(this, mUpdateLoaderId,
                new AbstractCallbacks<VersionInfo>() {
                    @Override
                    protected void onSuccess(VersionInfo version) {
//                        if (version != null && version.getUrl() != null){
//                            getActivity().getContentResolver().registerContentObserver(Uri.parse(version.getUrl()),true,observer);
//                        }
                        if (version != null && version.getUrl() != null){
                            mVersionInfo = version;
                            showUpdateDialog(version);
                        }
                    }
                });
        request.perform();
    }


    private void showUpdateDialog(final VersionInfo version) {

        if (version == null) {
            return;
        }

        getActivity().setFinishOnTouchOutside(false);

        final DialogBuilder dialogBuilder = new DialogBuilder(getActivity());

        dialogBuilder.setCanceledOnTouchOutside(false);
        dialogBuilder.setTitle(version.getTitle())
                .setMessage(version.getDesc())
                .setMessageGravity(Gravity.CENTER)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Bundle bundle = new Bundle();
                        bundle.putString(ProtocolConstants.PARAM_TITLE,
                                version.getTitle());
                        bundle.putString(ProtocolConstants.PARAM_URL,
                                version.getUrl());
                        NavigateUtil.navigateToNormalActivity(getActivity(), new WebViewFragment(), bundle);
                    }
                });
        if (!version.isForce()){
            dialogBuilder.
                    setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogBuilder.dismiss();
                        }
                    });
        }else {
            isForceUpdate = true;
        }
        dialogBuilder.create().show();
    }

    public void introRequest(){
        new HomeIntroRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<IntroInfo>() {
            @Override
            protected void onSuccess(IntroInfo introInfo) {
                if (introInfo != null){
                    mVideoUrl = introInfo.getVideo();
                }
            }
        }).perform();
    }

    @Override
    public void onPause() {
        Log.i("ChoiceFramgnet","-----------------------------------------------onPause");
        handler.removeCallbacks(task);
        isNeedPost = true;
        super.onPause();
    }

    @Override
    public void onResume() {
        Log.i("ChoiceFramgnet","-----------------------------------------------onResume");
        if (isNeedPost){
            handler.postDelayed(task,0);
            isNeedPost = false;
        }
        if (isForceUpdate){
            showUpdateDialog(mVersionInfo);
        }
        super.onResume();
    }

    @Override
    public void onStop() {
        Log.i("ChoiceFramgnet","-----------------------------------------------onStop");
        super.onStop();
    }

    @Override
    public void onDestroy() {
        Log.i("ChoiceFramgnet","-----------------------------------------------onDestroy");
        super.onDestroy();
    }

    @Override
    protected void onInitData(Bundle bundle) {
        super.onInitData(bundle);
        requestData();
        introRequest();
//        checkUpdate();
    }

    private void requestData() {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.try_listen:
                break;
            case R.id.lesson_begin_info:
                break;
            case R.id.information:
                break;
        }
    }

    @Override
    protected boolean isHideActionbar() {
        return true;
    }

    public void seeVideo(String url){
        Intent intent = new Intent(getActivity(),VideoPlayerActivityy.class);
        intent.putExtra("url",url);
        getActivity().startActivity(intent);
    }
}
