package com.ddlad.student.ui.agora;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.ddlad.student.tools.StringUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.request.LiveInfoRequest;
import com.ddlad.student.protocol.model.ChannelInfo;
import com.ddlad.student.protocol.model.LiveInfo;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.image.PaintView;
import com.ddlad.student.ui.widget.pager.CommonPager;
import com.ddlad.student.ui.widget.voice.MediaPlayerManager;
import com.ddlad.student.ui.widget.voice.SigletonMediaPlayer;

import java.io.IOException;

import io.agora.AgoraAPI;
import io.agora.AgoraAPIOnlySignal;

/**
 * Created by chen007 on 2017/7/10 0010.
 */
public class LiveRoomFragment extends BaseFragment implements MediaPlayer.OnCompletionListener,MediaPlayer.OnErrorListener,MediaPlayer.OnInfoListener,
        MediaPlayer.OnPreparedListener, MediaPlayer.OnSeekCompleteListener,MediaPlayer.OnVideoSizeChangedListener,SurfaceHolder.Callback {

    private int requestLiveInfoId = ViewUtil.generateUniqueId();
    private String mCid;
    private String mLid;

    private Display currDisplay;
    private SurfaceView surfaceView;
    private SurfaceHolder holder;
    private MediaPlayer player;
    private int vWidth,vHeight;
    private boolean isPause = false;
    private String currentVideoURL = "";
    private String currentVoiceURL = "";

    private static final int PERMISSION_REQ_ID_RECORD_AUDIO = 0;
    private static final int PERMISSION_REQ_ID_CAMERA = 1;

    private ViewGroup mTeacherView;
    private ViewGroup mStudentView;
    private ViewGroup mPPTLayout;
    private ViewGroup mGiftLayout;
    private ViewGroup teacher_view;
    private ViewGroup student_view;
    private ViewGroup back_layout;
    private ViewGroup teacher_bg;
    private ViewGroup student_bg;

    private CommonPager mPPTViewPager;
    private PPTPagerAdapter mAdapter;
    private ImageView mApplauseImage;
    private ImageView mStarImage;
    private ImageView mBearImage;
    private ImageView mBalloonImage;
    private ImageView mPlayAnimateImage;
    private PaintView mDrawPicture;

    private int uidTeacher;
    private int uidStudent;
    private int currentReceiveUid;
    private int uidMy;
    private int currentPage;
    private LiveInfo.LiveInfoBean.RoomInfoBean mRoomInfo;
    private LiveInfo.LiveInfoBean.FramesInfoBean mFrameInfo;
    private LiveInfo.LiveInfoBean.RejoinInfoBean mRejoinInfo;

    public static AgoraAPIOnlySignal m_agoraAPI;
    private static String channelName;
    @Override
    protected int getLayoutResource() {
        return R.layout.activity_live_room;
    }

    @Override
    protected void onInitData(Bundle bundle) {
        mCid = bundle.getString("cid");
        mLid = bundle.getString("lid");
    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setVisibility(View.GONE);

        if (m_agoraAPI == null){
            m_agoraAPI = AgoraAPIOnlySignal.getInstance(getActivity(), AppContext.getString(R.string.private_app_id));
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO, PERMISSION_REQ_ID_RECORD_AUDIO)) {
            //如果有录音权限，则再检查摄像头权限
            checkSelfPermission(Manifest.permission.CAMERA, PERMISSION_REQ_ID_CAMERA);
        }
        mTeacherView = (ViewGroup) contentView.findViewById(R.id.teacher_view);
        mStudentView = (ViewGroup) contentView.findViewById(R.id.student_view);
        mPPTLayout = (ViewGroup) contentView.findViewById(R.id.ppt_layout);
        mGiftLayout = (ViewGroup) contentView.findViewById(R.id.gift_layout);
        back_layout = (ViewGroup) contentView.findViewById(R.id.back_layout);
        teacher_bg = (ViewGroup) contentView.findViewById(R.id.teacher_bg);
        student_bg = (ViewGroup) contentView.findViewById(R.id.student_bg);
        mPPTViewPager = (CommonPager) contentView.findViewById(R.id.ppt_picture);
        surfaceView = (SurfaceView)contentView.findViewById(R.id.video_surface);
        mApplauseImage = (ImageView) contentView.findViewById(R.id.appluase_iamge);
        mStarImage = (ImageView) contentView.findViewById(R.id.star_iamge);
        mBalloonImage = (ImageView) contentView.findViewById(R.id.balloon_iamge);
        mBearImage = (ImageView) contentView.findViewById(R.id.bear_iamge);
        mPlayAnimateImage = (ImageView) contentView.findViewById(R.id.play_animate);
        mDrawPicture = (PaintView) contentView.findViewById(R.id.draw_picture);
        AgoraManager.getInstance().setOnPartyListener(mOnPartyListener);
        mAdapter = new PPTPagerAdapter(getActivity());
        mPPTViewPager.setAdapter(mAdapter);
        performRequest();

        holder = surfaceView.getHolder();
        holder.addCallback(this);
        //为了可以播放视频或者使用Camera预览，我们需要指定其Buffer类型
        holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        //下面开始实例化MediaPlayer对象
        player = SigletonMediaPlayer.getMediaPlayer();
        player.setOnCompletionListener(this);
        player.setOnErrorListener(this);
        player.setOnInfoListener(this);
        player.setOnPreparedListener(this);
        player.setOnSeekCompleteListener(this);
        player.setOnVideoSizeChangedListener(this);
        //然后，我们取得当前Display对象
        currDisplay = getActivity().getWindowManager().getDefaultDisplay();

        setPPTLayout();
        setCallBack();

        back_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

    }

    private void setPPTLayout() {
        double teacherViewWidth = (currDisplay.getHeight() - ViewUtil.dpToPx(45))/2;


        FrameLayout.LayoutParams paramsteacher = (FrameLayout.LayoutParams) mTeacherView.getLayoutParams();
        paramsteacher.width = (int) teacherViewWidth;
        mTeacherView.setLayoutParams(paramsteacher);
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        FrameLayout.LayoutParams paramsbg = (FrameLayout.LayoutParams) teacher_bg.getLayoutParams();
        paramsbg.width = (int) teacherViewWidth;
        teacher_bg.setLayoutParams(paramsbg);
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        FrameLayout.LayoutParams paramsStudentbg = (FrameLayout.LayoutParams) student_bg.getLayoutParams();
        paramsStudentbg.width = (int) teacherViewWidth;
        student_bg.setLayoutParams(paramsStudentbg);
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        FrameLayout.LayoutParams paramStudent = (FrameLayout.LayoutParams) mStudentView.getLayoutParams();
        paramStudent.width = (int) teacherViewWidth;
        mStudentView.setLayoutParams(paramStudent);
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        double width = (currDisplay.getHeight() - ViewUtil.dpToPx(135))*1.4;
        double height = (currDisplay.getHeight() - ViewUtil.dpToPx(135));
        RelativeLayout.LayoutParams paramsgift = (RelativeLayout.LayoutParams) mGiftLayout.getLayoutParams();
//        double width = params.height*1.4;
        paramsgift.width = (int) width;
        mGiftLayout.setLayoutParams(paramsgift);
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Log.i("LiveRoomActivity","currDisplay.getWidth()================================================================================"+currDisplay.getWidth());
        Log.i("LiveRoomActivity","currDisplay.getHeight()================================================================================"+currDisplay.getHeight());
        Log.i("LiveRoomActivity","height================================================================================"+height);
        Log.i("LiveRoomActivity","width================================================================================="+width);
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) mPPTLayout.getLayoutParams();
//        double width = params.height*1.4;
        params.height = (int) height;
        params.width = (int) width;
        mPPTLayout.setLayoutParams(params);
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        FrameLayout.LayoutParams paramsSurface = (FrameLayout.LayoutParams) surfaceView.getLayoutParams();
//        double width = params.height*1.4;
        paramsSurface.height = (int) height;
        paramsSurface.width = (int) width;
        surfaceView.setLayoutParams(paramsSurface);

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        RelativeLayout.LayoutParams paramsImage = (RelativeLayout.LayoutParams) mPlayAnimateImage.getLayoutParams();
        paramsImage.topMargin = (int) (teacherViewWidth/2)+30;
        paramsImage.rightMargin = (int) (width/2)-70;
        mPlayAnimateImage.setLayoutParams(paramsImage);
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        mDrawPicture.setViewWidth((float) width);
        mDrawPicture.setViewHeight((float) height);
    }

    private void setCallBack() {
        m_agoraAPI.callbackSet(new AgoraAPI.CallBack() {
            @Override
            public void onLoginSuccess(int uid, int fd) {
                Log.i("sdk2", "login successfully");
//                my_uid = uid;
                m_agoraAPI.channelJoin(channelName);
            }

            @Override
            public void onLoginFailed(int ecode) {
                Log.i("sdk2", "Login failed " + ecode);
            }

            @Override
            public void onLogout(int ecode) {
                if (ecode == m_agoraAPI.ECODE_LOGOUT_E_USER) {
                    Log.i("sdk2","Logout successfully ");
                } else {
                    Log.i("sdk2","Logout on " + ecode);
                }
            }

            @Override
            public void onLog(String txt) {
                //                ActivityLogin.this.log(txt);
                Log.e("sdk2", txt);
            }

            @Override
            public void onChannelJoined(String chanID) {
                Log.i("sdk2","Join channel " + chanID + " successfully"); // + " docall " + doCall);
            }

            @Override
            public void onInviteReceived(String channleID, String account, int uid, String extra) {
                Log.i("sdk2","Received Invitation from " + account + ":" + uid + " to join " + channleID + " extra:"+extra);
                m_agoraAPI.channelInviteAccept(channleID, account, uid);

//                doJoin();
//                set_state_incall();
            }

            @Override
            public void onChannelUserJoined(String account, int uid) {
                Log.i("sdk2",account + ":" + (long) (uid & 0xffffffffl) + " joined");
            }

            @Override
            public void onChannelJoinFailed(String chanID, int ecode) {
                Log.i("sdk2","Join " + chanID + " failed : ecode " + ecode);
            }

            @Override
            public void onMessageChannelReceive(String channelID, String account, int uid, String msg) {
                currentReceiveUid = uid;
                Log.i("sdk2","---------------------------------------------recv channel msg " + channelID + " " + account + " : " + msg);
                ObjectMapper mapper = new ObjectMapper();
                try {
                    final ChannelInfo channelInfo = mapper.readValue(msg, ChannelInfo.class);
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            updateUI(channelInfo);
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String name, int ecode, String desc) {
                Log.i("sdk2","---------------onError ------------------------------name   ecode desc=====" +name+"--"+ + ecode+"--"+desc);
                super.onError(name, ecode, desc);
            }

            @Override
            public void onMessageInstantReceive(String account, int uid, String msg) {
                Log.i("sdk2","---------------------------------------------recv inst msg " + account + " : " + (long) (uid & 0xffffffffl) + " : " + msg);
            }

        });
    }

    private void updateUI(ChannelInfo channelInfo) {
        if (mFrameInfo != null){
            String data = channelInfo.getData();
            String[] page = data.split(",");
            if ("2".equals(channelInfo.getType())){
//                mPPTImage.setUrl(mFrameInfo.getFrames().get(Integer.parseInt(page[0])).getImage().getImageLarge());
                mPPTViewPager.setCurrentItem(Integer.parseInt(page[0]),false);
                currentPage = Integer.parseInt(page[0]);
                currentVoiceURL = "";
                currentVideoURL = "";
                return;
            }
//            3.MP3操作指令     type ：3     data：1播放 2 暂停 3 关闭
            if ("3".equals(channelInfo.getType())){
                refreshVoice(Integer.parseInt(page[0]),mFrameInfo.getFrames().get(currentPage).getChildren().get(0).getAudio());
//                refreshVideo(Integer.parseInt(page[0]),"http://ddlad-vi.oss-cn-beijing.aliyuncs.com/0000000.mp4");
                return;
            }
//            4.MP4操作指令     type ：4     data：1播放 2 暂停 3 关闭
            if ("4".equals(channelInfo.getType())){
                if (mFrameInfo.getFrames().get(currentPage).getChildren().get(0).getVideo() != null){
                    refreshVideo(Integer.parseInt(page[0]),mFrameInfo.getFrames().get(currentPage).getChildren().get(0).getVideo());
                }else {
                    Toaster.toastShort("视频URL为NULL");
                }
//                refreshVideo(Integer.parseInt(page[0]),"http://ddlad-vi.oss-cn-beijing.aliyuncs.com/0000000.mp4");
                return;
            }
//            5.画线操作指令    type：5  data：@“坐标字符串”或者    为-1清除
            if ("5".equals(channelInfo.getType())){
                if ("-1".equals(page[0])){
                    if (uidTeacher == currentReceiveUid){
                        mDrawPicture.getTeacherPoints().clear();
                    }else {
                        mDrawPicture.getStudentPoints().clear();
                    }
                    mDrawPicture.postInvalidate();
                    return;
                }
                if (uidTeacher == currentReceiveUid){
                    mDrawPicture.setPaintColor(Color.parseColor("#25aa1f"));
                    mDrawPicture.getTeacherPoints().add(data);
                }else {
                    mDrawPicture.getStudentPoints().add(data);
                    mDrawPicture.setPaintColor(Color.parseColor("#217aff"));
                }
                mDrawPicture.postInvalidate();
                return;
            }
//            6.礼物指令          type：6  data 1 星星 2 鼓掌 3 气球 4 小熊
            if ("6".equals(channelInfo.getType())){
                showAnimate(Integer.parseInt(page[0]));
                return;
            }
        }

    }

    private void showAnimate(int i) {
        switch (i){
            case 1:
                mStarImage.setSelected(true);
                playAnimate(mStarImage,R.anim.gift_in,1);
                break;
            case 2:
                mApplauseImage.setSelected(true);
                playAnimate(mApplauseImage,R.anim.gift_appluase_in,2);
                break;
            case 3:
                mBalloonImage.setSelected(true);
                playAnimate(mBalloonImage,R.anim.gift_balloon_in,3);
                break;
            case 4:
                mBearImage.setSelected(true);
                playAnimate(mBearImage,R.anim.gift_bear_in,4);
                break;
        }
    }

    private void playAnimate(final ImageView imageView,int id,int i) {
        mPlayAnimateImage.setVisibility(View.VISIBLE);
        mPlayAnimateImage.clearAnimation();
        switch (i){
            case 1:
                playSound("good.mp3");
                mPlayAnimateImage.setImageResource(R.drawable.gift_star);
                break;
            case 2:
                playSound("great.mp3");
                mPlayAnimateImage.setImageResource(R.drawable.gift_applause);
                break;
            case 3:
                playSound("wonderful.mp3");
                mPlayAnimateImage.setImageResource(R.drawable.gift_balloon);
                break;
            case 4:
                playSound("excellent.mp3");
                mPlayAnimateImage.setImageResource(R.drawable.gift_bear);
                break;
        }

        AnimationDrawable drawable = (AnimationDrawable) mPlayAnimateImage.getDrawable();
        drawable.start();

        int[] location = new int[2];
        int[] locationtop = new int[2];
        imageView.getLocationInWindow(location);
        mPlayAnimateImage.getLocationInWindow(locationtop);
        int x = location[0]-locationtop[0];
        int y = location[1]-locationtop[1];
        Log.i("LiveRoomFragment","location -----------------------------x ======="+location[0]);
        Log.i("LiveRoomFragment","location -----------------------------y ======="+location[1]);
        final Animation translateAnimation=new TranslateAnimation(0,x,0,y);
        translateAnimation.setDuration(1000);
        translateAnimation.setFillEnabled(true);
//        translateAnimation.setFillAfter(true);
//        translateAnimation.setFillBefore(false);

        ScaleAnimation scaleAnimation = new ScaleAnimation(1,0.2f,1,0.2f,
                Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
        scaleAnimation.setDuration(1000);
//        scaleAnimation.setFillEnabled(true);
//        scaleAnimation.setFillAfter(true);

//        final TranslateAnimation translatein = (TranslateAnimation) AnimationUtils.loadAnimation(getActivity(),id);
//        translatein.setFillEnabled(true);
//        translatein.setFillAfter(true);
//        translatein.setFillBefore(false);
        final AnimationSet animationSet = new AnimationSet(false);
//        animationSet.addAnimation(translatein);
        animationSet.addAnimation(scaleAnimation);

        animationSet.addAnimation(translateAnimation);
        animationSet.setFillEnabled(true);
        animationSet.setFillAfter(true);


        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                mPlayAnimateImage.clearAnimation();
//                mPlayAnimateImage.startAnimation(translatein);
                mPlayAnimateImage.startAnimation(animationSet);
//                mPlayAnimateImage.startAnimation(translateAnimation);


            }
        },1000);
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                mPlayAnimateImage.clearAnimation();
                mPlayAnimateImage.setVisibility(View.INVISIBLE);
            }
        },2000);

    }

    public void playSound(String name) {
        if (StringUtil.isEmpty(name)){
            return;
        }
        MediaPlayerManager.playRawSound(name, new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                MediaPlayerManager.release();
            }
        });
    }

    private void refreshVoice(int i, String url) {
        switch (i){
            case 1:
                if (!currentVoiceURL.equals(url)){
                    currentVoiceURL = url;
                    //新的url重新播放
                    MediaPlayerManager.playSound(url, new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mp) {
                            MediaPlayerManager.release();
                        }
                    });
                }else {
                    ///继续播放
                   MediaPlayerManager.resume();
                }
                break;
            case 2:
                MediaPlayerManager.pause();
                break;
            case 3:
                MediaPlayerManager.release();
                break;
        }

    }

    private void refreshVideo(int i,String url) {
        switch (i){
            case 1:
                surfaceView.setVisibility(View.VISIBLE);
                if (!currentVideoURL.equals(url)){
                    currentVideoURL = url;
                    //新的url重新播放
                    try {
                        player.setDataSource(url);
//                        player.setDataSource("http://ddlad-vi.oss-cn-beijing.aliyuncs.com/0000000.mp4");
                        player.prepareAsync();
                        android.util.Log.v("Next:::", "surfaceDestroyed called");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }else {
                    ///继续播放
                    player.start();
                }
                break;
            case 2:
                surfaceView.setVisibility(View.VISIBLE);
                if (player != null && player.isPlaying()) { //正在播放的时候
                    player.pause();
                    isPause = true;
                }
                break;
            case 3:
                surfaceView.setVisibility(View.GONE);
                if (player != null) {
                    player.release();
                }
                break;
        }



    }

    private void performRequest() {
        LiveInfoRequest request = new LiveInfoRequest(this, requestLiveInfoId, new AbstractCallbacks<LiveInfo>() {
            @Override
            protected void onSuccess(LiveInfo liveInfo) {
//                AgoraManager.getInstance().setupLocalVideo(getActivity(),mTeacherView,mStudentView,uidTeacher,uidStudent);
                LiveInfo.LiveInfoBean.RoomInfoBean bean = liveInfo.getLiveInfo().getRoomInfo();
                mRoomInfo = bean;
                mFrameInfo = liveInfo.getLiveInfo().getFramesInfo();
                mRejoinInfo = liveInfo.getLiveInfo().getRejoinInfo();
                uidTeacher = bean.getTeacherAccount();
                uidStudent = bean.getStudentAccount();
                mAdapter.setData(mFrameInfo.getFrames());
                mAdapter.notifyDataSetChanged();
                AgoraManager.getInstance().setupLocalVideo(getActivity(),bean.getTeacherAccount(),bean.getStudentAccount(), bean.getAccount(),bean.getChannelKey());

                AgoraManager.getInstance().joinChannel(liveInfo.getLiveInfo().getRoomInfo().getChannelName()).startPreview();

                channelName = liveInfo.getLiveInfo().getRoomInfo().getChannelName();
                Log.i("LiveRoomFragment","==============================channelName"+channelName);
                String key = liveInfo.getLiveInfo().getRoomInfo().getSignalingKey();
                long account = liveInfo.getLiveInfo().getRoomInfo().getAccount();
                m_agoraAPI.login(AppContext.getString(R.string.private_app_id),account+"" , key, 0, "");
                if (mRejoinInfo != null){
                    mPPTViewPager.setCurrentItem(mRejoinInfo.getCurrentFrameX());
                    currentPage = mRejoinInfo.getCurrentFrameX();
                }

            }
        });
        request.perform(mCid,mLid);
    }


    private AgoraManager.OnPartyListener mOnPartyListener = new AgoraManager.OnPartyListener() {
        @Override
        public void onJoinChannelSuccess(String channel, final int uid) {
            uidMy = uid;
            AgoraManager.getInstance().setRemoteRenderMode(uid);
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    AgoraManager.getInstance().setupRemoteVideo(getActivity(), uidTeacher);
                    AgoraManager.getInstance().setupRemoteVideo(getActivity(), uidStudent);

                    mTeacherView.addView(AgoraManager.getInstance().getSurfaceView(uidTeacher));
                    mStudentView.addView(AgoraManager.getInstance().getSurfaceView(uidStudent));
                }
            });

        }

        @Override
        public void onGetRemoteVideo(final int uid) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    //注意SurfaceView要创建在主线程
//                    AgoraManager.getInstance().setupRemoteVideo(getActivity(), uid);
//                    mPartyRoomLayout.addView(AgoraManager.getInstance().getSurfaceView(uid));
                }
            });

        }

        @Override
        public void onLeaveChannelSuccess() {
            getActivity().finish();
        }

        @Override
        public void onUserOffline(final int uid) {

            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    AgoraManager.getInstance().removeSurfaceView(uidTeacher);
                    AgoraManager.getInstance().removeSurfaceView(uidStudent);

                }
            });
        }

        @Override
        public void onFirstRemoteVideoFrame(int uid) {

        }
    };

    @Override
    public void onDestroy() {
        m_agoraAPI.logout();
        super.onDestroy();
    }

    public static void channelLeave(){
        m_agoraAPI.channelLeave(channelName);
    }






    @Override
    public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
        // 当Surface尺寸等参数改变时触发
        android.util.Log.v("Surface Change:::", "surfaceChanged called");
    }
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        // 当SurfaceView中的Surface被创建的时候被调用
        //在这里我们指定MediaPlayer在当前的Surface中进行播放
        player.setDisplay(holder);
        //在指定了MediaPlayer播放的容器后，我们就可以使用prepare或者prepareAsync来准备播放了
//        player.prepareAsync();

    }
    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {

        android.util.Log.v("Surface Destory:::", "surfaceDestroyed called");
    }
    @Override
    public void onVideoSizeChanged(MediaPlayer arg0, int arg1, int arg2) {
        // 当video大小改变时触发
        //这个方法在设置player的source后至少触发一次
        android.util.Log.v("Video Size Change", "onVideoSizeChanged called");

    }
    @Override
    public void onSeekComplete(MediaPlayer arg0) {
        // seek操作完成时触发
        android.util.Log.v("Seek Completion", "onSeekComplete called");

    }
    @Override
    public void onPrepared(MediaPlayer player) {
        // 当prepare完成后，该方法触发，在这里我们播放视频

        //首先取得video的宽和高
        vWidth = player.getVideoWidth();
        vHeight = player.getVideoHeight();

        com.ddlad.student.primary.Log.i("PlayVadioActivity","---------------------------------vWidth"+vWidth);
        com.ddlad.student.primary.Log.i("PlayVadioActivity","---------------------------------vHeight"+vHeight);
        com.ddlad.student.primary.Log.i("PlayVadioActivity","---------------------------------currDisplay.getWidth()"+currDisplay.getWidth());
        com.ddlad.student.primary.Log.i("PlayVadioActivity","---------------------------------currDisplay.getHeight()"+currDisplay.getHeight());

        if(vWidth > currDisplay.getHeight() || vHeight > currDisplay.getWidth()){
            //如果video的宽或者高超出了当前屏幕的大小，则要进行缩放
            float wRatio = (float)vWidth/(float)currDisplay.getWidth();
            float hRatio = (float)vHeight/(float)currDisplay.getHeight();

            //选择大的一个进行缩放
            float ratio = Math.max(wRatio, hRatio);

            vWidth = (int)Math.ceil((float)vWidth/ratio);
            vHeight = (int)Math.ceil((float)vHeight/ratio);

            //设置surfaceView的布局参数
            surfaceView.setLayoutParams(new LinearLayout.LayoutParams(vWidth, vHeight));

            //然后开始播放视频

            player.start();
        }else {
            player.start();
        }
    }
    @Override
    public boolean onInfo(MediaPlayer player, int whatInfo, int extra) {
        // 当一些特定信息出现或者警告时触发
        switch(whatInfo){
            case MediaPlayer.MEDIA_INFO_BAD_INTERLEAVING:
                break;
            case MediaPlayer.MEDIA_INFO_METADATA_UPDATE:
                break;
            case MediaPlayer.MEDIA_INFO_VIDEO_TRACK_LAGGING:
                break;
            case MediaPlayer.MEDIA_INFO_NOT_SEEKABLE:
                break;
        }
        return false;
    }
    @Override
    public boolean onError(MediaPlayer player, int whatError, int extra) {
        android.util.Log.v("Play Error:::", "onError called");
        switch (whatError) {
            case MediaPlayer.MEDIA_ERROR_SERVER_DIED:
                android.util.Log.v("Play Error:::", "MEDIA_ERROR_SERVER_DIED");
                break;
            case MediaPlayer.MEDIA_ERROR_UNKNOWN:
                android.util.Log.v("Play Error:::", "MEDIA_ERROR_UNKNOWN");
                break;
            default:
                break;
        }
        return false;
    }
    @Override
    public void onCompletion(MediaPlayer player) {
        // 当MediaPlayer播放完成后触发
        android.util.Log.v("Play Over:::", "onComletion called");
        player.release();
    }

    @Override
    public void onPause() {
//        if (player != null && player.isPlaying()) { //正在播放的时候
//            player.pause();
//            isPause = true;
//        }
        super.onPause();
    }

    @Override
    public void onResume() {
//        if (player != null && isPause) {
//            player.start();
//            isPause = false;
//        }
        super.onResume();
    }


    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {

        switch (requestCode) {
            case PERMISSION_REQ_ID_RECORD_AUDIO: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    checkSelfPermission(Manifest.permission.CAMERA, PERMISSION_REQ_ID_CAMERA);
                } else {
                    Toaster.toastShort("权限被拒绝");
                    onBackPressed();
                }
                break;
            }
            case PERMISSION_REQ_ID_CAMERA: {
                if (grantResults.length > 0 && grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                    Toaster.toastShort("权限被拒绝");
                    onBackPressed();
                }
                break;
            }
        }
    }

    public boolean checkSelfPermission(String permission, int requestCode) {
        if (ContextCompat.checkSelfPermission(getActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
            //如果没有权限，则申请
            ActivityCompat.requestPermissions(getActivity(), new String[]{permission}, requestCode);
            return false;
        }
        return true;
    }
}
