package com.ddlad.student.ui.agora;

import android.app.Activity;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.ddlad.student.protocol.model.LiveInfo;
import com.ddlad.student.ui.widget.image.NetworkImageView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by chen007 on 2017/7/12 0012.
 */
public class PPTPagerAdapter extends PagerAdapter {
    protected Activity mActivity;

    protected List<LiveInfo.LiveInfoBean.FramesInfoBean.FramesBean> mList = new ArrayList<>();

    public PPTPagerAdapter(Activity activity) {
        mActivity = activity;
    }

    public PPTPagerAdapter(Activity activity, List<LiveInfo.LiveInfoBean.FramesInfoBean.FramesBean> list) {
        mActivity = activity;
        mList = list;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public void finishUpdate(View arg0) {
    }

    @Override
    public int getCount() {

        if (mList != null) {
            return mList.size();
        }

        return 0;
    }

    public void setData(List<LiveInfo.LiveInfoBean.FramesInfoBean.FramesBean> list) {
        mList = list;
    }

    @Override
    public Object instantiateItem(ViewGroup viewGroup, final int position) {

        final LiveInfo.LiveInfoBean.FramesInfoBean.FramesBean banner = mList.get(position);

        NetworkImageView image = new NetworkImageView(viewGroup.getContext());
        image.setScaleType(ImageView.ScaleType.FIT_XY);
        image.setUrl(banner.getImage().getImageLarge());
        ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        viewGroup.addView(image, lp);
        return image;
    }

    @Override
    public boolean isViewFromObject(View arg0, Object arg1) {
        return (arg0 == arg1);
    }

    @Override
    public void restoreState(Parcelable arg0, ClassLoader arg1) {

    }

    @Override
    public Parcelable saveState() {
        return null;
    }

    @Override
    public void startUpdate(View arg0) {

    }
}
