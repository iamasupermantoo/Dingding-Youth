package com.ddlad.student.ui.attendclass.schedule;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.request.CoursePointRequest;
import com.ddlad.student.protocol.http.request.LScheduleCourseListRequest;
import com.ddlad.student.protocol.model.SchedulePointsInfo;
import com.ddlad.student.tools.DateUtils;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.calendar.calendarview.CalendarUtils;
import com.ddlad.student.ui.classtable.ClassTableView;
import com.ddlad.student.ui.classtable.DateChangeListener;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.request.BaseListRequest;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.ScheduleCourseInfo;
import com.ddlad.student.ui.common.AbstractAdapter;

import java.util.Calendar;

/**
 * A simple {@link Fragment} subclass.
 */
public class LScheduleFragment extends BaseListFragment<ScheduleCourseInfo> implements DateChangeListener {

    protected int mGeneratedLoaderId = ViewUtil.generateUniqueId();
    protected int mCourseLoaderId = ViewUtil.generateUniqueId();
    private Calendar mCalendar = Calendar.getInstance();
    private ClassTableView mClassTableView;
    //    private ClassTable mClassTable;
    private TextView mDate;
    private TextView mLeft;
    private TextView mRight;
    private CoursePointRequest pointRequest;
//    private ScheduleAdapter scheduleAdapter;
//    private ListView mScheduleListView;

    private String mCid;

    private boolean mAdapterCreate = false;
    @Override
    protected int getLayoutResource() {
        return R.layout.l_fragment_schedule;
    }

//    @Override
//    protected int getHeaderResource() {
//        return R.layout.layout_schedule_header;
//    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.hideEvaluateTitle();
        mActionbar.setTitle(R.string.school_timetable);
//        mScheduleListView = (ListView) contentView.findViewById(R.id.schedule_list);
//        View view = LayoutInflater.from(getActivity()).inflate(R.layout.layout_schedule_header,null);
//        scheduleAdapter = new ScheduleAdapter(getActivity());
//        mScheduleListView.addHeaderView(view);
//        mScheduleListView.setAdapter(scheduleAdapter);
//        mDate = (TextView) view.findViewById(R.id.schedule_date);
//        mDate.setText(formatTitle());
//        mLeft = (TextView) view.findViewById(R.id.schedule_left);
//        mLeft.setOnClickListener(this);
//        mRight = (TextView) view.findViewById(R.id.schedule_right);
//        mRight.setOnClickListener(this);
//
//        mClassTableView = (ClassTableView) view.findViewById(R.id.class_table);
////        mClassTableView.setFragment(this);
//        mClassTableView.setToday();
//        mClassTableView.setDateChangeListener(this);
//
//
//        selectToday();
//        getCourseData(DateUtils.formattedDate(mCalendar));
    }

    @Override
    protected void onInitData(Bundle bundle) {
        super.onInitData(bundle);
        mCid = bundle.getString("cid");
        mCalendar.setTimeInMillis(System.currentTimeMillis());
    }

//    @Override
//    protected void onInitHeader(View header) {
//
//    }

    private String formatTitle() {
        String title = String.valueOf(mCalendar.get(Calendar.YEAR)) + "-"
                + String.valueOf(mCalendar.get(Calendar.MONTH) + 1);
        return title;
    }

    private void selectToday() {
        long current = System.currentTimeMillis();
        Calendar today = Calendar.getInstance();
        today.setTimeInMillis(current);
        onDateChanged(today);
        fetchData();
        mClassTableView.selectToday();
    }
    @Override
    protected boolean isNeedFetch() {
        return true;
    }

    @Override
    protected BaseListRequest makeRequest(AbstractStreamingCallbacks<AbstractListResponse<ScheduleCourseInfo>> streamingApiCallbacks) {
        return new LScheduleCourseListRequest(this, mCourseLoaderId, streamingApiCallbacks);
    }

    @Override
    protected void performRequest() {
        ((LScheduleCourseListRequest)mDefaultRequest).perform(DateUtils.formattedDate(mCalendar));
        fetchData();
    }

    @Override
    protected AbstractAdapter getAdapter() {
        if (mAdapter == null) {
            mAdapter = new LScheduleListAdapter(this);
        }
        return mAdapter;
    }

    @Override
    protected int getHeaderResource() {
        return R.layout.layout_schedule_header;
    }

    @Override
    protected void onInitHeader(View view) {
        mDate = (TextView) view.findViewById(R.id.schedule_date);
        mDate.setText(formatTitle());
        mLeft = (TextView) view.findViewById(R.id.schedule_left);
        mLeft.setOnClickListener(this);
        mRight = (TextView) view.findViewById(R.id.schedule_right);
        mRight.setOnClickListener(this);

        mClassTableView = (ClassTableView) view.findViewById(R.id.class_table);
        mClassTableView.setFragment(this);
        mClassTableView.setToday();
        mClassTableView.setDateChangeListener(this);


        selectToday();
        super.onInitHeader(view);
    }

    @Override
    protected void fetchData() {
        pointRequest = new CoursePointRequest(this, mGeneratedLoaderId, new AbstractCallbacks<SchedulePointsInfo>() {
            @Override
            protected void onSuccess(SchedulePointsInfo info) {
                updateClassTableView(info);
            }
        });
        pointRequest.perform(formatTitle(),mCid);
    }

    private void updateClassTableView(SchedulePointsInfo info) {
        if (info == null) {
            return;
        }
        mClassTableView.setDotedDays(info.getDays());
        mClassTableView.update(mCalendar);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.schedule_left:
                previousMonth();
                break;
            case R.id.schedule_right:
                nextMonth();
                break;
        }
    }
    public void previousMonth() {
        mClassTableView.past();
        onMonthChanged(mClassTableView.getMonth());
    }

    public void nextMonth() {
        mClassTableView.future();
        onMonthChanged(mClassTableView.getMonth());
    }

    @Override
    public void onMonthChanged(Calendar date) {
        mCalendar.set(Calendar.YEAR, date.get(Calendar.YEAR));
        mCalendar.set(Calendar.MONTH, date.get(Calendar.MONTH));
        mCalendar.set(Calendar.DAY_OF_MONTH, date.get(Calendar.DAY_OF_MONTH));
        mDate.setText(formatTitle());
        fetchData();
    }

    @Override
    public void onDateChanged(Calendar date) {
        boolean isDifferentYear = mCalendar.get(Calendar.YEAR) != date.get(Calendar.YEAR);
        boolean isDifferentMonth = mCalendar.get(Calendar.MONTH) != date.get(Calendar.MONTH);
        boolean isDifferentDay = mCalendar.get(Calendar.DAY_OF_MONTH) != date
                .get(Calendar.DAY_OF_MONTH);
        if (isDifferentYear || isDifferentMonth || isDifferentDay) {
            CalendarUtils.copyDateTo(date, mCalendar);
            mDate.setText(formatTitle());
//            handleRequest(true);
            ((LScheduleCourseListRequest)mDefaultRequest).perform(DateUtils.formattedDate(mCalendar));
        }
    }

}
