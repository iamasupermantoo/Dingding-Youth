package com.ddlad.student.push;

import android.content.Context;
import android.content.Intent;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.text.TextUtils;

import com.ddlad.student.primary.Prefs;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.service.WorkerService;
import com.ddlad.student.push.PushClient;


public class PushClientGetui implements PushClient {

    @Override
    public void bindPush() {

        Context context = AppContext.getContext();
        String pushCid = Prefs.getInstance().getGetuiPushCid();

        if (Log.DEBUG) {
            Log.d(getClass().getSimpleName(), "bindPush pushCid=" + pushCid);
        }

        if (!TextUtils.isEmpty(pushCid)) {
            Intent intent = new Intent(context, WorkerService.class);
            intent.putExtra(ProtocolConstants.PARAM_PUSH_TOKEN, pushCid);
            intent.putExtra(ProtocolConstants.PARAM_TYPE, WorkerService.BIND_GETUI_PUSH);
            WakefulBroadcastReceiver.startWakefulService(context, intent);
        }
    }

    @Override
    public void unbindPush() {
        Prefs.getInstance().clearGetuiPushCid();
    }
}
