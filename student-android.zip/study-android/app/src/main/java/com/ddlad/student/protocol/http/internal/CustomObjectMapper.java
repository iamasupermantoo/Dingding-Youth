package com.ddlad.student.protocol.http.internal;

import android.content.Context;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.ddlad.student.primary.AppContext;

import java.util.ArrayList;

public class CustomObjectMapper extends ObjectMapper {

    /**
     *
     */
    private static final long serialVersionUID = 2957366914657966630L;

    public static final String TAG = "CustomObjectMapper";

    public static final String CUSTOM_OBJECT_MAPPER = "com.udan.customObjectMapper";

    public CustomObjectMapper(Context context) {

        configure(MapperFeature.AUTO_DETECT_FIELDS, Boolean.FALSE);
        configure(MapperFeature.AUTO_DETECT_SETTERS, Boolean.FALSE);
        configure(MapperFeature.USE_ANNOTATIONS, Boolean.FALSE);
        configure(MapperFeature.AUTO_DETECT_CREATORS, Boolean.FALSE);
        configure(MapperFeature.USE_GETTERS_AS_SETTERS, Boolean.FALSE);
        configure(MapperFeature.CAN_OVERRIDE_ACCESS_MODIFIERS, Boolean.FALSE);
        configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, Boolean.FALSE);
        configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, Boolean.TRUE);

        SimpleModule simpleModule = new SimpleModule("JsonModule", new Version(1, 0, 0, null));
        registerModule(simpleModule);
    }

    public static CustomObjectMapper getInstance() {

        CustomObjectMapper customObjectMapper = (CustomObjectMapper) AppContext.getContext()
                .getSystemService(CUSTOM_OBJECT_MAPPER);

        if (customObjectMapper == null) {
            customObjectMapper = (CustomObjectMapper) AppContext.getContext().getSystemService(
                    CUSTOM_OBJECT_MAPPER);
        }

        if (customObjectMapper == null) {
            throw new IllegalStateException("CustomObjectMapper not available");
        }

        return customObjectMapper;
    }

    @SuppressWarnings("unchecked")
    public <T> ArrayList<T> readArrayList(JsonNode jsonNode, Class<T> clazz) {
        CollectionType collectionType = getTypeFactory().constructCollectionType(ArrayList.class,
                clazz);
        try {
            return (ArrayList<T>) super.readValue(super.treeAsTokens(jsonNode), collectionType);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
