package com.ddlad.student.ui.common;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.R;
import com.ddlad.student.protocol.model.BaseInfo;
import com.ddlad.student.tools.CollectionUtil;

import java.util.List;

public class BaseMultiItemAdapter {

    public static void bindView(final int position, final BaseFragment fragment, View view, final List<BaseInfo> list) {

        if (CollectionUtil.isEmpty(list)) {
            return;
        }

        BaseMultiItemAdapter.ViewHolder holder = (BaseMultiItemAdapter.ViewHolder) view.getTag();

        if (holder == null) {
            return;
        }

    }

    public static View createView(ViewGroup viewGroup) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.layout_item_base,
                null);

        BaseMultiItemAdapter.ViewHolder holder = new BaseMultiItemAdapter.ViewHolder();

        holder.mItem[0] = (ViewGroup) view.findViewById(R.id.item1);
        holder.mItem[1] = (ViewGroup) view.findViewById(R.id.item2);

        view.setTag(holder);

        return view;
    }

    private static class ViewHolder {
        public ViewGroup[] mItem = new ViewGroup[BaseRowViewHolder.NUM_IMAGES_PER_ROW];
    }

}
