package com.ddlad.student.ui.common;

import com.ddlad.student.protocol.model.BaseInfo;
import com.ddlad.student.ui.model.RowInfo;

import java.util.List;

public abstract class AbstractRowAdapter<T extends BaseInfo> extends AbstractAdapter<T> {

    protected List<RowInfo<T>> mRows;

    public AbstractRowAdapter(BaseFragment fragment) {
        super(fragment);
    }

    public int getListCount() {
        return super.getCount();
    }

    public int getRowCount() {
        return mRows.size();
    }

    @Override
    public int getCount() {
        return getRowCount();
    }

    public abstract T getListItem(int position);

}
