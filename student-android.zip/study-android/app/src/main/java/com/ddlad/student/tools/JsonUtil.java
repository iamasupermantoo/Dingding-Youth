package com.ddlad.student.tools;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * Created by Albert
 * on 16-6-2.
 */
public class JsonUtil {

    public static boolean exists(JsonNode jsonNode, String fieldName) {
        if (jsonNode.has(fieldName) && !jsonNode.get(fieldName).isNull()) {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    public static int asInt(JsonNode jsonNode, String fieldName) {
        if (exists(jsonNode, fieldName)) {
            return jsonNode.get(fieldName).asInt();
        }
        return 0;
    }

    public static long asLong(JsonNode jsonNode, String fieldName) {
        if (exists(jsonNode, fieldName)) {
            return jsonNode.get(fieldName).asLong();
        }
        return 0;
    }

    public static String asText(JsonNode jsonNode, String fieldName) {
        if (exists(jsonNode, fieldName)) {
            return jsonNode.get(fieldName).asText();
        }
        return null;
    }

    public static boolean asBoolean(JsonNode jsonNode, String fieldName) {
        if (exists(jsonNode, fieldName)) {
            return jsonNode.get(fieldName).asBoolean();
        }
        return Boolean.FALSE;
    }
}
