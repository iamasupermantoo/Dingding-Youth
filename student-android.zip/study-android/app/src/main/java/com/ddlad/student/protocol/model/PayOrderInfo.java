package com.ddlad.student.protocol.model;

/**
 * Created by chenjianing on 2017/4/18 0018.
 */
public class PayOrderInfo {
        /**
         * product : 系统解剖学
         * totalPrice : 10000
         */

        private InfoBean info;

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public static class InfoBean {
            private String product;
            private int totalPrice;

            public String getProduct() {
                return product;
            }

            public void setProduct(String product) {
                this.product = product;
            }

            public int getTotalPrice() {
                return totalPrice;
            }

            public void setTotalPrice(int totalPrice) {
                this.totalPrice = totalPrice;
            }
        }

}
