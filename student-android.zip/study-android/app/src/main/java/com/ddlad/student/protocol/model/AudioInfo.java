package com.ddlad.student.protocol.model;

/**
 * Created by chenjianing on 2017/5/13 0013.
 */
public class AudioInfo extends BaseInfo {

        /**
         * time : 05-13 17:23
         * audioLength : 5
         * audio : http://au.z.ziduan.com/wcq7w1cMTPs9RzEFBVF2BQ.wma
         * id : g89lewa7STk9RzEFBVF2BQ
         * type : 2
         */

        private AnswerBean answer;

        public AnswerBean getAnswer() {
            return answer;
        }

        public void setAnswer(AnswerBean answer) {
            this.answer = answer;
        }

        public static class AnswerBean {
            private String time;
            private int audioLength;
            private String audio;
            private String id;
            private int type;

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public int getAudioLength() {
                return audioLength;
            }

            public void setAudioLength(int audioLength) {
                this.audioLength = audioLength;
            }

            public String getAudio() {
                return audio;
            }

            public void setAudio(String audio) {
                this.audio = audio;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }
        }
}
