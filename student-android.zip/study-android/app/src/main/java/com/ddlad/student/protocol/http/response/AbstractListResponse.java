package com.ddlad.student.protocol.http.response;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.model.LHomeWorkDetailInfo;
import com.ddlad.student.protocol.model.LessonInfo;
import com.ddlad.student.tools.CollectionUtil;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public abstract class AbstractListResponse<T> {

    protected LooseListResponse<T> mLooseListResponse;

    protected long mTimestamp;

    protected boolean hasBlockAuth;

    protected boolean allowShare;

    protected int waitCommit;

    public boolean isAllowShare() {
        return allowShare;
    }

    public void setAllowShare(boolean allowShare) {
        this.allowShare = allowShare;
    }

    public int getWaitCommit() {
        return waitCommit;
    }

    public void setWaitCommit(int waitCommit) {
        this.waitCommit = waitCommit;
    }

    public LHomeWorkDetailInfo getmHomeWorkDetail() {
        return mHomeWorkDetail;
    }

    public void setmHomeWorkDetail(LHomeWorkDetailInfo mHomeWorkDetail) {
        this.mHomeWorkDetail = mHomeWorkDetail;
    }

    protected LHomeWorkDetailInfo mHomeWorkDetail;

    public LessonInfo getmLessonInfo() {
        return mLessonInfo;
    }

    public void setmLessonInfo(LessonInfo mLessonInfo) {
        this.mLessonInfo = mLessonInfo;
    }

    protected LessonInfo mLessonInfo;

    public boolean isHasBlockAuth() {
        return hasBlockAuth;
    }

    public void setHasBlockAuth(boolean hasBlockAuth) {
        this.hasBlockAuth = hasBlockAuth;
    }

    public LooseListResponse<T> getLooseListResponse() {
        return mLooseListResponse;
    }

    public void setLooseListResponse(LooseListResponse<T> looseListResponse) {
        this.mLooseListResponse = looseListResponse;
    }

    public long getTimestamp() {
        return mTimestamp;
    }

    public void setTimestamp(long timestamp) {
        this.mTimestamp = timestamp;
    }

    public abstract T getModelInfo(JsonParser jsonParser);

    public void initModelInfo(T t) {

    }

    public boolean hasData() {
        return mLooseListResponse != null && !CollectionUtil.isEmpty(mLooseListResponse.getList());
    }

    public List<T> getData() {
        return mLooseListResponse.getList();
    }


    public void parse(JsonParser jsonParser, String listFieldKey) throws IOException {

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            jsonParser.nextToken();

            while ((jsonParser.nextToken()) != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (listFieldKey.equals(fieldName)
                        && jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {
                    jsonParser.nextToken();
                    fromJsonParser(jsonParser);
                    continue;
                }

                if (ProtocolConstants.JSON_FIELD_TIMESTAMP.equals(fieldName)) {
                    jsonParser.nextToken();
                    mTimestamp = jsonParser.getLongValue();
                    continue;
                }

                if (ProtocolConstants.JSON_FIELD_BLOCK_AUTH.equals(fieldName)) {
                    jsonParser.nextToken();
                    hasBlockAuth = jsonParser.getBooleanValue();
                    continue;
                }

                if ("waitCommit".equals(fieldName)) {
                    jsonParser.nextToken();
                    waitCommit = jsonParser.getIntValue();
                    continue;
                }
                if ("allowShare".equals(fieldName)) {
                    jsonParser.nextToken();
                    allowShare = jsonParser.getBooleanValue();
                    continue;
                }

                if ("answers".equals(fieldName)) {
                    jsonParser.nextToken();
                    if (mLooseListResponse == null) {
                        mLooseListResponse = new com.ddlad.student.protocol.http.response.LooseListResponse<>();
                    }

                    ArrayList<T> list = new ArrayList<>();
                    while (jsonParser.nextToken() != JsonToken.END_ARRAY) {
                            T t = getModelInfo(jsonParser);
                            if (t != null) {
                                initModelInfo(t);
                                list.add(t);
                            }
                            continue;
                        }
                    mLooseListResponse.setList(list);
                    continue;
                }
                if ("details".equals(fieldName)){
                    jsonParser.nextToken();
                    mHomeWorkDetail = LHomeWorkDetailInfo.fromJsonParser(jsonParser);
                    continue;
                }
                if ("lesson".equals(fieldName)){
                    jsonParser.nextToken();
                    mLessonInfo = LessonInfo.fromJsonParser(jsonParser);
                    continue;
                }

                extraJsonParser(jsonParser, fieldName);

                jsonParser.skipChildren();
            }
        }
    }

    public void extraJsonParser(JsonParser jsonParser, String fieldName) throws IOException {
        //  预留着，子类新增加key 可以直接解析
    }

    public void parseCache(JsonParser jsonParser, String fieldKey) throws JsonParseException,
            IOException {

        while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

            String fieldName = jsonParser.getCurrentName();

            if (fieldName == null) {
                continue;
            }
            if (ProtocolConstants.JSON_FIELD_DATA.equals(fieldName)) {
                parse(jsonParser, fieldKey);
            }

            jsonParser.skipChildren();
        }
    }

    protected void fromJsonParser(JsonParser jsonParser) throws IOException {

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            if (mLooseListResponse == null) {
                mLooseListResponse = new com.ddlad.student.protocol.http.response.LooseListResponse<>();
            }

            ArrayList<T> list = new ArrayList<>();

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }
                if (ProtocolConstants.JSON_FIELD_LIST.equals(fieldName)) {
                    jsonParser.nextToken();

                    while (jsonParser.nextToken() != JsonToken.END_ARRAY) {
                        T t = getModelInfo(jsonParser);
                        if (t != null) {
                            initModelInfo(t);
                            list.add(t);
                        }
                        continue;
                    }
                    mLooseListResponse.setList(list);
                }
//表示下一页的cursor
                if (ProtocolConstants.JSON_FIELD_NEXT_CURSOR.equals(fieldName)) {
                    if (jsonParser.nextToken() != JsonToken.VALUE_NULL) {
                        mLooseListResponse.setNextCursorId(jsonParser.getText());
                    }

                    continue;
                }
//表示是不是底部还有下一页
                if (ProtocolConstants.JSON_FIELD_HAS_NEXT.equals(fieldName)) {
                    jsonParser.nextToken();
                    mLooseListResponse.setHasMore(jsonParser.getBooleanValue());
                    continue;
                }

                jsonParser.skipChildren();
            }

            mLooseListResponse.setList(list);
        }
    }

}
