package com.ddlad.student.protocol.model;

/**
 * Created by chen007 on 2017/5/27 0027.
 */
public class CourseDetailInfo extends BaseInfo {

        /**
         * level : 2
         * totalCnt : 90
         * price : 1000
         * cmId : sh27hheflsE9RzEFBVF2BQ
         * desc : 托福是由美国教育测验服务社（ETS）举办的英语能力考试，全名为“检定非英语为母语者的英语能力考试”，中文音译为“托福”。TOEFL有三种，分别是： pbt—paper based test 纸考 677, cbt—computer based test 机考 300, ibt—internet based test 网考 120, 新托福满分是120分。TOEFL考试的有效期为两年，是从考试日期开始计算的。例如：2003年1月18日参加考试，这次考试成绩的有效期是从2003年1月18日到2005年1月18日。托福复习主要资料为托福机经又称民间托福答案题库。
         * image : {"width":200,"height":200,"pattern":"http://img.z.ziduan.com/TZPQRqqGOyU9RzEFBVF2BQ.png@{w}w_{h}h_75q","id":"TZPQRqqGOyU9RzEFBVF2BQ"}
         * name : 托福
         */

        private CourseBean course;

        public CourseBean getCourse() {
            return course;
        }

        public void setCourse(CourseBean course) {
            this.course = course;
        }

        public static class CourseBean {
            private int level;
            private int totalCnt;
            private String price;
            private String cmId;
            private String desc;
            /**
             * width : 200
             * height : 200
             * pattern : http://img.z.ziduan.com/TZPQRqqGOyU9RzEFBVF2BQ.png@{w}w_{h}h_75q
             * id : TZPQRqqGOyU9RzEFBVF2BQ
             */

            private ImageBean image;
            private String name;

            public int getLevel() {
                return level;
            }

            public void setLevel(int level) {
                this.level = level;
            }

            public int getTotalCnt() {
                return totalCnt;
            }

            public void setTotalCnt(int totalCnt) {
                this.totalCnt = totalCnt;
            }

            public String getPrice() {
                return price;
            }

            public void setPrice(String price) {
                this.price = price;
            }

            public String getCmId() {
                return cmId;
            }

            public void setCmId(String cmId) {
                this.cmId = cmId;
            }

            public String getDesc() {
                return desc;
            }

            public void setDesc(String desc) {
                this.desc = desc;
            }

            public ImageBean getImage() {
                return image;
            }

            public void setImage(ImageBean image) {
                this.image = image;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public static class ImageBean {
                private int width;
                private int height;
                private String pattern;
                private String id;

                public int getWidth() {
                    return width;
                }

                public void setWidth(int width) {
                    this.width = width;
                }

                public int getHeight() {
                    return height;
                }

                public void setHeight(int height) {
                    this.height = height;
                }

                public String getPattern() {
                    return pattern;
                }

                public void setPattern(String pattern) {
                    this.pattern = pattern;
                }

                public String getId() {
                    return id;
                }

                public void setId(String id) {
                    this.id = id;
                }
            }
        }
}
