package com.ddlad.student.protocol.http.request;




import android.util.Log;

import com.ddlad.student.protocol.convert.DataCenter;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.Account;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.protocol.http.internal.ApiResponse;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-10-13.
 */
public class AccountRequest extends AbstractRequest<Account> {

    private static final String TAG = "AccountRequest";

    public AccountRequest(BaseFragment fragment, int loaderId,
                          AbstractCallbacks<Account> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url,
                                          RequestParams requestParams) {
        return httpClient.getRequest(url, requestParams);
    }



    protected String getFieldKey() {
        return ProtocolConstants.JSON_FIELD_PROFILE;
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_PROFILE;
    }

    //getFieldKey(),
    @Override
    public Account processInBackground(ApiResponse<Account> response) {
        Account account = response.readRootValue(ProtocolConstants.JSON_FIELD_DATA,
                getFieldKey(),Account.class);
        if (account != null) {
            Log.i(TAG, "saveProfile:account.getUser().getName() "+account.getUser().getName());
            Log.i(TAG, "saveProfile:account.getUser().getGrade() "+account.getUser().getGrade());
            Log.i(TAG, "saveProfile:account.getUser().getProvince() "+account.getUser().getProvince());
            DataCenter.saveProfile(account);
        }
        return account;
    }

    public void perform(String user) {
        RequestParams param = getParams();
        param.put(ProtocolConstants.PARAM_USER, user);
        super.perform();
    }
}