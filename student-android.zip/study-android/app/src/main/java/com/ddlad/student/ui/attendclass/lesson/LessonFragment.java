package com.ddlad.student.ui.attendclass.lesson;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.protocol.http.cache.NetworkImageCache;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.request.ConstantsRequest;
import com.ddlad.student.protocol.http.request.LessonRequest;
import com.ddlad.student.protocol.http.request.ScholarWxShareOkRequest;
import com.ddlad.student.protocol.http.request.ScholarWxShareRequest;
import com.ddlad.student.protocol.model.ConstantsInfo;
import com.ddlad.student.protocol.model.GetChargeItemInfo;
import com.ddlad.student.protocol.model.ShareWxIssueInfo;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.request.BaseListRequest;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.LessonInfo;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.widget.dialog.IDialogClickListener;
import com.ddlad.student.ui.widget.dialog.ShareLessonDialogBuilder;
import com.ddlad.student.ui.widget.image.NetworkImageView;
import com.ddlad.student.wxapi.WXEntryActivity;
import com.ddlad.student.wxapi.WechatHelper;


public class LessonFragment extends BaseListFragment<LessonInfo> {

    public static boolean isNeedRefresh = false;
    private String cid;


    public static boolean shareSuccess;

    //课程id
    private String lid;

    private String first = "5";
    private String second = "100";

    private WechatHelper wechatHelper;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_lesson;
    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle("课次列表");
        wechatHelper = new WechatHelper();
    }

    @Override
    protected void onInitData(Bundle bundle) {
        cid = bundle.getString(ProtocolConstants.PARAM_CID);
    }

    @Override
    protected AbstractAdapter getAdapter() {
        if (mAdapter == null){
            mAdapter = new LessonAdapter(this,allowShare);
        }
        return mAdapter;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (isNeedRefresh){
            isNeedRefresh = false;
            handleRequest(true);
        }

        if (WXEntryActivity.shareSuccess){
            WXEntryActivity.shareSuccess = false;
            perfromShareSuccess();
        }
    }

    @Override
    protected void afterCallbackSuccess() {
        ((LessonAdapter)mAdapter).setAllowShare(allowShare);
    }

    @Override
    protected BaseListRequest makeRequest(AbstractStreamingCallbacks<AbstractListResponse<LessonInfo>> streamingApiCallbacks) {
        return new LessonRequest(this,mDefaultLoaderId,streamingApiCallbacks);
    }

    @Override
    protected void performRequest() {
        ((LessonRequest) mDefaultRequest).perform(cid);
    }

    public void showShareDialog(String one,String two,String id){
        first = one;
        second = two;
        lid = id;
        showDialog();
    }


    private ShareLessonDialogBuilder dialogBuilder;

    public void showDialog(){
        if (dialogBuilder == null){
            dialogBuilder = new ShareLessonDialogBuilder(this);
            dialogBuilder.setmListener(new IDialogClickListener() {
                @Override
                public void onClick(int type) {
                    if (type == 1){
                        getWxShareInfo();
                    }
                }
            });
            dialogBuilder.setContent(first,second);
        }
        dialogBuilder.create().show();
    }

    public void getWxShareInfo(){
        performConstants();
        ScholarWxShareRequest request = new ScholarWxShareRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<ShareWxIssueInfo>() {
            @Override
            protected void onSuccess(final ShareWxIssueInfo shareWxIssueInfo) {
                String url = shareWxIssueInfo.getInfo().getPicUrl();
                if (NetworkImageCache.getInstance().getBitmap(url) != null) {
                    NetworkImageCache.getInstance().removeBitmapAndRecycle(url);
                }
                NetworkImageView imageView = new NetworkImageView(getActivity());
                imageView.setUrl(url);

                imageView.setOnLoadListener(new NetworkImageView.OnLoadListener() {
                    @Override
                    public void onLoad(Bitmap bitmap, String url) {
                        ShareWxIssueInfo.InfoBean info = shareWxIssueInfo.getInfo();
                        wechatHelper.inviteWechatFriendUrl(info.getUrl(),info.getPicUrl(),info.getTitle(),info.getBrief(),false);

                    }
                });
            }
        });
        request.perform(cid);
    }

    private void performConstants() {
        ConstantsRequest request = new ConstantsRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<ConstantsInfo>() {
            @Override
            protected void onSuccess(ConstantsInfo constantsInfo) {
            }
        });
        request.perform();
    }

    public void perfromShareSuccess(){
        ScholarWxShareOkRequest request = new ScholarWxShareOkRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<ShareWxIssueInfo>() {
            @Override
            protected void onSuccess(ShareWxIssueInfo shareWxIssueInfo) {

            }
        });
        request.perform("",cid,lid);
    }

    @Override
    protected boolean isNeedFetch() {
        return true;
    }

    @Override
    protected void showEmptyView() {

        if (mEmptyView == null) {
            mEmptyView = (ViewGroup) LayoutInflater.from(getActivity()).inflate(R.layout.layout_empty_footer, null);
            mListView.addFooterView(mEmptyView, null, false);
        }

        if (mAdapter == null || mAdapter.isEmpty()) {
            mEmptyView.setVisibility(View.VISIBLE);
        } else {
            hideEmptyView();
        }

    }

    @Override
    protected void hideEmptyView() {
        if (mEmptyView != null) {
            mListView.removeFooterView(mEmptyView);
        }
        mEmptyView = null;
    }
}
