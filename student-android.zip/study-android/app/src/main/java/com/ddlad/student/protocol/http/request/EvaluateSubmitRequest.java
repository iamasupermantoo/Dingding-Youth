package com.ddlad.student.protocol.http.request;



import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.MetaInfo;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.protocol.http.internal.ApiResponse;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-11-7.
 */
public class EvaluateSubmitRequest extends AbstractRequest<MetaInfo> {

    public EvaluateSubmitRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<MetaInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_EVALUATE_SUBMIT;
    }

    @Override
    public MetaInfo processInBackground(ApiResponse<MetaInfo> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_META, MetaInfo.class);
    }

    public void perform(int quality, int acceptance,String remark,int star,String cid,String lid) {
        RequestParams params = getParams();
        params.put("quality", quality);
        params.put("acceptance", acceptance);
        params.put("remark", remark);
        params.put("star", star);
        params.put("cid", cid);
        params.put("lid", lid);
        super.perform();
    }
}
