package com.ddlad.student.ui.choice;


import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewPager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.OvershootInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;
import com.ddlad.student.protocol.convert.DataCenter;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.request.ClientVersionRequest;
import com.ddlad.student.protocol.http.request.ConstantsRequest;
import com.ddlad.student.protocol.http.request.HomeFeedRequest;
import com.ddlad.student.protocol.http.request.HomeIntroRequest;
import com.ddlad.student.protocol.http.request.RecommendBannerRequest;
import com.ddlad.student.protocol.model.BannerInfo;
import com.ddlad.student.protocol.model.CalendarReminderCourseInfo;
import com.ddlad.student.protocol.model.ConstantsInfo;
import com.ddlad.student.protocol.model.CoursesLiveBean;
import com.ddlad.student.protocol.model.FeedsInfo;
import com.ddlad.student.protocol.model.IntroInfo;
import com.ddlad.student.protocol.model.NewBannerInfo;
import com.ddlad.student.protocol.model.VersionInfo;
import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.tools.Constants;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.tools.StringUtil;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.attendclass.VideoPlayerActivityy;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.course.LatestCourseDetailsFragment;
import com.ddlad.student.ui.course.NewCourseDetailsFragment;
import com.ddlad.student.ui.course.NewLiveCourseDetailsFragment;
import com.ddlad.student.ui.export.WebViewFragment;
import com.ddlad.student.ui.widget.dialog.DialogBuilder;
import com.ddlad.student.ui.widget.image.CircleImageView;
import com.ddlad.student.ui.widget.image.NetworkImageView;
import com.ddlad.student.ui.widget.pager.CommonPager;
import com.ddlad.student.ui.widget.pager.PagerPointer;
import com.ddlad.student.ui.widget.scroll.HomePageScroller;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;


public class NewChoiceFragment extends BaseFragment {

    private int mUpdateLoaderId = ViewUtil.generateUniqueId();

    private TextView discover_teacher;
    private TextView course_gkk;
    private ViewGroup bottom_learn_layout;
    private ViewGroup introduce;
    private TranslateAnimation animation;

    private ViewGroup try_listen;
    private ViewGroup lesson_begin_info;
    private ViewGroup information;

    private BannerPagerAdapter mBannerAdapter;
    private CommonPager pager;
    private PagerPointer mPagerPointer;
    private boolean isFirstCreate = true;
    private boolean isTouch = false;
    private List<BannerInfo> mInfoList;
    private int bannerCount = 1;

    private FeedsInfo mFeedsInfo;

    private boolean isNeedPost = false;
    private TimerTask  timerTask = new TimerTask() {
        @Override
        public void run() {
            handler.sendEmptyMessage(0511);
        }
    };

    private Timer timer = new Timer();

    private String mVideoUrl;

    private boolean isForceUpdate = false;
    private VersionInfo mVersionInfo;

    private int imageCount = 1;
    private int count = 0;

    private Runnable task = new Runnable() {
        @Override
        public void run() {
            handler.sendEmptyMessage(0511);
            handler.postDelayed(this, 3 * 1000);
        }
    };
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {

            if (msg.what == 1){
                if (count == 0){
                    count++;
                }
                if (imageCount == 1){
                    return;
                }
                pager.setCurrentItem(count%imageCount,false);
                count++;
                handler.sendEmptyMessageDelayed(1,3000);

            }
            super.handleMessage(msg);
        }
    };


    @Override
    protected int getLayoutResource() {
//        return R.layout.fragment_choice;
        return R.layout.fragment_choice_new;
    }

    @Override
    protected void onInitData(Bundle bundle) {
        super.onInitData(bundle);
        performBannerRequest();
        introRequest();
        performConstants();
//        checkUpdate();
    }

    private void performConstants() {
        ConstantsRequest request = new ConstantsRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<ConstantsInfo>() {
            @Override
            protected void onSuccess(ConstantsInfo constantsInfo) {
            }
        });
        request.perform();
    }


    @Override
    protected void onInitView(View contentView) {

        mActionbar.hideEvaluateTitle();
        mActionbar.setTitle("首页");
//        mActionbar.setBottomDividerGone();
        mActionbar.hideLeftLayout();
        ///////////////////////////////////////////////////////////////////////
        mPagerPointer = (PagerPointer) contentView.findViewById(R.id.pager_pointer);
        pager = (CommonPager) contentView.findViewById(R.id.pager);
        pager.setDisableTouch(false);
        if (mBannerAdapter == null) {
            mBannerAdapter = new BannerPagerAdapter(getActivity());
        } else {
            if (imageCount == 1){
                mPagerPointer.bindPoints(1, R.drawable.yellow_dot, R.drawable.white_dot);
            }else {
                if (mBannerAdapter.getCount()>1){
                    if(isFirstCreate){
                        bannerCount = mBannerAdapter.getCount()-2;
                        isFirstCreate = false;
                    }
                    mPagerPointer.bindPoints(bannerCount, R.drawable.yellow_dot, R.drawable.white_dot);
                }else {
                    mPagerPointer.bindPoints(mBannerAdapter.getCount(), R.drawable.yellow_dot, R.drawable.white_dot);
                }
                mPagerPointer.setVisibility(mBannerAdapter.getCount() <= 1 ? View.GONE : View.VISIBLE);
            }

        }

        pager.setAdapter(mBannerAdapter);
        setViewPagerScrollSpeed();
        pager.getLayoutParams().height = AppContext.getScreenWidth()
                * AppContext.getInteger(R.integer.discovery_banner_height)
                / AppContext.getInteger(R.integer.discovery_banner_width);
        pager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            int currentPosition;
            @Override
            public void onPageSelected(int position) {
                if (imageCount == 1){

                }else {
                    if (position == 0){
                        mPagerPointer.selectIndex(mInfoList.size()-1);
                    }else if (position == mInfoList.size()+1){
                        mPagerPointer.selectIndex(0);
                    }else {
                        mPagerPointer.selectIndex(position-1);
                    }

                    // 当视图在第一个时，将页面号设置为图片的最后一张。
                    if (position == 0) {
//                        pager.setCurrentItem(mInfoList.size(),true);
                        pager.setCurrentItem(mInfoList.size(),false);
                    } else if (position == mInfoList.size() + 1) {
                        // 当视图在最后一个是,将页面号设置为图片的第一张。
//                        pager.setCurrentItem(1,true);
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                pager.setCurrentItem(1, false);
                            }
                        },600);
                    }
                }
            }

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                currentPosition = position;
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                if (imageCount <= 1){

                }else {
                    if (state == ViewPager.SCROLL_STATE_DRAGGING){
                        handler.removeMessages(1);
                        isTouch = true;
                    }else if (isTouch){
                        handler.removeMessages(1);
                        handler.sendEmptyMessageDelayed(1,2000);
                        isTouch = false;
                    }
                    if (state != ViewPager.SCROLL_STATE_IDLE) return;

//                    // 当视图在第一个时，将页面号设置为图片的最后一张。
//                    if (currentPosition == 0) {
////                        pager.setCurrentItem(mInfoList.size(),true);
//                        pager.setCurrentItem(mInfoList.size()-2,true);
//                    } else if (currentPosition == mInfoList.size() + 1) {
//                        // 当视图在最后一个是,将页面号设置为图片的第一张。
//                        pager.setCurrentItem(1,true);
//                    }
                }

            }
        });

        handler.removeMessages(1);
        handler.sendEmptyMessage(1);

        ///////////////////////////////////////////////////////////////////////
        try_listen = (ViewGroup) contentView.findViewById(R.id.try_listen);
        lesson_begin_info = (ViewGroup) contentView.findViewById(R.id.lesson_begin_info);
        information = (ViewGroup) contentView.findViewById(R.id.information);




        course_gkk = (TextView) contentView.findViewById(R.id.course_gkk);
        discover_teacher = (TextView) contentView.findViewById(R.id.discover_teacher);
        bottom_learn_layout = (ViewGroup) contentView.findViewById(R.id.bottom_learn_layout);
        course_gkk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ///跳到视频播放页
                if (!StringUtil.isEmpty(mVideoUrl)){
                    seeVideo(mVideoUrl);
                }
            }
        });
        discover_teacher.setOnClickListener(this);

        if (mFeedsInfo != null){
            mVideoUrl = mFeedsInfo.getVideo();
            mFeedsInfo = mFeedsInfo;
            if (mFeedsInfo.getTrials() != null){
                initLabelGroup(try_listen,1);
            }
            if (mFeedsInfo.getOpencourses() != null){
                initLabelGroup(lesson_begin_info,2);
            }
            if (mFeedsInfo.getInformations() != null){
                initLabelGroup(information,3);
            }
        }

    }

    private void initLabelGroup(ViewGroup groupItem, final int type) {
        TextView label_name = (TextView) groupItem.findViewById(R.id.label_name);
        TextView more = (TextView) groupItem.findViewById(R.id.more);
        ViewGroup item_layout = (ViewGroup) groupItem.findViewById(R.id.item_layout);

        if (type == 1){
            label_name.setText("试听课程");
            initLabelItem(item_layout,type);
        }
        if (type == 2){
            label_name.setText("开课信息");
            initLabelItem(item_layout,type);
        }
        if (type == 3){
            label_name.setText("资讯");
            initLabelItem(item_layout,type);
        }


        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToLiveCourseList(type);
            }
        });

    }

    private void initLabelItem(ViewGroup itemLayout, final int type) {
        itemLayout.removeAllViews();
        View labelItem;
        ArrayList<CoursesLiveBean> list = null;
        if (type == 1){
            list = (ArrayList<CoursesLiveBean>) mFeedsInfo.getTrials();
        }
        if (type == 2){
            list = (ArrayList<CoursesLiveBean>) mFeedsInfo.getOpencourses();
        }
        if (type == 3){
            list = (ArrayList<CoursesLiveBean>) mFeedsInfo.getInformations();
        }
        for(int i = 0; list != null && i < list.size() ; i++ ){
            labelItem = LayoutInflater.from(getActivity()).inflate(R.layout.layout_home_label_item,null);
            TextView title = (TextView) labelItem.findViewById(R.id.title);
            TextView partake_num = (TextView) labelItem.findViewById(R.id.partake_num);
            TextView begin_time = (TextView) labelItem.findViewById(R.id.begin_time);
            NetworkImageView image = (NetworkImageView) labelItem.findViewById(R.id.image);

            title.setText(list.get(i).getTitle());
            if (list.get(i).getImage() != null){
                image.setUrl(list.get(i).getImage().getImageMedium());
            }
            if (type == 3){
                partake_num.setVisibility(View.GONE);
                begin_time.setText(AppContext.getString(R.string.lesson_publish_time, list.get(i).getPubTime()));
            }else {
                partake_num.setText(AppContext.getString(R.string.partake_num_detail, list.get(i).getJoinCnt()));
                if (StringUtil.isEmpty(list.get(i).getOpenTime())){
                    begin_time.setVisibility(View.GONE);
                }else {
                    begin_time.setText(AppContext.getString(R.string.lesson_begin_time, list.get(i).getOpenTime()));
                }

            }
            final ArrayList<CoursesLiveBean> finalList = list;
            final int finalI = i;
            labelItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (type == 1){
                        if (finalList.get(finalI).getDataType() == 1){
                            navigateToNewLiveCourse(finalList.get(finalI).getId());
                        }
                        if (finalList.get(finalI).getDataType() == 0){
                            navigateToLatestCourseDetail(finalList.get(finalI).getId());
                        }

                    }
                    if (type == 2){
                        navigateToNewLiveCourse(finalList.get(finalI).getId());
                    }
                    if (type == 3){
                        navigateToWebDetail(finalList.get(finalI).getUrl());
                    }
                }
            });
            itemLayout.addView(labelItem);
        }

    }

    private void setViewPagerScrollSpeed( ){
        try {
            Field mScroller = null;
            mScroller = ViewPager.class.getDeclaredField("mScroller");
            mScroller.setAccessible(true);
            HomePageScroller scroller = new HomePageScroller(getActivity());
            mScroller.set(pager, scroller);
        }catch(NoSuchFieldException e){

        }catch (IllegalArgumentException e){

        }catch (IllegalAccessException e){

        }
    }


    private void checkUpdate() {
//        BaseActivity.isNeedInterceptBack = false;
        ClientVersionRequest request = new ClientVersionRequest(this, mUpdateLoaderId,
                new AbstractCallbacks<VersionInfo>() {
                    @Override
                    protected void onSuccess(VersionInfo version) {
//                        if (version != null && version.getUrl() != null){
//                            getActivity().getContentResolver().registerContentObserver(Uri.parse(version.getUrl()),true,observer);
//                        }
                        if (version != null && version.getUrl() != null){
                            mVersionInfo = version;
                            showUpdateDialog(version);
                        }
                    }
                });
        request.perform();
    }


    private void showUpdateDialog(final VersionInfo version) {

        if (version == null) {
            return;
        }

        getActivity().setFinishOnTouchOutside(false);

        final DialogBuilder dialogBuilder = new DialogBuilder(getActivity());

        dialogBuilder.setCanceledOnTouchOutside(false);
        dialogBuilder.setTitle(version.getTitle())
                .setMessage(version.getDesc())
                .setMessageGravity(Gravity.CENTER)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Bundle bundle = new Bundle();
                        bundle.putString(ProtocolConstants.PARAM_TITLE,
                                version.getTitle());
                        bundle.putString(ProtocolConstants.PARAM_URL,
                                version.getUrl());
                        NavigateUtil.navigateToNormalActivity(getActivity(), new WebViewFragment(), bundle);
                    }
                });
        if (!version.isForce()){
            dialogBuilder.
                    setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogBuilder.dismiss();
                        }
                    });
        }else {
            isForceUpdate = true;
        }
        dialogBuilder.create().show();
    }

    public void introRequest(){
        new HomeFeedRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<FeedsInfo>() {
            @Override
            protected void onSuccess(FeedsInfo feedsInfo) {
                if (feedsInfo != null){
                    mVideoUrl = feedsInfo.getVideo();
                    mFeedsInfo = feedsInfo;
                    if (feedsInfo.getTrials() != null){
                        initLabelGroup(try_listen,1);
                    }
                    if (feedsInfo.getOpencourses() != null){
                        initLabelGroup(lesson_begin_info,2);
                    }
                    if (feedsInfo.getInformations() != null){
                        initLabelGroup(information,3);
                    }
                }
            }
        }).perform();
    }


    private void performBannerRequest() {
        RecommendBannerRequest mBannerRequest = new RecommendBannerRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<NewBannerInfo>() {
            @Override
            protected void onSuccess(NewBannerInfo bannerInfo) {
                mInfoList = bannerInfo.getBanners();
                if (!CollectionUtil.isEmpty(mInfoList)) {
                    if (imageCount == 1){
                        handler.removeMessages(1);
                        handler.sendEmptyMessageDelayed(1,3000);
                    }
                    imageCount = mInfoList.size();
                    mPagerPointer.bindPoints(mInfoList.size(), R.drawable.yellow_dot, R.drawable.white_dot);
                    mPagerPointer.setVisibility(mInfoList.size() <= 1 ? View.GONE : View.VISIBLE);
                    mBannerAdapter.setData(mInfoList);
                    mBannerAdapter.notifyDataSetChanged();
                    pager.setCurrentItem(1,false);
                }
            }
        });
        mBannerRequest.perform();
    }


    @Override
    public void onPause() {
        Log.i("ChoiceFramgnet","-----------------------------------------------onPause");
        handler.removeCallbacks(task);
        isNeedPost = true;
        super.onPause();
    }

    @Override
    public void onResume() {
        Log.i("ChoiceFramgnet","-----------------------------------------------onResume");
        if (isNeedPost){
            handler.postDelayed(task,0);
            isNeedPost = false;
        }
        if (isForceUpdate){
            showUpdateDialog(mVersionInfo);
        }
        super.onResume();
    }

    @Override
    public void onStop() {
        Log.i("ChoiceFramgnet","-----------------------------------------------onStop");
        super.onStop();
    }

    @Override
    public void onDestroy() {
        Log.i("ChoiceFramgnet","-----------------------------------------------onDestroy");
        super.onDestroy();
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.try_listen:
                break;
            case R.id.lesson_begin_info:
                break;

            case R.id.discover_teacher:
                navigateToDiscoverTeacher();
                break;
        }
    }

    public void navigateToWebDetail(String url){
        Bundle bundle = new Bundle();
        bundle.putString(ProtocolConstants.PARAM_URL,url);
        NavigateUtil.navigateToNormalActivity(getActivity(),new WebDetailFragment(),bundle);
    }

    public void navigateToDiscoverTeacher(){
        Bundle bundle = new Bundle();
        NavigateUtil.navigateToNormalActivity(getActivity(),new DiscoverTeacherFragment(),bundle);
    }

    public void navigateToNewLiveCourse(String id){
        Bundle bundle = new Bundle();
        bundle.putString("cmid",id);
        NavigateUtil.navigateToNormalActivity(getActivity(),new NewLiveCourseDetailsFragment(),bundle);
    }

    public void navigateToLatestCourseDetail(String id){
        Bundle bundle = new Bundle();
        bundle.putString("cmid",id);
        NavigateUtil.navigateToNormalActivity(getActivity(),new LatestCourseDetailsFragment(),bundle);
    }

    public void navigateToLiveCourseList(int type){
        Bundle bundle = new Bundle();
        bundle.putInt("type",type);
        NavigateUtil.navigateToNormalActivity(getActivity(),new LiveCourseListFragment(),bundle);
    }

    public void seeVideo(String url){
        Intent intent = new Intent(getActivity(),VideoPlayerActivityy.class);
        intent.putExtra("url",url);
        getActivity().startActivity(intent);
    }
}
