package com.ddlad.student.ui.edit;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;


/**
 * Created by Albert
 * on 16-10-27.
 */
public class EditDetailFragment extends BaseFragment {

    private String mValue;

    private String mTitle;

    private EditText mValueEditor;

    private TextView mCount;

    @Override
    protected void onInitData(Bundle bundle) {
        mValue = bundle.getString(ProtocolConstants.PARAM_VALUE);
        mTitle = bundle.getString(ProtocolConstants.PARAM_TITLE);
    }

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_edit_detail;
    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle(mTitle);
        mActionbar.setLeftImage(R.drawable.arrow_back);
        mActionbar.setRightText(R.string.finish);
        mActionbar.setRightButtonOnClickListener(this);
        mValueEditor = (EditText) contentView.findViewById(R.id.value);
        mValueEditor.setText(mValue);
        mValueEditor.setSelection(mValue.length());
        mValueEditor.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                updateSignature();
            }
        });
        mCount = (TextView) contentView.findViewById(R.id.count);
        updateSignature();
    }

    private void updateSignature() {
        mCount.setText(AppContext.getString(R.string.letter_count_format,
                mValueEditor.getMaxEms() - mValueEditor.length()));
    }

    @Override
    public void onPause() {
        hideKeyboard();
        super.onPause();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.right_layout:
                finish();
                break;
        }
    }

    private void finish() {
        mValue = mValueEditor.getText().toString().trim();
        Intent intent = new Intent();
        Bundle bundle = new Bundle();
        bundle.putString(ProtocolConstants.PARAM_VALUE, mValue);
        intent.putExtras(bundle);
        getActivity().setResult(Activity.RESULT_OK, intent);
        getActivity().finish();
    }

}
