package com.ddlad.student.ui.fresco;


import com.ddlad.student.ui.fresco.models.FolderItem;

public interface OnFolderRecyclerViewInteractionListener {
    void onFolderItemInteraction(FolderItem item);
}
