package com.ddlad.student.ui.choice;

import android.app.Activity;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageView;

import com.ddlad.student.protocol.model.BannerInfo;
import com.ddlad.student.protocol.model.GoToPage;
import com.ddlad.student.ui.widget.image.NetworkImageView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Albert
 * on 16-10-13.
 */
public class BannerPagerAdapter extends PagerAdapter {

    protected Activity mActivity;

    protected List<BannerInfo> mList = new ArrayList<>();
    protected List<NetworkImageView> mImageList = new ArrayList<>();

    public BannerPagerAdapter(Activity activity) {
        mActivity = activity;
    }

    public BannerPagerAdapter(Activity activity, List<BannerInfo> list) {
        mActivity = activity;
//        mList.add(0,list.get(list.size()-1));
//        for (int i = 1; i <= list.size(); i++){
//           mList.add(i,list.get(i-1));
//        }
//        mList.add(list.size()+1,list.get(0));
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
//        container.removeView((View) object);
    }

    @Override
    public void finishUpdate(View arg0) {
    }

    @Override
    public int getCount() {
        if (mList != null && mList.size()>0) {
            return mList.size();
        }
//        if (mImageList != null) {
//            return Integer.MAX_VALUE;
//        }
        return 0;
    }

    public void setData(List<BannerInfo> list) {
//        mList = list;
        mList.clear();
        mImageList.clear();
        if (list.size() == 1){
            mList.add(0,list.get(list.size()-1));
            BannerInfo banner = list.get(list.size()-1);
            NetworkImageView image = new NetworkImageView(mActivity);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
//            image.setScaleType(ImageView.ScaleType.FIT_XY);
            image.setUrl(banner.getImageUrl());
            mImageList.add(0,image);
            return;
        }
        mList.add(0,list.get(list.size()-1));
        BannerInfo banner = list.get(list.size()-1);
        NetworkImageView image = new NetworkImageView(mActivity);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
//        image.setScaleType(ImageView.ScaleType.FIT_XY);
        image.setUrl(banner.getImageUrl());
        mImageList.add(0,image);
        for (int i = 1; i <= list.size(); i++){
            mList.add(i,list.get(i-1));
            banner = list.get(i-1);
            image = new NetworkImageView(mActivity);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
//            image.setScaleType(ImageView.ScaleType.FIT_XY);
            image.setUrl(banner.getImageUrl());
            mImageList.add(i,image);
        }
        mList.add(list.size()+1,list.get(0));
        banner = list.get(0);
        image = new NetworkImageView(mActivity);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
//        image.setScaleType(ImageView.ScaleType.FIT_XY);
        image.setUrl(banner.getImageUrl());
        mImageList.add(list.size()+1,image);
    }

    @Override
    public Object instantiateItem(ViewGroup viewGroup, int position) {

        final BannerInfo banner = mList.get(position);
//        NetworkImageView image = new NetworkImageView(viewGroup.getContext());
//        image.setScaleType(ImageView.ScaleType.FIT_XY);
//        Log.i("BannerPagerAdapter", "getImageUrl: "+banner.getImageUrl());
//        image.setUrl(banner.getImageUrl());

        NetworkImageView image = mImageList.get(position);
        //如果View已经在之前添加到了一个父组件，则必须先remove，否则会抛出IllegalStateException。

        ViewParent viewParent = image.getParent();
        if (viewParent!=null){
            ViewGroup parent = (ViewGroup)viewParent;
            parent.removeView(image);
        }
        ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        viewGroup.addView(image, lp);
//        int height = ViewUtil.getScreenWidthPixels()*32/75;
//        ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
//        lp.height = height;
//        viewGroup.addView(image, lp);

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GoToPage.go(banner.getGotoPage(), mActivity);
            }
        });

        return image;
    }

    @Override
    public boolean isViewFromObject(View arg0, Object arg1) {
        return (arg0 == arg1);
    }

    @Override
    public void restoreState(Parcelable arg0, ClassLoader arg1) {

    }

    @Override
    public Parcelable saveState() {
        return null;
    }

    @Override
    public void startUpdate(View arg0) {

    }

}
