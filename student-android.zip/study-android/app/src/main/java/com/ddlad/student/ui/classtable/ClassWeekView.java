package com.ddlad.student.ui.classtable;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;

import com.ddlad.student.R;

/**
 * Created by Albert
 * on 16-8-31.
 */
public class ClassWeekView extends LinearLayout {

    private ClassDayView[] days = new ClassDayView[7];

    public ClassWeekView(Context context) {
        super(context);
        init(context);
    }

    public ClassWeekView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ClassWeekView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        setOrientation(HORIZONTAL);
        LayoutInflater.from(context).inflate(R.layout.layout_class_week, this, true);
        days[0] = (ClassDayView) findViewById(R.id.day0);
        days[1] = (ClassDayView) findViewById(R.id.day1);
        days[2] = (ClassDayView) findViewById(R.id.day2);
        days[3] = (ClassDayView) findViewById(R.id.day3);
        days[4] = (ClassDayView) findViewById(R.id.day4);
        days[5] = (ClassDayView) findViewById(R.id.day5);
        days[6] = (ClassDayView) findViewById(R.id.day6);
    }

    public ClassDayView getDayView(int index) {
        return days[index];
    }
}
