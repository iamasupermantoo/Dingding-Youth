package com.ddlad.student.protocol.http.request;


import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.VersionInfo;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-11-15.
 */
public class ClientVersionRequest extends AbstractRequest<VersionInfo> {

    public ClientVersionRequest(BaseFragment fragment, int loaderId,
                                AbstractCallbacks<VersionInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url,
                                          RequestParams requestParams) {
        return httpClient.getRequest(url, requestParams);
    }

    @Override
    protected String getPath() {
//        return ProtocolConstants.URL_CHECK_VERSION;
        return "/client/version";
    }

    @Override
    public VersionInfo processInBackground(ApiResponse<VersionInfo> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, ProtocolConstants.JSON_FIELD_VERSION, VersionInfo.class);
    }

    @Override
    public void perform() {
        RequestParams params = getParams();
        params.put("platform", VersionInfo.ClientType.Android.getValue());
        super.perform();
    }
}