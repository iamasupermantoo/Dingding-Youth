package com.ddlad.student.ui.attendclass.evaluate;

import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.protocol.model.LCorrectNotInfo;
import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.common.BaseFragment;

import java.util.List;

/**
 * Created by Albert
 * on 16-10-20.
 */
public class LEvaluateAlreadyListAdapter extends AbstractAdapter<LCorrectNotInfo> {

    public LEvaluateAlreadyListAdapter(BaseFragment fragment) {
        super(fragment);
    }

    @Override
    public LCorrectNotInfo getItem(int position) {
        return mList.get(position);
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public int getItemViewType(int position) {
        return getItem(position).getType();
    }

    @Override
    protected View createView(int position, ViewGroup parent) {
        return EvaluateAlreadyListItemAdapter.createView(parent);
    }

    @Override
    protected void bindView(int position, View view) {
        LCorrectNotInfo feed = getItem(position);
        EvaluateAlreadyListItemAdapter.bindView(view, feed, mFragment);
    }

    @Override
    public void clearItem() {
        mList.clear();
    }


    @Override
    public void addItem(LCorrectNotInfo info) {
        mList.add(info);
    }

    @Override
    public void addItem(List<LCorrectNotInfo> list) {
        if (!CollectionUtil.isEmpty(list)) {
            mList.addAll(list);
        }
    }

    @Override
    public int getCount() {
        return mList.size();
    }

//    public enum ProfileViewType {
//
//        Article(0), Image(1);
//
//        private ProfileViewType(int value) {
//            this.mValue = value;
//        }
//
//        private int mValue;
//
//        public int getValue() {
//            return mValue;
//        }
//    }

}

