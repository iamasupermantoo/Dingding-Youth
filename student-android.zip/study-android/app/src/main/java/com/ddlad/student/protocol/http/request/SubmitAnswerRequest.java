package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-8-11.
 */
public class SubmitAnswerRequest extends AbstractRequest<String> {
    public SubmitAnswerRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<String> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_HOMEWORK_COMMIT;
    }

    @Override
    public String processInBackground(ApiResponse<String> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, String.class);
    }

    public void perform(String hid,Object type,Object content,String cid,String lid) {
        RequestParams param = getParams();
        if (hid != null && !hid.equals("")){
            param.put(ProtocolConstants.PARAM_HID, hid);
        }
        param.put(ProtocolConstants.PARAM_TYPE, type);
        param.put(ProtocolConstants.PARAM_TEXT, content);
        param.put("cid", cid);
        param.put("lid", lid);
        super.perform();
    }

    public void perform(String hid,Object type,Object content) {
        RequestParams param = getParams();
        param.put(ProtocolConstants.PARAM_HID, hid);
        param.put(ProtocolConstants.PARAM_TYPE, type);
        param.put(ProtocolConstants.PARAM_TEXT, content);
//        param.put("cid", cid);
//        param.put("lid", lid);
        super.perform();
    }
}
