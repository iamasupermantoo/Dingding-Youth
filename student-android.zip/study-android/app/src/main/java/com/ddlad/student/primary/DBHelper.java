package com.ddlad.student.primary;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Administrator on 2016/12/20 0020.
 */

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "chat_udan.db";
    private static final int DATABASE_VERSION = 1;

    public DBHelper(Context context) {
        //CursorFactory设置为null,使用默认值
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS chatInfo " +
                "(_id INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT, session TEXT,content TEXT,pattern TEXT ,message TEXT, chatTime TEXT,type INTEGER,isSender INTEGER)");
//        id,session,content,pattern,message,time,isSender

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("ALTER TABLE chatInfo ADD COLUMN other STRING");
    }
}
