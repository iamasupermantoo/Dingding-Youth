package com.ddlad.student.ui.choice;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.ddlad.student.R;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.request.DiscoverTeacherRequest;
import com.ddlad.student.protocol.model.DiscoverTeacherInfo;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.pager.CommonPager;

import java.util.ArrayList;

/**
 * Created by chen007 on 2017/11/6 0006.
 */
public class DiscoverTeacherFragment extends BaseFragment {

    private RecyclerView recycle_view;
    private DiscoverTeacherAdapter mAdapter;

    private CommonPager common_pager;
    private DiscoverPagerAdapter pagerAdapter;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_discover_teacher;
    }

    @Override
    protected void onInitData(Bundle bundle) {
        requestData();
    }



    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle("发现老师");
        recycle_view = (RecyclerView) contentView.findViewById(R.id.recycle_view);
//        common_pager = (CommonPager) contentView.findViewById(R.id.common_pager);
//        pagerAdapter = new DiscoverPagerAdapter(getActivity());
//        common_pager.setAdapter(pagerAdapter);
//        common_pager.setDisableTouch(false);
        LinearLayoutManager manager = new LinearLayoutManager(getActivity());
        if (mAdapter == null){
            mAdapter = new DiscoverTeacherAdapter(getActivity());
        }
        manager.setOrientation(LinearLayoutManager.HORIZONTAL);
        recycle_view.setLayoutManager(manager);
        recycle_view.setAdapter(mAdapter);
    }

    private void requestData() {
        DiscoverTeacherRequest request = new DiscoverTeacherRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<DiscoverTeacherInfo>() {
            @Override
            protected void onSuccess(DiscoverTeacherInfo info) {
                if (info != null  && info.getTeachers() != null){
                    mAdapter.setmInfos((ArrayList<DiscoverTeacherInfo.TeachersBean.ListBean>) info.getTeachers().getList());
                    mAdapter.notifyDataSetChanged();
//                    pagerAdapter.setData((ArrayList<DiscoverTeacherInfo.TeachersBean.ListBean>) info.getTeachers().getList());
//                    pagerAdapter.notifyDataSetChanged();

                }
            }
        });
        request.perform();
    }

}
