package com.ddlad.student.ui.edit;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


import com.ddlad.student.protocol.convert.DataCenter;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.request.MyAccountRequest;
import com.ddlad.student.protocol.http.request.UploadImageRequestMy;
import com.ddlad.student.protocol.model.UploadedImage;
import com.ddlad.student.protocol.model.UserInfo;
import com.ddlad.student.tools.CameraUtil;
import com.ddlad.student.tools.Constants;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.dialog.AddressDialogBuilder;
import com.ddlad.student.ui.widget.dialog.BottomDialogBuilder;
import com.ddlad.student.ui.widget.dialog.DateDialogBuilder;
import com.ddlad.student.ui.widget.image.CircleImageView;
import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ResponseMessage;
import com.ddlad.student.protocol.http.request.UpdateAccountInfoRequest;
import com.ddlad.student.protocol.model.Account;
import com.ddlad.student.protocol.model.MyAccountInfo;
import com.ddlad.student.tools.CropUtil;
import com.ddlad.student.tools.GalleryUtil;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.tools.StringUtil;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.account.AccountFragment;
import com.ddlad.student.ui.widget.dialog.WheelDialogBuilder;
import com.ddlad.student.ui.widget.wheel.WheelAdapter;

import java.io.File;
import java.util.Calendar;


public class EditFragment extends BaseFragment {

//    private Account mAccountTemp;
    private MyAccountInfo mAccountTemp;

    private boolean mEditMode;

    private int mActionLoaderId = ViewUtil.generateUniqueId();

    private Account mAccount;

    private Uri mTempAvatar;

    private File mTempImage;

    private String mTempName;

    private String mTempHome;

    private String mTName = "";
    private String mTHome =  "";
    private int mTSex;
    private String mTSignture = "";
    private String mTBirthDay = "";
    private String mTGrade =  "";

    private String mTempGrade = "";

    private String mTempSex = "";

    private String mTempProvince;

    private String mTempCity;

    private int mTempGender = -1;

    private String mTempSignature;

    private String mTempBirthDay;

    private EditText mSexEdit;
    private EditText mNameEdit;
    private EditText mGradeEdit;
    private EditText mHomeEdit;
    private boolean hasChange = false;

    private int mAvatarLoaderId = ViewUtil.generateUniqueId();

    /**
     * User
     */


    private ViewGroup mAvatarLayout;

    private ViewGroup mNameLayout;

    private ViewGroup mTypeLayout;

    private ViewGroup mHomeLayout;

    private ViewGroup mGenderLayout;

    private ViewGroup mSignatureLayout;

    private ViewGroup mBirthDayLayout;


    private BottomDialogBuilder mChoiceDialog;

    private AddressDialogBuilder mAddressDialogBuilder;

    @Override
    protected void systemConfig() {
        cameraPermission();
    }

    @Override
    protected void onInitData(Bundle bundle) {
        mAccount = DataCenter.getAccount();
    }

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_edit;
    }

    @Override
    public void onPause() {
        hideKeyboard();
        super.onPause();
    }

    @Override
    protected void onInitView(View contentView) {

        mActionbar.setTitle("资料");
//        mActionbar.setTitle(mAccount.getUser().getName());
        mActionbar.setLeftImage(R.drawable.arrow_back);
        mActionbar.setRightText("修改");
        mActionbar.setRightButtonOnClickListener(this);

        // User
        mAvatarLayout = (ViewGroup) contentView.findViewById(R.id.avatar_layout);
        mNameLayout = (ViewGroup) contentView.findViewById(R.id.name_layout);
        mTypeLayout = (ViewGroup) contentView.findViewById(R.id.type_layout);
        mHomeLayout = (ViewGroup) contentView.findViewById(R.id.home_layout);
        mGenderLayout = (ViewGroup) contentView.findViewById(R.id.gender_layout);
        mSignatureLayout = (ViewGroup) contentView.findViewById(R.id.signature_layout);
        mBirthDayLayout = (ViewGroup) contentView.findViewById(R.id.birthday_layout);

    }

    private void initUserView() {
//        setItemIcon(mAvatarLayout, mAccount.getUser().getHeadImage().getImageTiny());
//        initItemView(mAvatarLayout, R.string.user_avatar);
//        mTempName = mAccount.getUser().getName();
//        Log.i(TAG, "initUserView: mTempName ------"+mTempName);
//        initItemView(mNameLayout, R.string.user_name, mTempName);

        if (mAccountTemp != null){
            setItemIcon(mAvatarLayout, mAccountTemp.getInfo().getHeadImage().getImageTiny());
            initItemView(mAvatarLayout, R.string.user_avatar);
            mTempName = mAccountTemp.getInfo().getName();
            if (mTempName != null){
                mTName = mTempName;
            }

            Log.i(TAG, "initUserView: mTempName ------"+mTempName);
            initItemView(mNameLayout, R.string.user_name, mTempName);
            //////////////////////////////////////////////////////////////////
            mTempGrade = mAccountTemp.getInfo().getGrade();
            Log.i(TAG, "initUserView: mTempGrade ------"+mTempGrade);
            if (mTempGrade != null){
                mTGrade = mTempGrade;
                initItemView(mTypeLayout, R.string.user_grade, mTempGrade);
//                if (mTempGrade.equals("0")){
//                    initItemView(mTypeLayout, R.string.user_grade, "高中");
//                }else {
//                    initItemView(mTypeLayout, R.string.user_grade, "大学");
//                }
            }else {
                initItemView(mTypeLayout, R.string.user_grade, "");
            }
            mTempProvince = mAccountTemp.getInfo().getProvince();
            mTempCity = mAccountTemp.getInfo().getRegion();
            Log.i(TAG, "initUserView: mTempProvince ------"+mTempProvince);
            Log.i(TAG, "initUserView: mTempProvince ------"+mTempProvince);

            if (mTempCity != null  && mTempProvince != null){
                String hometown = (StringUtil.isEmpty(mTempProvince) ? "" : (mTempProvince + "  "))
                        + (StringUtil.isEmpty(mTempCity) ? "" : mTempCity);
//                String hometown = mTempCity+"";
                mTHome = hometown;
                Log.i(TAG, "initUserView: home ------"+hometown);
                initItemView(mHomeLayout, R.string.user_home, hometown);
            }else {
                initItemView(mHomeLayout, R.string.user_home, "");
            }
            mTempGender = mAccountTemp.getInfo().getGender();
            mTSex = mTempGender;
            String gender = UserInfo.Gender.fromValue(mTempGender);
            initItemView(mGenderLayout, R.string.user_gender, gender);

            mTempSignature =  mAccountTemp.getInfo().getSignature();
            if (mTempSignature != null){
                mTSignture = mTempSignature;
            }
            initItemView(mSignatureLayout, R.string.user_signature, mTempSignature);

             mTempBirthDay =  mAccountTemp.getInfo().getBirthday();
            if (mTempBirthDay != null){
                mTBirthDay = mTempBirthDay;
            }
            if (StringUtil.isEmpty(mTempBirthDay)){
                initItemView(mBirthDayLayout, R.string.user_birth_day, "");
            }else {
                initItemView(mBirthDayLayout, R.string.user_birth_day, mTempBirthDay);
            }
        }else {
            mTempGender = mAccount.getUser().getGender();
            mTSex = mTempGender;
            String gender = UserInfo.Gender.fromValue(mTempGender);
            initItemView(mGenderLayout, R.string.user_gender, gender);

            mTempSignature = mAccount.getUser().getSignature();
            if (mTempSignature != null){
                mTSignture = mTempSignature;
            }
            initItemView(mSignatureLayout, R.string.user_signature, mTempSignature);


            mTempBirthDay =  mAccountTemp.getInfo().getBirthday();
            if (mTempBirthDay != null){
                mTBirthDay = mTempBirthDay;
            }
            if (StringUtil.isEmpty(mTempBirthDay)){
                initItemView(mBirthDayLayout, R.string.user_birth_day, "");
            }else {
                initItemView(mBirthDayLayout, R.string.user_birth_day, mTempBirthDay);
            }

        }



    }



    private String getItemValue(ViewGroup itemLayout) {
        TextView valueText = (TextView) itemLayout.findViewById(R.id.value);
        return valueText.getText().toString().trim();
    }

    private void setItemValue(ViewGroup itemLayout, String value) {
        CircleImageView icon = (CircleImageView) itemLayout.findViewById(R.id.icon);
        TextView valueText = (TextView) itemLayout.findViewById(R.id.value);

        if (valueText != null && !StringUtil.isEmpty(value)) {
            valueText.setText(value);
            valueText.setVisibility(View.VISIBLE);
            icon.setVisibility(View.GONE);
        }
    }

    private void setItemIcon(ViewGroup itemLayout, String iconUrl) {
        CircleImageView icon = (CircleImageView) itemLayout.findViewById(R.id.icon);
        TextView valueText = (TextView) itemLayout.findViewById(R.id.value);
        if (icon != null && !StringUtil.isEmpty(iconUrl)) {
            icon.setUrl(iconUrl);
            icon.setVisibility(View.VISIBLE);
            valueText.setVisibility(View.GONE);
        }
    }

    private String textEdit;
    private void setItemEditable(ViewGroup itemLayout, boolean visible) {
        ImageView image = (ImageView) itemLayout.findViewById(R.id.right_image);
//        ((EditText) itemLayout.findViewById(R.id.value)).setEnabled(false);
        if (!visible && mTypeLayout == itemLayout){
            ((EditText) itemLayout.findViewById(R.id.value)).setEnabled(false);
        }
        if (!visible && mNameLayout == itemLayout){
            ((EditText) itemLayout.findViewById(R.id.value)).setEnabled(false);
        }
        if (visible && mTypeLayout == itemLayout){
            //年级
            mGradeEdit = (EditText) itemLayout.findViewById(R.id.value);
            mGradeEdit.setEnabled(true);
            textEdit = mGradeEdit.getText().toString();
//            mGradeEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
//                @Override
//                public void onFocusChange(View v, boolean hasFocus) {
//                    if (hasFocus){
//                        String text = mGradeEdit.getText().toString();
//                        int length = text.length();
//                        mGradeEdit.setSelection(length);
//                    }
//                }
//            });
        }
        if (visible && mNameLayout == itemLayout){
            mNameEdit = (EditText) itemLayout.findViewById(R.id.value);
            mNameEdit.setEnabled(true);
        }


        if (image != null) {
            ///点击完成的时候会隐藏右边的箭头
            image.setVisibility(visible ? View.VISIBLE : View.INVISIBLE);
        }
    }

    private void initItemView(ViewGroup itemLayout, int textRes) {
        initItemView(itemLayout, textRes, null);
    }

    private void initItemView(ViewGroup itemLayout, int textRes, String value) {

        itemLayout.setOnClickListener(this);
//        EditText valueText1 = (EditText) itemLayout.findViewById(R.id.value);
        TextView valueText1 = (TextView) itemLayout.findViewById(R.id.value);
//        valueText1.setEnabled(false);
//        valueText1.setClickable(false);
        if (mNameLayout == itemLayout || mTypeLayout == itemLayout){
            valueText1.setEnabled(false);
        }
        if (StringUtil.isEmpty(value) && mNameLayout == itemLayout){
            valueText1.setHint("请输入姓名");
        }
        if (StringUtil.isEmpty(value) && mTypeLayout == itemLayout){
            valueText1.setHint("请输入年级");
        }

        if (textRes != 0) {
            TextView label = (TextView) itemLayout.findViewById(R.id.label);
            label.setText(textRes);
        }

        if (!StringUtil.isEmpty(value)) {
            TextView valueText = (TextView) itemLayout.findViewById(R.id.value);
            valueText.setText(value);
        }
    }

    @Override
    protected boolean isNeedFetch() {
        return true;
    }

    @Override
    protected void fetchData() {
//        AccountRequest request = new AccountRequest(this, mDefaultLoaderId, new AbstractCallbacks<Account>() {
//            @Override
//            protected void onSuccess(Account account) {
//                mAccountTemp = account;
//                initUserView();
//            }
//        });
//        request.perform();
        MyAccountRequest request = new MyAccountRequest(this, getDefaultLoaderId(), new AbstractCallbacks<MyAccountInfo>() {
            @Override
            protected void onSuccess(MyAccountInfo myAccountInfo) {
                mAccountTemp = myAccountInfo;
                initUserView();
            }
        });
        request.perform();
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.right_layout:
                editMode();
                break;
            case R.id.avatar_layout:
                showChoiceDialog();
                break;
        }

        if (!mEditMode) {
            return;
        }

        switch (v.getId()) {
            case R.id.name_layout:
                mNameEdit.requestFocus();
                String text1 = mNameEdit.getText().toString();
                int length1 = text1.length();
                mNameEdit.setSelection(length1);
                mNameEdit.requestFocus();
                hideKeyboard();
                InputMethodManager imm = (InputMethodManager) mNameEdit.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);

//                navigateToEditDetail(Constants.REQUEST_CODE_NAME, getItemValue(mNameLayout), AppContext.getString(R.string.name));
                break;
            case R.id.type_layout:
                if(mEditMode){
                    mGradeEdit.requestFocus();
                    String text = mGradeEdit.getText().toString();
                    int length = text.length();
                    mGradeEdit.setSelection(length);
                    mGradeEdit.requestFocus();
                    hideKeyboard();
                    InputMethodManager imm1 = (InputMethodManager) mNameEdit.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm1.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);

                }
                //年级取消弹窗
//                showTypeDialog();
                break;
            case R.id.home_layout:
                showAddressDialog();
                break;
            case R.id.gender_layout:
                showGenderDialog();
                break;
            case R.id.signature_layout:
                navigateToEditDetail(Constants.REQUEST_CODE_SIGNATURE,
                        getItemValue(mSignatureLayout),
                        AppContext.getString(R.string.user_signature));
                break;
            case R.id.birthday_layout:
                showBirthDayDialog();
                break;

        }
    }




    private void navigateToEditDetail(int requestCode, String value, String title) {
        Bundle bundle = new Bundle();
        bundle.putString(ProtocolConstants.PARAM_VALUE, value);
        bundle.putString(ProtocolConstants.PARAM_TITLE, title);
        NavigateUtil.navigateToNormalActivityForResult(this, new EditDetailFragment(), bundle,
                requestCode);
    }

    private void showTypeDialog() {
        WheelDialogBuilder wheelDialog = new WheelDialogBuilder(getActivity(),
                new WheelAdapter(UserInfo.UserType.textArray(), UserInfo.UserType.valueArray()),
                new WheelDialogBuilder.WheelSelectListener() {

                    @Override
                    public void onWheelSelected(String text, long value) {
                        mTempGrade =  value+"";
                        setItemValue(mTypeLayout, text);
                    }
                });
        wheelDialog.create().show();
    }

    private void showAddressDialog() {
        if (mAddressDialogBuilder == null) {
            mAddressDialogBuilder = new AddressDialogBuilder(getActivity(), 5, 5, new AddressDialogBuilder.CitySelectListener() {
                @Override
                public void onCitySelected(String province, String city) {
                    mTempProvince = province;
                    mTempCity = city;
                    setItemValue(mHomeLayout, province + "  " + city);
                }
            });
        }
        mAddressDialogBuilder.create().show();
    }

    private void showGenderDialog() {
        WheelDialogBuilder wheelDialog = new WheelDialogBuilder(getActivity(),
                new WheelAdapter(UserInfo.Gender.textArray(), UserInfo.Gender.valueArray()),
                new WheelDialogBuilder.WheelSelectListener() {

                    @Override
                    public void onWheelSelected(String text, long value) {
                        mTempGender = (int) value;
                        setItemValue(mGenderLayout, text);
                    }
                });
        wheelDialog.create().show();
    }

    private void showBirthDayDialog() {
        final Calendar calendar = Calendar.getInstance();
        DateDialogBuilder wheelDialog = new DateDialogBuilder(getActivity(), 5, 5, 5, new DateDialogBuilder.DateSelectListener() {
            @Override
            public void onDateSelected(String year, String month, String day) {
                setItemValue(mBirthDayLayout, year+month+day);
//                text_birth_day.setText(year+month+day);
            }

            @Override
            public void onDateItemSelected(int year, int month, int day) {
                mTempBirthDay = (2017 - year)+"-"+String.format("%02d", month+1)+"-"+String.format("%02d", day+1);
//                com.ddlad.ddlad.primary.Log.e("Signinfo", "mBirthDay-------------------------------------="+mBirthDay);
            }
        });
        wheelDialog.create().show();
    }



    private void editMode() {

        mEditMode = !mEditMode;
        mActionbar.setRightText(mEditMode ? R.string.finish : R.string.edit);

        setItemEditable(mAvatarLayout, mEditMode);
        mAvatarLayout.setSelected(mEditMode);
        setItemEditable(mNameLayout, mEditMode);
        mNameLayout.setSelected(mEditMode);
        setItemEditable(mTypeLayout, mEditMode);
        mTypeLayout.setSelected(mEditMode);
        setItemEditable(mHomeLayout, mEditMode);
        mHomeLayout.setSelected(mEditMode);
        setItemEditable(mGenderLayout, mEditMode);
        mGenderLayout.setSelected(mEditMode);
        setItemEditable(mSignatureLayout, mEditMode);
        mSignatureLayout.setSelected(mEditMode);
        setItemEditable(mBirthDayLayout, mEditMode);
        mBirthDayLayout.setSelected(mEditMode);
        if (!mEditMode) {
            performUpload();
        }
    }

    private void performUpload() {
        if (mTempAvatar != null) {
            UploadImageRequestMy uploadImageRequest = new UploadImageRequestMy(this, mAvatarLoaderId, new AbstractCallbacks<UploadedImage>() {

                @Override
                public void onRequestStart() {
                    startLoading();
                }

                @Override
                protected void onSuccess(UploadedImage uploadedImage) {
                    stopLoading();
                    performUpdateRequest(uploadedImage.getId());
                }

                @Override
                protected void onFail(ApiResponse<UploadedImage> response) {
                    stopLoading();
                    performUpdateRequest("");
                    ResponseMessage.show(response);
                }
            });
            uploadImageRequest.perform(mTempAvatar);
        }else {
            performUpdateRequest("");
        }
    }

    private void performUpdateRequest(String uploadedImageId) {
        if (mTSignture == null){
            mTSignture = "";
        }
        if (mTBirthDay == null){
            mTBirthDay = "";
        }
        if (mTName == null){
            mTName = "";
        }
        if (mTHome == null){
            mTHome = "";
        }
        if (mTGrade == null){
            mTGrade = "";
        }
        if (mNameEdit != null){
            mTempName = mNameEdit.getText().toString().trim();
        }
        if (mGradeEdit != null){
            mTempGrade = mGradeEdit.getText().toString().trim();
        }
        String hometown = (StringUtil.isEmpty(mTempProvince) ? "" : (mTempProvince + "  "))
                + (StringUtil.isEmpty(mTempCity) ? "" : mTempCity);
        if (mTBirthDay.equals(mTempBirthDay) && mTSignture.equals(mTempSignature) && mTName.equals(mTempName) && mTGrade.equals(mTempGrade) && mTHome.equals(hometown)&& mTSex == mTempGender){
            return;
        }else {
            mTBirthDay = mTempBirthDay;
            mTSignture = mTempSignature;
            mTName = mTempName;
            mTGrade = mTempGrade;
            mTHome = hometown;
            mTSex = mTempGender;

        }
        boolean performResult;
        UpdateAccountInfoRequest request = new UpdateAccountInfoRequest(this, mActionLoaderId, new AbstractCallbacks<String>() {
            @Override
            public void onRequestStart() {
                startLoading();
            }

            @Override
            protected void onSuccess(String s) {
                AccountFragment.sAccountUpdated = true;
                Toaster.toastShort(R.string.update_success,1);
                Log.i(TAG, "onSuccess        000000000000000    :  up data has success!!!");
                stopLoading();
            }

            @Override
            protected void onFail(ApiResponse<String> response) {
                ResponseMessage.show(response);
            }
        });
        Log.i(TAG, "editMode: mtempProvince"+mTempProvince);
        Log.i(TAG, "editMode: mtempProvince"+mTempCity);
        Log.i(TAG, "editMode: mtempProvince"+mTempSignature);


        performResult = request.perform( mTempBirthDay,mTempName, mTempProvince, mTempCity, mTempGender, mTempSignature, mTempGrade,uploadedImageId);
        if (!performResult) {
            stopLoading();
        }
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (Activity.RESULT_OK != resultCode) {
            return;
        }

        switch (requestCode) {
            case Constants.REQUEST_CODE_NAME:
                if (data != null && data.getExtras() != null) {
                    mTempName = data.getExtras().getString(ProtocolConstants.PARAM_VALUE);
                    setItemValue(mNameLayout, mTempName);
                }
                break;
            case Constants.REQUEST_CODE_SIGNATURE:
                if (data != null && data.getExtras() != null) {
                    mTempSignature = data.getExtras().getString(ProtocolConstants.PARAM_VALUE);
                    setItemValue(mSignatureLayout, mTempSignature);
                }
                break;
            case Constants.REQUEST_CODE_TAKE_PHOTO:
            case Constants.REQUEST_CODE_CHOOSE_IMAGE:
                CropUtil.cropImage(getActivity(), data, mTempImage);
                break;
            case Constants.REQUEST_CODE_CROP_IMAGE:
                updateAvatar(data);
                break;
        }
    }



    private void updateAvatar(Intent data) {
        mTempAvatar = Uri.parse(data.getAction());
        CircleImageView avatar = (CircleImageView) mAvatarLayout.findViewById(R.id.icon);
        avatar.setImageURI(mTempAvatar);
    }

    private void showChoiceDialog() {

        if (mChoiceDialog == null) {
            mChoiceDialog = new BottomDialogBuilder(getActivity());
            String[] items = new String[]{AppContext.getString(R.string.take_photo),
                    AppContext.getString(R.string.choose_image)};
            mChoiceDialog.setItems(items, new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    switch (i) {
                        case 0:
                            mTempImage = CameraUtil.takePhoto(getActivity());
                            break;
                        case 1:
                            mTempImage = GalleryUtil.chooseImage(getActivity());
                            break;
                    }
                }
            });
        }

        if (mEditMode) {
            mChoiceDialog.create().show();
        }
    }



}
