package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.IOException;

/**
 * Created by Administrator on 2017/2/6 0006.
 */

public class HomeworkInfo extends BaseInfo {

//    hid: "homeworkid1",
//    course: "Java初级入门课",
//    teacher: "wangsch",
//    title: "Java关键字默写一万遍",
//    status: 0,
//    date: "2017-01-19",
//    time: "19:00 - 20:00"
    private String hid;
    private String course;
    private String teacher;
    private String title;
    private int status;
    private String date;
    private String time;

    public String getHid() {
        return hid;
    }

    public void setHid(String hid) {
        this.hid = hid;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public static HomeworkInfo fromJsonParser(JsonParser jsonParser) throws IOException {
        HomeworkInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new HomeworkInfo();
                }

                if ("hid".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.hid = jsonParser.getText();

                    continue;
                }

                if ("course".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.course = jsonParser.getText();
                    continue;
                }
                if ("teacher".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.teacher = jsonParser.getText();
                    continue;
                }

                if ("title".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.title = jsonParser.getText();
                    continue;
                }

                if ("status".equals(fieldName)){
                    jsonParser.nextToken();
                    info.status = jsonParser.getIntValue();
                    continue;
                }

                if ("date".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.date = jsonParser.getText();
                    continue;
                }

                if ("time".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.time = jsonParser.getText();
                    continue;
                }
                jsonParser.skipChildren();


            }
        }
        return info;
    }
}
