package com.ddlad.student.primary;

import android.text.TextUtils;


import com.ddlad.student.protocol.http.internal.ProtocolConstants;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.zip.GZIPInputStream;

import ch.boye.httpclientandroidlib.Header;
import ch.boye.httpclientandroidlib.HttpEntity;
import ch.boye.httpclientandroidlib.HttpResponse;
import ch.boye.httpclientandroidlib.client.methods.HttpGet;
import ch.boye.httpclientandroidlib.client.methods.HttpPost;
import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;
import ch.boye.httpclientandroidlib.entity.ByteArrayEntity;

public class HttpManager {

    private static final String TAG = "HttpManager";

    private static final String BOUNDARY = getBoundry();

    private static final String MP_BOUNDARY = "--" + BOUNDARY;

    private static final String END_MP_BOUNDARY = "--" + BOUNDARY + "--";

    private static final String MULTIPART_FORM_DATA = "multipart/form-data";

    public interface ThirdPartyListener {

        void onComplete(String resp);

        void onError(Exception e);
    }

    /**
     * @param url         服务器地址
     * @param params      存放参数的容器
     * @param inputStream 发送图片的，不需要则传null
     * @return 响应结果
     */

    public static void request(final String url, final com.ddlad.student.primary.ThirdParams params,
                               final InputStream inputStream, final String httpMethod,
                               final ThirdPartyListener listener) {

        request(url, params, inputStream, httpMethod, null, listener);
    }

    /**
     * @param url                       服务器地址
     * @param params                    存放参数的容器
     * @param inputStream               发送图片的，不需要则传null
     * @param customAuthorizationHeader 自定义Authorization Header (人人api需要)
     * @return 响应结果
     */

    public static void request(final String url, final com.ddlad.student.primary.ThirdParams params,
                               final InputStream inputStream, final String httpMethod,
                               final String customAuthorizationHeader, final ThirdPartyListener listener) {
        new Thread() {

            @Override
            public void run() {
                try {
                    String resp = openUrl(url, httpMethod, params, inputStream,
                            customAuthorizationHeader);

                    if (Log.DEBUG) {
                        Log.d(TAG, "openUrl=" + url + "; httpMethod=" + httpMethod + ";resp= "
                                + resp);
                    }

                    listener.onComplete(resp);
                } catch (Exception e) {
                    listener.onError(e);
                }
            }
        }.start();

    }

    public static String openUrl(String url, String method, com.ddlad.student.primary.ThirdParams params,
                                 InputStream inputStream, String authHeader) throws IOException {

        String result = "";

        HttpUriRequest request = null;
        ByteArrayOutputStream bos = null;

        if (method.equals(ProtocolConstants.HTTP_METHOD_GET)) {
            url = url + "?" + encodeUrl(params);
            HttpGet get = new HttpGet(url);
            request = get;
        }

        if (method.equals(ProtocolConstants.HTTP_METHOD_POST)) {
            HttpPost post = new HttpPost(url);
            request = post;
            byte[] data = null;
            String _contentType = params.getValue("content-type");

            bos = new ByteArrayOutputStream();

            if (inputStream != null) {

                post.setHeader("Content-Type", MULTIPART_FORM_DATA + ";boundary=" + BOUNDARY);
                paramToUpload(bos, params);

                imageContentToUpload(bos, inputStream, !TextUtils.isEmpty(authHeader) ? "file" : "pic", "file");
            } else {
                if (_contentType != null) {
                    params.remove("content-type");
                    post.setHeader("Content-Type", _contentType);
                } else {
                    post.setHeader("Content-Type", "application/x-www-form-urlencoded");
                }

                String postParam = encodeParameters(params);
                data = postParam.getBytes("UTF-8");
                bos.write(data);

            }

            data = bos.toByteArray();
            bos.close();
            ByteArrayEntity formEntity = new ByteArrayEntity(data);
            post.setEntity(formEntity);

        }

        if (!TextUtils.isEmpty(authHeader)) {
            request.addHeader("Authorization", authHeader);
        }

        HttpResponse response = CommonHttpClient.getInstance().sendRequest(request);

        result = readHttpResponse(response);

        return result;
    }

    /**
     * 读取HttpResponse数据
     *
     * @param response
     * @return
     */
    private static String readHttpResponse(HttpResponse response) {
        String result = "";
        HttpEntity entity = response.getEntity();
        InputStream inputStream = null;
        try {
            inputStream = entity.getContent();
            ByteArrayOutputStream content = new ByteArrayOutputStream();

            Header header = response.getFirstHeader("Content-Encoding");
            if (header != null && header.getValue().toLowerCase().indexOf("gzip") > -1) {
                inputStream = new GZIPInputStream(inputStream);
            }

            int readBytes = 0;
            byte[] sBuffer = new byte[512];
            while ((readBytes = inputStream.read(sBuffer)) != -1) {
                content.write(sBuffer, 0, readBytes);
            }
            result = new String(content.toByteArray());
            return result;
        } catch (IllegalStateException e) {

        } catch (IOException e) {

        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }
        return result;
    }

    /**
     * 产生11位的boundary
     */
    static String getBoundry() {
        StringBuffer _sb = new StringBuffer();
        for (int t = 1; t < 12; t++) {
            long time = System.currentTimeMillis() + t;
            if (time % 3 == 0) {
                _sb.append((char) time % 9);
            } else if (time % 3 == 1) {
                _sb.append((char) (65 + time % 26));
            } else {
                _sb.append((char) (97 + time % 26));
            }
        }
        return _sb.toString();
    }

    /**
     * 参数拼装url
     */

    public static String encodeUrl(com.ddlad.student.primary.ThirdParams thirdParams) {
        if (thirdParams == null) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (int loc = 0; loc < thirdParams.size(); loc++) {
            if (first) {
                first = false;
            } else {
                sb.append("&");
            }
            String _key = thirdParams.getKey(loc);
            String _value = thirdParams.getValue(_key);
            if (_value != null) {

                try {
                    sb.append(URLEncoder.encode(thirdParams.getKey(loc), "UTF-8") + "="
                            + URLEncoder.encode(thirdParams.getValue(loc), "UTF-8"));
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }

        }
        return sb.toString();
    }

    public static String encodeParameters(com.ddlad.student.primary.ThirdParams httpParams) {
        if (null == httpParams || isBundleEmpty(httpParams)) {
            return "";
        }
        StringBuilder buf = new StringBuilder();
        int j = 0;
        for (int loc = 0; loc < httpParams.size(); loc++) {
            String key = httpParams.getKey(loc);
            if (j != 0) {
                buf.append("&");
            }
            try {
                buf.append(URLEncoder.encode(key, "UTF-8")).append("=")
                        .append(URLEncoder.encode(httpParams.getValue(key), "UTF-8"));
            } catch (java.io.UnsupportedEncodingException neverHappen) {
            }
            j++;
        }
        return buf.toString();

    }

    private static void paramToUpload(OutputStream baos, com.ddlad.student.primary.ThirdParams params) throws IOException {
        String key = "";
        for (int loc = 0; loc < params.size(); loc++) {
            key = params.getKey(loc);
            StringBuilder temp = new StringBuilder(10);
            temp.setLength(0);
            temp.append(MP_BOUNDARY).append("\r\n");
            temp.append("content-disposition: form-data; name=\"").append(key).append("\"\r\n\r\n");
            temp.append(params.getValue(key)).append("\r\n");
            byte[] res = temp.toString().getBytes();
            baos.write(res);
        }
    }

    private static boolean isBundleEmpty(com.ddlad.student.primary.ThirdParams bundle) {
        if (bundle == null || bundle.size() == 0) {
            return true;
        }
        return false;
    }

    private static void imageContentToUpload(OutputStream output, InputStream input,
                                             String paramName, String fileName) throws IOException {
        StringBuilder temp = new StringBuilder();

        temp.append(MP_BOUNDARY).append("\r\n");
        temp.append("Content-Disposition: form-data; name=\"").append(paramName)
                .append("\"; filename=\"").append(fileName).append("\"\r\n");
        String filetype = "image/jpg";
        temp.append("Content-Type: ").append(filetype).append("\r\n\r\n");

        byte[] res = temp.toString().getBytes();

        output.write(res);

        byte[] buffer = new byte[1024 * 8];
        while (true) {
            int count = input.read(buffer);
            if (count == -1) {
                break;
            }

            output.write(buffer, 0, count);
        }
        output.write("\r\n".getBytes());
        output.write(("\r\n" + END_MP_BOUNDARY + "\r\n").getBytes());

        if (input != null) {
            input.close();
        }

    }
}
