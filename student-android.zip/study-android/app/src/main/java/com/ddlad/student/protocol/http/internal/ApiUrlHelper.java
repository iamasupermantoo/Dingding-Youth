package com.ddlad.student.protocol.http.internal;

import android.text.TextUtils;


import com.ddlad.student.protocol.convert.DataCenter;

import java.net.URLEncoder;

public class ApiUrlHelper {

//    public static final String API_HOST = String.format("api.%s", ProtocolConstants.DOMAIN);
    //增加彩蛋，去掉了final
    public static  String API_HOST = String.format("api.%s", ProtocolConstants.DOMAIN);

    public static final String API_OAUTH_HOST = String.format("api.%s",ProtocolConstants.DOMAIN);

    public static final String API_VERSION = "/";

    public static String expandPath(String path) {
        return expandPath(path, false, true);
    }

    public static String expandPath(String path, boolean isSSL, boolean expandApiVersionPath) {
        return expandPath(path, isSSL, expandApiVersionPath, API_VERSION);
    }

    public static String expandPath(String path, boolean isSSL, boolean expandApiVersionPath,
                                    String apiVersion) {

        String url = (apiVersion == null) ? String.format("%s://%s%s", (isSSL ? "https" : "http"),
                expandApiVersionPath ? API_HOST : API_OAUTH_HOST, path) : String.format(
                "%s://%s%s%s", (isSSL ? "https" : "http"), expandApiVersionPath ? API_HOST
                        : API_OAUTH_HOST, (expandApiVersionPath ? apiVersion : "/"), path);

        return appendExtraToPath(url);
    }

    public static String appendExtraToPath(String origURL) {

        StringBuilder sb = new StringBuilder(origURL);

        String accessToken = getAccessToken();
        String userAgent = getUserAgent();
        String acceptLanguage = getAcceptLanguage();

        if (!TextUtils.isEmpty(ApiHttpClient.MAC_ADDRESS)) {
            sb.append((origURL.indexOf("?") == -1) ? "?" : "&");
            sb.append(ProtocolConstants.PARAM_DEVICE_MAC).append("=")
                    .append(ApiHttpClient.MAC_ADDRESS);
        }

        if (!TextUtils.isEmpty(ApiHttpClient.DEVICE_ID)) {
            sb.append((sb.toString().indexOf("?") == -1) ? "?" : "&");
            sb.append(ProtocolConstants.PARAM_DEVICE_ID).append("=").append(ApiHttpClient.DEVICE_ID);
        }

        if (!TextUtils.isEmpty(accessToken)) {
            sb.append((sb.toString().indexOf("?") == -1) ? "?" : "&");
            sb.append("z").append("=").append(accessToken);
        }

        if (!TextUtils.isEmpty(userAgent)) {
            sb.append((sb.toString().indexOf("?") == -1) ? "?" : "&");
            sb.append(ProtocolConstants.PARAM_USER_AGENT).append("=").append(userAgent);
        }

        if (!TextUtils.isEmpty(acceptLanguage)) {
            sb.append((sb.toString().indexOf("?") == -1) ? "?" : "&");
            sb.append(ProtocolConstants.PARAM_ACCEPT_LANGUAGE).append("=").append(acceptLanguage);
        }

        return sb.toString();
    }

    private static String getAccessToken() {

        if (!DataCenter.isLogin()) {
            return null;
        }

        String token = DataCenter.getAccount().getZ();

        if (TextUtils.isEmpty(token)) {
            return null;
        } else {
            try {
                token = URLEncoder.encode(token, "UTF-8");
            } catch (Exception e) {
                e.printStackTrace();
            }
            return token;
        }
    }

    private static String getUserAgent() {
        String userAgent = null;
        try {
            userAgent = URLEncoder.encode(ApiHttpClient.USER_AGENT, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return userAgent;
    }

    private static String getAcceptLanguage() {
        String acceptLanguage = null;
        try {
            acceptLanguage = URLEncoder.encode(ApiHttpClient.getCurrentAcceptLanguage(), "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return acceptLanguage;
    }

}
