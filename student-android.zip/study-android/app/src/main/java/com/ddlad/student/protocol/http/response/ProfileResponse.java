package com.ddlad.student.protocol.http.response;


import com.ddlad.student.protocol.model.Account;
import com.ddlad.student.protocol.model.BaseInfo;

/**
 * Created by Albert
 * on 16-11-17.
 */
public class ProfileResponse extends BaseInfo {

    private Account profile;
    private int followStatus;

    public Account getProfile() {
        return profile;
    }

    public void setProfile(Account profile) {
        this.profile = profile;
    }

    public int getFollowStatus() {
        return followStatus;
    }

    public void setFollowStatus(int followStatus) {
        this.followStatus = followStatus;
    }

}
