package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.Account;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.protocol.http.internal.ApiResponse;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-6-30.
 */
public class UserBindingLoginRequest extends AbstractRequest<Account> {

    public UserBindingLoginRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<Account> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_LOGIN_BIND;
    }

    @Override
    public Account processInBackground(ApiResponse<Account> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA,Account.class);
    }

    public void perform(Object mobile,String code ,int type , String externalUserId,String accessToken, String name) {
        RequestParams params = getParams();
        params.put(ProtocolConstants.PARAM_MOBILE, mobile);
        params.put(ProtocolConstants.PARAM_CODE, code);
        params.put(ProtocolConstants.PARAM_TYPE, type);
        params.put(ProtocolConstants.PARAM_EXTERNAL_USERID, externalUserId);
        params.put(ProtocolConstants.PARAM_ACCESSTOKEN, accessToken);
        params.put(ProtocolConstants.PARAM_NICKNAME, name);
        super.perform();
    }
}
