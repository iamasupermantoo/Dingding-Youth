package com.ddlad.student.protocol.model;

/**
 * Created by chenjianing on 2017/4/19 0019.
 */
public class PayParamsInfo {

        /**
         * orderSn : Z0AvZyxXZy
         * weiXin : {"noncestr":"6NR3WixVH2SUzNwdQnRyz1hRzBEs0eQT","timestamp":"1492591880","sign":"2DDAEC6F07542880FDFC5702E7900333","package":"Sign=WXPay"}
         */

        private ParamsBean params;

        public ParamsBean getParams() {
            return params;
        }

        public void setParams(ParamsBean params) {
            this.params = params;
        }

        public static class ParamsBean {
            private String orderSn;
            /**
             * noncestr : 6NR3WixVH2SUzNwdQnRyz1hRzBEs0eQT
             * timestamp : 1492591880
             * sign : 2DDAEC6F07542880FDFC5702E7900333
             * package : Sign=WXPay
             */
            private AlipayBean alipay;

            public AlipayBean getAlipay() {
                return alipay;
            }

            public void setAlipay(AlipayBean alipay) {
                this.alipay = alipay;
            }


            public static class AlipayBean {
                private String orderStr;

                public String getOrderStr() {
                    return orderStr;
                }

                public void setOrderStr(String orderStr) {
                    this.orderStr = orderStr;
                }
            }
            private WeiXinBean weiXin;

            public String getOrderSn() {
                return orderSn;
            }

            public void setOrderSn(String orderSn) {
                this.orderSn = orderSn;
            }

            public WeiXinBean getWeiXin() {
                return weiXin;
            }

            public void setWeiXin(WeiXinBean weiXin) {
                this.weiXin = weiXin;
            }

            public static class WeiXinBean {
                private String noncestr;
                private String timestamp;
                private String sign;
                private String packageStr;
                private String prepayid;
                private String appid;

                public String getPartnerid() {
                    return partnerid;
                }

                public void setPartnerid(String partnerid) {
                    this.partnerid = partnerid;
                }

                public String getAppid() {
                    return appid;
                }

                public void setAppid(String appid) {
                    this.appid = appid;
                }

                public String getPrepayid() {
                    return prepayid;
                }

                public void setPrepayid(String prepayid) {
                    this.prepayid = prepayid;
                }

                public String getPackageStr() {
                    return packageStr;
                }

                public void setPackageStr(String packageStr) {
                    this.packageStr = packageStr;
                }

                private String partnerid;

                public String getNoncestr() {
                    return noncestr;
                }

                public void setNoncestr(String noncestr) {
                    this.noncestr = noncestr;
                }

                public String getTimestamp() {
                    return timestamp;
                }

                public void setTimestamp(String timestamp) {
                    this.timestamp = timestamp;
                }

                public String getSign() {
                    return sign;
                }

                public void setSign(String sign) {
                    this.sign = sign;
                }

            }
        }
}
