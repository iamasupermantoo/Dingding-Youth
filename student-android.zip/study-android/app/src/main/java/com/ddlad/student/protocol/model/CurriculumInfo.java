package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.ui.model.MultiImageInfo;

import java.io.IOException;

/**
 * Created by Administrator on 2017/1/16 0016.
 */

public class CurriculumInfo extends BaseInfo {

    private String cid;

    public String getCmId() {
        return cmId;
    }

    public void setCmId(String cmId) {
        this.cmId = cmId;
    }

    private String cmId;
    private MultiImageInfo image;
    private String name;
    private int totalCnt;
    private String teacher;

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public MultiImageInfo getImage() {
        return image;
    }

    public void setImage(MultiImageInfo image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTotalCnt() {
        return totalCnt;
    }

    public void setTotalCnt(int totalCnt) {
        this.totalCnt = totalCnt;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    public static CurriculumInfo fromJsonParser(JsonParser jsonParser) throws IOException {
        CurriculumInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new CurriculumInfo();
                }

                if ("cid".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.cid = jsonParser.getText();
                    continue;
                }
                if ("cmId".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.cmId = jsonParser.getText();
                    continue;
                }

                if ("image".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.image = MultiImageInfo.fromJsonParser(jsonParser);
                    continue;
                }

                if ("name".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.name = jsonParser.getText();
                    continue;
                }

                if ("totalCnt".equals(fieldName)){
                    jsonParser.nextToken();
                    info.totalCnt = jsonParser.getIntValue();
                    continue;
                }

                if ("teacher".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.teacher = jsonParser.getText();
                    continue;
                }
                jsonParser.skipChildren();


            }
        }
        return info;
    }
}
