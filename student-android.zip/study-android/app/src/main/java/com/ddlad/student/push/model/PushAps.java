package com.ddlad.student.push.model;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.IOException;
import java.io.Serializable;

public class PushAps implements Serializable {

    private static final long serialVersionUID = 3962576227235027127L;

    private int badge;

    private String alert;

    public int getBadge() {
        return badge;
    }

    public void setBadge(int badge) {
        this.badge = badge;
    }

    public String getAlert() {
        return alert;
    }

    public void setAlert(String alert) {
        this.alert = alert;
    }

    public static PushAps fromJsonParser(JsonParser jsonParser) throws JsonParseException,
            IOException {

        PushAps pushAps = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (pushAps == null) {
                    pushAps = new PushAps();
                }

                if ("badge".equals(fieldName)) {
                    jsonParser.nextToken();
                    pushAps.badge = jsonParser.getIntValue();
                    continue;
                }

                if ("alert".equals(fieldName)) {
                    jsonParser.nextToken();
                    pushAps.alert = jsonParser.getText();
                    continue;
                }

                jsonParser.skipChildren();
            }
        }

        return pushAps;
    }

}
