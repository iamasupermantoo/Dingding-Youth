package com.ddlad.student.protocol.http.response;

import com.ddlad.student.protocol.http.response.LooseListResponse;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.protocol.model.Person;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Albert
 * on 16-10-28.
 */
public class UserSearchResponse extends AbstractListResponse<Person> {

    @Override
    public Person getModelInfo(JsonParser jsonParser) {

        try {
            return Person.fromJsonParser(jsonParser);
        } catch (Throwable t) {
            t.printStackTrace();
        }

        return null;
    }

    @Override
    protected void fromJsonParser(JsonParser jsonParser) throws IOException {
        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            if (mLooseListResponse == null) {
                mLooseListResponse = new LooseListResponse<>();
            }

            List<Person> list = new ArrayList<>();

            while (jsonParser.nextToken() != JsonToken.END_ARRAY) {
                Person info = getModelInfo(jsonParser);
                if (info != null) {
                    initModelInfo(info);
                    list.add(info);
                }
                continue;
            }

            mLooseListResponse.setList(list);
        }
    }
}