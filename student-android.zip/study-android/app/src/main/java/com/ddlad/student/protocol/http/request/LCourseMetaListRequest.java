package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.request.BaseListRequest;
import com.fasterxml.jackson.core.JsonParser;
import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.http.internal.StreamingApiResponse;
import com.ddlad.student.protocol.model.CourseMetaListInfo;
import com.ddlad.student.ui.common.BaseListFragment;

import java.io.IOException;

/**
 * Created by chenjianing
 * on 17-04-21.
 */
public class LCourseMetaListRequest extends BaseListRequest<CourseMetaListInfo> {



    public LCourseMetaListRequest(BaseListFragment baseListFragment, int loaderId, AbstractStreamingCallbacks<AbstractListResponse<CourseMetaListInfo>> streamingApiCallbacks) {
        super(baseListFragment, loaderId, streamingApiCallbacks);
    }

    @Override
    protected String getBasePath() {
        return "course/meta/list";
    }

    protected String getFieldKey() {
        return "courses";
//        return "";
    }



    @Override
    public void processResponseField(String fieldName, JsonParser jsonParser,
                                     StreamingApiResponse<AbstractListResponse<CourseMetaListInfo>> streamingApiResponse) throws IOException {

        AbstractListResponse response = streamingApiResponse.getSuccessObject();
        if (response == null) {
            response = new AbstractListResponse() {
                @Override
                public CourseMetaListInfo getModelInfo(JsonParser jsonParser) {
                    try {
                        return CourseMetaListInfo.fromJsonParser(jsonParser);
                    } catch (Throwable t) {
                        t.printStackTrace();
                    }

                    return null;
                }
            };
        }
        response.parse(jsonParser, getFieldKey());
        streamingApiResponse.setSuccessObject(response);
    }



    public void perform(String cursor) {
        RequestParams params = getParams();
//        params.put("hid", hid);
//        params.put("cursor", cursor);
        super.perform();
    }
}

