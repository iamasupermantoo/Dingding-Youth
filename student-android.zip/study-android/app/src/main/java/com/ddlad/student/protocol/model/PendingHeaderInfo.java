package com.ddlad.student.protocol.model;

/**
 * Created by Administrator on 2017/2/8 0008.
 */

public class PendingHeaderInfo extends BaseInfo {

    private PendingDetails details;
    private PendingAnswers answers;

    public PendingAnswers getAnswers() {
        return answers;
    }

    public void setAnswers(PendingAnswers answers) {
        this.answers = answers;
    }

    public PendingDetails getDetails() {
        return details;
    }

    public void setDetails(PendingDetails details) {
        this.details = details;
    }

    public class PendingAnswers{
        
    }

    public class PendingDetails {

        //        date: "2017-02-12",
//        time: "10:10 - 12:10",
//        hid: "sh27hheflsE9RzEFBVF2BQ",
//        status: 0,
//        title: "这是数据库里边的作业title",
//        teacher: "wangsch",
//        course: "Java高级课程",
//        content: "这是数据库里边的作业content"
        private String date;
        private String time;
        private String hid;
        private int status;
        private String title;
        private String teacher;
        private String course;
        private String content;

        private String correctDate;
        private String remark;
        private boolean intime;
        private int complete;
        private int quality;




        public String getCorrectDate() {
            return correctDate;
        }

        public void setCorrectDate(String correctDate) {
            this.correctDate = correctDate;
        }
        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public boolean isIntime() {
            return intime;
        }

        public void setIntime(boolean intime) {
            this.intime = intime;
        }

        public int getComplete() {
            return complete;
        }

        public void setComplete(int complete) {
            this.complete = complete;
        }


        public int getQuality() {
            return quality;
        }

        public void setQuality(int quality) {
            this.quality = quality;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public String getTime() {
            return time;
        }

        public void setTime(String time) {
            this.time = time;
        }

        public String getHid() {
            return hid;
        }

        public void setHid(String hid) {
            this.hid = hid;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getTeacher() {
            return teacher;
        }

        public void setTeacher(String teacher) {
            this.teacher = teacher;
        }

        public String getCourse() {
            return course;
        }

        public void setCourse(String course) {
            this.course = course;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }
    }
}
