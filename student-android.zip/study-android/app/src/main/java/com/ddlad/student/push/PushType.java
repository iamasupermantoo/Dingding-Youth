package com.ddlad.student.push;

public enum PushType {

    /**
     * 0 	gotoPage，显示在head上，点击后gotoPage
     * 1 	只显示在手机的head上
     * 2	在后台默默地清一下客户端缓存（预留）
     * 3	在后台默默地调用服务端接口，上传crash log（预留）
     */

    GoToPage(0, "GoToPage"), Notify(1, "Notify"), ClearCache(2, "ClearCache"), UploadLog(3, "UploadLog");

    private int value;
    private String text;

    private PushType(int value, String text) {
        this.value = value;
        this.text = text;
    }

    public int getValue() {
        return value;
    }

    public String getText() {
        return text;
    }
}
