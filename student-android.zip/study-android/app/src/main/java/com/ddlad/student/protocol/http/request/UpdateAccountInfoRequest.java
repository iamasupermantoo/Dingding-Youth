package com.ddlad.student.protocol.http.request;



import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.tools.StringUtil;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-11-1.
 */
public class UpdateAccountInfoRequest extends AbstractRequest<String> {

    public UpdateAccountInfoRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<String> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_COLLEGE_UPDATE;
    }

    @Override
    public String processInBackground(ApiResponse<String> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, String.class);
    }

    public boolean perform(String birthday, String name, String province, String region, int gender,
                           String signature,String grade,String headImage) {

        RequestParams params = getParams();

        params.put("birthday", birthday);

        if (StringUtil.isEmpty(name)) {
            Toaster.toastShort(R.string.edit_info_empty, AppContext.getString(R.string.name));
            return false;
        } else {
            params.put("name", name);
        }
        ///年级
        params.put("grade", grade);

        if (StringUtil.isEmpty(province)) {
            Toaster.toastShort(R.string.edit_info_empty, AppContext.getString(R.string.province));
            return false;
        } else {
            params.put("province", province);
        }
        ////家乡：
        if (StringUtil.isEmpty(region)) {
            Toaster.toastShort(R.string.edit_info_empty, AppContext.getString(R.string.city));
            return false;
        } else {
            params.put("region", region);
        }

        if (gender < 0) {
            Toaster.toastShort(R.string.edit_info_empty, AppContext.getString(R.string.gender));
            return false;
        } else {
            params.put("gender", gender);
        }
        if (!StringUtil.isEmpty(signature)) {
            params.put("signature", signature);
        }

        ///////////////////zzzzzzzzzzzzzzzzzzzz

        if (!StringUtil.isEmpty(headImage)) {
            params.put("headImg", headImage);
        }
        super.perform();
        return true;
    }

}
