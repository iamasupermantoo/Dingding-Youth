package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ddlad.student.protocol.http.internal.CustomObjectMapper;

import java.io.Serializable;

/**
 * Created by Albert
 * on 16-5-30.
 */
public class AccountInfo implements Serializable {

    private static final long serialVersionUID = -511129335541555034L;

    private String l;
    private String mEmail;
    private String mName;
    private String mPassword;
    private String mHeadImgUrl;
    private int mLessonCnt;
    private int mStudentCnt;

    public String getL() {
        return l;
    }

    public void setL(String token) {
        this.l = token;
    }

    public String getEmail() {
        return mEmail;
    }

    public String getName() {
        return mName;
    }

    public String getPassword() {
        return mPassword;
    }

    public String getHeadImgUrl() {
        return mHeadImgUrl;
    }

    public void setEmail(String email) {
        this.mEmail = email;
    }

    public void setName(String name) {
        this.mName = name;
    }

    public void setPassword(String password) {
        this.mPassword = password;
    }

    public void setHeadImgUrl(String headImage) {
        this.mHeadImgUrl = headImage;
    }

    public int getLessonCnt() {
        return mLessonCnt;
    }

    public void setLessonCnt(int count) {
        this.mLessonCnt = count;
    }

    public int getStudentCnt() {
        return mStudentCnt;
    }

    public void setStudentCnt(int count) {
        this.mStudentCnt = count;
    }

    public String serialize() {
        try {
            ObjectMapper mapper = CustomObjectMapper.getInstance();
            return mapper.writeValueAsString(this);
        } catch (Throwable t) {
            t.printStackTrace();
        }

        return null;
    }

    public static AccountInfo deserialize(String accountJson) {

        try {
            return CustomObjectMapper.getInstance().readValue(accountJson, AccountInfo.class);
        } catch (Throwable t) {
            t.printStackTrace();
        }

        return null;
    }
}
