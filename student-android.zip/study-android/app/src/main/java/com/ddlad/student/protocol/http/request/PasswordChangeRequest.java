package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-10-18.
 */
public class PasswordChangeRequest extends AbstractRequest<String> {

    public PasswordChangeRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<String> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_PASSWORD_CHANGE;
    }

    @Override
    public String processInBackground(ApiResponse<String> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, String.class);
    }

    public void perform(Object oldPassword,Object newPassword) {
        RequestParams params = getParams();
        params.put("oldpasswd", oldPassword);
        params.put("newpasswd", newPassword);
        super.perform();
    }
}