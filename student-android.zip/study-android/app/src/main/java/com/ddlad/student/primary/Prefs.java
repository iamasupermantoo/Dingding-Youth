package com.ddlad.student.primary;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;

import com.ddlad.student.primary.AppContext;
import com.ddlad.student.wxapi.WechatAccount;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;

/**
 * Created by Albert
 * on 16-6-15.
 */
public class Prefs {

    public static final String PREFS_SERVICE = "com.udan.preferences";

    public static final String PREFS_LOGIN = "PREFS_LOGIN";

    public static final String PREFS_ACCOUNT = "PREFS_ACCOUNT";

    public static final String PREFS_WECHAT = "PREFS_WECHAT_";

    public static final String PREFS_GETUI_PUSH_CID = "PREFS_GETUI_PUSH_CID";

    public static final String PREFS_PUSH_CONFIG = "PREFS_PUSH_CONFIG";

    public SharedPreferences mPrefs;

    public Prefs(Context context) {
        this.mPrefs = PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static Prefs getInstance() {
        Prefs prefs = (Prefs) AppContext.getContext().getSystemService(PREFS_SERVICE);

        if (prefs == null) {
            prefs = (Prefs) AppContext.getContext().getSystemService(PREFS_SERVICE);
        }

        if (prefs == null) {
            throw new IllegalStateException("Preferences not available");
        }

        return prefs;
    }

    public boolean isLogin() {
        return mPrefs.getBoolean(PREFS_LOGIN, false);
    }

    public void saveLogin(boolean isLogin) {
        SharedPreferences.Editor editor = mPrefs.edit();
        editor.putBoolean(PREFS_LOGIN, isLogin);
        editor.apply();
    }

    public void clearLogin() {
        mPrefs.edit().remove(PREFS_LOGIN).apply();
    }

    public String getAccount() {
        return mPrefs.getString(PREFS_ACCOUNT, null);
    }

    public boolean saveAccount(String accountJson) {
        return mPrefs.edit().putString(PREFS_ACCOUNT, accountJson).commit();
    }

    public void clearAccount() {
        mPrefs.edit().remove(PREFS_ACCOUNT).apply();
    }

    public void clearWechat() {
        mPrefs.edit()
                .remove(PREFS_WECHAT + ProtocolConstants.PARAM_ACCESS_TOKEN)
                .remove(PREFS_WECHAT + ProtocolConstants.PARAM_OPEN_ID)
                .remove(PREFS_WECHAT + ProtocolConstants.PARAM_REFRESH_TOKEN)
                .apply();
    }

    public WechatAccount saveWechat(String accessToken, String openId, String refreshToken) {

        SharedPreferences.Editor editor = mPrefs.edit();

        if (!TextUtils.isEmpty(accessToken)) {
            editor.putString(PREFS_WECHAT + ProtocolConstants.PARAM_ACCESS_TOKEN, accessToken);
        }
        if (!TextUtils.isEmpty(openId)) {
            editor.putString(PREFS_WECHAT + ProtocolConstants.PARAM_OPEN_ID, openId);
        }
        if (!TextUtils.isEmpty(refreshToken)) {
            editor.putString(PREFS_WECHAT + ProtocolConstants.PARAM_REFRESH_TOKEN, refreshToken);
        }

        editor.apply();

        return getWechat();
    }

    public WechatAccount getWechat() {

        WechatAccount wechatAccount = null;

        String accessToken = mPrefs.getString(PREFS_WECHAT + ProtocolConstants.PARAM_ACCESS_TOKEN, null);
        String openId = mPrefs.getString(PREFS_WECHAT + ProtocolConstants.PARAM_OPEN_ID, null);
        String refreshToken = mPrefs.getString(PREFS_WECHAT + ProtocolConstants.PARAM_REFRESH_TOKEN, null);

        if (!TextUtils.isEmpty(accessToken)) {
            wechatAccount = new WechatAccount(accessToken, openId, refreshToken);
        }

        return wechatAccount;
    }

    public String getGetuiPushCid() {
        return mPrefs.getString(PREFS_GETUI_PUSH_CID, "");
    }

    public void saveGetuiPushCid(String pushCid) {
        mPrefs.edit().putString(PREFS_GETUI_PUSH_CID, pushCid).commit();
    }

    public void clearGetuiPushCid() {
        mPrefs.edit().remove(PREFS_GETUI_PUSH_CID).commit();
    }

    public boolean getPushConfig() {
        return mPrefs.getBoolean(PREFS_PUSH_CONFIG, true);
    }

    public void savePushConfig(boolean open) {
        mPrefs.edit().putBoolean(PREFS_PUSH_CONFIG, open).commit();
    }

    public void clearPushConfig() {
        mPrefs.edit().remove(PREFS_PUSH_CONFIG).commit();
    }

}
