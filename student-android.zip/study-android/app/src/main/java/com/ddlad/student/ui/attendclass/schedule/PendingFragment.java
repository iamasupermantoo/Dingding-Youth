package com.ddlad.student.ui.attendclass.schedule;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.request.SubmitAnswerRequest;
import com.ddlad.student.tools.CameraUtil;
import com.ddlad.student.tools.Constants;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.request.HomeWorkDetailsRequest;
import com.ddlad.student.protocol.http.request.PendingHeaderRequest;
import com.ddlad.student.protocol.http.request.RemoveAnswerRequest;
import com.ddlad.student.protocol.http.request.UploadAudioRequest;
import com.ddlad.student.protocol.http.request.UploadImageRequest;
import com.ddlad.student.protocol.model.AudioInfo;
import com.ddlad.student.protocol.model.HomeWorkDetailsInfo;
import com.ddlad.student.protocol.model.PendingHeaderInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.tools.PictureUtil;
import com.ddlad.student.tools.SaveReport;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.fresco.ImagesSelectorActivity;
import com.ddlad.student.ui.fresco.SelectorSettings;
import com.ddlad.student.ui.model.MultiImageInfo;
import com.ddlad.student.ui.pic.BigPhotoUriAcitivity;
import com.ddlad.student.ui.widget.dialog.ShareDialogBuilder;
import com.ddlad.student.ui.widget.voice.AudioRecorderButton;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/2/6 0006.
 */

public class PendingFragment extends BaseFragment {

    private String hid;
    private String cid;
    private String lid;

    private static final int PERMISSION_REQ_ID_RECORD_AUDIO = 0;
    private static final int PERMISSION_REQ_ID_CAMERA = 1;

    private int mRequestHomeworkListId = ViewUtil.generateUniqueId();
    private int mUploadAudioListId = ViewUtil.generateUniqueId();

    private TextView mSend;

    private TextView mTitle;

    private TextView mTime;

    private TextView mContent;

    private TextView mCancel;
    private TextView mCancel1;

    private EditText mETSend;

    private ViewGroup mSendLayout;

    private TextView mUploadHomework;

    private LinearLayout partent_lay;

    private LinearLayout mVoiceLayout;

    private ListView mPendingListView;

    private PendingAdapter mPendingAdapter;

    private AudioRecorderButton mRecorderButton;

    private ShareDialogBuilder mShareDialogBuilder;

    protected int mHeaderLoaderId = ViewUtil.generateUniqueId();

    protected int mUploadImageLoaderId = ViewUtil.generateUniqueId();

    private ArrayList<String> mImageSelected = new ArrayList<>();

    private TextView mPendingTitle;
    private TextView mPendingTime;
    private TextView mPendingContent;

//    private PhotoView mBigImage;
//    private ViewGroup mBigImageBg;

    private CorrectNotDetailsAdapter adapter;

    private HomeWorkDetailsInfo mInfo;

    private boolean mIsModify = false;
    private boolean mIsBigImage = false;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_pending;
    }

    @Override
    protected void onInitData(Bundle bundle) {
        super.onInitData(bundle);
        hid = bundle.getString(ProtocolConstants.PARAM_QID);
        cid = bundle.getString("cid");
        lid = bundle.getString("lid");
        Log.i("penddingFramgnet","hid-------------==================="+hid);
        requestData();
        getLessonData();
    }

    @Override
    public void onPause() {
        hideKeyboard();
        super.onPause();
    }


    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle("作业详情");
        mActionbar.setRightText(R.string.change);
//
//        mBigImage = (PhotoView) contentView.findViewById(R.id.big_image);
//        mBigImageBg = (ViewGroup) contentView.findViewById(R.id.big_iamge_bg);
        mUploadHomework = (TextView) contentView.findViewById(R.id.pending_btn);
        mSend = (TextView) contentView.findViewById(R.id.pending_send_btn);
        mCancel = (TextView) contentView.findViewById(R.id.pending_cancel);
        mCancel1 = (TextView) contentView.findViewById(R.id.pending_cancel_1);
        mVoiceLayout = (LinearLayout) contentView.findViewById(R.id.pending_voice_layout);
        mETSend = (EditText) contentView.findViewById(R.id.pending_send_et);
        mSendLayout = (ViewGroup) contentView.findViewById(R.id.pending_send_Layout);
        mPendingListView = (ListView) contentView.findViewById(R.id.pending_listview);
        View listViewHeader=getActivity().getLayoutInflater().inflate(R.layout.pedding_list_header,mPendingListView, false);
        mPendingListView.addHeaderView(listViewHeader);
        mPendingTitle = (TextView) listViewHeader.findViewById(R.id.pending_title);
        mPendingContent = (TextView) listViewHeader.findViewById(R.id.pending_content);
        mPendingTime = (TextView) listViewHeader.findViewById(R.id.pending_time);
//        partent_lay = (LinearLayout) contentView.findViewById(R.id.pending_partent_Layout);

        mRecorderButton = (AudioRecorderButton) contentView.findViewById(R.id.pending_voice);

        mUploadHomework.setOnClickListener(this);
        mSend.setOnClickListener(this);
        mETSend.setOnClickListener(this);
        mCancel.setOnClickListener(this);
        mCancel1.setOnClickListener(this);

        adapter = new CorrectNotDetailsAdapter(this,null,mIsModify,hid,getDefaultLoaderId());
        adapter.setmContext(getActivity());
        adapter.setFragment(this);
//        mRecorderButton.setFinishRecorderCallBack(new AudioRecorderButton.AudioFinishRecorderCallBack() {
//
//            public void onFinish(float seconds, String filePath) {
////                Recorder recorder = new Recorder(seconds, filePath);
////                mDatas.add(recorder);
////                //更新数据
////                mAdapter.notifyDataSetChanged();
////                //设置位置
////                mListView.setSelection(mDatas.size() - 1);
//            }
//        });

        mActionbar.setRightButtonOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mIsModify = !mIsModify;
                if (mIsModify){
                    mActionbar.setRightText("完成");
                    adapter.setmIsModify(mIsModify);
                    adapter.notifyDataSetChanged();
                }else {
                    mActionbar.setRightText("修改");
                    adapter.setmIsModify(mIsModify);
                    adapter.notifyDataSetChanged();
                }
            }
        });
        adapter.setListener(new CorrectNotDetailsAdapter.IRemoveAnswerListener() {
            @Override
            public void removeAnswer(int position,PendingFragment fragment) {
                removeData(position);
            }

            @Override
            public void enlargeImage(int position, int i) {
                setBigImage(position,i);
            }
        });

//        mBigImage.setOnPhotoTapListener(new PhotoViewAttacher.OnPhotoTapListener() {
//            @Override
//            public void onPhotoTap(View view, float v, float v1) {
//                mBigImageBg.setVisibility(View.GONE);
//            }
//        });

    }

    private void setBigImage(int position, int i) {
//        mBigImageBg.setVisibility(View.VISIBLE);
        String url =  mInfo.getAnswers().get(position).getImages().get(i).getPattern();
//        Glide.with(getActivity()).load(url.substring(url.indexOf("http"),url.indexOf("@{w}"))).into(mBigImage);
        navigateToBigImage((ArrayList<MultiImageInfo>) mInfo.getAnswers().get(position).getImages(),i);
    }

    private void removeData(final int position) {
        RemoveAnswerRequest removeAnswerRequest = new RemoveAnswerRequest(this, getDefaultLoaderId(), new AbstractCallbacks<String>() {
            @Override
            protected void onSuccess(String s) {
                Toaster.toastShort("删除消息成功!");
                mInfo.getAnswers().remove(position);
                adapter.notifyDataSetChanged();
            }

            @Override
            protected void onFail(ApiResponse<String> response) {
                Toaster.toastShort("删除消息失败");
            }
        });
        removeAnswerRequest.perform(hid,mInfo.getAnswers().get(position).getId());
    }


    public void requestData() {
        startLoading();
        HomeWorkDetailsRequest request = new HomeWorkDetailsRequest(this, mRequestHomeworkListId, new AbstractCallbacks<HomeWorkDetailsInfo>() {
            @Override
            protected void onSuccess(HomeWorkDetailsInfo evaluateListInfo) {
                Log.i(TAG, "onSuccess: 请求成功oooooooooooooooooooooo");
                if (evaluateListInfo != null){
                    stopLoading();
                    if (evaluateListInfo.getDetails().getHid() != null && !evaluateListInfo.getDetails().getHid().equals("") ){
                        hid = evaluateListInfo.getDetails().getHid();
                    }
                    mInfo = evaluateListInfo;
                    mPendingTime.setText(evaluateListInfo.getDetails().getTime());
                    mPendingTitle.setText(evaluateListInfo.getDetails().getTitle());
                    mPendingContent.setText(evaluateListInfo.getDetails().getContent());
                    adapter.setmInfo(evaluateListInfo);
                    mPendingListView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }

            }

            @Override
            protected void onFail(ApiResponse<HomeWorkDetailsInfo> response) {
                Toaster.toastShort(response.getErrorDescription());
                stopLoading();
            }
        });
        request.perform(hid,cid,lid);
    }

    private void getLessonData() {
        if (hid != null){
            PendingHeaderRequest request = new PendingHeaderRequest(this, mHeaderLoaderId, new AbstractCallbacks<PendingHeaderInfo>() {
                @Override
                protected void onSuccess(PendingHeaderInfo info) {
//                    if (info != null){
//                        if (info.getDetails().getHid() != null && !info.getDetails().getHid().equals("") ){
//                            hid = info.getDetails().getHid();
//                        }
//                    }
                    setHeaderData(info);
                }
            });
            request.perform(hid);
        }

    }

    private void setHeaderData(PendingHeaderInfo info) {
        if (info == null){
            return;
        }
//        mTitle.setText(info.getDetails().getTitle());
//        mTime.setText(info.getDetails().getTime());
//        mContent.setText(info.getDetails().getContent());
    }

    private void showShareDialog() {
        if (mShareDialogBuilder == null) {
            mShareDialogBuilder = new ShareDialogBuilder(this);
            mShareDialogBuilder.setTakePhotoButton(this);
            mShareDialogBuilder.setEnterTextButton(this);
            mShareDialogBuilder.setPictureSelectButton(this);
            mShareDialogBuilder.setRecordedVoiceButton(this);
        }
        mShareDialogBuilder.create().show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.pending_btn:
                showShareDialog();
                mSendLayout.setVisibility(View.GONE);
                break;
            case R.id.pending_send_btn:
                submitAnswer(0);
                break;
            case R.id.enter_text_layout:
                mShareDialogBuilder.dismiss();
                mUploadHomework.setVisibility(View.GONE);
                mSendLayout.setVisibility(View.VISIBLE);
                break;
            case R.id.recorded_voice_layout:
                setVoice();

                break;
            case R.id.picture_select_layout:
                startGallery();
                break;
            case R.id.photograph_upload_layout:
                takePhoto();
                break;
            case R.id.pending_cancel:
                mVoiceLayout.setVisibility(View.GONE);
                mUploadHomework.setVisibility(View.VISIBLE);
                hideKeyboard();
                break;
            case R.id.pending_cancel_1:
                mVoiceLayout.setVisibility(View.GONE);
                mSendLayout.setVisibility(View.GONE);
                mUploadHomework.setVisibility(View.VISIBLE);
                hideKeyboard();
                break;
        }
    }

    private void setVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO, PERMISSION_REQ_ID_RECORD_AUDIO)) {
        }else {
            return;
        }
        mShareDialogBuilder.dismiss();
        mVoiceLayout.setVisibility(View.VISIBLE);
        mUploadHomework.setVisibility(View.GONE);

        mRecorderButton.setFinishRecorderCallBack(new AudioRecorderButton.AudioFinishRecorderCallBack() {

            public void onFinish(float seconds, String filePath) {
//                Recorder recorder = new Recorder(seconds, filePath,null,null,2,null);
//                mDatas.add(recorder);
//                mPendingAdapter = new PendingAdapter(getActivity(), mDatas);
//                mPendingListView.setAdapter(mPendingAdapter);
                //更新数据

                //设置位置
                Log.i("penddingFragment","      Audio  ------- length==========="+seconds);
                uploadAudio(filePath);
                mPendingListView.setSelection(mDatas.size() - 1);


            }
        });


    }

    private void uploadAudio(String filePath) {
        Log.i("uplodAudio","filepath ====================="+filePath);
        final UploadAudioRequest request = new UploadAudioRequest(this, mUploadAudioListId, new AbstractCallbacks<AudioInfo>() {
            @Override
            protected void onSuccess(AudioInfo audioInfo) {
                requestData();
                Log.i("uploadAudio","-----------------------音频上传成功-------------------");
            }
        });
        request.perform(filePath,hid,cid,lid);
    }

    private List<Recorder> mDatas = new ArrayList<Recorder>();
    private void submitAnswer(int type) {
        String content = mETSend.getText().toString().trim();

//        Recorder recorder = new Recorder((float) 1.001,null,null,content,0,null);
//        mDatas.add(recorder);
//        mPendingAdapter = new PendingAdapter(getActivity(),mDatas);
//        mPendingListView.setAdapter(mPendingAdapter);
//        mPendingAdapter.notifyDataSetChanged();

        if (TextUtils.isEmpty(content)){
            Toaster.toastShort("请输入文字");
            return;
        }
        SubmitAnswerRequest request = new SubmitAnswerRequest(this, mDefaultLoaderId, new AbstractCallbacks<String>() {
            @Override
            protected void onSuccess(String info) {
                mETSend.setText("");
//                Toaster.toastShort("上传成功");
                requestData();
//                mPendingAdapter.notifyDataSetChanged();
            }
        });
        request.perform(hid,type,content,cid,lid);
    }

    private void takePhoto() {
        if (checkSelfPermission(Manifest.permission.CAMERA, PERMISSION_REQ_ID_CAMERA)){
        }else {
            return;
        }
        File imageFile = CameraUtil.takePhoto(getActivity());
        if (imageFile != null) {
            CameraUtil.sImagePath = imageFile.getAbsolutePath();
            SaveReport.infoLog("take_photo, sImagePath", CameraUtil.sImagePath);
        } else {
            SaveReport.infoLog("take_photo, sImagePath", "is null");
        }
        if (mShareDialogBuilder != null) {
            mShareDialogBuilder.dismiss();

        }
    }

    private void startGallery() {
        Intent intent = new Intent(getActivity(), ImagesSelectorActivity.class);
//        intent.putExtra(SelectorSettings.SELECTOR_MAX_IMAGE_NUMBER, mShareDialogBuilder.getImageCountAllowed());
//        intent.putExtra(SelectorSettings.SELECTOR_MIN_IMAGE_SIZE, 100000);
        intent.putExtra(SelectorSettings.SELECTOR_SHOW_CAMERA, false);
        startActivityForResult(intent, Constants.REQUEST_CHOOSE_IMAGE);
        if (mShareDialogBuilder != null) {
            mShareDialogBuilder.dismiss();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (Activity.RESULT_OK != resultCode) {
            return;
        }
        switch (requestCode) {
            case Constants.REQUEST_CODE_TAKE_PHOTO:
                uploadImage(CameraUtil.sImagePath);
                break;
            case Constants.REQUEST_CHOOSE_IMAGE:
                onImagesSelected(data);
                break;
        }
    }

    private void onImagesSelected(Intent data) {
        mImageSelected = data.getStringArrayListExtra(SelectorSettings.SELECTOR_RESULTS);
        uploadImage(mImageSelected);
    }
    public static List<String> list = new ArrayList<>();
    private void uploadImage(List<String> paths) {
        list.clear();

        try {

            for (int i= 0 ;i<paths.size();i++){
                list.add(PictureUtil.bitmapToPath(paths.get(i)));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        if (list!= null){
//            Recorder recorder = new Recorder((float) 0.00,null,null,null,1,list);
//            mDatas.add(recorder);
//            mPendingAdapter = new PendingAdapter(getActivity(),mDatas);
//            mPendingListView.setAdapter(mPendingAdapter);
//            mPendingAdapter.notifyDataSetChanged();
        }
        uploadImageRequst(list);
    }

    private void uploadImageRequst(List<String> paths) {
        UploadImageRequest request = new UploadImageRequest(this, mUploadImageLoaderId, new AbstractCallbacks<String>() {
            @Override
            public void onRequestStart() {
                super.onRequestStart();
                startLoading();
            }

            @Override
            public void onRequestFinished() {
                super.onRequestFinished();
                stopLoading();
            }

            @Override
            protected void onSuccess(String info) {
                Toaster.toastShort("上传成功",1);
                requestData();
//                Log.i("infoinfoinfo","info          "+info);
            }

            @Override
            protected void onFail(ApiResponse<String> response) {
                super.onFail(response);
                Log.i("uploadimageonFail","info          "+response.getErrorDescription());
            }
        });
        Log.i(TAG, "uploadImageRequst: 11111111111111");
        request.perform(hid,paths,cid,lid);
    }

//    private void selectToday() {
//        long current = System.currentTimeMillis();
//        Calendar today = Calendar.getInstance();
//        today.setTimeInMillis(current);
//        onDateChanged(today);
//        fetchData();
//        mClassTableView.selectToday();
//    }

    private void uploadImage(String imagePath) {
        String newPath =  null;
        try {
//            newPath = PictureUtil.bitmapToPath(imagePath);
            newPath = PictureUtil.homeWorkBitmapToPath(imagePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
        list.clear();
        list.add(newPath);
        uploadImageRequst(list);
//        Recorder recorder = new Recorder((float) 1.001,null,newPath,null,4,null);
//        mDatas.add(recorder);
//        mPendingAdapter = new PendingAdapter(getActivity(),mDatas);
//        mPendingListView.setAdapter(mPendingAdapter);
//        mPendingAdapter.notifyDataSetChanged();

        File imageFile = (TextUtils.isEmpty(imagePath) ? null : new File(imagePath));

        SaveReport.infoLog("imagePath", imagePath);
//
        if (imageFile == null) {
            SaveReport.infoLog("imageFile", "is null");
        } else {
            SaveReport.infoLog("imageFile", imageFile.getAbsolutePath()
                    + ", " + (imageFile.exists() ? "exist" : "not exist"));
        }


    }

    private void navigateToBigImage(ArrayList<MultiImageInfo> images,int i) {
        Intent intent = new Intent(getActivity(),BigPhotoUriAcitivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("images",images);
        bundle.putInt("position",i);
        intent.putExtras(bundle);
        getActivity().startActivity(intent);
    }


    public boolean checkSelfPermission(String permission, int requestCode) {
        if (ContextCompat.checkSelfPermission(getActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
            //如果没有权限，则申请
            ActivityCompat.requestPermissions(getActivity(), new String[]{permission}, requestCode);
            return false;
        }
        return true;
    }
}
