package com.ddlad.student.protocol.model;

/**
 * Created by Administrator on 2017/1/17 0017.
 */

public class CommentInfo extends BaseInfo{

}
