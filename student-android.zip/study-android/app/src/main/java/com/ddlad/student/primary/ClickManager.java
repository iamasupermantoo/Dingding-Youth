package com.ddlad.student.primary;

import android.app.Activity;
import android.os.Handler;
import android.support.v4.app.FragmentManager;

/**
 * Created by Albert
 * on 16-6-2.
 */
public class ClickManager {

    private static ClickManager mInstance;

    private Activity mCurrentActivity;

    private FragmentManager mFragmentManager;

    private Handler mHandler;

    public static ClickManager getInstance() {
        if (mInstance == null) {
            mInstance = new ClickManager();
        }
        return mInstance;
    }

    public Activity getCurrentActivity() {
        return this.mCurrentActivity;
    }

    public FragmentManager getCurrentFragmentManager() {
        return this.mFragmentManager;
    }

    public Handler getHandler() {
        return this.mHandler;
    }

    public void setCurrentActivity(Activity activity) {
        this.mCurrentActivity = activity;
    }

    public void setFragmentManager(FragmentManager fragmentManager) {
        this.mFragmentManager = fragmentManager;
    }

    public void setHandler(Handler handler) {
        this.mHandler = handler;
    }

}
