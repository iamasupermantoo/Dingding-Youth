package com.ddlad.student.protocol.http.cache;



public class DiskCache<T> {

    private com.ddlad.student.protocol.http.response.AbstractListResponse<T> mResponse;

    public com.ddlad.student.protocol.http.response.AbstractListResponse<T> getResponse() {
        return mResponse;
    }

    public void setResponse(com.ddlad.student.protocol.http.response.AbstractListResponse<T> response) {
        this.mResponse = response;
    }

}
