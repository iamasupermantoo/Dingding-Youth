package com.ddlad.student.ui.common;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;


import com.ddlad.student.tools.CollectionUtil;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractAdapter<T> extends BaseAdapter {

    protected BaseFragment mFragment;

    protected LayoutInflater mInflater;

    protected List<T> mList;

    public AbstractAdapter(BaseFragment fragment) {
        mList = new ArrayList();
        mFragment = fragment;
        mInflater = LayoutInflater.from(fragment.getActivity());
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = createView(position, parent);
        }

        bindView(position, convertView);

        return convertView;
    }

    protected View createView(int position, ViewGroup parent) {
        return null;
    }

    protected void bindView(int position, View view) {

    }

    @Override
    public abstract Object getItem(int position);

    @Override
    public long getItemId(int position) {
        return position;
    }

//    public abstract void clearItem();
//
//    public abstract void addItem(T t);
//
//    public abstract void addItem(List<T> list);

    public void clearItem() {
        mList.clear();
    }

    public void addItem(T t) {
        mList.add(t);
    }

    public void addItem(List<T> list) {
        if (CollectionUtil.hasData(list)) {
            mList.addAll(list);
        }
    }

    public Object removeItem(int position) {
        return null;
    }

    public void addItem(int position, T t) {

    }

    public List<T> getList() {
        return mList;
    }

    public void removeAll(List<T> list) {

    }

    public int getCount() {
        return mList.size();
    }

    public boolean isEmpty() {
        return CollectionUtil.isEmpty(mList);
    }

    public Context getContext() {
        return mFragment == null ? null : mFragment.getActivity();
    }

}
