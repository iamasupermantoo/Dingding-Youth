package com.ddlad.student.ui.account;

import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.protocol.model.CoursesLiveBean;
import com.ddlad.student.ui.choice.LiveCourseListFragment;
import com.ddlad.student.ui.common.AbstractAdapter;


/**
 * Created by Albert
 * on 17-6-2.
 */

public class WithdrawalsCashListAdapter extends AbstractAdapter<CoursesLiveBean> {

    private WithdrawalsCashListItemAdapter mItemAdapter;
    private WithdrawalsCashRecordFragment mFragment;
    private int type;

    public WithdrawalsCashListAdapter(WithdrawalsCashRecordFragment fragment) {
        super(fragment);
        mFragment = fragment;
        mItemAdapter = new WithdrawalsCashListItemAdapter(mFragment);
    }

    public WithdrawalsCashListAdapter(WithdrawalsCashRecordFragment fragment, int type) {
        super(fragment);
        mFragment = fragment;
        mItemAdapter = new WithdrawalsCashListItemAdapter(mFragment);
        this.type = type;
    }

    @Override
    public CoursesLiveBean getItem(int position) {
        return mList.get(position);
    }

    @Override
    protected View createView(int position, ViewGroup parent) {
        return mItemAdapter.createView(parent);
    }

    @Override
    protected void bindView(int position, View view) {
        mItemAdapter.bindView(view, getItem(position), 0,position,type);
    }


}
