package com.ddlad.student.protocol.model;

import com.ddlad.student.ui.model.MultiImageInfo;

/**
 * Created by Administrator on 2017/1/19 0019.
 */

public class CourseMetas extends BaseInfo{

    //        "cmid":"CM001",
//        "image":Object{...},
//        "brief":"听老师，讲装逼1"
    private String cmid;
    private MultiImageInfo image;
    private String brief;

    public String getCmid() {
        return cmid;
    }

    public void setCmid(String cmid) {
        this.cmid = cmid;
    }

    public MultiImageInfo getImage() {
        return image;
    }

    public void setImage(MultiImageInfo image) {
        this.image = image;
    }

    public String getBrief() {
        return brief;
    }

    public void setBrief(String brief) {
        this.brief = brief;
    }

}
