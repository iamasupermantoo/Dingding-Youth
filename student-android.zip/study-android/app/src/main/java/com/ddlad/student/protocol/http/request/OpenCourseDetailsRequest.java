package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.CourseDetailsInfo;
import com.ddlad.student.ui.common.BaseFragment;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 *
 */

public class OpenCourseDetailsRequest extends AbstractRequest<CourseDetailsInfo> {
    public OpenCourseDetailsRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<CourseDetailsInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.getRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return "/opencourse/meta/details";
    }

    @Override
    public CourseDetailsInfo processInBackground(ApiResponse<CourseDetailsInfo> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, CourseDetailsInfo.class);
    }

    public void perform(String lmid) {
        RequestParams params = getParams();
        params.put("lmid", lmid);
        super.perform();
    }
}
