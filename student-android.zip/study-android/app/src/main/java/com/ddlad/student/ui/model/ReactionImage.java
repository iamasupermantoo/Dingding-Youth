package com.ddlad.student.ui.model;


import com.ddlad.student.protocol.model.BaseInfo;
import com.ddlad.student.tools.CollectionUtil;

import java.util.List;

/**
 * Created by Albert
 * on 16-12-8.
 */
public class ReactionImage extends BaseInfo {

    public static int COURSE_MAX_IMAGE_COUNT = 3;

    protected int typeName;
    protected List<String> imageIds;

    public int getTypeName() {
        return typeName;
    }

    public void setTypeName(int type) {
        this.typeName = type;
    }

    public List<String> getImageIds() {
        return imageIds;
    }

    public void setImageIds(List<String> imageIds) {
        this.imageIds = imageIds;
    }

    public boolean isImageFull() {
        return !CollectionUtil.isEmpty(imageIds) && imageIds.size() >= COURSE_MAX_IMAGE_COUNT;
    }
}
