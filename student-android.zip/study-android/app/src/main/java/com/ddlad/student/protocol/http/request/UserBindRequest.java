package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.protocol.http.internal.ApiResponse;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-6-30.
 */
public class UserBindRequest extends AbstractRequest<String> {

    public UserBindRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<String> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_CONNECT_BIND;
    }

    @Override
    public String processInBackground(ApiResponse<String> response) {
        return response.readRootValue(String.class);
    }

    public void perform(String name ,int type , String externalUserId,String accessToken ,String refreshToken) {
        RequestParams params = getParams();
        params.put("name", name);
        params.put(ProtocolConstants.PARAM_TYPE, type);
        params.put(ProtocolConstants.PARAM_EXTERNAL_USERID, externalUserId);
        params.put(ProtocolConstants.PARAM_ACCESSTOKEN, accessToken);
        params.put("refreshToken", refreshToken);
        super.perform();
    }
}
