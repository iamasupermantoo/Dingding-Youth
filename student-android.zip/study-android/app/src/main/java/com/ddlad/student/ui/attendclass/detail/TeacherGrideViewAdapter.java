package com.ddlad.student.ui.attendclass.detail;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.model.CourseMetas;
import com.ddlad.student.ui.widget.image.NetworkImageView;

import java.util.ArrayList;

/**
 * Created by Administrator on 2017/1/19 0019.
 */

public class TeacherGrideViewAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<CourseMetas> list;
    public TeacherGrideViewAdapter(Context context , ArrayList<CourseMetas> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public CourseMetas getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        GrideHolder holder = null;
        if (convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.teacher_gride_view_item,null);
            holder = new GrideHolder();
            convertView.setTag(holder);
        }else {
            holder = (GrideHolder) convertView.getTag();
        }
        holder.mImage = (NetworkImageView) convertView.findViewById(R.id.teacher_item_image);
        holder.mContent = (TextView) convertView.findViewById(R.id.teacher_item_content);
        holder.mImage.setUrl(list.get(position).getImage().getImageSmall());
        holder.mContent.setText(list.get(position).getBrief());
        return convertView;
    }
    public class GrideHolder{
        private NetworkImageView mImage;
        private TextView mContent;
    }

}
