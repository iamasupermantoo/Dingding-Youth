package com.ddlad.student.protocol.http.internal;

import android.content.Context;
import android.text.TextUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;
import com.ddlad.student.primary.Meta;
import com.ddlad.student.tools.JsonUtil;

import java.util.ArrayList;

import ch.boye.httpclientandroidlib.HttpEntity;
import ch.boye.httpclientandroidlib.HttpResponse;
import ch.boye.httpclientandroidlib.StatusLine;
import ch.boye.httpclientandroidlib.util.EntityUtils;

public class ObjectMappedApiResponse<T> extends ApiResponse<T> {

    private static final String TAG = "ObjectMappedApiResponse";

    private String mErrorTitle;

    //    private String mErrorMessage;

    private String mError;

    private String mErrorDescription;

    private CustomObjectMapper mMapper;

    private boolean mNetworkRequest;

    private boolean mNotModified;

    private String mStatusMessage;

    private int mStatus;

    JsonNode mRootNode;

    T mSuccessObject;

    public ObjectMappedApiResponse() {
    }

    public ObjectMappedApiResponse(Context context, String content) throws Exception {
        if (Log.DEBUG) {
            Log.d(TAG, "ObjectMappedApiResponse, content=" + content);
        }

        mMapper = CustomObjectMapper.getInstance();
        mRootNode = mMapper.readValue(content, JsonNode.class);
    }

    public static <T> ObjectMappedApiResponse<T> createWithError(String error) {

        ObjectMappedApiResponse<T> objectMappedApiResponse = new ObjectMappedApiResponse<T>();

        objectMappedApiResponse.createWithError();

        if (!TextUtils.isEmpty(error)) {
            objectMappedApiResponse.setError(error);
            objectMappedApiResponse.setErrorDescription(error);
        }

        return objectMappedApiResponse;
    }

    public void setErrorTitle(String errorTitle) {
        mErrorTitle = errorTitle;
    }

    private void setError(String error) {
        mError = error;
    }

    private void setErrorDescription(String errorDescription) {
        mErrorDescription = errorDescription;
    }

    public void setStatus(int status) {
        mStatus = status;
    }

    public void setStatusMessage(String statusMessage) {
        mStatusMessage = statusMessage;
    }

    @Override
    public String getErrorTitle() {
        return mErrorTitle;
    }

    @Override
    public String getError() {
        return mError;
    }

    @Override
    public String getErrorDescription() {
        return mErrorDescription;
    }

    @Override
    public int getStatus() {
        return mStatus;
    }

    @Override
    public String getStatusMessage() {
        return mStatusMessage;
    }

    public void createWithError() {

        if (TextUtils.isEmpty(mErrorTitle)) {
            mErrorTitle = AppContext.getContext().getString(R.string.error);
        }

        if (TextUtils.isEmpty(mError)) {
            mError = NETWORK_ERROR_MESSAGE;
        }

        if (TextUtils.isEmpty(mErrorDescription)) {
            mErrorDescription = NETWORK_ERROR_MESSAGE;
        }

    }

    public static <T> ObjectMappedApiResponse<T> parseResponse(Context context,
                                                               HttpResponse httpResponse) {

        if (httpResponse == null) {
            return createWithError(NETWORK_ERROR_MESSAGE);
        }

        try {
            HttpEntity httpEntity = httpResponse.getEntity();
            StatusLine statusLine = httpResponse.getStatusLine();

            ObjectMappedApiResponse<T> response = new ObjectMappedApiResponse<T>(context,
                    EntityUtils.toString(httpEntity));
            EntityUtils.consume(httpEntity);
            response.setStatusLine(statusLine);
            response.setIsNetworkResponse(true);

            response.setStatus(statusLine.getStatusCode());

            if (statusLine.getStatusCode() == HttpResponseCode.STATUS_CODE_NOT_MODIFIED) {

                response.setStatus(statusLine.getStatusCode());
                response.setNotModified(true);

            } else if (statusLine.getStatusCode() != HttpResponseCode.STATUS_CODE_OK) { // 出错

                response.setStatus(statusLine.getStatusCode());

                String error = response.parseError();
                String errorTitle = AppContext.getContext().getString(R.string.error);
                String errorDescription = response.parseErrorDescription();

                response.setErrorTitle(errorTitle);
                response.setError(error);
                response.setErrorDescription(errorDescription);

            } else { // 正确的情况
                response.parseCode();
                if (response.getCode() != Meta.META_CODE_OK) {
                    String error = response.parseError();
                    String errorTitle = AppContext.getString(R.string.error);
                    String errorDescription = response.parseErrorDescription();

                    response.setErrorTitle(errorTitle);
                    response.setError(error);
                    response.setErrorDescription(errorDescription);
                }
            }

            return response;
        } catch (Exception e) {
            e.printStackTrace();
            return createWithError(NETWORK_ERROR_MESSAGE);
        }
    }

    private String parseError() {
        String error = null;

        if (getRootNode() != null) {

            error = parseStatusMessage();

            if (error == null) {
                try {
                    error = JsonUtil.asText(getRootNode(), com.ddlad.student.protocol.http.internal.ProtocolConstants.JSON_FIELD_ERROR);
                } catch (Throwable t) {
                    if (Log.DEBUG) {
                        Log.w(TAG, "parseError failed");
                    }
                    t.printStackTrace();
                }
            }
        }

        return TextUtils.isEmpty(error) ? NETWORK_ERROR_MESSAGE : error;
    }

    private String parseErrorDescription() {

        String errorDescription = null;

        if (getRootNode() != null) {
            errorDescription = parseStatusMessage();
            if (errorDescription == null) {
                try {
                    errorDescription = JsonUtil.asText(getRootNode(),
                            com.ddlad.student.protocol.http.internal.ProtocolConstants.JSON_FIELD_ERROR_DESCRIPTION);
                } catch (Throwable t) {
                    if (Log.DEBUG) {
                        Log.w(TAG, "parseErrorDescription failed");
                    }
                    t.printStackTrace();
                }
            }
        }

        return TextUtils.isEmpty(errorDescription) ? NETWORK_ERROR_MESSAGE : errorDescription;

    }

    public CustomObjectMapper getMapper() {
        return mMapper;
    }

    @Override
    public JsonNode getRootNode() {
        return mRootNode;
    }

    public void parseCode() {

        int code = 0;

        JsonNode rootNode = getRootNode();
        if (rootNode != null) {
            JsonNode metaNode = rootNode.get(com.ddlad.student.protocol.http.internal.ProtocolConstants.JSON_FIELD_META);
            if (metaNode != null) {
                code = JsonUtil.asInt(metaNode, com.ddlad.student.protocol.http.internal.ProtocolConstants.JSON_FIELD_CODE);
            } else {
                code = Meta.META_CODE_OK;
            }
        }

        setCode(code);
    }

    private String parseStatusMessage() {
        try {
            JsonNode rootNode = getRootNode();
            if (rootNode != null) {
                JsonNode metaNode = rootNode.get(com.ddlad.student.protocol.http.internal.ProtocolConstants.JSON_FIELD_META);
                if (metaNode != null) {
                    return JsonUtil.asText(metaNode, com.ddlad.student.protocol.http.internal.ProtocolConstants.JSON_FIELD_DESC);
                }
            }
        } catch (Exception e) {
            if (Log.DEBUG) {
                Log.w(TAG, "parseStatusMessage failed");
            }
        }
        return null;
    }

    @Override
    public T getSuccessObject() {
        return mSuccessObject;
    }

    @Override
    public boolean hasRootValue(String fieldname) {
        return getRootNode().has(fieldname);
    }

    @Override
    public boolean isNetworkRequest() {
        return mNetworkRequest;
    }

    @Override
    public boolean isOk() {

        if (mErrorDescription != null) {
            return Boolean.FALSE;
        }

        Integer responseCode = getResponseCode();
        if (responseCode != null) {
            if (responseCode.intValue() == HttpResponseCode.STATUS_CODE_OK) {
                if (getStatus() != HttpResponseCode.STATUS_CODE_OK) {
                    return Boolean.FALSE;
                }

                return Boolean.TRUE;
            }
        }

        return Boolean.FALSE;
    }

    public ArrayList<T> readRootArrayList(String fieldName, Class<T> clazz) {
        JsonNode jsonNode = getRootNode();
        return getMapper().readArrayList(jsonNode.get(fieldName), clazz);
    }

    @Override
    public T readRootValue(Class<T> clazz) {
        //        if (Log.DEBUG) {
        //            Log.d(TAG,
        //                    "readRootValue(), getRootNode()=" + getRootNode() + ",clazz=" + clazz.getName());
        //        }

        try {
            return getMapper().treeToValue(getRootNode(), clazz);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public T readRootValue(String key, Class<T> clazz) {

        JsonNode jsonNode = getRootNode();

        try {
            return getMapper().treeToValue(jsonNode.get(key), clazz);
        } catch (Exception e) {
            if (Log.DEBUG) {
                Log.d(TAG, "readRootValue(), error");
            }
        }

        return null;
    }

    @Override
    public T readRootValue(String key, String childKey, Class<T> clazz) {
        JsonNode jsonNode = getRootNode();
        try {
            return getMapper().treeToValue(jsonNode.get(key).get(childKey), clazz);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    //    public void setErrorMessage(String errorMessage) {
    //        mErrorMessage = errorMessage;
    //    }

    @Override
    public void setIsNetworkResponse(boolean networkRequest) {
        mNetworkRequest = networkRequest;
    }

    @Override
    public void setSuccessObject(T successObject) {
        mSuccessObject = successObject;
    }

    //    public void setErrorDescription(String mErrorDescription) {
    //        this.mErrorDescription = mErrorDescription;
    //    }

    @Override
    public boolean isNotModified() {
        return mNotModified;
    }

    public void setNotModified(boolean mNotModified) {
        this.mNotModified = mNotModified;
    }

}
