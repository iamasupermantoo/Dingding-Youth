package com.ddlad.student.ui.attendclass.schedule;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.request.ScheduleRequest;
import com.ddlad.student.ui.calendar.calendarview.CalendarUtils;
import com.ddlad.student.ui.classtable.DateChangeListener;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.request.CoursePointRequest;
import com.ddlad.student.protocol.model.CalendarReminderCourseInfo;
import com.ddlad.student.protocol.model.SchedulePointsInfo;
import com.ddlad.student.tools.DateUtils;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.classtable.ClassTableView;

import java.util.Calendar;

/**
 * A simple {@link Fragment} subclass.
 */
public class ScheduleFragment extends BaseFragment implements DateChangeListener {

    protected int mGeneratedLoaderId = ViewUtil.generateUniqueId();
    private Calendar mCalendar = Calendar.getInstance();
    private ClassTableView mClassTableView;
    //    private ClassTable mClassTable;
    private TextView mDate;
    private TextView mLeft;
    private TextView mRight;

    private TextView jskc;
    private TextView emptytext;
    private ViewGroup calendar_divider;
    private ViewGroup calendar_divider_list;

    private CoursePointRequest pointRequest;
    private ScheduleAdapter scheduleAdapter;
    private ListView mScheduleListView;
    View viewfoot;
    private String mCid;

    private boolean mAdapterCreate = false;
    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_schedule;
    }

//    @Override
//    protected int getHeaderResource() {
//        return R.layout.layout_schedule_header;
//    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.hideEvaluateTitle();
        mActionbar.setTitle(R.string.school_timetable);
        mScheduleListView = (ListView) contentView.findViewById(R.id.schedule_list);
        emptytext = (TextView) contentView.findViewById(R.id.emptytext);
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.layout_schedule_header,null);
        viewfoot = LayoutInflater.from(getActivity()).inflate(R.layout.schedule_foot_view,null);
        scheduleAdapter = new ScheduleAdapter(this);
        mScheduleListView.addHeaderView(view,null,true);
//        mScheduleListView.addFooterView(viewfoot,null,true);
        mScheduleListView.addFooterView(viewfoot);
        mScheduleListView.setAdapter(scheduleAdapter);
        jskc = (TextView) view.findViewById(R.id.jskc);
        calendar_divider = (ViewGroup) view.findViewById(R.id.calendar_divider);
        calendar_divider_list = (ViewGroup) view.findViewById(R.id.calendar_divider_list);
        mDate = (TextView) view.findViewById(R.id.schedule_date);
        mDate.setText(formatTitle());
        mLeft = (TextView) view.findViewById(R.id.schedule_left);
        mLeft.setOnClickListener(this);
        mRight = (TextView) view.findViewById(R.id.schedule_right);
        mRight.setOnClickListener(this);

        mClassTableView = (ClassTableView) view.findViewById(R.id.class_table);
        mClassTableView.setFragment(this);
        mClassTableView.setToday();
        mClassTableView.setDateChangeListener(this);
        jskc.setVisibility(View.GONE);
        calendar_divider.setVisibility(View.GONE);
        calendar_divider_list.setVisibility(View.GONE);


        selectToday();
        getCourseData(DateUtils.formattedDate(mCalendar));
    }

    @Override
    protected void onInitData(Bundle bundle) {
        super.onInitData(bundle);
        mCid = bundle.getString("cid");
        mCalendar.setTimeInMillis(System.currentTimeMillis());
    }

//    @Override
//    protected void onInitHeader(View header) {
//
//    }

    private String formatTitle() {
        //加入年月
        String title = String.valueOf(mCalendar.get(Calendar.YEAR)) + "年 - "
                + String.valueOf(mCalendar.get(Calendar.MONTH) + 1)+"月";
        return title;
    }
    private String formatNoTextTitle() {
        //加入年月
        String title = String.valueOf(mCalendar.get(Calendar.YEAR)) + "- "
                + String.valueOf(mCalendar.get(Calendar.MONTH) + 1);
        return title;
    }

    private void selectToday() {
        long current = System.currentTimeMillis();
        Calendar today = Calendar.getInstance();
        today.setTimeInMillis(current);
        onDateChanged(today);
        fetchData();
        mClassTableView.selectToday();
    }
    @Override
    protected boolean isNeedFetch() {
        return true;
    }

    @Override
    protected void fetchData() {
        pointRequest = new CoursePointRequest(this, mGeneratedLoaderId, new AbstractCallbacks<SchedulePointsInfo>() {
            @Override
            protected void onSuccess(SchedulePointsInfo info) {
                updateClassTableView(info);
            }
        });
        pointRequest.perform(formatNoTextTitle(),mCid);
    }

    private void updateClassTableView(SchedulePointsInfo info) {
        if (info == null) {
            return;
        }
        mClassTableView.setDotedDays(info.getDays());
        mClassTableView.update(mCalendar);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.schedule_left:
                previousMonth();
                break;
            case R.id.schedule_right:
                nextMonth();
                break;
        }
    }
    public void previousMonth() {
        mClassTableView.past();
        onMonthChanged(mClassTableView.getMonth());
    }

    public void nextMonth() {
        mClassTableView.future();
        onMonthChanged(mClassTableView.getMonth());
    }

    @Override
    public void onMonthChanged(Calendar date) {
        mCalendar.set(Calendar.YEAR, date.get(Calendar.YEAR));
        mCalendar.set(Calendar.MONTH, date.get(Calendar.MONTH));
        mCalendar.set(Calendar.DAY_OF_MONTH, date.get(Calendar.DAY_OF_MONTH));
        mDate.setText(formatTitle());
        fetchData();
        getCourseData(DateUtils.formattedDate(date));
    }

    @Override
    public void onDateChanged(Calendar date) {
        boolean isDifferentYear = mCalendar.get(Calendar.YEAR) != date.get(Calendar.YEAR);
        boolean isDifferentMonth = mCalendar.get(Calendar.MONTH) != date.get(Calendar.MONTH);
        boolean isDifferentDay = mCalendar.get(Calendar.DAY_OF_MONTH) != date
                .get(Calendar.DAY_OF_MONTH);
        if (isDifferentYear || isDifferentMonth || isDifferentDay) {
            CalendarUtils.copyDateTo(date, mCalendar);
            mDate.setText(formatTitle());
//            handleRequest(true);
            getCourseData(DateUtils.formattedDate(mCalendar));
        }
    }

    private void getCourseData(final String data) {
        Log.i(TAG, "getCourseData: "+data);
        ScheduleRequest scheduleRequest = new ScheduleRequest(this, mDefaultLoaderId, new AbstractCallbacks<CalendarReminderCourseInfo>() {
            @Override
            protected void onSuccess(CalendarReminderCourseInfo scheduleInfo) {

                if (scheduleInfo != null ){
                    if (scheduleInfo.getLessons().size()>= 1){
                        viewfoot.setVisibility(View.GONE);
                        jskc.setVisibility(View.VISIBLE);
                        calendar_divider.setVisibility(View.VISIBLE);
                        calendar_divider_list.setVisibility(View.VISIBLE);
                    }else {
                        viewfoot.setVisibility(View.VISIBLE);
                        jskc.setVisibility(View.GONE);
                        calendar_divider.setVisibility(View.GONE);
                        calendar_divider_list.setVisibility(View.GONE);
                    }
                    scheduleAdapter.setInfo(scheduleInfo);
//                    if (!mAdapterCreate){
//                        mAdapterCreate = true;
//                        mScheduleListView.setAdapter(scheduleAdapter);
//                    }else {
//
//                        Log.i(TAG, "onSuccess: "+scheduleInfo.getLessons().size());
//                    }
                    scheduleAdapter.notifyDataSetChanged();
                }else {
                    viewfoot.setVisibility(View.VISIBLE);
                    jskc.setVisibility(View.GONE);
                    calendar_divider.setVisibility(View.GONE);
                    calendar_divider_list.setVisibility(View.GONE);
                }
            }

            @Override
            protected void onFail(ApiResponse<CalendarReminderCourseInfo> response) {
                super.onFail(response);

                viewfoot.setVisibility(View.VISIBLE);
                jskc.setVisibility(View.GONE);
                calendar_divider.setVisibility(View.GONE);
                calendar_divider_list.setVisibility(View.GONE);
                scheduleAdapter.notifyDataSetChanged();
            }
        });
        scheduleRequest.perform(data);
    }
}
