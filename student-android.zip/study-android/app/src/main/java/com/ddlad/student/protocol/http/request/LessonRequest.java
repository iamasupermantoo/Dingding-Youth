package com.ddlad.student.protocol.http.request;


import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.request.BaseLessonRequest;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.LessonInfo;

/**
 * Created by Administrator on 2016/12/8 0008.
 */

public class LessonRequest extends BaseLessonRequest {
    public LessonRequest(BaseListFragment baseListFragment, int loaderId, AbstractStreamingCallbacks<AbstractListResponse<LessonInfo>> streamingApiCallbacks) {
        super(baseListFragment, loaderId, streamingApiCallbacks);
    }

    @Override
    protected String getBasePath() {
        return ProtocolConstants.URL_LESSON_LIST;
    }

    public void perform(String cid) {
        RequestParams param = getParams();
        param.put(ProtocolConstants.PARAM_CID, cid);
        super.perform();
    }
}
