package com.ddlad.student.ui.attendclass.schedule;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.ddlad.student.ui.widget.voice.MediaPlayerManager;
import com.ddlad.student.R;

import java.util.List;

/**
 * Created by Administrator on 2017/2/9 0009.
 */

public class PendingAdapter extends BaseAdapter {
    final int TYPE_1 = 0;
    final int TYPE_2 = 1;
    final int TYPE_3 = 2;
    final int TYPE_4 = 3;

    //item的最小宽度
    private int mMinWidth;
    //item的最大宽度
    private int mMaxWidth;

    private List<Recorder> list;
    private LayoutInflater inflater;
    public PendingAdapter(Context context, List<Recorder> list) {
        inflater = LayoutInflater.from(context);
        this.list = list;


        //获取屏幕的宽度
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        //最大宽度为屏幕宽度的百分之七十
        mMaxWidth = (int) (outMetrics.widthPixels * 0.7f);
        //最小宽度为屏幕宽度的百分之十五
        mMinWidth = (int) (outMetrics.widthPixels * 0.15f);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Recorder getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        TextHolder textHolder = null;
        CameraHolder cameraHolder = null;
        PhotoHolder photoHolder = null;
        VoiceHolder voiceHolder = null;
        int type = getItemViewType(position);
        if (convertView == null){
            switch (type){
                case TYPE_1:
                    convertView = inflater.inflate(R.layout.pending_item_text,null);
                    textHolder = new TextHolder();
                    textHolder.mText = (TextView) convertView.findViewById(R.id.pending_item_text);
                    convertView.setTag(textHolder);
                    break;
                case TYPE_2:
                    convertView = inflater.inflate(R.layout.pending_item_photo_image,null);
                    photoHolder = new PhotoHolder();
                    photoHolder.mPhotoImage1 = (ImageView) convertView.findViewById(R.id.pending_item_photo_image1);
                    photoHolder.mPhotoImage2 = (ImageView) convertView.findViewById(R.id.pending_item_photo_image2);
                    photoHolder.mPhotoImage3 = (ImageView) convertView.findViewById(R.id.pending_item_photo_image3);
                    convertView.setTag(photoHolder);
                    break;
                case TYPE_3:
                    convertView = inflater.inflate(R.layout.pending_item_voice,null);
                    voiceHolder = new VoiceHolder();
                    voiceHolder.mTime = (TextView) convertView.findViewById(R.id.item_time);
                    voiceHolder.mVoice = convertView.findViewById(R.id.pending_item_voice);
                    voiceHolder.mLength = (ViewGroup) convertView.findViewById(R.id.pending_voice_length);
//                    photoHolder.mPhotoImage1 = (ImageView) convertView.findViewById(R.id.pending_item_photo_image1);

                    convertView.setTag(voiceHolder);
                    break;
                case  TYPE_4:
                    convertView = inflater.inflate(R.layout.pending_item_camera_image,null);
                    cameraHolder = new CameraHolder();
                    cameraHolder.mImage = (ImageView) convertView.findViewById(R.id.pending_item_camera_image);
                    convertView.setTag(cameraHolder);
                    break;
            }
        }else {
            switch (type){
                case TYPE_1:
                    textHolder = (TextHolder) convertView.getTag();
                    break;
                case TYPE_2:
                    photoHolder = (PhotoHolder) convertView.getTag();
                    break;
                case TYPE_3:
                    voiceHolder = (VoiceHolder) convertView.getTag();
                    break;
                case TYPE_4:
                    cameraHolder = (CameraHolder) convertView.getTag();
                    break;

            }
        }

        switch (type){
            case TYPE_1:
                textHolder.mText.setText(list.get(position).getContent());
                break;

            case TYPE_2:
                if (list.get(position).getPhotoImage().size() == 1){
                    photoHolder.mPhotoImage1.setImageURI(Uri.parse(list.get(position).getPhotoImage().get(0)));
                }
                if (list.get(position).getPhotoImage().size() == 2){
                    photoHolder.mPhotoImage1.setImageURI(Uri.parse(list.get(position).getPhotoImage().get(0)));
                    photoHolder.mPhotoImage2.setImageURI(Uri.parse(list.get(position).getPhotoImage().get(1)));
                }
                if (list.get(position).getPhotoImage().size() == 3){

                    photoHolder.mPhotoImage1.setImageURI(Uri.parse(list.get(position).getPhotoImage().get(0)));
                    photoHolder.mPhotoImage2.setImageURI(Uri.parse(list.get(position).getPhotoImage().get(1)));
                    photoHolder.mPhotoImage3.setImageURI(Uri.parse(list.get(position).getPhotoImage().get(2)));
                }


                break;
            case TYPE_3:

//                WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
//                DisplayMetrics outMetrics = new DisplayMetrics();
//                wm.getDefaultDisplay().getMetrics(outMetrics);
                voiceHolder.mTime.setText(Math.round(list.get(position).getTime()) + "\"");
                final VoiceHolder finalVoiceHolder = voiceHolder;
                voiceHolder.mLength.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finalVoiceHolder.mVoice.setBackgroundResource(R.drawable.play_anim);
                        AnimationDrawable animation = (AnimationDrawable) finalVoiceHolder.mVoice.getBackground();
                        animation.start();
                        // 播放录音
                        MediaPlayerManager.playSound(list.get(position).filePath,new MediaPlayer.OnCompletionListener() {

                            public void onCompletion(MediaPlayer mp) {
                                //播放完成后修改图片
                                finalVoiceHolder.mVoice.setBackgroundResource(R.drawable.adj);
                            }
                        });
                    }
                });

                ViewGroup.LayoutParams lp = voiceHolder.mLength.getLayoutParams();
                lp.width = (int) (mMinWidth + (mMaxWidth / 60f) * getItem(position).time);
                break;

            case TYPE_4:
                cameraHolder.mImage.setImageURI(Uri.parse(list.get(position).getImagePath()));
                break;
        }

        return convertView;
    }

    @Override
    public int getItemViewType(int position) {
        int type = getItem(position).getType();
        if (type == TYPE_1){
            return TYPE_1;
        }else if (type == TYPE_2){
            return TYPE_2;
        }else if (type == TYPE_3){
            return TYPE_3;
        }else {
            return TYPE_4;
        }

//        return super.getItemViewType(position);
    }

    @Override
    public int getViewTypeCount() {
        return 4;
    }
    class TextHolder{
        private TextView mText;
    }
    class CameraHolder{
        private ImageView mImage;
    }
    class PhotoHolder{
        private ImageView mPhotoImage1;
        private ImageView mPhotoImage2;
        private ImageView mPhotoImage3;

    }
    class  VoiceHolder{
        private TextView mTime;
        private View mVoice;
        private ViewGroup mLength;
    }

}
