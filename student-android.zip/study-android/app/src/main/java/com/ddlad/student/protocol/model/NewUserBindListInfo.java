package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.IOException;

/**
 * Created by chenjianing on 2017/5/10 0010.
 */
public class NewUserBindListInfo extends BaseInfo {



    public QQBean QQ;

    public WeiXinBean WeiXin;

    public MobileBean Mobile;

    public WeiXinBean getWeiXin() {
        return WeiXin;
    }

    public void setWeiXin(WeiXinBean weiXin) {
        WeiXin = weiXin;
    }

    public QQBean getQQ() {
        return QQ;
    }

    public void setQQ(QQBean QQ) {
        this.QQ = QQ;
    }

    public MobileBean getMobile() {
        return Mobile;
    }

    public void setMobile(MobileBean mobile) {
        Mobile = mobile;
    }



        public static class QQBean {
            private String type;
            private String account;
            private int status;

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getAccount() {
                return account;
            }

            public void setAccount(String account) {
                this.account = account;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }
            public static QQBean fromJsonParser(JsonParser jsonParser) throws IOException {
                QQBean info = null;

                if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

                    while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                        String fieldName = jsonParser.getCurrentName();

                        if (fieldName == null) {
                            continue;
                        }

                        if (info == null) {
                            info = new QQBean();
                        }

                        if ("status".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.status = jsonParser.getIntValue();
                            continue;
                        }
                        if ("account".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.account = jsonParser.getText();
                            continue;
                        }
                        if ("type".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.type = jsonParser.getText();
                            continue;
                        }
                        jsonParser.skipChildren();
                    }
                }
                return info;
            }

        }

        public static class WeiXinBean {
            private String type;
            private String account;
            private int status;

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getAccount() {
                return account;
            }

            public void setAccount(String account) {
                this.account = account;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

        }

        public static class MobileBean {
            private String type;
            private String account;
            private int status;

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getAccount() {
                return account;
            }

            public void setAccount(String account) {
                this.account = account;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }
        }
}
