package com.ddlad.student.protocol.http.callbacks;


import com.ddlad.student.protocol.http.internal.ApiResponse;

public abstract class AbstractCallbacks<T> {

    public void onRequestStart() {

    }

    public void onRequestFinished() {

    }

    protected void onFail(ApiResponse<T> response) {

    }

    protected void onSuccessNotModify() {

    }

    protected abstract void onSuccess(T t);

}
