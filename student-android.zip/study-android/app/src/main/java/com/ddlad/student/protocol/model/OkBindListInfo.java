package com.ddlad.student.protocol.model;

/**
 * Created by chenjianing on 2017/5/10 0010.
 */
public class OkBindListInfo {

    /**
     * code : 1
     * timestamp : 1494403325549
     * cost : 20
     * desc : 成功
     * hostname : dorado-serv
     */

    private MetaBean meta;
    /**
     * QQ : {"type":"QQ","account":"heartã\u0081®heart","status":1}
     * WeiXin : {"type":"WeiXin","account":"frankay","status":1}
     * Mobile : {"type":"Mobile","account":"15038391553","status":1}
     */

    private DataBean data;

    public MetaBean getMeta() {
        return meta;
    }

    public void setMeta(MetaBean meta) {
        this.meta = meta;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class MetaBean {
        private int code;
        private long timestamp;
        private int cost;
        private String desc;
        private String hostname;

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public long getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(long timestamp) {
            this.timestamp = timestamp;
        }

        public int getCost() {
            return cost;
        }

        public void setCost(int cost) {
            this.cost = cost;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        public String getHostname() {
            return hostname;
        }

        public void setHostname(String hostname) {
            this.hostname = hostname;
        }
    }

    public static class DataBean {
        /**
         * type : QQ
         * account : heartã®heart
         * status : 1
         */

        private QQBean QQ;
        /**
         * type : WeiXin
         * account : frankay
         * status : 1
         */

        private WeiXinBean WeiXin;
        /**
         * type : Mobile
         * account : 15038391553
         * status : 1
         */

        private MobileBean Mobile;

        public QQBean getQQ() {
            return QQ;
        }

        public void setQQ(QQBean QQ) {
            this.QQ = QQ;
        }

        public WeiXinBean getWeiXin() {
            return WeiXin;
        }

        public void setWeiXin(WeiXinBean WeiXin) {
            this.WeiXin = WeiXin;
        }

        public MobileBean getMobile() {
            return Mobile;
        }

        public void setMobile(MobileBean Mobile) {
            this.Mobile = Mobile;
        }

        public static class QQBean {
            private String type;
            private String account;
            private int status;

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getAccount() {
                return account;
            }

            public void setAccount(String account) {
                this.account = account;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }
        }

        public static class WeiXinBean {
            private String type;
            private String account;
            private int status;

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getAccount() {
                return account;
            }

            public void setAccount(String account) {
                this.account = account;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }
        }

        public static class MobileBean {
            private String type;
            private String account;
            private int status;

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getAccount() {
                return account;
            }

            public void setAccount(String account) {
                this.account = account;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }
        }
    }
}
