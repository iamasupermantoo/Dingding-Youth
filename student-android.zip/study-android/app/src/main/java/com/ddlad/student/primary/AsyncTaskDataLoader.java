package com.ddlad.student.primary;

import android.content.Context;
import android.support.v4.content.AsyncTaskLoader;

/**
 * Created by Albert
 * on 16-6-2.
 */
public class AsyncTaskDataLoader<D> extends AsyncTaskLoader<D> {

    public AsyncTaskDataLoader(Context context) {
        super(context);
    }

    @Override
    public void deliverResult(D d) {
        if (!isReset()) {
            super.deliverResult(d);
        }
    }

    @Override
    public D loadInBackground() {
        return null;
    }

    @Override
    protected void onReset() {
        super.onReset();
        onStopLoading();
    }
}
