package com.ddlad.student.ui.listener;

import android.widget.AbsListView;

public interface InternalScrollListener {

    public void beforeScroll(int firstVisibleItem);

    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount,
                         int totalItemCount);

    public void onFling();

    public void onIdle();
}
