package com.ddlad.student.protocol.http.callbacks;

import android.content.Context;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.content.Loader;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.callbacks.ApiRequestLoaderCallbacks;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.HttpError;
import com.ddlad.student.primary.ImmediateAsyncTaskLoaderAsyncTask;
import com.ddlad.student.primary.InputStreamWrapper;
import com.ddlad.student.primary.Log;
import com.ddlad.student.primary.Meta;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.HttpResponseCode;
import com.ddlad.student.protocol.http.internal.ObjectMappedApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.request.AbstractStreamingRequest;
import com.ddlad.student.tools.FileUtil;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.StreamingApiResponse;
import com.ddlad.student.protocol.http.request.AbstractRequest;

import java.io.IOException;
import java.io.InputStream;

import ch.boye.httpclientandroidlib.HttpEntity;
import ch.boye.httpclientandroidlib.HttpResponse;
import ch.boye.httpclientandroidlib.util.EntityUtils;

public class StreamingApiRequestLoaderCallbacks<T> extends ApiRequestLoaderCallbacks<T> {

    public static final String TAG = "StreamingApiRequestLoaderCallbacks";

    public static final String PARSE_ERROR_MESSAGE = "解析错误，请稍后再试…";

    private final AbstractStreamingRequest<T> mApiRequest;

    public StreamingApiRequestLoaderCallbacks(Context context, AbstractStreamingRequest<T> request,
                                              AbstractCallbacks<T> callbacks) {
        super(context, request, callbacks);
        this.mApiRequest = request;
    }

    protected void onApiResponseObjectCreated(StreamingApiResponse<T> streamingApiResponse) {
    }

    @Override
    public Loader<ApiResponse<T>> onCreateLoader(int loaderId, Bundle bundle) {

        if (getApiCallbacks() != null) {
            getApiCallbacks().onRequestStart();
        }

        return new ImmediateAsyncTaskLoaderAsyncTask<ApiResponse<T>>(mContext) {

            @Override
            public void deliverResult(ApiResponse<T> apiResponse) {
                super.deliverResult(apiResponse);
            }

            @Override
            public StreamingApiResponse<T> loadInBackground() {

                StreamingApiResponse<T> streamingApiResponse = new StreamingApiResponse<T>();

                try {
                    mApiRequest.preProcessInBackground();

                    HttpResponse httpResponse = ApiHttpClient.getInstance().sendRequest(
                            mApiRequest.getRequest());

                    if ((httpResponse != null) && (httpResponse.getStatusLine() != null)) {

                        int statusCode = httpResponse.getStatusLine().getStatusCode();

                        streamingApiResponse.setStatus(statusCode);
                        streamingApiResponse.setStatusLine(httpResponse.getStatusLine());

                        if (statusCode == HttpResponseCode.STATUS_CODE_NOT_MODIFIED) {

                            streamingApiResponse.setNotModified(true);

                        } else if (statusCode != HttpResponseCode.STATUS_CODE_OK) {
                            HttpEntity httpEntity = httpResponse.getEntity();
                            String entity = null;

                            try {
                                entity = EntityUtils.toString(httpEntity);
                                EntityUtils.consume(httpEntity);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                            Meta meta = parseMeta(entity);

                            if (meta != null) {
                                streamingApiResponse.setCode(meta.getCode());
                                streamingApiResponse.setErrorTitle(AppContext.getContext()
                                        .getString(R.string.error));
                                streamingApiResponse.setError(meta.getDesc());
                                streamingApiResponse.setErrorDescription(meta.getDesc());
                            } else {
                                HttpError httpError = parseHttpError(entity);
                                if (httpError != null) {
                                    streamingApiResponse.setErrorTitle(AppContext.getContext()
                                            .getString(R.string.error));
                                    streamingApiResponse.setError(httpError.getError());
                                    streamingApiResponse.setErrorDescription(httpError
                                            .getError_description());
                                } else {
                                    streamingApiResponse.createWithError();
                                }
                            }

                        } else {

                            long startParseTime = SystemClock.uptimeMillis();

                            parseJsonStreaming(httpResponse, streamingApiResponse);

                            if (Log.DEBUG) {
                                long endParseTime = SystemClock.uptimeMillis();
                                Log.d(TAG,
                                        "LoadInBackground, parse streaming json end, time="
                                                + endParseTime + ", cost:"
                                                + (endParseTime - startParseTime));
                            }

                            if ((streamingApiResponse.isOk())) {
                                streamingApiResponse.setIsNetworkResponse(true);
                                onApiResponseObjectCreated(streamingApiResponse);
                            } else {
                                streamingApiResponse.createWithError();
                            }
                        }

                    } else {
                        streamingApiResponse = StreamingApiResponse.createWithError(null);
                    }
                } catch (AbstractRequest.PreProcessException e) {
                    e.printStackTrace();
                    streamingApiResponse = StreamingApiResponse.createWithError(e.getMessage());
                    mApiRequest.handleErrorInBackground(streamingApiResponse);
                }

                return streamingApiResponse;
            }

            @Override
            protected void onStartLoading() {
                super.onStartLoading();
            }
        };
    }

    private HttpError parseHttpError(String entity) {

        ObjectMappedApiResponse<HttpError> response;
        HttpError httpError = null;
        try {

            response = new ObjectMappedApiResponse<HttpError>(getContext(), entity);
            httpError = response.readRootValue(HttpError.class);

        } catch (Exception e) {
            httpError = null;
            if (Log.DEBUG) {
                Log.w(TAG, "parseHttpError failed");
            }
        }

        return httpError;
    }

    private Meta parseMeta(String entity) {
        ObjectMappedApiResponse<Meta> response;
        Meta meta = null;

        try {
            response = new ObjectMappedApiResponse<Meta>(getContext(), entity);
            meta = response.readRootValue(ProtocolConstants.JSON_FIELD_META, Meta.class);
        } catch (Exception e) {
            meta = null;
            if (Log.DEBUG) {
                Log.w(TAG, "parseMeta failed");
            }

        }

        return meta;
    }

    private void parseJsonStreaming(HttpResponse httpResponse,
                                    StreamingApiResponse<T> streamingApiResponse) {

        InputStream inputStream = null;

        try {
            HttpEntity httpEntity = httpResponse.getEntity();
            inputStream = httpEntity.getContent();

            if (mApiRequest.isNeedCache() && mApiRequest.cacheResponseFile() != null) { // 保存缓存
                inputStream = new InputStreamWrapper(inputStream, mApiRequest.cacheResponseFile());
            }

            JsonFactory jsonFactory = new JsonFactory();
            JsonParser jsonParser = jsonFactory.createJsonParser(inputStream);

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (ProtocolConstants.JSON_FIELD_DATA.equals(fieldName)) {
                    mApiRequest.processResponseField(fieldName, jsonParser, streamingApiResponse);
                    continue;
                }

                if (ProtocolConstants.JSON_FIELD_META.equals(fieldName)) {
                    jsonParser.nextToken();
                    Meta meta = Meta.fromJsonParser(AppContext.getContext(), jsonParser);
                    if (meta != null) {
                        streamingApiResponse.setCode(meta.getCode());
                        streamingApiResponse.setStatusMessage(meta.getDesc());
                    }
                    continue;
                }

                jsonParser.skipChildren();

            }

            jsonParser.close();
            mApiRequest.onResponseParsed(streamingApiResponse);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            FileUtil.closeSilently(inputStream);
        }
    }
}
