package com.ddlad.student.protocol.model;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.ui.choice.WebDetailFragment;
import com.ddlad.student.ui.course.LatestCourseDetailsFragment;
import com.ddlad.student.ui.course.NewLiveCourseDetailsFragment;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;

import java.io.IOException;

/**
 * Created by Albert
 * on 16-10-13.
 */
public class GoToPage extends BaseInfo {

    private com.ddlad.student.protocol.model.GoToPageParam params;

    public com.ddlad.student.protocol.model.GoToPageParam getParams() {
        return params;
    }

    public void setParams(com.ddlad.student.protocol.model.GoToPageParam params) {
        this.params = params;
    }

    public static GoToPage fromJsonParser(JsonParser jsonParser) throws IOException {

        GoToPage info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new GoToPage();
                }

                if ("type".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.type = jsonParser.getIntValue();
                    continue;
                }

                if ("params".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.params = com.ddlad.student.protocol.model.GoToPageParam.fromJsonParser(jsonParser);
                    continue;
                }

                jsonParser.skipChildren();
            }
        }

        return info;
    }

    public static enum GoType {

        Detail(0), Profile(1), Web(2), Feedback(3);

        private GoType(int value) {
            mValue = value;
        }

        private int mValue;

        public int getValue() {
            return mValue;
        }
    }

    public static void go(GoToPage goToPage, Activity activity) {

        if (goToPage == null || activity == null) {
            return;
        }

        Bundle bundle = new Bundle();

        switch (goToPage.getType()) {
            case 0:
                //1v1
                bundle.putString(ProtocolConstants.PARAM_CMID, goToPage.getParams().getDataId());
                NavigateUtil.navigateToNormalActivity(activity, new LatestCourseDetailsFragment(), bundle);
                break;
            case 1:
                //1v多
                bundle.putString(ProtocolConstants.PARAM_CMID, goToPage.getParams().getDataId());
                NavigateUtil.navigateToNormalActivity(activity, new NewLiveCourseDetailsFragment(), bundle);
                break;
            case 2:
                bundle.putString(ProtocolConstants.PARAM_URL, goToPage.getParams().getUrl());
                NavigateUtil.navigateToNormalActivity(activity, new WebDetailFragment(), bundle);
                break;
            case 3:
                break;
            case 4:
                bundle.putString(ProtocolConstants.PARAM_QID, goToPage.getParams().getQid());
                bundle.putString(ProtocolConstants.PARAM_ANSWERID, goToPage.getParams().getAid());
//                NavigateUtil.navigateToDetailActivity(activity, new AnswerDetailFragment(), bundle);
                break;
        }
    }

    public static Intent getIntent(GoToPage goToPage, Context context) {

        if (goToPage == null || context == null) {
            return null;
        }

        Intent intent = null;

        Bundle bundle = new Bundle();

        switch (goToPage.getType()) {
            case 0:
                bundle.putString(ProtocolConstants.PARAM_ID, goToPage.getParams().getDataId());
                bundle.putInt(ProtocolConstants.PARAM_TYPE, goToPage.getParams().getType());
//                intent = NavigateUtil.getNavigateIntent(context, DetailActivity.class, new DetailFragment(), bundle);
                break;
            case 1:
                bundle.putString(ProtocolConstants.PARAM_USER, goToPage.getParams().getDataId());
//                intent = NavigateUtil.getNavigateIntent(context, NormalActivity.class, new ProfileFragment(), bundle);
                break;
            case 2:
                bundle.putString(ProtocolConstants.PARAM_URL, goToPage.getParams().getUrl());
//                intent = NavigateUtil.getNavigateIntent(context, NormalActivity.class, new WebViewFragment(), bundle);
                break;
            case 3:
                break;
            case 4:
                bundle.putString(ProtocolConstants.PARAM_QID, goToPage.getParams().getQid());
                bundle.putString(ProtocolConstants.PARAM_ANSWERID, goToPage.getParams().getAid());
//                intent = NavigateUtil.getNavigateIntent(context, NormalActivity.class, new AnswerDetailFragment(), bundle);
                break;
        }

        return intent;
    }
}
