package com.ddlad.student.protocol.model;

import com.ddlad.student.ui.model.MultiImageInfo;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.IOException;

/**
 * Created by chen007 on 2017/11/8 0008.
 */
public class CoursesLiveBean extends BaseInfo {

    private String title;
    private String desc;
    private String url;
    private String publishTime;
    private String pubTime;
    private String openTime;
    private int type;
    private String startTime;
    private int joinCnt;
    private MultiImageInfo image;
    private String id;
    private int dataType;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public int getJoinCnt() {
        return joinCnt;
    }

    public void setJoinCnt(int joinCnt) {
        this.joinCnt = joinCnt;
    }

    public MultiImageInfo getImage() {
        return image;
    }

    public void setImage(MultiImageInfo image) {
        this.image = image;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(String publishTime) {
        this.publishTime = publishTime;
    }

    public String getPubTime() {
        return pubTime;
    }

    public void setPubTime(String pubTime) {
        this.pubTime = pubTime;
    }

    public int getDataType() {
        return dataType;
    }

    public void setDataType(int dataType) {
        this.dataType = dataType;
    }

    public String getOpenTime() {
        return openTime;
    }

    public void setOpenTime(String openTime) {
        this.openTime = openTime;
    }

    public static CoursesLiveBean fromJsonParser(JsonParser jsonParser) throws IOException {

        CoursesLiveBean info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new CoursesLiveBean();
                }

                if ("title".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.title = jsonParser.getText();
                    continue;
                }
                if ("desc".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.desc = jsonParser.getText();
                    continue;
                }
                if ("url".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.url = jsonParser.getText();
                    continue;
                }
                if ("publishTime".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.publishTime = jsonParser.getText();
                    continue;
                }
                if ("startTime".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.startTime = jsonParser.getText();
                    continue;
                }
                if ("openTime".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.openTime = jsonParser.getText();
                    continue;
                }
                if ("id".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.id = jsonParser.getText();
                    continue;
                }

                if ("type".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.type = jsonParser.getIntValue();
                    continue;
                }
                if ("joinCnt".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.joinCnt = jsonParser.getIntValue();
                    continue;
                }
                if ("dataType".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.dataType = jsonParser.getIntValue();
                    continue;
                }
                if ("pubTime".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.pubTime = jsonParser.getText();
                    continue;
                }
                if ("image".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.image = MultiImageInfo.fromJsonParser(jsonParser);
                    continue;
                }
                jsonParser.skipChildren();
            }
        }
        return info;
    }

}
