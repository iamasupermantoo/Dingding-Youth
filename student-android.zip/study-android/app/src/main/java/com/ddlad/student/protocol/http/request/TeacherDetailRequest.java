package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.model.TeacherDetailInfo;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-8-11.
 */
public class TeacherDetailRequest extends AbstractRequest<TeacherDetailInfo> {
    public TeacherDetailRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<TeacherDetailInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.getRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_TEACHER_DETAILS;
    }

    @Override
    public TeacherDetailInfo processInBackground(ApiResponse<TeacherDetailInfo> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, TeacherDetailInfo.class);
    }

    public void perform(String tid) {
        RequestParams param = getParams();
        param.put(ProtocolConstants.PARAM_TID, tid);
        super.perform();
    }

}
