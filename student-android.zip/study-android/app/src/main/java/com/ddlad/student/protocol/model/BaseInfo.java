package com.ddlad.student.protocol.model;

import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.tools.Util;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;

public class BaseInfo implements Serializable {

    private static final long serialVersionUID = -5055097765823574608L;

    protected String id;

    protected int type;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public static BaseInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        BaseInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new BaseInfo();
                }

                if ("id".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.id = jsonParser.getText();
                    continue;
                }

                jsonParser.skipChildren();
            }
        }

        return info;
    }

    public static AbstractListResponse<BaseInfo> loadSerializedList(File file, String pid) {

        InputStream inputStream = null;
        BufferedInputStream bufferedInputStream = null;

        try {
            inputStream = new FileInputStream(file);
            bufferedInputStream = new BufferedInputStream(inputStream, Util.IO_BUFFER_SIZE);
            JsonFactory jsonFactory = new JsonFactory();
            JsonParser jsonParser = jsonFactory.createJsonParser(bufferedInputStream);

            AbstractListResponse<BaseInfo> response = new AbstractListResponse<BaseInfo>() {

                @Override
                public BaseInfo getModelInfo(JsonParser jsonParser) {
                    try {
                        return BaseInfo.fromJsonParser(jsonParser);
                    } catch (JsonParseException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return null;
                }
            };

            response.parseCache(jsonParser, ProtocolConstants.JSON_FIELD_DATA);
            jsonParser.close();

            return response;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (bufferedInputStream != null) {
                try {
                    bufferedInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return null;
    }

    public static AbstractListResponse<BaseInfo> loadSerializedListOnlyPost(File file) {

        InputStream inputStream = null;
        BufferedInputStream bufferedInputStream = null;
        try {
            inputStream = new FileInputStream(file);
            bufferedInputStream = new BufferedInputStream(inputStream, Util.IO_BUFFER_SIZE);
            JsonFactory jsonFactory = new JsonFactory();
            JsonParser jsonParser = jsonFactory.createJsonParser(bufferedInputStream);

            AbstractListResponse<BaseInfo> response = new AbstractListResponse<BaseInfo>() {

                @Override
                public BaseInfo getModelInfo(JsonParser jsonParser) {
                    try {
                        BaseInfo info = BaseInfo.fromJsonParser(jsonParser);
                        return info;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    return null;
                }
            };

            response.parseCache(jsonParser, ProtocolConstants.JSON_FIELD_DATA);
            jsonParser.close();

            return response;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {

            if (bufferedInputStream != null) {
                try {
                    bufferedInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return null;
    }

}
