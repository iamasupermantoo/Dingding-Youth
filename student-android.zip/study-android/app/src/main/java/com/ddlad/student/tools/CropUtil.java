package com.ddlad.student.tools;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;

import com.ddlad.student.ui.cropper.activity.CropperActivity;

import java.io.File;

public class CropUtil {

    private static final int AVATAR_WIDTH_PX = 1080;

    public static final int IMAGE_WIDTH_PX = 1080;

    private static Intent constructCropIntentForAvatar(Activity activity, Uri uri) {
        return constructCropIntent(activity, uri, AVATAR_WIDTH_PX, AVATAR_WIDTH_PX);
    }

    private static Intent constructCropIntentForImage(Activity activity, Uri uri) {
        return constructCropIntent(activity, uri, IMAGE_WIDTH_PX, IMAGE_WIDTH_PX);
    }

    public static Intent constructCropIntentForImage(Activity activity, Uri uri, int width,
                                                     int height) {
        return constructCropIntent(activity, uri, width, height);
    }

    public static Intent constructCropIntent(Activity activity, Uri uri, int requestCode) {
        if (requestCode == Constants.REQUEST_CODE_TAKE_PHOTO
                || requestCode == Constants.REQUEST_CODE_CHOOSE_IMAGE) {
            return constructCropIntentForAvatar(activity, uri);
        } else {
            return constructCropIntentForImage(activity, uri);
        }
    }

    private static Intent constructCropIntent(Activity activity, Uri uri, int outputX, int outputY) {

        Intent intent = new Intent(activity, CropperActivity.class);
        intent.setType("image/*");
        Bitmap.CompressFormat format = Bitmap.CompressFormat.JPEG;

        Uri fileUri = Uri.fromFile(FileUtil.generateAppImageFile());

        intent.setData(uri);
        intent.putExtra("scale", false);
        intent.putExtra("scaleUpIfNeeded", false);
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        intent.putExtra("noFaceDetection", true);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);

        if (outputX > 0) {
            intent.putExtra("outputX", outputX);
        }

        if (outputY > 0) {
            intent.putExtra("outputY", outputY);
        }

        intent.putExtra("outputFormat", format.toString());

        return intent;
    }

    public static void cropImage(Activity activity, Uri uri) {
        Intent forwardIntent = constructCropIntent(activity, uri, Constants.REQUEST_CODE_CROP_IMAGE);
        activity.startActivityForResult(forwardIntent, Constants.REQUEST_CODE_CROP_IMAGE);
    }

    public static void cropImage(Activity activity, Intent intent, File galleryTempFile) {
        Uri uri = getImageUriFromResult(intent, galleryTempFile);
        Intent forwardIntent = constructCropIntent(activity, uri, Constants.REQUEST_CODE_CROP_IMAGE);
        activity.startActivityForResult(forwardIntent, Constants.REQUEST_CODE_CROP_IMAGE);
    }

    private static Uri getImageUriFromResult(Intent intent, File file) {

        Uri uri = null;

        if (intent != null) {
            uri = intent.getData();
        }

        if ((file != null) && (uri == null)) {
            uri = Uri.fromFile(file);
        }

        return uri;
    }

}
