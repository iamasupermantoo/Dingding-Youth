package com.ddlad.student.ui.attendclass.teacher;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.request.CourseDetailsRequest;
import com.ddlad.student.protocol.model.CourseDetailsInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.ui.attendclass.evaluate.EvaluateDetailsFragment;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.course.UserFeedBackAdapter;
import com.ddlad.student.R;
import com.ddlad.student.ui.widget.image.NetworkImageView;

/**
 * Created by chenjianing on 2017/3/24 0024.
 */
public class TeacherDetailFragment extends BaseFragment {

    private String mCmId;

    private CourseDetailsInfo mInfo;

    private RecyclerView mRvUserFeedBack;
    private UserFeedBackAdapter mAdapter;


    private NetworkImageView mCourseImage;
    private TextView mCourseName;
    private TextView mCourseTime;
    private TextView mTeacherName;
    private TextView mLevel;
    private TextView mPrice;
    private TextView mIntroduction;
    private TextView mConvention;


    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_teacher_detail_my;
    }

    @Override
    protected void onInitView(View contentView) {
//        mRvUserFeedBack = (RecyclerView) contentView.findViewById(R.id.user_feed_back_rv);
        mCourseImage = (NetworkImageView) contentView.findViewById(R.id.evaluate_item_image);
        mCourseName = (TextView) contentView.findViewById(R.id.evaluate_item_course);
        mCourseTime = (TextView) contentView.findViewById(R.id.evaluate_item_class_time);
        mTeacherName = (TextView) contentView.findViewById(R.id.evaluate_item_teacher);
        mLevel = (TextView) contentView.findViewById(R.id.course_detai_item_level);
        mPrice = (TextView) contentView.findViewById(R.id.evaluate_item_price);
        mConvention = (TextView) contentView.findViewById(R.id.convention);
        mIntroduction = (TextView) contentView.findViewById(R.id.course_introduction);
        mAdapter = new UserFeedBackAdapter();
        mRvUserFeedBack.setLayoutManager(new LinearLayoutManager(getActivity()));
        mRvUserFeedBack.setAdapter(mAdapter);

    }

    @Override
    protected void onInitData(Bundle bundle) {
        mCmId = (String) bundle.get("cmid");
        requestData();
        super.onInitData(bundle);
    }

    private void requestData() {
        CourseDetailsRequest courseDetailsRequest = new CourseDetailsRequest(this, getDefaultLoaderId(), new AbstractCallbacks<CourseDetailsInfo>() {
            @Override
            protected void onSuccess(CourseDetailsInfo courseDetailsInfo) {
                mInfo = courseDetailsInfo;
                String url =  mInfo.getCourse().getImage().getPattern();
                mCourseImage.setUrl(url.substring(url.indexOf("http"),url.indexOf(".png"))+".png");
                mCourseName.setText(mInfo.getCourse().getName());
//                mCourseTime  返回的数据中没有时间
                mTeacherName.setText(mInfo.getCourse().getTeacher());
                mPrice.setText(mInfo.getCourse().getPrice());
//                mLevel.setText(mInfo.getCourse().getLevel());
                mIntroduction.setText(mInfo.getCourse().getDesc());
//                mCourseTime.setText(mInfo.getCourse().getTotalCnt());
            }
        });
        courseDetailsRequest.perform(mCmId);
    }

    private void navigateCourseDetailsFragment() {
        NavigateUtil.navigateToNormalActivity(getActivity(), new EvaluateDetailsFragment(), null);
    }
}
