package com.ddlad.student.protocol.model;

import java.util.List;

/**
 * Created by Administrator on 2017/1/19 0019.
 */

public class SchedulePointsInfo extends BaseInfo{

    private List<Integer> days;

    public List<Integer> getDays() {
        return days;
    }

    public void setDays(List<Integer> days) {
        this.days = days;
    }
    public class Days{

    }
}
