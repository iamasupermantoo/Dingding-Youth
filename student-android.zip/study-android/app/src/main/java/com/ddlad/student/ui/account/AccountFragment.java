package com.ddlad.student.ui.account;


import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.ddlad.student.protocol.convert.DataCenter;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ResponseMessage;
import com.ddlad.student.protocol.http.request.MyAccountRequest;
import com.ddlad.student.protocol.model.Account;
import com.ddlad.student.protocol.model.UserInfo;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.edit.EditFragment;
import com.ddlad.student.ui.widget.image.CircleImageView;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.model.MyAccountInfo;
import com.ddlad.student.tools.NavigateUtil;

/**
 * A simple {@link BaseFragment} subclass.
 */
public class AccountFragment extends BaseFragment {

    private ImageView mSetting;
    private ViewGroup mDataManager;
    private ViewGroup mOrderManager;
    private ViewGroup mAccountSafe;
    private ViewGroup mScholarship;
    private ViewGroup mMyAccount;
    private TextView mIcon;
    private CircleImageView mAvatar;
    private TextView mName;
    private TextView mBalance;

    private Account mAccount;

    public static boolean sAccountUpdated;

    public AccountFragment() {
        // Required empty public constructor

    }


    @Override
    protected int getLayoutResource() {
        return R.layout.layout_account;
    }

    @Override
    protected void onInitData(Bundle bundle) {
        mAccount = DataCenter.getAccount();
    }

    @Override
    protected void onInitView(View contentView) {
//        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT){//4.4 全透明状态栏
//            getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//        }

        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP) {
            Window window = getActivity().getWindow();
//            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
//            window.setStatusBarColor(0);
//            getActivity().findViewById(R.id.toolbar).setBackgroundColor(Color.TRANSPARENT);
            //取消设置透明状态栏,使 ContentView 内容不再覆盖状态栏
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            //需要设置这个 flag 才能调用 setStatusBarColor 来设置状态栏颜色
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            //设置状态栏颜色
//            window.setStatusBarColor(Color.parseColor("#08b0ee"));
        }

//        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {//5.0 全透明实现
//            Window window = getActivity().getWindow();
//            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
//                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
//            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
//            window.setStatusBarColor(Color.TRANSPARENT);//calculateStatusColor(Color.WHITE, (int) alphaValue)
//        }
        mActionbar.setVisibility(View.GONE);
        mSetting = (ImageView) contentView.findViewById(R.id.setting);
        mDataManager = (ViewGroup) contentView.findViewById(R.id.data_manager);
        mOrderManager = (ViewGroup) contentView.findViewById(R.id.order_manager);
        mAccountSafe = (ViewGroup) contentView.findViewById(R.id.account_safe);
        mMyAccount = (ViewGroup) contentView.findViewById(R.id.my_account);
        mScholarship = (ViewGroup) contentView.findViewById(R.id.scholarship);
        mIcon = (TextView) contentView.findViewById(R.id.icon);
        mAvatar = (CircleImageView) contentView.findViewById(R.id.avatar);
        mName = (TextView) contentView.findViewById(R.id.name);
        mBalance = (TextView) contentView.findViewById(R.id.balance);

        setOnClickListener();


        super.onInitView(contentView);
    }

    @Override
    public void onPause() {
        super.onPause();
    }


    private void setOnClickListener() {
        mSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToSetting();
            }
        });
        mDataManager.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToEdit();
            }
        });
        mOrderManager.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToOrderManager();
            }
        });
        mAccountSafe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToAccountSafe();
            }
        });
        mMyAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToMyAccountBalance();
            }
        });
        mScholarship.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToScholarship();
            }
        });
    }

    @Override
    protected boolean isHideActionbar() {
        return true;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!isFirstCreated() && sAccountUpdated) {
            sAccountUpdated = false;
            fetchData();
        }
    }

    @Override
    protected void fetchData() {
        UserInfo user = mAccount.getUser();
        if (user != null && !TextUtils.isEmpty(user.getId())) {
            fetchAccount();
        }
    }
    private void updateHeader(MyAccountInfo account) {

        mName.setText(account.getInfo().getName());
        if (account.getInfo().getHeadImage() != null) {
//            String url =  account.getInfo().getHeadImage().getPattern();
//            mAvatar.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}w_{h}h_")));
            String url =  account.getInfo().getHeadImage().getImageSmall();
            mAvatar.setUrl(url);
            mIcon.setVisibility(View.GONE);
            mAvatar.setVisibility(View.VISIBLE);
        }
    }

//    private void updateHeader() {
//        UserInfo user = mAccount.getUser();
//
//        Log.i(TAG, "onSuccess  : name: "+user.getHeadImage().getPattern());
//        mName.setText(user.getName());
//        if (user.getHeadImage() != null) {
//            String url =  user.getHeadImage().getPattern();
//            mAvatar.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}w_{h}h_")));
//            mIcon.setVisibility(View.GONE);
//            mAvatar.setVisibility(View.VISIBLE);
//        }
//    }


//
//    private void fetchAccount() {
//        UserInfo user = mAccount.getUser();
////        Log.i(TAG, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa:::::"+user.getId());
//        AccountRequest request = new AccountRequest(this, mDefaultLoaderId,
//                new AbstractCallbacks<Account>() {
//
//                    @Override
//                    protected void onSuccess(Account account) {
//                        Log.i(TAG, "saveProfile:account.getUser().getName() "+account.getUser().getName());
//                        Log.i(TAG, "saveProfile:account.getUser().getGrade() "+account.getUser().getGrade());
//                        Log.i(TAG, "saveProfile:account.getUser().getProvince() "+account.getUser().getProvince());
//                        updateHeader();
//                    }
//
//                    @Override
//                    protected void onFail(ApiResponse<Account> response) {
//                        ResponseMessage.show(response);
//                    }
//                });
////        request.perform(user.getId());
//        request.perform();
//    }
    private void fetchAccount() {
        UserInfo user = mAccount.getUser();
//        Log.i(TAG, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa:::::"+user.getId());
        MyAccountRequest request = new MyAccountRequest(this, mDefaultLoaderId,
                new AbstractCallbacks<MyAccountInfo>() {

                    @Override
                    protected void onSuccess(MyAccountInfo account) {
                        updateHeader(account);
                    }

                    @Override
                    protected void onFail(ApiResponse<MyAccountInfo> response) {
                        ResponseMessage.show(response);
                    }
                });
//        request.perform(user.getId());
        request.perform();
    }

    @Override
    protected boolean isNeedFetch() {
        return true;
    }

    private void navigateToSetting() {
        NavigateUtil.navigateToNormalActivity(getActivity(), new SettingFragment(), null);
    }
    private void navigateToEdit() {
        NavigateUtil.navigateToNormalActivity(getActivity(), new EditFragment(), null);
    }
    private void navigateToAccountSafe() {
        NavigateUtil.navigateToNormalActivity(getActivity(), new AccountSafeFragment(), null);
    }
    private void navigateToOrderManager() {
//        NavigateUtil.navigateToNormalActivity(getActivity(), new OrderManagerFragment(), null);
        NavigateUtil.navigateToNormalActivity(getActivity(), new NewOrderMangerFragment(), null);
    }

    private void navigateToMyAccountBalance() {
        NavigateUtil.navigateToNormalActivity(getActivity(), new MyAccountBalanceFragment(), null);
    }

    private void navigateToScholarship() {
        NavigateUtil.navigateToNormalActivity(getActivity(), new ScholarshipFragment(), null);
    }

}
