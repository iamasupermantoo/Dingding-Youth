package com.ddlad.student.ui.attendclass.detail;


import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.request.CurriculumDetailRequest;
import com.ddlad.student.protocol.model.CurriculumDetailInfo;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.model.CommentInfo;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.widget.image.NetworkImageView;

/**
 * A simple {@link Fragment} subclass.
 */
public class CurriculumDetailFragment extends BaseListFragment<CommentInfo> {

    private NetworkImageView mAvatar;
    private TextView mCourse;
    private TextView mLesson;
    private TextView mTeacher;
    private TextView mLevel;
    private TextView mCost;
    private TextView mImmediateAppointment;
    private TextView mSynopsis;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_curriculum_detail;
    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle(R.string.course_detail);
    }

    @Override
    protected int getHeaderResource() {
        return R.layout.curriculum_detail_header_layout;
    }

    @Override
    protected void onInitHeader(View header) {
        mAvatar = (NetworkImageView) header.findViewById(R.id.curriculum_detail_header_avatar);
        mCourse = (TextView) header.findViewById(R.id.curriculum_detail_course);
        mLesson = (TextView) header.findViewById(R.id.curriculum_detail_lesson);
        mTeacher = (TextView) header.findViewById(R.id.curriculum_detail_teacher);
        mLevel = (TextView) header.findViewById(R.id.curriculum_detail_level);
        mCost = (TextView) header.findViewById(R.id.curriculum_detail_cost);
        mImmediateAppointment = (TextView) header.findViewById(R.id.curriculum_detail_immediate_appointment);
        mImmediateAppointment.setOnClickListener(this);
        mSynopsis = (TextView) header.findViewById(R.id.curriculum_detail_synopsis);
        getData();
    }

    @Override
    protected AbstractAdapter getAdapter() {
        if (mAdapter == null){
            mAdapter = new CommentAdapter(this);
        }
        return mAdapter;
    }

    private void getData() {
        CurriculumDetailRequest request = new CurriculumDetailRequest(this, mDefaultLoaderId, new AbstractCallbacks<CurriculumDetailInfo>() {
            @Override
            protected void onSuccess(CurriculumDetailInfo info) {
                setHeaderData(info);
            }
        });
        request.perform("CM001");
    }

    private void setHeaderData(CurriculumDetailInfo info) {
        if (info == null){
            return;
        }
        if (info.getCourse().getImage() != null){
            mAvatar.setUrl(info.getCourse().getImage().getImageSmall());
        }
        mCourse.setText(info.getCourse().getName());
        mLesson.setText(String.valueOf(info.getCourse().getTotalCnt()));
        mTeacher.setText(info.getCourse().getTeacher());
        mLevel.setText(info.getCourse().getLevel());
        mCost.setText(info.getCourse().getPrice());
        mSynopsis.setText(info.getCourse().getDesc());

    }
}
