package com.ddlad.student.protocol.http.request;

import com.ddlad.student.ui.common.BaseListFragment;
import com.fasterxml.jackson.core.JsonParser;
import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.StreamingApiResponse;
import com.ddlad.student.protocol.model.CurriculumInfo;

import java.io.IOException;

/**
 * Created by Administrator on 2016/12/8 0008.
 */

public abstract  class BaseCurriculumRequest extends com.ddlad.student.protocol.http.request.BaseListRequest<CurriculumInfo> {
    public BaseCurriculumRequest(BaseListFragment baseListFragment, int loaderId, AbstractStreamingCallbacks<AbstractListResponse<CurriculumInfo>> streamingApiCallbacks) {
        super(baseListFragment, loaderId, streamingApiCallbacks);
    }


    protected String getFieldKey() {
        return ProtocolConstants.JSON_FIELD_COURSES;
    }

    public void processResponseField(String fieldName, JsonParser jsonParser,
                                     StreamingApiResponse<AbstractListResponse<CurriculumInfo>> streamingApiResponse) throws IOException {

        AbstractListResponse response = streamingApiResponse.getSuccessObject();
        if (response == null) {
            response = new AbstractListResponse() {

                @Override
                public CurriculumInfo getModelInfo(JsonParser jsonParser) {

                    try {
                        return CurriculumInfo.fromJsonParser(jsonParser);
                    } catch (Throwable t) {
                        t.printStackTrace();
                    }

                    return null;
                }
            };
        }

        response.parse(jsonParser, getFieldKey());
        streamingApiResponse.setSuccessObject(response);
    }
}
