package com.ddlad.student.ui.course;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.protocol.model.HomeworkInfo;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.RattingBar.RatingBar;
import com.ddlad.student.ui.widget.image.CircleImageView;
import com.ddlad.student.R;


/**
 * Created by Albert
 * on 16-10-20.
 */
public class UserFeedBackListItemAdapter {

    public static View createView(ViewGroup viewGroup) {

//        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.user_feed_back_item, null);
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.course_detail_feed_back_item, null);

        ViewHolder holder = new ViewHolder(view);

        view.setTag(holder);

        return view;
    }

    public static void bindView(View view, final HomeworkInfo mInfo, final BaseFragment fragment) {

        if (mInfo == null) {
            return;
        }

        ViewHolder myViewHolder = (ViewHolder) view.getTag();

        if (myViewHolder == null) {
            return;
        }

        myViewHolder.mUserStar.setClickable(false);



    }

    private static class ViewHolder {
        public TextView mUserName;
        public RatingBar mUserStar;
        public TextView mUserTime;
        public CircleImageView mImage;
        public TextView mUserEvaluate;
        public ViewHolder(View itemView) {
            mUserName = (TextView) itemView.findViewById(R.id.item_user_name);
            mUserTime = (TextView) itemView.findViewById(R.id.item_user_time);
            mImage = (CircleImageView) itemView.findViewById(R.id.item_user_head_image);
            mUserEvaluate = (TextView) itemView.findViewById(R.id.item_user_evaluate);
            mUserStar = (RatingBar) itemView.findViewById(R.id.item_user_star);
        }
    }
}
