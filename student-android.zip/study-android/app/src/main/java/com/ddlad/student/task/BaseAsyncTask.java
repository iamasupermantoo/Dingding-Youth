package com.ddlad.student.task;

import android.os.AsyncTask;

import com.ddlad.student.tools.Util;


public abstract class BaseAsyncTask<Params, Progress, Result> extends
        AsyncTask<Params, Progress, Result> {

    /**
     * Android
     * 3.0以上，asyncTask的默认Executor由THREAD_POOL_EXECUTOR变为SERIAL_EXECUTOR
     * ，SERIAL_EXECUTOR意为顺序执行，即新启动的task要等之前的task完成后才可以执行，
     * 而非像THREAD_POOL_EXECUTOR一样可以并列执行指定个数的task。此方法相当于在3.0以上的系统中仍然按照3.0
     * 以下的执行方式去启动asyncTask
     *
     * @param params
     * @return
     */
    public final AsyncTask<Params, Progress, Result> originalExecute(Params... params) {
        if (Util.hasHoneycomb()) {
            return executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, params);
        } else {
            return execute(params);
        }
    }

}
