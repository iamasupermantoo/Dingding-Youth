package com.ddlad.student.protocol.model;

/**
 * Created by chenjianing on 2017/4/20 0020.
 */
public class PayResultInfo {


        private int result;

        public int getResult() {
            return result;
        }

        public void setResult(int result) {
            this.result = result;
        }
}
