package com.ddlad.student.primary;

import android.app.Application;
import android.os.Handler;

import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Prefs;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.PersistentCookieStore;
import com.ddlad.student.push.service.Push;
import com.ddlad.student.tools.SaveReport;
import com.ddlad.student.tools.Util;
import com.ddlad.student.tools.ViewUtil;
import com.umeng.analytics.MobclickAgent;
import com.ddlad.student.protocol.http.internal.CustomObjectMapper;
import com.ddlad.student.ui.agora.AgoraManager;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Albert
 * on 16-5-31.
 */
public class ZebraApp extends Application implements Thread.UncaughtExceptionHandler {

    public static final String PACKAGE_NAME = "com.ddlad.student";

    private static ZebraApp app;

    public static Handler mainHandler;

    private Map<String, Object> serviceMap;

    private Thread.UncaughtExceptionHandler sSystemUncaughtExceptionHandler;

    public ZebraApp() {
        app = this;
        AppContext.setContext(app);
    }

    @Override
    public void onCreate() {
        super.onCreate();

        if (Log.DEBUG) {
            Util.enableStrictMode();
        }
        mainHandler = new Handler();
//        OkHttpClient okHttpClient = new OkHttpClient.Builder()
////                .addInterceptor(new LoggerInterceptor("TAG"))
//                .connectTimeout(10000L, TimeUnit.MILLISECONDS)
//                .readTimeout(10000L, TimeUnit.MILLISECONDS)
//                //其他配置
//                .build();
//
//        OkHttpUtils.initClient(okHttpClient);


        sSystemUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(this);

        MobclickAgent.openActivityDurationTrack(false);

        AppContext.setScreenWidth(ViewUtil.getScreenWidthPixels());
        AppContext.setScreenHeight(ViewUtil.getScreenHeightPixels());

        serviceMap = new HashMap();
        PersistentCookieStore persistentCookieStore = new PersistentCookieStore(this);
        this.serviceMap.put(PersistentCookieStore.COOKIE_STORE_SERVICE, persistentCookieStore);
        this.serviceMap.put(ApiHttpClient.HTTP_CLIENT_SERVICE, new ApiHttpClient(
                persistentCookieStore));
        this.serviceMap.put(Prefs.PREFS_SERVICE, new Prefs(this));
        this.serviceMap.put(Push.PUSH_SERVICE, new Push(this));
        this.serviceMap.put(CustomObjectMapper.CUSTOM_OBJECT_MAPPER, new CustomObjectMapper(this));

        Fresco.initialize(this);
        AgoraManager.getInstance().init(getApplicationContext());

    }

    @Override
    public Object getSystemService(String serviceName) {
        if (serviceMap.containsKey(serviceName)) {
            return serviceMap.get(serviceName);
        }

        return super.getSystemService(serviceName);
    }

    @Override
    public void onTerminate() {
        super.onTerminate();

        serviceMap.clear();
        AppContext.setContext(null);
    }

    @Override
    public void uncaughtException(Thread thread, Throwable throwable) {

        SaveReport.crashLog(throwable);

        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        sSystemUncaughtExceptionHandler.uncaughtException(thread, throwable);
    }
}
