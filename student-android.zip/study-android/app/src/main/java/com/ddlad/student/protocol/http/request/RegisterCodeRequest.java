package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-6-30.
 */
public class RegisterCodeRequest extends AbstractRequest<String> {

    public RegisterCodeRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<String> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_REGISTER_CODE;
    }

    @Override
    public String processInBackground(ApiResponse<String> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, String.class);
    }

    public void perform(Object mobile) {
        RequestParams params = getParams();
        params.put("mobile", mobile);
        super.perform();
    }
}
