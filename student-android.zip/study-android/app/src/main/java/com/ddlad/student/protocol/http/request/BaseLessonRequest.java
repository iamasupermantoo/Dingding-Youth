package com.ddlad.student.protocol.http.request;

import com.fasterxml.jackson.core.JsonParser;
import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.StreamingApiResponse;
import com.ddlad.student.protocol.model.LessonInfo;

import java.io.IOException;

/**
 * Created by Administrator on 2016/12/8 0008.
 */

public abstract  class BaseLessonRequest extends com.ddlad.student.protocol.http.request.BaseListRequest<LessonInfo> {
    public BaseLessonRequest(BaseListFragment baseListFragment, int loaderId, AbstractStreamingCallbacks<AbstractListResponse<LessonInfo>> streamingApiCallbacks) {
        super(baseListFragment, loaderId, streamingApiCallbacks);
    }


    protected String getFieldKey() {
        return ProtocolConstants.JSON_FIELD_LESSONS;
    }

    public void processResponseField(String fieldName, JsonParser jsonParser,
                                     StreamingApiResponse<AbstractListResponse<LessonInfo>> streamingApiResponse) throws IOException {

        AbstractListResponse response = streamingApiResponse.getSuccessObject();
        if (response == null) {
            response = new AbstractListResponse() {

                @Override
                public LessonInfo getModelInfo(JsonParser jsonParser) {

                    try {
                        return LessonInfo.fromJsonParser(jsonParser);
                    } catch (Throwable t) {
                        t.printStackTrace();
                    }

                    return null;
                }
            };
        }

        response.parse(jsonParser, getFieldKey());
        streamingApiResponse.setSuccessObject(response);
    }
}
