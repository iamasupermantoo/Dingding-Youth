package com.ddlad.student.ui.account;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.request.LOrderListRequest;
import com.ddlad.student.protocol.model.PayResultInfo;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.request.BaseListRequest;
import com.ddlad.student.protocol.http.request.PayResultRequest;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.LOrderInfo;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.common.BaseFragment;

/**
 * A simple {@link BaseFragment} subclass.
 */
public class NewOrderMangerFragment extends BaseListFragment<LOrderInfo> {

    private int mLoaderId = ViewUtil.generateUniqueId();
    private int mPayVertifyInfoId = ViewUtil.generateUniqueId();

    public static boolean isPay = false;
    public static String mOrderSn = "";
    public static int mChannel;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_course;
    }

    @Override
    protected int getFooterResource() {
        return R.layout.footer_layout_empty;
    }


    @Override
    protected void addFooterViews(LayoutInflater inflater) {
        super.addFooterViews(inflater);
    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle("订单列表");
        super.onInitView(contentView);
    }

    @Override
    protected BaseListRequest makeRequest(AbstractStreamingCallbacks<AbstractListResponse<LOrderInfo>> streamingApiCallbacks) {
        return new LOrderListRequest(this, mLoaderId, streamingApiCallbacks);
    }

    @Override
    protected void performRequest() {
        ((LOrderListRequest)mDefaultRequest).perform();
    }

    @Override
    protected boolean isNeedFetch() {
        return true;
    }

    @Override
    protected AbstractAdapter getAdapter() {
        if (mAdapter == null) {
            mAdapter = new LOrderListAdapter(this);
        }
        return mAdapter;
    }

    @Override
    public void onResume() {
        if (isPay){
            modifyRequest();
            handleRequest(true);
        }
        super.onResume();
    }

    private void modifyRequest() {
        isPay = false;
        PayResultRequest request = new PayResultRequest(this, mPayVertifyInfoId, new AbstractCallbacks<PayResultInfo>() {
            @Override
            protected void onSuccess(PayResultInfo wxpayOrderInfo) {
                if (wxpayOrderInfo.getResult() == 1){
                    Toaster.toastShort("支付成功");
                }
            }

            @Override
            protected void onFail(ApiResponse<PayResultInfo> response) {
                Toaster.toastShort(response.getErrorDescription());
            }
        });
        request.perform(mOrderSn,mChannel);
    }

    @Override
    protected void showEmptyView() {

        if (mEmptyView == null) {
            mEmptyView = (ViewGroup) LayoutInflater.from(getActivity()).inflate(R.layout.layout_empty_footer, null);
            mListView.addFooterView(mEmptyView, null, false);
        }

        if (mAdapter == null || mAdapter.isEmpty()) {
            TextView textView = (TextView) mEmptyView.findViewById(R.id.empty_text);
            textView.setText("您还没有订单");
            mEmptyView.setVisibility(View.VISIBLE);
        } else {
            hideEmptyView();
        }

    }

    @Override
    protected void hideEmptyView() {
        if (mEmptyView != null) {
            mListView.removeFooterView(mEmptyView);
        }
        mEmptyView = null;
    }

}
