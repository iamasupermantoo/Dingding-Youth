package com.ddlad.student.protocol.model;

import java.util.List;

/**
 * Created by chen007 on 2017/11/10 0010.
 */
public class GetChargeItemInfo extends BaseInfo {

        private int totalAmount;
        /**
         * plusAmount : 10
         * product : E4I8pwyGCxmDuzLCF4Bi-Q
         * price : 128
         */

        private List<ItemsBean> items;

        public int getTotalAmount() {
            return totalAmount;
        }

        public void setTotalAmount(int totalAmount) {
            this.totalAmount = totalAmount;
        }

        public List<ItemsBean> getItems() {
            return items;
        }

        public void setItems(List<ItemsBean> items) {
            this.items = items;
        }

        public static class ItemsBean {
            private String plusAmount;
            private String product;
            private String price;

            public String getPlusAmount() {
                return plusAmount;
            }

            public void setPlusAmount(String plusAmount) {
                this.plusAmount = plusAmount;
            }

            public String getProduct() {
                return product;
            }

            public void setProduct(String product) {
                this.product = product;
            }

            public String getPrice() {
                return price;
            }

            public void setPrice(String price) {
                this.price = price;
            }
        }
}
