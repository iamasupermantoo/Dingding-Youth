package com.ddlad.student.ui.home;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;

import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.ui.account.AccountFragment;
import com.ddlad.student.ui.attendclass.AttendClassFragment;
import com.ddlad.student.ui.attendclass.NewAttendClassFragment;
import com.ddlad.student.ui.choice.NewChoiceFragment;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.common.NormalActivity;
import com.ddlad.student.ui.discover.DiscoverFragment;
import com.ddlad.student.ui.listener.HomeNavigateListener;
import com.ddlad.student.R;
import com.ddlad.student.tools.StringUtil;
import com.ddlad.student.ui.choice.ChoiceFragment;
import com.ddlad.student.ui.course.CourseFragment;

/**
 * Created by Administrator on 2017/1/16 0016.
 */

public class HomeActivity extends NormalActivity implements HomeNavigateListener {
    public static final String ACTION_HOME = "com.ddlad.student.action.home";
//    private static int defaultTabId = R.id.home_attend_class;
    private static int defaultTabId = R.id.home_choice;
    private int mCurrentTabId;
    protected BaseFragment mContentFragment;
    private Fragment mLastFragment;
    private ViewGroup mChoiceLayout;
    private ViewGroup mCourseLayout;
    private ViewGroup mAttendClassLayout;
    private ViewGroup mAccountLayout;

    private NewChoiceFragment mChoiceFragment;
    private DiscoverFragment mCourseFragment;
    private NewAttendClassFragment mAttendClassFragment;
    private AccountFragment mAccountFragment;
    @Override
    protected int getLayoutResource() {
        return R.layout.activity_home;
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            //取消设置透明状态栏,使 ContentView 内容不再覆盖状态栏
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            //需要设置这个 flag 才能调用 setStatusBarColor 来设置状态栏颜色
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            //设置状态栏颜色
            window.setStatusBarColor(Color.parseColor("#ffffff"));
        }
        if (bundle != null) {
            mCurrentTabId = bundle.getInt(ProtocolConstants.PARAM_TAB_ID, defaultTabId);
        } else {
            mCurrentTabId = defaultTabId;
        }
        AttendClassFragment.iToChoice = new AttendClassFragment.IToChoice() {
            @Override
            public void tochoice() {
                onChoiceClick(R.id.home_choice);
            }
        };
    }


    @Override
    protected BaseFragment initContentFragment() {

        mChoiceLayout = (ViewGroup) findViewById(R.id.home_choice);
        mCourseLayout = (ViewGroup) findViewById(R.id.home_course);
        mAttendClassLayout = (ViewGroup) findViewById(R.id.home_attend_class);
        mAccountLayout = (ViewGroup) findViewById(R.id.home_account);
        Bundle bundle = getIntent().getExtras();

        if (StringUtil.equals(ACTION_HOME, getIntent().getAction())) {
            int menuId = bundle.getInt(ProtocolConstants.PARAM_TAB_ID);
            mContentFragment = replaceFragment(menuId, bundle);
        } else {
            mContentFragment = replaceFragment(defaultTabId, bundle);
        }

        return mContentFragment;
    }

    private BaseFragment replaceFragment(int fragmentId, Bundle bundle) {

        BaseFragment fragment = null;
        boolean isFirstCreate = false;
//        RelativeLayout.LayoutParams linearParams =(RelativeLayout.LayoutParams) mMainContain.getLayoutParams();
        LinearLayout.LayoutParams linearParams =(LinearLayout.LayoutParams) mMainContain.getLayoutParams();
        linearParams.setMargins(0,0,0,0);
        mMainContain.setLayoutParams(linearParams);
        switch (fragmentId) {

            case R.id.home_choice:
                if (mChoiceFragment == null) {
                    mChoiceFragment = new NewChoiceFragment();
                    isFirstCreate = true;
                }
//                linearParams.setMargins(0,(int) ViewUtil.dpToPx(40),0,(int) ViewUtil.dpToPx(51));
//                mMainContain.setLayoutParams(linearParams);
                fragment = mChoiceFragment;
                mChoiceLayout.setSelected(true);
                mCourseLayout.setSelected(false);
                mAttendClassLayout.setSelected(false);
                mAccountLayout.setSelected(false);
                break;

            case R.id.home_course:
                if (mCourseFragment == null){
//                    mCourseFragment = new CourseFragment();
                    mCourseFragment = new DiscoverFragment();
                    isFirstCreate = true;
                }
//                linearParams.setMargins(0,(int) ViewUtil.dpToPx(40),0,(int) ViewUtil.dpToPx(51));
//                mMainContain.setLayoutParams(linearParams);
                fragment = mCourseFragment;
                mCourseLayout.setSelected(true);
                mChoiceLayout.setSelected(false);
                mAttendClassLayout.setSelected(false);
                mAccountLayout.setSelected(false);
                break;

            case R.id.home_attend_class:
                if (mAttendClassFragment == null){
//                    mAttendClassFragment = new AttendClassFragment();
                    mAttendClassFragment = new NewAttendClassFragment();
                    isFirstCreate = true;
                }
//                linearParams.setMargins(0,(int) ViewUtil.dpToPx(40),0,(int) ViewUtil.dpToPx(51));
//                mMainContain.setLayoutParams(linearParams);
                fragment = mAttendClassFragment;
                mAttendClassLayout.setSelected(true);
                mCourseLayout.setSelected(false);
                mChoiceLayout.setSelected(false);
                mAccountLayout.setSelected(false);
                break;

            case R.id.home_account:
                if (mAccountFragment == null) {
                    mAccountFragment = new AccountFragment();
                    isFirstCreate = true;
                }
                fragment = mAccountFragment;
                mAccountLayout.setSelected(true);
                mChoiceLayout.setSelected(false);
                mAttendClassLayout.setSelected(false);
                mCourseLayout.setSelected(false);
                break;
        }

        if (fragment != null) {
            mFragmentClassName = fragment.getClass().getName();
            replaceFragment(getSupportFragmentManager(), fragment, bundle, isFirstCreate);
            mCurrentTabId = fragmentId;
        }

        return fragment;
    }

    private void replaceFragment(FragmentManager fragmentManager, Fragment fragment, Bundle bundle, boolean isFirstCreate) {

        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        if (mLastFragment != null) {
            fragmentTransaction.detach(mLastFragment);
        }

        if (isFirstCreate) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            fragment.setArguments(bundle);
            fragmentTransaction.add(R.id.layout_container_main, fragment, fragment.getClass()
                    .getName());
        } else {
            if (fragment.getArguments() != null && bundle != null) {
                fragment.getArguments().clear();
                fragment.getArguments().putAll(bundle);
            }
            fragmentTransaction.attach(fragment);
        }

        mLastFragment = fragment;

        fragmentTransaction.commitAllowingStateLoss();
        fragmentManager.executePendingTransactions();
    }

    public void onNavigationClick(View view) {

        if (mCurrentTabId == view.getId()) {
            return;
        }

        switch (view.getId()) {
            case R.id.home_choice:
                onChoiceClick(view.getId());
                break;
            case R.id.home_course:
                onCourseClick(view.getId());
                break;
            case R.id.home_attend_class:
                onAttendClassClick(view.getId());
                break;
            case R.id.home_account:
                onAccountClick(view.getId());
                break;
        }
    }

    @Override
    public void onChoiceClick(int id) {
        replaceFragment(id, new Bundle());
    }

    @Override
    public void onAccountClick(int id) {
        replaceFragment(id, new Bundle());
    }

    @Override
    public void onCourseClick(int id) {
        replaceFragment(id, new Bundle());
    }

    @Override
    public void onAttendClassClick(int id) {
        replaceFragment(id, new Bundle());
    }

    public static void show(Context context) {
        Bundle bundle = new Bundle();
        bundle.putInt(ProtocolConstants.PARAM_TAB_ID, defaultTabId);
        show(context, bundle, -1);
    }

    public static void show(Context context, Bundle bundle) {
        if (bundle == null) {
            bundle = new Bundle();
        }
        bundle.putInt(ProtocolConstants.PARAM_TAB_ID, defaultTabId);
        show(context, bundle, -1);
    }

    public static void show(Context context, int flag) {
        Bundle bundle = new Bundle();
        bundle.putInt(ProtocolConstants.PARAM_TAB_ID, defaultTabId);
//        bundle.putBoolean(ARGUMENTS_FULL_SCREEN,true);
        show(context, bundle, flag);
    }


    public static void show(Context context, Bundle bundle, int flag) {
        Intent intent = new Intent(context, HomeActivity.class);
        intent.setFlags(flag > 0 ? flag : (Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
        if (bundle != null) {
            intent.putExtras(bundle);
            intent.setAction(ACTION_HOME);
        }
        context.startActivity(intent);
    }
}
