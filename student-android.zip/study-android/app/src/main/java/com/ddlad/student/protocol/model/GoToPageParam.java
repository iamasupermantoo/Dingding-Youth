package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.IOException;

/**
 * Created by Albert
 * on 16-10-13.
 */
public class GoToPageParam {

    private String dataId;

    private String url;

    private int type;

    private String qid;

    private String aid;

    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid;
    }

    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getDataId() {
        return dataId;
    }

    public void setDataId(String dataId) {
        this.dataId = dataId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public static GoToPageParam fromJsonParser(JsonParser jsonParser) throws IOException {

        GoToPageParam info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new GoToPageParam();
                }

                if ("dataId".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.dataId = jsonParser.getText();
                    continue;
                }

                if ("url".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.url = jsonParser.getText();
                    continue;
                }

                if ("type".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.type = jsonParser.getIntValue();
                    continue;
                }

                jsonParser.skipChildren();
            }
        }

        return info;
    }
}
