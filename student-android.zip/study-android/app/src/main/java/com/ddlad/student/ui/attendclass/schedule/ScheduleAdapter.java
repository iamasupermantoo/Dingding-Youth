package com.ddlad.student.ui.attendclass.schedule;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.ddlad.student.protocol.model.CalendarReminderCourseInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.ui.attendclass.student.ScheduleLessonFragment;
import com.ddlad.student.R;
import com.ddlad.student.ui.widget.image.NetworkImageView;

/**
 * Created by Administrator on 2017/1/19 0019.
 */

public class ScheduleAdapter extends BaseAdapter {
    private ScheduleFragment fragment;



    private CalendarReminderCourseInfo info ;
    public ScheduleAdapter(ScheduleFragment context ) {
        this.fragment =  context;
    }

//    public ScheduleAdapter(Context context , CalendarReminderCourseInfo info) {
//        this.context =  context;
//        this.info = info;
//    }

    @Override
    public int getCount() {
        if (info == null){
            return 0;
        }
        return info.getLessons().size();
    }

    @Override
    public Object getItem(int position) {
        if (info == null){
            return 0;
        }
        return info.getLessons().get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ScheduleHolder holder = null;
        if (convertView == null){
            convertView = LayoutInflater.from(fragment.getActivity()).inflate(R.layout.layout_lessons_item,null);
            holder = new ScheduleHolder(convertView);
            convertView.setTag(holder);
        }else {
            holder = (ScheduleHolder) convertView.getTag();
        }
        if (info != null){
            holder.mCourse.setText(info.getLessons().get(position).getCourse());
            holder.mLesson.setText(info.getLessons().get(position).getCnt()+"节课");
            holder.mTeacher.setText(info.getLessons().get(position).getTeacher());
            holder.mTime.setText(info.getLessons().get(position).getTime());
            String url =  info.getLessons().get(position).getCourseImage().getPattern();
            holder.mImage.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}w")));
            holder.mLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                bundle.putString("cid",info.getLessons().get(position).getCid());
                bundle.putString("lid",info.getLessons().get(position).getLid());
                bundle.putString("url",info.getLessons().get(position).getCourseImage().getPattern());
                bundle.putString("course",info.getLessons().get(position).getCourse());
                bundle.putInt("coursetime",info.getLessons().get(position).getTotalCnt());
                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new ScheduleLessonFragment(), bundle);
                }
            });
        }

//        holder.mImage.setUrl(list.get(position).get);
        return convertView;
    }
    public class ScheduleHolder{
        private NetworkImageView mImage;
        private TextView mCourse;
        private TextView mLesson;
        private TextView mTeacher;
        private TextView mTime;
        private ViewGroup mLayout;

        public ScheduleHolder(View convertView) {
            mImage = (NetworkImageView) convertView.findViewById(R.id.lessons_item_image);
            mCourse = (TextView) convertView.findViewById(R.id.lessons_item_course);
            mLesson = (TextView) convertView.findViewById(R.id.lesson_item_time_my);
            mTeacher = (TextView) convertView.findViewById(R.id.lessons_item_teacher);
            mTime = (TextView) convertView.findViewById(R.id.lessons_item_time);
            mLayout = (ViewGroup) convertView.findViewById(R.id.layout_schedule_course);
        }
    }

    public CalendarReminderCourseInfo getInfo() {
        return info;
    }

    public void setInfo(CalendarReminderCourseInfo info) {
        this.info = info;
    }
}
