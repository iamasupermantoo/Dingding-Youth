package com.ddlad.student.protocol.http.internal;

import com.ddlad.student.primary.ParamInfo;
import com.ddlad.student.tools.CollectionUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import ch.boye.httpclientandroidlib.Header;
import ch.boye.httpclientandroidlib.HttpEntity;
import ch.boye.httpclientandroidlib.client.entity.UrlEncodedFormEntity;
import ch.boye.httpclientandroidlib.client.utils.URLEncodedUtils;
import ch.boye.httpclientandroidlib.message.BasicNameValuePair;

public class RequestParams {

    private static String ENCODING = "UTF-8";

    protected ConcurrentHashMap<String, String> urlParams;

    protected List<ParamInfo> urlParamsList;

    protected ConcurrentHashMap<String, FileWrapper> fileParams;

    private boolean isAbort;

    private boolean isMultipart;

    private SimpleMultiPartEntity multiPartEntity;
    private MulitFileWrapper mulitFileWrapper;

    public void setMulitFileWrapper(String key,String type,List<String> paths){
        this.mulitFileWrapper = new MulitFileWrapper();
        this.mulitFileWrapper.setKey(key);
        this.mulitFileWrapper.setPaths(paths);
        this.mulitFileWrapper.setType(type);
    }

    public boolean isAbort() {
        return isAbort;
    }

    public void setAbort(boolean isAbort) {
        this.isAbort = isAbort;
        if (multiPartEntity != null) {
            multiPartEntity.setAbort(true);
        }
    }

    public boolean isMultipart() {
        return isMultipart;
    }

    public void setMultipart(boolean isMultipart) {
        this.isMultipart = isMultipart;
    }

    public Header getMultipartHeader() {
        return multiPartEntity == null ? null : multiPartEntity.getContentType();
    }

    /**
     * Constructs a new empty <code>RequestParams</code> instance.
     */
    public RequestParams() {
        init();
    }

    public RequestParams(boolean isMultipart) {
        this.isMultipart = isMultipart;
        init();
    }

    /**
     * Constructs a new RequestParams instance containing the key/value
     * string params from the specified map.
     *
     * @param source the source key/value string map to add.
     */
    public RequestParams(Map<String, String> source) {
        init();

        for (Map.Entry<String, String> entry : source.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    /**
     * Constructs a new RequestParams instance and populate it with a
     * single initial key/value string param.
     *
     * @param key   the key name for the intial param.
     * @param value the value string for the initial param.
     */
    public RequestParams(String key, String value) {
        init();

        put(key, value);
    }

    /**
     * Constructs a new RequestParams instance and populate it with
     * multiple initial key/value string param.
     *
     * @param keysAndValues a sequence of keys and values. Objects are
     *                      automatically converted to Strings (including the value
     *                      {@code null}).
     * @throws IllegalArgumentException if the number of arguments isn't
     *                                  even.
     */
    public RequestParams(Object... keysAndValues) {
        init();
        int len = keysAndValues.length;
        if (len % 2 != 0) throw new IllegalArgumentException("Supplied arguments must be even");
        for (int i = 0; i < len; i += 2) {
            String key = String.valueOf(keysAndValues[i]);
            String val = String.valueOf(keysAndValues[i + 1]);
            put(key, val);
        }
    }

    /**
     * Adds a key/value string pair to the request.
     *
     * @param key   the key name for the new param.
     * @param value the value for the new param.
     */
    public void put(String key, Object value) {
        if (key != null && value != null) {
            urlParams.put(key, String.valueOf(value));
        }
    }

    /**
     * Adds a List<ParamsInfo> to the request.
     *
     * @param list
     */
    public void put(List<ParamInfo> list) {
        urlParamsList = list;
    }

    /**
     * Adds a file to the request.
     *
     * @param key  the key name for the new param.
     * @param file the file to add.
     */
    public void put(String key, File file) throws FileNotFoundException {
        put(key, new FileInputStream(file), file.getName());
    }

    /**
     * Adds an input stream to the request.
     *
     * @param key    the key name for the new param.
     * @param stream the input stream to add.
     */
    public void put(String key, InputStream stream) {
        put(key, stream, null);
    }

    /**
     * Adds an input stream to the request.
     *
     * @param key      the key name for the new param.
     * @param stream   the input stream to add.
     * @param fileName the name of the file.
     */
    public void put(String key, InputStream stream, String fileName) {
        put(key, stream, fileName, null);
    }

    /**
     * Adds an input stream to the request.
     *
     * @param key         the key name for the new param.
     * @param stream      the input stream to add.
     * @param fileName    the name of the file.
     * @param contentType the content type of the file, eg.
     *                    application/json
     */
    public void put(String key, InputStream stream, String fileName, String contentType) {
        if (key != null) {
            fileParams.put(key, new FileWrapper(stream, fileName, contentType));
        }
    }

    /**
     * Removes a parameter from the request.
     *
     * @param key the key name for the parameter to remove.
     */
    public void remove(String key) {
        urlParams.remove(key);
        fileParams.remove(key);
    }

    public String get(String key) {
        return urlParams.get(key);
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        for (ConcurrentHashMap.Entry<String, String> entry : urlParams.entrySet()) {
            if (result.length() > 0) result.append("&");

            result.append(entry.getKey());
            result.append("=");
            result.append(entry.getValue());
        }

        for (ConcurrentHashMap.Entry<String, FileWrapper> entry : fileParams.entrySet()) {
            if (result.length() > 0) result.append("&");

            result.append(entry.getKey());
            result.append("=");
            result.append("FILE");
        }

        return result.toString();
    }

    /**
     * Returns an HttpEntity containing all request parameters
     */
    public HttpEntity getEntity() {
        HttpEntity entity = null;

        if (isMultipart || !fileParams.isEmpty()) {

            multiPartEntity = new SimpleMultiPartEntity();

            // Add string params
            for (ConcurrentHashMap.Entry<String, String> entry : urlParams.entrySet()) {
                multiPartEntity.addPart(entry.getKey(), entry.getValue());
            }

            // Add list params
            if (!CollectionUtil.isEmpty(urlParamsList)) {
                for (ParamInfo paramInfo : urlParamsList) {
                    multiPartEntity.addPart(paramInfo.getKey(), paramInfo.getValue());
                }
            }
            // Add file params
            int currentIndex = 0;
            int lastIndex = fileParams.entrySet().size() - 1;
            if (isAbort()) {
                return null;
            }
            boolean isLast = false;

            for (ConcurrentHashMap.Entry<String, FileWrapper> entry : fileParams.entrySet()) {
                if (isAbort()) {
                    return null;
                }
                if(this.mulitFileWrapper == null){
                    isLast = currentIndex == lastIndex;
                }
                FileWrapper file = entry.getValue();
                if (file.inputStream == null) {
                    multiPartEntity.addPart(entry.getKey(), file.getFileName(),
                            file.inputStream, isLast);
                } else if (file.contentType != null) {
                    multiPartEntity.addPart(entry.getKey(), file.getFileName(),
                            file.inputStream, file.contentType, isLast);
                } else {
                    multiPartEntity.addPart(entry.getKey(), file.getFileName(),
                            file.inputStream, isLast);
                }
                currentIndex++;
            }

            currentIndex = 0;

            if(this.mulitFileWrapper != null){
                for(String path:mulitFileWrapper.getPaths()){
                    lastIndex = this.mulitFileWrapper.getPaths().size() - 1;
                    isLast = currentIndex == lastIndex;
                    File file = new File(path);
                    if(file.exists()){
                        try {
                            FileInputStream fin = new FileInputStream(file);
                            multiPartEntity.addPart(this.mulitFileWrapper.getKey(), file.getName(),
                                    fin, this.mulitFileWrapper.getType(), isLast);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                    currentIndex++;
                }
            }

            entity = multiPartEntity;
        } else {
            try {
                entity = new UrlEncodedFormEntity(getParamsList(), ENCODING);

            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        if (isAbort()) {
            return null;
        }
        return entity;
    }

    private void init() {
        urlParams = new ConcurrentHashMap<String, String>();

        urlParamsList = new ArrayList<ParamInfo>();

        fileParams = new ConcurrentHashMap<String, FileWrapper>();

    }

    protected List<BasicNameValuePair> getParamsList() {
        List<BasicNameValuePair> params = new LinkedList<BasicNameValuePair>();

        for (ConcurrentHashMap.Entry<String, String> entry : urlParams.entrySet()) {
            params.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
        }

        if (!CollectionUtil.isEmpty(urlParamsList)) {
            for (ParamInfo paramInfo : urlParamsList) {
                params.add(new BasicNameValuePair(paramInfo.getKey(), paramInfo.getValue()));
            }
        }

        return params;
    }

    public String getParamString() {
        return URLEncodedUtils.format(getParamsList(), ENCODING);
    }

    private static class FileWrapper {

        public InputStream inputStream;

        public String fileName;

        public String contentType;

        public FileWrapper(InputStream inputStream, String fileName, String contentType) {
            this.inputStream = inputStream;
            this.fileName = fileName;
            this.contentType = contentType;
        }

        public String getFileName() {
            if (fileName != null) {
                return fileName;
            } else {
                return "nofilename";
            }
        }
    }

    private static class MulitFileWrapper {
        private String key;
        private String type;
        private List<String> paths;

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public List<String> getPaths() {
            return paths;
        }

        public void setPaths(List<String> paths) {
            this.paths = paths;
        }
    }
}
