package com.ddlad.student.ui.choice;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.model.CoursesLiveBean;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.tools.StringUtil;
import com.ddlad.student.ui.course.LatestCourseDetailsFragment;
import com.ddlad.student.ui.course.NewLiveCourseDetailsFragment;
import com.ddlad.student.ui.widget.image.NetworkImageView;


/**
 * Created by Albert
 * on 17-6-2.
 */

public class LiveCourseListItemAdapter {

    private LiveCourseListFragment fragment;

    public LiveCourseListItemAdapter(LiveCourseListFragment fragment){
        this.fragment = fragment;
    }

    public View createView(ViewGroup viewGroup) {

        View view = View.inflate(viewGroup.getContext(), R.layout.layout_live_label_item, null);

        ViewHolder holder = new ViewHolder(view);


        view.setTag(holder);

        return view;
    }


    public void bindView(View view, final CoursesLiveBean info, final int totalPageCount, final int position,final int type) {

        if (info == null) {
            return;
        }

        final ViewHolder holder = (ViewHolder) view.getTag();

        if (holder == null) {
            return;
        }

        holder.title.setText(info.getTitle());
        holder.partake_num.setText(AppContext.getString(R.string.partake_num_detail,info.getJoinCnt()));
        holder.partake_num.setVisibility(View.VISIBLE);

        if (StringUtil.isEmpty(info.getOpenTime())){
            holder.begin_time.setVisibility(View.INVISIBLE);
        }else {
            holder.begin_time.setVisibility(View.VISIBLE);
            holder.begin_time.setText(AppContext.getString(R.string.lesson_begin_time,info.getOpenTime()));
        }

        if(info.getDataType() == 2){
            holder.partake_num.setVisibility(View.GONE);
            if (StringUtil.isEmpty(info.getPubTime())){
                holder.begin_time.setVisibility(View.INVISIBLE);
            }else {
                holder.begin_time.setVisibility(View.VISIBLE);
                holder.begin_time.setText(AppContext.getString(R.string.lesson_begin_time,info.getPubTime()));
            }
        }


        holder.image.setUrl(info.getImage().getImageLarge());

        info.getDataType();

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToDetail(type,info.getDataType(),info.getId());
            }
        });

    }

    private void navigateToDetail(int type,int dataType,String id) {
        if (type == 3){
            navigateToWebDetail("");
            return;
        }
        if (type == 1){
            if (dataType == 1){
                navigateToNewLiveCourse(id);
                return;
            }
            if (dataType == 0){
                navigateToLatestCourseDetail(id);
                return;
            }
        }
        navigateToNewLiveCourse(id);

    }

    public void navigateToWebDetail(String url){
        Bundle bundle = new Bundle();
        bundle.putString(ProtocolConstants.PARAM_URL,url);
        NavigateUtil.navigateToNormalActivity(fragment.getActivity(),new WebDetailFragment(),bundle);
    }

    public void navigateToNewLiveCourse(String id){
        Bundle bundle = new Bundle();
        bundle.putString(ProtocolConstants.PARAM_CMID,id);
        NavigateUtil.navigateToNormalActivity(fragment.getActivity(),new NewLiveCourseDetailsFragment(),bundle);
    }
    public void navigateToLatestCourseDetail(String id){
        Bundle bundle = new Bundle();
        bundle.putString(ProtocolConstants.PARAM_CMID,id);
        NavigateUtil.navigateToNormalActivity(fragment.getActivity(),new LatestCourseDetailsFragment(),bundle);
    }

    private static class ViewHolder {

        TextView title;
        TextView partake_num;
        TextView begin_time;
        NetworkImageView image;

        public ViewHolder(View view){
            title = (TextView) view.findViewById(R.id.title);
            partake_num = (TextView) view.findViewById(R.id.partake_num);
            begin_time = (TextView) view.findViewById(R.id.begin_time);
            image = (NetworkImageView) view.findViewById(R.id.image);

        }
    }

}
