package com.ddlad.student.ui.attendclass.student;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.model.CurriculumInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.attendclass.lesson.LessonFragment;
import com.ddlad.student.ui.attendclass.schedule.ScheduleFragment;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.common.BaseFragment;

/**
 * Created by Administrator on 2017/1/16 0016.
 */

public class NewCurriculumItemAdapter {
    private static float imageH = (ViewUtil.getScreenWidthPixels() - ViewUtil.dpToPx(40))*4/7;
    //    13
    private static float bgH = imageH + ViewUtil.dpToPx(40) + ViewUtil.dpToPx(5);
    private static float itemH = imageH + ViewUtil.dpToPx(40);

    public static View createView(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.new_curriculum_item_layout, null);
        CurriculumHolder holder = new CurriculumHolder();

//        holder.mImage = (NetworkImageView) view.findViewById(R.id.item_image);
        holder.mImage = (com.facebook.drawee.view.SimpleDraweeView) view.findViewById(R.id.item_image);
        holder.mCourse = (TextView) view.findViewById(R.id.curriculum_item_course);
        holder.mTotalLesson = (TextView) view.findViewById(R.id.curriculum_item_total_lesson);
        holder.mTimeTable = (TextView) view.findViewById(R.id.course_table);
        holder.mLesson = (TextView) view.findViewById(R.id.lesson);

        holder.mCourseDetails = (ViewGroup) view.findViewById(R.id.item_layout);
        holder.card_item_layout = (ViewGroup) view.findViewById(R.id.card_item_layout);
        holder.bg_shadow_layout = (ViewGroup) view.findViewById(R.id.bg_shadow_layout);
        holder.course_bt_layout = (ViewGroup) view.findViewById(R.id.course_bt_layout);
        holder.lesson_bt_layout = (ViewGroup) view.findViewById(R.id.lesson_bt_layout);
        view.setTag(holder);

        return view;
    }

    public static void bindView(View view, final CurriculumInfo curriculumInfo, final BaseFragment fragment, final AbstractAdapter adapter){
        if (curriculumInfo == null){
            return;
        }
        CurriculumHolder holder = (CurriculumHolder) view.getTag();
        if (holder == null){
            return;
        }

        LinearLayout.LayoutParams paramsBg = (LinearLayout.LayoutParams) holder.bg_shadow_layout.getLayoutParams();
        paramsBg.height = (int) bgH;
        holder.bg_shadow_layout.setLayoutParams(paramsBg);

        FrameLayout.LayoutParams paramsItem = (FrameLayout.LayoutParams) holder.card_item_layout.getLayoutParams();
        paramsItem.height = (int) itemH;
        holder.card_item_layout.setLayoutParams(paramsItem);

        LinearLayout.LayoutParams paramsImage = (LinearLayout.LayoutParams) holder.mImage.getLayoutParams();
        paramsImage.height = (int) imageH;
        holder.mImage.setLayoutParams(paramsImage);

        holder.mCourse.setText(curriculumInfo.getName());
        holder.mTotalLesson.setText(String.valueOf(curriculumInfo.getTotalCnt())+"节课");
        if (curriculumInfo.getImage() != null){
            String url =  curriculumInfo.getImage().getPattern();
            Uri uri = Uri.parse(url.substring(url.indexOf("http"),url.indexOf("@{w}w")));
            holder.mImage.setImageURI(uri);
//            holder.mImage.setUrl(curriculumInfo.getImage().getImageMedium());
        }
        holder.lesson_bt_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString(ProtocolConstants.PARAM_CID,curriculumInfo.getCid());
                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new LessonFragment(), bundle);

            }
        });
        holder.course_bt_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString(ProtocolConstants.PARAM_CID,curriculumInfo.getCid());
                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new ScheduleFragment(), bundle);
//                HomeActivity.show(fragment.getActivity(), Intent.FLAG_ACTIVITY_CLEAR_TASK);
//                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new ChoiceFragment(), bundle);
            }
        });
        holder.mCourseDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Bundle bundle = new Bundle();
//                bundle.putString(ProtocolConstants.PARAM_CMID,curriculumInfo.getCmId());
//                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new CourseDetailsFragment(), bundle);
                Bundle bundle = new Bundle();
                bundle.putString(ProtocolConstants.PARAM_CID,curriculumInfo.getCid());
                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new LessonFragment(), bundle);
            }
        });


    }

    public static class CurriculumHolder{
        public com.facebook.drawee.view.SimpleDraweeView mImage;
//        private NetworkImageView mImage;
        private TextView mCourse;
        private TextView mTotalLesson;
        private TextView mTimeTable;
        private TextView mLesson;
        private ViewGroup mCourseDetails;
        private ViewGroup card_item_layout;
        private ViewGroup bg_shadow_layout;
        private ViewGroup lesson_bt_layout;
        private ViewGroup course_bt_layout;
    }
}
