package com.ddlad.student.protocol.http.internal;

import android.text.TextUtils;

import com.ddlad.student.tools.Toaster;
import com.ddlad.student.R;
import com.ddlad.student.tools.NetworkUtil;

public class ResponseMessage {

    public static void show(ApiResponse<?> response) {
        if (NetworkUtil.hasConnection() && response != null
                && !TextUtils.isEmpty(response.getErrorDescription())) {
            Toaster.toastShort(response.getErrorDescription());
        } else {
            Toaster.toastShort(R.string.network_error_message);
        }
    }

    public static void showRetry(ApiResponse<?> apiResponse) {
        if (NetworkUtil.hasConnection() && apiResponse != null
                && !TextUtils.isEmpty(apiResponse.getErrorDescription())) {
            Toaster.toastShort(apiResponse.getErrorDescription());
        } else {
            Toaster.toastShort(R.string.request_action_error);
        }
    }

    /**
     * 显示特定文案
     *
     * @param resStrId
     */
    public static void show(ApiResponse<?> apiResponse, int resStrId) {
        if (!NetworkUtil.hasConnection()) {
            Toaster.toastShort(R.string.network_error_message);
        } else {
            if (apiResponse != null && !TextUtils.isEmpty(apiResponse.getErrorDescription())) {
                Toaster.toastShort(apiResponse.getErrorDescription());
            } else {
                Toaster.toastShort(resStrId);
            }
        }
    }

    /**
     * 显示特定文案
     *
     * @param apiResponse
     * @param resString
     */
    public static void show(ApiResponse<?> apiResponse, String resString) {
        if (!NetworkUtil.hasConnection()) {
            Toaster.toastShort(R.string.network_error_message);
        } else if (TextUtils.isEmpty(resString)) {
            if (apiResponse != null && !TextUtils.isEmpty(apiResponse.getErrorDescription())) {
                Toaster.toastShort(apiResponse.getErrorDescription());
            } else {
                Toaster.toastShort(resString);
            }
        }
    }
}
