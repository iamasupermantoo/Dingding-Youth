package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.IOException;

/**
 * Created by boge on 2017/3/2.
 */

public class WxpayOrderInfo {
    private OrderInfo info;

    public OrderInfo getInfo() {
        return info;
    }

    public void setInfo(OrderInfo info) {
        this.info = info;
    }

    public static class OrderInfo{
        private String packagestr;
        private String appid;
        private String sign;
        private String partnerid;
        private String prepayid;
        private String noncestr;
        private String timestamp;

        public String getPackagestr() {
            return packagestr;
        }

        public void setPackagestr(String packagestr) {
            this.packagestr = packagestr;
        }

        public String getAppid() {
            return appid;
        }

        public void setAppid(String appid) {
            this.appid = appid;
        }

        public String getSign() {
            return sign;
        }

        public void setSign(String sign) {
            this.sign = sign;
        }

        public String getPartnerid() {
            return partnerid;
        }

        public void setPartnerid(String partnerid) {
            this.partnerid = partnerid;
        }

        public String getPrepayid() {
            return prepayid;
        }

        public void setPrepayid(String prepayid) {
            this.prepayid = prepayid;
        }

        public String getNoncestr() {
            return noncestr;
        }

        public void setNoncestr(String noncestr) {
            this.noncestr = noncestr;
        }

        public String getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(String timestamp) {
            this.timestamp = timestamp;
        }

        public static OrderInfo fromJsonParser(JsonParser jsonParser) throws IOException {

            OrderInfo info = null;

            if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

                while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                    String fieldName = jsonParser.getCurrentName();

                    if (fieldName == null) {
                        continue;
                    }

                    if (info == null) {
                        info = new OrderInfo();
                    }

                    if ("appid".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.appid = jsonParser.getText();
                        continue;
                    }
                    if ("partnerid".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.partnerid = jsonParser.getText();
                        continue;
                    }
                    if ("prepayid".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.appid = jsonParser.getText();
                        continue;
                    }
                    if ("noncestr".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.noncestr = jsonParser.getText();
                        continue;
                    }
                    if ("timestamp".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.timestamp = jsonParser.getText();
                        continue;
                    }
                    if ("sign".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.sign = jsonParser.getText();
                        continue;
                    }

                    if ("package".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.packagestr = jsonParser.getText();
                        continue;
                    }
                    jsonParser.skipChildren();
                }
            }
            return info;
        }

    }


    public static WxpayOrderInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        WxpayOrderInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new WxpayOrderInfo();
                }

                if ("info".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.info = OrderInfo.fromJsonParser(jsonParser);
                    continue;
                }

                jsonParser.skipChildren();
            }
        }
        return info;
    }

}
