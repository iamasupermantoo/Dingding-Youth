package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ddlad.student.protocol.http.internal.CustomObjectMapper;


import java.io.IOException;

/**
 * Created by Albert
 * on 16-5-30.
 */
public class Account extends com.ddlad.student.protocol.model.Person {

    private String z;

//    private UserInfo userInfo;
//    public UserInfo getUserInfo() {
//        return userInfo;
//    }
//    public void setUserInfo(UserInfo userInfo) {
//        this.userInfo = userInfo;
//    }

//    public UserInfo getInfo() {
//        return info;
//    }
//
//    public void setInfo(UserInfo info) {
//        this.info = info;
//    }
//
//    private UserInfo info;



    public String getZ() {
        return z;
    }

    public void setZ(String z) {
        this.z = z;
    }



//    public static Account fromJsonParser(JsonParser jsonParser) throws IOException {
//
//        Account info = null;
//
//        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {
//
//            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {
//
//                String fieldName = jsonParser.getCurrentName();
//
//                if (fieldName == null) {
//                    continue;
//                }
//
//                if (info == null) {
//                    info = new Account();
//                }
//
//                if ("id".equals(fieldName)) {
//                    jsonParser.nextToken();
//                    info.id = jsonParser.getText();
//                    continue;
//                }
//                if ("info".equals(fieldName)) {
//                    jsonParser.nextToken();
//                    info.info = UserInfo.fromJsonParser(jsonParser);
//                    continue;
//                }
//
//
//                jsonParser.skipChildren();
//            }
//        }
//
//        return info;
//    }
//

    public String serialize() {
        try {
            ObjectMapper mapper = CustomObjectMapper.getInstance();
            return mapper.writeValueAsString(this);
        } catch (JsonGenerationException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static Account deserialize(String accountJson) {

        try {
            return CustomObjectMapper.getInstance().readValue(accountJson, Account.class);
        } catch (Throwable t) {
            t.printStackTrace();
        }

        return null;
    }



}
