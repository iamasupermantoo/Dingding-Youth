package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by chenjianing on 2017/5/10 0010.
 */
public class UserBindListInfo extends BaseInfo {



    @JsonProperty(value = "QQ")
    public QQBean qq;

    @JsonProperty(value = "WeiXin")
    public WeiXinBean weixin;

    @JsonProperty(value = "Mobile")
    public MobileBean mobile;

    @JsonIgnore
    public QQBean getQq() {
        return qq;
    }

    @JsonIgnore
    public void setQq(QQBean qq) {
        this.qq = qq;
    }

    @JsonIgnore
    public WeiXinBean getWeixin() {
        return weixin;
    }

    @JsonIgnore
    public void setWeixin(WeiXinBean weixin) {
        this.weixin = weixin;
    }

    @JsonIgnore
    public MobileBean getMobile() {
        return mobile;
    }

    @JsonIgnore
    public void setMobile(MobileBean mobile) {
        this.mobile = mobile;
    }

        public static class QQBean {
            private String type;
            private String account;
            private int status;

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getAccount() {
                return account;
            }

            public void setAccount(String account) {
                this.account = account;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

        }

        public static class WeiXinBean {
            private String type;
            private String account;
            private int status;

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getAccount() {
                return account;
            }

            public void setAccount(String account) {
                this.account = account;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

        }

        public static class MobileBean {
            private String type;
            private String account;
            private int status;

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getAccount() {
                return account;
            }

            public void setAccount(String account) {
                this.account = account;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }
        }
}
