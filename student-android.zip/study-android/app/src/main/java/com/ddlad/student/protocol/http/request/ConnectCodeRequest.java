package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.ConnectInfo;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.protocol.http.internal.ApiResponse;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-6-30.
 */
public class ConnectCodeRequest extends AbstractRequest<ConnectInfo> {

    public ConnectCodeRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<ConnectInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_CONNECT_CODE;
    }

    @Override
    public ConnectInfo processInBackground(ApiResponse<ConnectInfo> response) {
        return response.readRootValue(ConnectInfo.class);
    }

    public void perform(Object mobile , int type) {
        RequestParams params = getParams();
        params.put("mobile", mobile);
        params.put("type", type);
        super.perform();
    }
}
