package com.ddlad.student.ui.account;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.R;

/**
 * Created by Administrator on 2017/3/17 0017.
 */
public class OrderManagerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context context;
    public OrderManagerAdapter(Context context){
        this.context = context;
    }


    public static interface OnRecyclerViewItemClickListener{
        void onItemClick(View view,int position);
    }

    private OnRecyclerViewItemClickListener mOnItemClickListener = null;

    public void setmOnItemClickListener(OnRecyclerViewItemClickListener onItemClickListener){
        mOnItemClickListener = onItemClickListener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_item,null);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 2;
    }
    class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        private TextView mOrderTime;
        private TextView mCourse;
        //总课时
        private TextView mCourseHour;
        private TextView mTeacher;
        private TextView mCourseTime;
        private TextView mMoney;
        private TextView mPay;


        public MyViewHolder(View itemView) {
            super(itemView);
            mOrderTime = (TextView) itemView.findViewById(R.id.order_time);
            mCourse = (TextView) itemView.findViewById(R.id.order_course);
            mCourseHour = (TextView) itemView.findViewById(R.id.order_course_hour);
            mTeacher = (TextView) itemView.findViewById(R.id.order_techer);
            mCourseTime = (TextView) itemView.findViewById(R.id.order_course_time);
            mMoney = (TextView) itemView.findViewById(R.id.money);
            mPay = (TextView) itemView.findViewById(R.id.pay_btn);
            mPay.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            //跳转到支付页面
            if (mOnItemClickListener != null){
                mOnItemClickListener.onItemClick(v,getPosition());
            }
        }
    }
}
