package com.ddlad.student.protocol.model;

import android.text.TextUtils;

import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.ui.model.MultiImageInfo;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;


import java.io.IOException;

/**
 * Created by Albert
 * on 16-10-13.
 */
public class BannerInfo extends BaseInfo {

    private MultiImageInfo image;
    private GoToPage gotoPage;

    private String imageUrl;

    private String desc;

    public MultiImageInfo getImage() {
        return image;
    }

    public void setImage(MultiImageInfo image) {
        this.image = image;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public GoToPage getGotoPage() {
        return gotoPage;
    }

    public void setGotoPage(GoToPage gotoPage) {
        this.gotoPage = gotoPage;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageUrl() {
        if (TextUtils.isEmpty(imageUrl) && image != null) {
            int width = AppContext.getScreenWidth();
            int height = width
                    * AppContext.getInteger(R.integer.discovery_banner_height)
                    / AppContext.getInteger(R.integer.discovery_banner_width);
            imageUrl = image.createImageUrl(width, height);
        }
        return imageUrl;
    }

    public static BannerInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        BannerInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new BannerInfo();
                }

                if ("image".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.image = MultiImageInfo.fromJsonParser(jsonParser);
                    continue;
                }

                if ("gotoPage".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.gotoPage = GoToPage.fromJsonParser(jsonParser);
                    continue;
                }

                if ("desc".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.desc = jsonParser.getText();
                    continue;
                }
                jsonParser.skipChildren();
            }
        }

        return info;
    }
}
