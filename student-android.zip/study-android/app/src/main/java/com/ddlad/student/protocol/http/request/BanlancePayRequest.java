package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.OrderSubmitInfo;
import com.ddlad.student.ui.common.BaseFragment;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Administrator on 2017/1/19 0019.
 */

public class BanlancePayRequest extends AbstractRequest<OrderSubmitInfo> {
    public BanlancePayRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<OrderSubmitInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return "pay/cost";
    }

    @Override
    public OrderSubmitInfo processInBackground(ApiResponse<OrderSubmitInfo> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, OrderSubmitInfo.class);
    }

    public void perform(int type,String product) {
        RequestParams params = getParams();
        params.put("type", type);
        params.put("product", product);
        super.perform();
    }
}
