package com.ddlad.student.protocol.model;

/**
 * Created by chen007 on 2017/11/21 0021.
 */
public class ConstantsInfo extends BaseInfo {

        /**
         * retainMinAmount : 100元
         * sharePlusAmount : 0元
         * servicePhone : 400-6000009
         */

        private ConstantsBean constants;

        public ConstantsBean getConstants() {
            return constants;
        }

        public void setConstants(ConstantsBean constants) {
            this.constants = constants;
        }

        public static class ConstantsBean {
            private String retainMinAmount;
            private String sharePlusAmount;
            private String servicePhone;

            public String getRetainMinAmount() {
                return retainMinAmount;
            }

            public void setRetainMinAmount(String retainMinAmount) {
                this.retainMinAmount = retainMinAmount;
            }

            public String getSharePlusAmount() {
                return sharePlusAmount;
            }

            public void setSharePlusAmount(String sharePlusAmount) {
                this.sharePlusAmount = sharePlusAmount;
            }

            public String getServicePhone() {
                return servicePhone;
            }

            public void setServicePhone(String servicePhone) {
                this.servicePhone = servicePhone;
            }
        }
}
