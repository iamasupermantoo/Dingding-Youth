package com.ddlad.student.protocol.model;

import com.ddlad.student.ui.model.MultiImageInfo;

/**
 * Created by Administrator on 2017/1/18 0018.
 */

public class CurriculumDetailInfo extends BaseInfo {

    //    "cid":"CE002",
//    "image":,
//    "name":"装逼的技巧",
//    "totalCnt":365,
//    "teacher":"wangsch",
//    "level":"_1",
//    "price":"998W元",
//    "desc":"这个课程，从0开始由浅入深，循序渐进叫兽学生如何装逼。
    private Course course;

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public static class Course{
        private String cid ;
        private MultiImageInfo image;
        private String name ;
        private int totalCnt ;
        private String teacher ;
        private String level ;
        private String price ;
        private String desc ;

        public String getCid() {
            return cid;
        }

        public void setCid(String cid) {
            this.cid = cid;
        }

        public MultiImageInfo getImage() {
            return image;
        }

        public void setImage(MultiImageInfo image) {
            this.image = image;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getTotalCnt() {
            return totalCnt;
        }

        public void setTotalCnt(int totalCnt) {
            this.totalCnt = totalCnt;
        }

        public String getTeacher() {
            return teacher;
        }

        public void setTeacher(String teacher) {
            this.teacher = teacher;
        }

        public String getLevel() {
            return level;
        }

        public void setLevel(String level) {
            this.level = level;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }
    }


}
