package com.ddlad.student.protocol.http.cache;

import android.graphics.Bitmap;


import com.ddlad.student.tools.Util;

import java.util.Map;

public class BitmapMemoryLruCache<T> extends LruCache<T, Bitmap> {

    private static final String TAG = "BitmapMemoryLruCache";

    private final int mMaxCount;

    private int mMinTrimCount = 60;

    public BitmapMemoryLruCache(int maxSize, int maxCount, int minTrimCount) {
        super(maxSize);
        mMaxCount = maxCount;
        mMinTrimCount = minTrimCount;
    }

    @Override
    protected int sizeOf(T key, Bitmap value) {
        return Util.getBitmapSize(value);
    }

    private void trimToCount(int maxCount) {
        int i = 0;
        while (true) {
            T key;
            Bitmap value;
            synchronized (this) {

                //                if (Log.DEBUG) {
                //                    Log.d(TAG, "trimToCount(), map.size()=" + map.size() + ", maxCount=" + maxCount
                //                            + ", mMinTrimCount=" + mMinTrimCount + ",i=" + i);
                //                }

                if (map.size() <= maxCount || (i >= mMinTrimCount && map.size() <= maxCount)
                        || map.isEmpty()) {
                    break;
                }

                //                if (Log.DEBUG) {
                //                    Log.d(TAG, "trimToCount()222, map.size()=" + map.size() + ", maxCount="
                //                            + maxCount + ", mMinTrimCount=" + mMinTrimCount + ",i=" + i);
                //                }

                Map.Entry<T, Bitmap> toEvict = map.entrySet().iterator().next();
                key = toEvict.getKey();
                value = toEvict.getValue();
                map.remove(key);
            }

            entryRemoved(true, key, value, null);
            i++;
        }
    }

    public Bitmap put(T t, Bitmap cachedBitmap) {

        //        if (Log.DEBUG) {
        //            Log.d(TAG, "put(), put into memcache, cachedBitmap=" + cachedBitmap);
        //        }

        Bitmap bitmap = super.put(t, cachedBitmap);
        trimToCount(mMaxCount);
        return bitmap;
    }

}
