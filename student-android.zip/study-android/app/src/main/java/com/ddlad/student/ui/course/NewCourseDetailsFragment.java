package com.ddlad.student.ui.course;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Html;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.request.CourseDetailsRequest;
import com.ddlad.student.protocol.http.request.YueKeRequest;
import com.ddlad.student.protocol.model.CourseDetailsInfo;
import com.ddlad.student.protocol.model.HomeWorkDetailsInfo;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.dialog.DialogBuilder;
import com.ddlad.student.ui.widget.image.NetworkImageView;

/**
 * Created by chen007 on 2017/3/24 0024.
 */
public class NewCourseDetailsFragment extends BaseFragment {

    private int mLoaderFeedBackId = ViewUtil.generateUniqueId();
    private int mYueKeBackId = ViewUtil.generateUniqueId();
    private String mCmId;

    private CourseDetailsInfo mInfo;

    private static float imageH = (ViewUtil.getScreenWidthPixels() - ViewUtil.dpToPx(40))*4/7;

    private static float bgH = imageH + ViewUtil.dpToPx(50) + ViewUtil.dpToPx(13);

    private NetworkImageView mCourseImage;
    private TextView mCourseName;
    private TextView mCourseTime;
    private TextView mTeacherName;
    private TextView mLevel;
    private TextView mPrice;
    private TextView mIntroduction;
    private TextView mConvention;

    private TextView mSutablePeople;
    private TextView sub_notice;
    private String productId;
    private ViewGroup notice_layout;


    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_new_course_detail;
    }



    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle("课程详情");
        mCourseImage = (NetworkImageView) contentView.findViewById(R.id.evaluate_item_image);
        mCourseName = (TextView) contentView.findViewById(R.id.evaluate_item_course);
        mCourseTime = (TextView) contentView.findViewById(R.id.evaluate_item_class_time);
        mTeacherName = (TextView) contentView.findViewById(R.id.evaluate_item_teacher);
        mLevel = (TextView) contentView.findViewById(R.id.course_detai_item_level);
        mPrice = (TextView) contentView.findViewById(R.id.evaluate_item_price);
        mConvention = (TextView) contentView.findViewById(R.id.convention);
        mIntroduction = (TextView) contentView.findViewById(R.id.course_introduction);
        notice_layout = (ViewGroup) contentView.findViewById(R.id.notice_layout);

        mSutablePeople = (TextView) contentView.findViewById(R.id.sutable_peple);
        sub_notice = (TextView) contentView.findViewById(R.id.sub_notice);
    }




    @Override
    protected void onInitData(Bundle bundle) {
        mCmId = (String) bundle.get("cmid");
        requestData();
        super.onInitData(bundle);
    }

    private void requestData() {
        CourseDetailsRequest courseDetailsRequest = new CourseDetailsRequest(this, getDefaultLoaderId(), new AbstractCallbacks<CourseDetailsInfo>() {
            @Override
            protected void onSuccess(CourseDetailsInfo courseDetailsInfo) {
                mInfo = courseDetailsInfo;
                String url =  mInfo.getCourse().getImage().getPattern();
                mCourseImage.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}w")));;
                mCourseName.setText(mInfo.getCourse().getName());

                mTeacherName.setText(mInfo.getCourse().getTeacher());
                mPrice.setText(mInfo.getCourse().getPrice());
//                mLevel.setText(mInfo.getCourse().getLevel());
//                mIntroduction.setText(mInfo.getCourse().getDesc());
                mIntroduction.setText(Html.fromHtml(mInfo.getCourse().getDesc()));
                //                mCourseTime  返回的数据中没有时间
                mCourseTime.setText(mInfo.getCourse().getTotalCnt()+"节课");

                mSutablePeople.setText(mInfo.getCourse().getSuitableCrowds()+"");
//                StringBuilder sb = new StringBuilder();
//                if (mInfo.getCourse().getSubNotes() != null){
//                    for (int i = 0; i < mInfo.getCourse().getSubNotes().size(); i++){
//                        if (i < mInfo.getCourse().getSubNotes().size() -1){
//                            sb.append(mInfo.getCourse().getSubNotes().get(i)+"\n");
//                        }else {
//                            sb.append(mInfo.getCourse().getSubNotes().get(i));
//                        }
//                    }
//                }
//                sub_notice.setText(sb);
                for (int i = 0;i<mInfo.getCourse().getSubNotes().size();i++){
                    View view =  LayoutInflater.from(getActivity()).inflate(R.layout.expert_notices_item,null);
                    TextView textView = (TextView) view.findViewById(R.id.subscribe_notice_1);
                    textView.setText(mInfo.getCourse().getSubNotes().get(i));
                    notice_layout.addView(view);
                }



                mConvention.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        yueke();

                    }
                });
            }
        });
        courseDetailsRequest.perform(mCmId);
    }

    public void yueke(){
        YueKeRequest request = new YueKeRequest(this, mYueKeBackId, new AbstractCallbacks<HomeWorkDetailsInfo>() {
            @Override
            protected void onSuccess(HomeWorkDetailsInfo info) {
                showDialog();
            }

            @Override
            protected void onFail(ApiResponse<HomeWorkDetailsInfo> response) {
                Toaster.toastShort(response.getErrorDescription());
            }
        });
        request.perform(mInfo.getCourse().getCmId());
    }

    private void showDialog() {
        final DialogBuilder dialogBuilder = new DialogBuilder(getActivity());

        dialogBuilder.setCanceledOnTouchOutside(false);
        dialogBuilder.setTitle("提示")
                .setMessage("您已约课成功，稍后我们的工作人员将会联系您进行确认!")
                .setMessageGravity(Gravity.CENTER)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogBuilder.dismiss();
                    }
                });
        dialogBuilder.create().show();
    }


}
