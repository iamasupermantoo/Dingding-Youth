package com.ddlad.student.ui.course;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.model.HomeWorkDetailsInfo;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.image.NetworkImageView;
import com.ddlad.student.ui.widget.voice.MediaPlayerManager;

/**
 * Created by chenjianing on 2017/3/28 0028.
 */
public class CorrectDetailsAdapter extends BaseAdapter {
    final int TYPE_1 = 0;
    final int TYPE_2 = 1;
    final int TYPE_3 = 2;
    final int TYPE_4 = 3;

    //item的最小宽度
    private int mMinWidth;
    //item的最大宽度
    private int mMaxWidth;

    private Context mContext;

    private CorrectPendingFragment fragment;
    private boolean mIsModify;

    private HomeWorkDetailsInfo mInfo;
    private LayoutInflater inflater;
    private String mHid;

    private int defaultId;


    public IRemoveAnswerListener getListener() {
        return listener;
    }

    public void setListener(IRemoveAnswerListener listener) {
        this.listener = listener;
    }

    private IRemoveAnswerListener listener = null;



    public static interface IRemoveAnswerListener{
        void removeAnswer(int position, CorrectPendingFragment fragment);
        void enlargeImage(int position, int i);
    }

    public String getmHid() {
        return mHid;
    }

    public void setmHid(String mHid) {
        this.mHid = mHid;
    }

    public boolean ismIsModify() {
        return mIsModify;
    }

    public void setmIsModify(boolean mIsModify) {
        this.mIsModify = mIsModify;
    }

    public CorrectPendingFragment getFragment() {
        return fragment;
    }

    public void setFragment(CorrectPendingFragment fragment) {
        this.fragment = fragment;
    }

    public Context getmContext() {
        return mContext;
    }

    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }

    public HomeWorkDetailsInfo getmInfo() {
        return mInfo;
    }

    public void setmInfo(HomeWorkDetailsInfo mInfo) {
        this.mInfo = mInfo;
    }

    public CorrectDetailsAdapter(BaseFragment fragment, HomeWorkDetailsInfo info, boolean isModify, String mHid, int defaultId) {
        fragment = fragment;
        inflater = LayoutInflater.from(fragment.getActivity());
        this.mInfo = info;
        this.mHid = mHid;
        this.mIsModify = isModify;
        this.defaultId = defaultId;
        //获取屏幕的宽度
        WindowManager wm = (WindowManager) fragment.getActivity().getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        //最大宽度为屏幕宽度的百分之七十
        mMaxWidth = (int) (outMetrics.widthPixels * 0.7f);
        //最小宽度为屏幕宽度的百分之十五
        mMinWidth = (int) (outMetrics.widthPixels * 0.15f);
    }

    @Override
    public int getCount() {
        if (mInfo != null){
            return mInfo.getAnswers().size();
        }else {
            return 0;

        }
    }

    @Override
    public HomeWorkDetailsInfo.AnswersBean getItem(int position) {
        if (mInfo != null){
            return mInfo.getAnswers().get(position);
        }else {
            return null;
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        if (mInfo != null){

        TextHolder textHolder = null;
        CameraHolder cameraHolder = null;
        PhotoHolder photoHolder = null;
        VoiceHolder voiceHolder = null;
        int type = getItemViewType(position);
        if (convertView == null){
            switch (type){
                case TYPE_1:
                    convertView = inflater.inflate(R.layout.pending_item_text,null);
                    textHolder = new TextHolder();
                    textHolder.mText = (TextView) convertView.findViewById(R.id.pending_item_text);
                    textHolder.mTime = (TextView) convertView.findViewById(R.id.text_time);
                    textHolder.xx = (ImageView) convertView.findViewById(R.id.xx);
                    convertView.setTag(textHolder);
                    break;
//                case TYPE_2:
//                    convertView = inflater.inflate(R.layout.pending_item_camera_image,null);
//                    cameraHolder = new CameraHolder();
//                    cameraHolder.mImage = (ImageView) convertView.findViewById(R.id.pending_item_camera_image);
//                    convertView.setTag(cameraHolder);
//                    break;
                case TYPE_2:
                    convertView = inflater.inflate(R.layout.pending_item_photo_image,null);
                    photoHolder = new PhotoHolder();
                    photoHolder.mPhotoImage1 = (NetworkImageView) convertView.findViewById(R.id.pending_item_photo_image1);
                    photoHolder.mPhotoImage2 = (NetworkImageView) convertView.findViewById(R.id.pending_item_photo_image2);
                    photoHolder.mPhotoImage3 = (NetworkImageView) convertView.findViewById(R.id.pending_item_photo_image3);
                    photoHolder.xx = (ImageView) convertView.findViewById(R.id.xx);
                    photoHolder.mTime = (TextView) convertView.findViewById(R.id.item_time);

                    convertView.setTag(photoHolder);
                    break;
                case TYPE_3:
                    convertView = inflater.inflate(R.layout.pending_item_voice,null);
                    voiceHolder = new VoiceHolder();
                    voiceHolder.mTime = (TextView) convertView.findViewById(R.id.item_time);
                    voiceHolder.mVoidLength = (TextView) convertView.findViewById(R.id.pending_item_voice_length);
                    voiceHolder.xx = (ImageView) convertView.findViewById(R.id.xx);
//                    Bitmap temp = BitmapFactory.decodeResource(fragment.getActivity().getResources(), R.drawable.adj);
//                    int width = temp.getWidth();
//                    int height = temp.getHeight();
                    //定义预转换成的图片的宽度和高度
//                    int newWidth = (int) ViewUtil.dpToPx(25);
//                    int newHeight = (int) ViewUtil.dpToPx(25);
//                    //计算缩放率，新尺寸除原始尺寸
//                    float scaleWidth = ((float) newWidth) / width;
//                    float scaleHeight = ((float) newHeight) / height;
//                    // 创建操作图片用的matrix对象
//                    Matrix matrix = new Matrix();
//                    // 缩放图片动作
//                    matrix.postScale(scaleWidth, scaleHeight);
//                    matrix.postRotate(180);
//                    Bitmap bimap = Bitmap.createBitmap(temp,0,0,width,height,matrix,true);
                    voiceHolder.mVoice = (ImageView) convertView.findViewById(R.id.pending_item_voice);
//                    BitmapDrawable bmd = new BitmapDrawable(bimap);
//                    voiceHolder.mVoice.setBackgroundDrawable(bmd);
                    voiceHolder.mLength = (ViewGroup) convertView.findViewById(R.id.pending_voice_length);
                    voiceHolder.xx = (ImageView) convertView.findViewById(R.id.xx);
                    convertView.setTag(voiceHolder);
                    break;
            }
        }else {
            switch (type){
                case TYPE_1:
                    textHolder = (TextHolder) convertView.getTag();
                    break;
//                case TYPE_2:
//                    cameraHolder = (CameraHolder) convertView.getTag();
//                    break;
                case TYPE_2:
                    photoHolder = (PhotoHolder) convertView.getTag();
                    break;
                case TYPE_3:
                    voiceHolder = (VoiceHolder) convertView.getTag();
                    break;

            }
        }

        switch (type){
            case TYPE_1:
                if (mIsModify){
                    textHolder.xx.setVisibility(View.VISIBLE);
                    textHolder.xx.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            listener.removeAnswer(position,fragment);
                        }
                    });
                }else {
                    textHolder.xx.setVisibility(View.GONE);
                }
                if (mInfo.getAnswers().get(position).getText().length()<= 3){

                    textHolder.mText.setText(mInfo.getAnswers().get(position).getText()+"      ");
                }else {
                    textHolder.mText.setText(mInfo.getAnswers().get(position).getText());
                }
                textHolder.mTime.setText(mInfo.getAnswers().get(position).getTime());
                break;
//            case TYPE_2:
//                cameraHolder.mImage.setImageURI(Uri.parse(mInfo.getAnswers().get(position).getImagePath()));
//                break;
            case TYPE_2:
                if (mIsModify){
                    photoHolder.xx.setVisibility(View.VISIBLE);
                    photoHolder.xx.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            listener.removeAnswer(position,fragment);
                        }
                    });
                }else {
                    photoHolder.xx.setVisibility(View.GONE);
                }
                if (mInfo.getAnswers().get(position).getImages().size() >= 1){
                    String url =  mInfo.getAnswers().get(position).getImages().get(0).getPattern();
//                    Glide.with(mContext).load(url.substring(url.indexOf("http"),url.indexOf("@{w}"))).into(photoHolder.mPhotoImage1);
                    photoHolder.mPhotoImage1.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}")));
                    photoHolder.mPhotoImage1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            listener.enlargeImage(position,0);
                        }
                    });

                    photoHolder.mPhotoImage2.setVisibility(View.GONE);
                    photoHolder.mPhotoImage3.setVisibility(View.GONE);
                    photoHolder.mPhotoImage1.setVisibility(View.VISIBLE);
                    photoHolder.mTime.setText(mInfo.getAnswers().get(position).getTime());
                    //viewHolder.mImage.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}")));

                }
                if (mInfo.getAnswers().get(position).getImages().size() >= 2){
//                    String url =  mInfo.getAnswers().get(position).getImages().get(0).getPattern();
//                    Glide.with(mContext).load(url.substring(url.indexOf("http"),url.indexOf("@{w}"))).into(photoHolder.mPhotoImage1);

//                    photoHolder.mPhotoImage1.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}")));
                    String url1 =  mInfo.getAnswers().get(position).getImages().get(1).getPattern();
//                    Glide.with(mContext).load(url1.substring(url1.indexOf("http"),url1.indexOf("@{w}"))).into(photoHolder.mPhotoImage2);
                    photoHolder.mPhotoImage2.setUrl(url1.substring(url1.indexOf("http"),url1.indexOf("@{w}")));
                    photoHolder.mPhotoImage2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            listener.enlargeImage(position,1);
                        }
                    });


                    photoHolder.mPhotoImage2.setVisibility(View.VISIBLE);
                    photoHolder.mPhotoImage3.setVisibility(View.GONE);
                    photoHolder.mTime.setText(mInfo.getAnswers().get(position).getTime());
                }
                if (mInfo.getAnswers().get(position).getImages().size() == 3){

//                    String url =  mInfo.getAnswers().get(position).getImages().get(0).getPattern();
//                    Glide.with(mContext).load(url.substring(url.indexOf("http"),url.indexOf("@{w}"))).into(photoHolder.mPhotoImage1);
//
////                    photoHolder.mPhotoImage1.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}")));
//                    String url1 =  mInfo.getAnswers().get(position).getImages().get(1).getPattern();
//                    Glide.with(mContext).load(url1.substring(url1.indexOf("http"),url1.indexOf("@{w}"))).into(photoHolder.mPhotoImage2);

//                    photoHolder.mPhotoImage2.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}")));
                    String url2 =  mInfo.getAnswers().get(position).getImages().get(2).getPattern();
//                    Glide.with(mContext).load(url2.substring(url2.indexOf("http"),url2.indexOf("@{w}"))).into(photoHolder.mPhotoImage3);
                    photoHolder.mPhotoImage3.setUrl(url2.substring(url2.indexOf("http"),url2.indexOf("@{w}")));

                    photoHolder.mPhotoImage3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            listener.enlargeImage(position,2);
                        }
                    });


//                    photoHolder.mPhotoImage1.setVisibility(View.VISIBLE);
//                    photoHolder.mPhotoImage2.setVisibility(View.VISIBLE);
                    photoHolder.mPhotoImage3.setVisibility(View.VISIBLE);
                    photoHolder.mTime.setText(mInfo.getAnswers().get(position).getTime());
                }


                break;
            case TYPE_3:
                if (mIsModify){
                    voiceHolder.xx.setVisibility(View.VISIBLE);
                    voiceHolder.xx.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            listener.removeAnswer(position,fragment);
                        }
                    });
                }else {
                    voiceHolder.xx.setVisibility(View.GONE);
                }

//                WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
//                DisplayMetrics outMetrics = new DisplayMetrics();
//                wm.getDefaultDisplay().getMetrics(outMetrics);
//                voiceHolder.mTime.setText(Math.round(list.get(position).getTime()) + "\"");
                voiceHolder.mTime.setText(mInfo.getAnswers().get(position).getTime());
                voiceHolder.mVoidLength.setText(mInfo.getAnswers().get(position).getAudioLength()+"");
                final VoiceHolder finalVoiceHolder = voiceHolder;
                voiceHolder.mLength.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
//                        finalVoiceHolder.mVoice.setBackgroundResource(R.drawable.play_anim);
                        finalVoiceHolder.mVoice.setImageResource(R.drawable.voice_anim);

                        final AnimationDrawable animationDrawable = (AnimationDrawable) finalVoiceHolder.mVoice.getDrawable();
                        // 播放录音
                        MediaPlayerManager.playSound(mInfo.getAnswers().get(position).getAudio(),new MediaPlayer.OnCompletionListener() {

                            public void onCompletion(MediaPlayer mp) {
                                //播放完成后修改图片
//                                finalVoiceHolder.mVoice.setBackgroundResource(R.drawable.adj);
                                animationDrawable.stop();
                                finalVoiceHolder.mVoice.setImageResource(R.drawable.voice_3);
                            }
                        });
                        animationDrawable.start();

                    }
                });

                ViewGroup.LayoutParams lp = voiceHolder.mLength.getLayoutParams();
                ///修改
                lp.width = (int) (mMinWidth + (mMaxWidth / 60f) * mInfo.getAnswers().get(position).getAudioLength());
                break;
        }

        }
        return convertView;

    }

    @Override
    public int getItemViewType(int position) {
        int type = getItem(position).getType();
        if (type == TYPE_1){
            return TYPE_1;
        }else if (type == TYPE_2){
            return TYPE_2;
        }else if (type == TYPE_3){
            return TYPE_3;
        }else {
            return TYPE_4;
        }

//        return super.getItemViewType(position);
    }

    @Override
    public int getViewTypeCount() {
        return 4;
    }
    class TextHolder{
        private TextView mText;
        private TextView mTime;
        private ImageView xx;
    }
    class CameraHolder{
        private ImageView mImage;
        private ImageView xx;
    }
    class PhotoHolder{
        private NetworkImageView mPhotoImage1;
        private NetworkImageView mPhotoImage2;
        private NetworkImageView mPhotoImage3;
        private TextView mTime;
        private ImageView xx;

    }
    class  VoiceHolder{
        private TextView mTime;
        private ImageView mVoice;
        private ViewGroup mLength;
        private TextView mVoidLength;
        private ImageView xx;
    }


}
