package com.ddlad.student.ui.attendclass.student;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.model.LessonInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.course.TeacherReactionDetailFragment;

/**
 * Created by Administrator on 2017/1/17 0017.
 */

public class ScheduleLessonItemAdapter {

    public static View createView(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_lesson_layout, null);
        LessonHolder holder = new LessonHolder();
        holder.mLeeson = (TextView) view.findViewById(R.id.lesson_item_name);
        holder.mTime = (TextView) view.findViewById(R.id.lesson_item_time);
        holder.mStatus = (TextView) view.findViewById(R.id.lesson_item_status);
        holder.mPlayback = (TextView) view.findViewById(R.id.lesson_item_playback);
        holder.mEvaluate = (TextView) view.findViewById(R.id.lesson_item_evaluate);
        holder.mHomework = (TextView) view.findViewById(R.id.lesson_item_homework);
        holder.mFeedBack = (TextView) view.findViewById(R.id.lesson_item_feedback);
        view.setTag(holder);
        return view;
    }

    public static void bindView(View view, final LessonInfo lessonInfo, final BaseFragment fragment, final AbstractAdapter adapter){
        if (lessonInfo == null){
            return;
        }
        LessonHolder holder = (LessonHolder) view.getTag();
        if (holder == null){
            return;
        }

        holder.mLeeson.setText(lessonInfo.getLabel());
        holder.mTime.setText(String.valueOf(lessonInfo.getDate()+" "+lessonInfo.getTime()));
        if (lessonInfo.getStatus() == LessonInfo.LessonType.NoLesson.getValue()){
            holder.mStatus.setText("未上课");
            holder.mStatus.setTextColor(Color.parseColor("#cccccc"));

        }else if (lessonInfo.getStatus() == LessonInfo.LessonType.AlreadyLesson.getValue()){
            holder.mStatus.setText(R.string.already_class);
            holder.mStatus.setTextColor(Color.parseColor("#fe8d25"));
        }

        holder.mPlayback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        holder.mFeedBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("cid",lessonInfo.getCid());
                bundle.putString("lid",lessonInfo.getLid());
                NavigateUtil.navigateToDetailActivity(fragment.getActivity(), new TeacherReactionDetailFragment(),bundle);
            }
        });
        holder.mEvaluate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        holder.mHomework.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

    public static class LessonHolder{
        private TextView mLeeson;
        private TextView mTime;
        private TextView mStatus;
        private TextView mPlayback;
        private TextView mEvaluate;
        private TextView mHomework;
        private TextView mFeedBack;
    }

}
