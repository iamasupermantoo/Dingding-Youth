package com.ddlad.student.protocol.http.cache;

import android.annotation.TargetApi;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.text.TextUtils;


import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;
import com.ddlad.student.protocol.http.cache.BitmapMemoryLruCache;
import com.ddlad.student.protocol.http.cache.CacheAsyncTask;
import com.ddlad.student.tools.ArrayUtils;
import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.tools.FileUtil;
import com.ddlad.student.tools.GalleryUtil;
import com.ddlad.student.tools.HttpUtil;
import com.ddlad.student.tools.LibWebpUtil;
import com.ddlad.student.tools.NetworkUtil;
import com.ddlad.student.tools.StringUtil;
import com.ddlad.student.tools.ThreadPoolUtil;
import com.ddlad.student.tools.Util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import ch.boye.httpclientandroidlib.Header;
import ch.boye.httpclientandroidlib.HttpEntity;
import ch.boye.httpclientandroidlib.HttpHost;
import ch.boye.httpclientandroidlib.HttpResponse;
import ch.boye.httpclientandroidlib.HttpStatus;
import ch.boye.httpclientandroidlib.client.cache.HttpCacheEntry;
import ch.boye.httpclientandroidlib.client.cache.Resource;
import ch.boye.httpclientandroidlib.client.methods.HttpGet;
import ch.boye.httpclientandroidlib.conn.params.ConnRoutePNames;
import ch.boye.httpclientandroidlib.impl.client.DefaultHttpClient;
import ch.boye.httpclientandroidlib.impl.client.cache.DefaultHttpCacheEntrySerializer;
import ch.boye.httpclientandroidlib.impl.client.cache.HeapResource;
import ch.boye.httpclientandroidlib.impl.conn.tsccm.ThreadSafeClientConnManager;
import ch.boye.httpclientandroidlib.params.BasicHttpParams;
import ch.boye.httpclientandroidlib.params.HttpConnectionParams;
import ch.boye.httpclientandroidlib.params.HttpParams;
import ch.boye.httpclientandroidlib.util.ByteArrayBuffer;
import ch.boye.httpclientandroidlib.util.EntityUtils;

public class NetworkImageCache {

    private static final String TAG = "NetworkImageCache";

    public static final int MAX_ENTRIES = 350;

    public static final int MAX_SIZE = 31457280;

    private static final int MAX_TASKS = 4;

    public static final int MIN_TRIM_COUNT = 60;

    static final BitmapFactory.Options options = new BitmapFactory.Options();

    private static NetworkImageCache sInstance;

    private DefaultHttpClient mHttpClient;

    private BitmapMemoryLruCache<String> mLoadedBitmaps = new BitmapMemoryLruCache<String>(
            MAX_SIZE, MAX_ENTRIES, MIN_TRIM_COUNT);

    private com.ddlad.student.protocol.http.cache.PaHttpCacheStorage mStorage;

    private HashMap<String, LoadBitmapTask> mAllTasks = new HashMap<String, LoadBitmapTask>();

    private HashSet<LoadBitmapTask> mRunningTasks = new HashSet<LoadBitmapTask>();

    private LinkedList<LoadBitmapTask> mTaskQueue = new LinkedList<LoadBitmapTask>();

    static {
        options.inPurgeable = Boolean.TRUE;
        options.inInputShareable = Boolean.FALSE;
    }

    public NetworkImageCache(Context context) {

        try {
            mStorage = new com.ddlad.student.protocol.http.cache.PaHttpCacheStorage(context, new DefaultHttpCacheEntrySerializer());
        } catch (Exception e) {
            e.printStackTrace();
        }

        ThreadSafeClientConnManager threadSafeClientConnManager = new ThreadSafeClientConnManager();
        threadSafeClientConnManager.setDefaultMaxPerRoute(10);
        threadSafeClientConnManager.setMaxTotal(10);

        HttpParams httpParams = new BasicHttpParams();
        HttpConnectionParams.setTcpNoDelay(httpParams, Boolean.TRUE);
        HttpConnectionParams.setConnectionTimeout(httpParams, 10 * 1000);
        HttpConnectionParams.setSoTimeout(httpParams, 30 * 1000);

        mHttpClient = new DefaultHttpClient(threadSafeClientConnManager, httpParams);

        // 代理支持
        int netType = NetworkUtil.getAccessPointType(AppContext.getContext());
        if (netType == NetworkUtil.APN_PROXY) {
            HttpHost proxy = new HttpHost(NetworkUtil.getHostIp(), NetworkUtil.getHostPort());
            mHttpClient.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);
        }

        // 测试抓包
        HttpUtil.captureRequest(mHttpClient);
    }

    private static synchronized void createCache(Context context) {
        try {
            sInstance = new NetworkImageCache(context);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static NetworkImageCache getInstance() {
        if (sInstance == null) {
            createCache(AppContext.getContext());
        }
        return sInstance;
    }

    private void queueTask(boolean addFirst, LoadBitmapTask task) {
        if (addFirst) {
            mTaskQueue.addFirst(task);
        } else {
            mTaskQueue.addLast(task);
        }
    }

    public void preLoadBitmaps(String[] urls) {
        int urlCount = urls.length;
        for (int i = 0; i < urlCount; i++) {
            loadBitmap(urls[i], null, false, false);
        }
    }

    public Bitmap preLoadBitmapFromMemory(String[] urls) {
        int urlCount = urls.length;
        Bitmap bitmap = null;
        for (int i = 0; i < urlCount; i++) {
            if (TextUtils.isEmpty(urls[i])) {
                continue;
            }
            bitmap = mLoadedBitmaps.get(urls[i]);

            if (bitmap != null) {
                break;
            }
        }

        return bitmap;
    }

    public void loadBitmap(String url, BitmapCallback callback, boolean reportProgress,
                           boolean addFirst) {

        if (TextUtils.isEmpty(url)) {
            return;
        }

        Bitmap bitmap = mLoadedBitmaps.get(url);

        if (bitmap == null) {
            if (!mAllTasks.containsKey(url)) {
                LoadBitmapTask task = new LoadBitmapTask(url, reportProgress);
                if (callback != null) {
                    task.addCallback(callback);
                }

                mAllTasks.put(url, task);
                queueTask(addFirst, task);
            } else {
                LoadBitmapTask task = mAllTasks.get(url);
                if (callback != null) {
                    task.addCallback(callback);
                    if (reportProgress) {
                        task.setReportProgress(reportProgress);
                    }
                }

                if (!mRunningTasks.contains(task)) {
                    mTaskQueue.remove(task);
                    queueTask(addFirst, task);
                }
            }

            updateTasks();
        } else {
            if (callback != null) {
                callback.setBitmap(url, bitmap, Boolean.FALSE);
            }
        }

    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void updateTasks() {
        while ((mRunningTasks.size() < MAX_TASKS) && (!mTaskQueue.isEmpty())) {
            LoadBitmapTask task = mTaskQueue.removeFirst();
            mRunningTasks.add(task);
            task.executeOnExecutor(ThreadPoolUtil.getThreadPoolExecutor(), new Void[0]);
        }
    }

    public interface BitmapCallback {

        public void bindToTask(LoadBitmapTask task);

        public void reportError();

        public void reportProgress(String url, int progress);

        public void setBitmap(String url, Bitmap bitmap, boolean isFade);
    }

    /**
     * 查找图片是否在磁盘中
     */
    public boolean isImageCached(String url) {

        return (mStorage != null && !TextUtils.isEmpty(url) && mStorage.getEntry(url) != null);

    }

    public class LoadBitmapTask extends CacheAsyncTask<Void, Integer, Bitmap> {

        private List<BitmapCallback> mCallbacks = new ArrayList();

        protected String mUrl;

        private int mProgress = 0;

        @SuppressWarnings("unused")
        private boolean mReportProgress;

        public LoadBitmapTask(String url, boolean reportProgress) {
            mUrl = url;
            mReportProgress = reportProgress;
            setDefaultExecutor(ThreadPoolUtil.getThreadPoolExecutor());
        }

        private void reportProgressToCallbacks(Integer progress) {

            Iterator<BitmapCallback> iterator = mCallbacks.iterator();
            while (iterator.hasNext()) {
                BitmapCallback bitmapCallback = iterator.next();
                if (bitmapCallback == null) {
                    continue;
                }
                bitmapCallback.reportProgress(mUrl, progress.intValue());
            }
        }

        public void addCallback(BitmapCallback callback) {
            callback.bindToTask(this);
            callback.reportProgress(mUrl, mProgress);
            mCallbacks.add(callback);
        }

        protected Bitmap doInBackground(Void... params) {
            if (mUrl.startsWith("file:")) {
                return loadFileBitmap(mUrl);
            } else {
                return loadBitmap(mUrl);
            }
        }

        public String getUrl() {
            return mUrl;
        }

        protected void onPostExecute(Bitmap bitmap) {

            Iterator<BitmapCallback> iterator = mCallbacks.iterator();
            mAllTasks.remove(mUrl);
            while (iterator.hasNext()) {
                BitmapCallback bitmapCallback = iterator.next();

                if (bitmapCallback == null) {
                    continue;
                }

                if (bitmap != null) {
                    bitmapCallback.setBitmap(mUrl, bitmap, Boolean.TRUE);
                    continue;
                }

                bitmapCallback.reportError();
            }

            mRunningTasks.remove(this);
            updateTasks();

            super.onPostExecute(bitmap);
        }

        protected void onPreExecute() {
            reportProgressToCallbacks(Integer.valueOf(0));
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            mProgress = values[0].intValue();

            reportProgressToCallbacks(Integer.valueOf(this.mProgress));
            super.onProgressUpdate(values);
        }

        public void setReportProgress(boolean reportProgress) {
            this.mReportProgress = reportProgress;
        }

        public void removeCallback(BitmapCallback callback) {
            mCallbacks.remove(callback);
        }

    }

    private byte[] readBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        byte[] buffer = new byte[Util.IO_BUFFER_SIZE];
        int i;
        while (-1 != (i = inputStream.read(buffer))) {
            outputStream.write(buffer, 0, i);
        }

        return outputStream.toByteArray();
    }

    private byte[] toByteArray(HttpEntity httpEntity, boolean reportProgress,
                               LoadBitmapTask loadBitmapTask) throws IOException {
        int bufferSize = Util.IO_BUFFER_SIZE;

        if (httpEntity == null) {
            throw new IllegalArgumentException("HTTP entity may not be null");
        }

        InputStream inputStream = httpEntity.getContent();
        if (inputStream == null) {
            return null;
        }

        int contentLength = (int) httpEntity.getContentLength();
        try {
            if (contentLength > Integer.MAX_VALUE) {
                throw new IllegalArgumentException("HTTP entity too large to be buffered in memory");
            }

            ByteArrayBuffer byteArrayBuffer = new ByteArrayBuffer(bufferSize);
            int n;
            byte[] buffer = new byte[bufferSize];
            while ((n = inputStream.read(buffer)) != -1) {
                byteArrayBuffer.append(buffer, 0, n);

                if (reportProgress && loadBitmapTask != null) {
                    int progerss = (int) (byteArrayBuffer.length() * 100 / contentLength);
                    loadBitmapTask.publishProgress(progerss);
                }
            }

            return (byteArrayBuffer.length() == contentLength) ? byteArrayBuffer.toByteArray()
                    : null;
        } finally {
            inputStream.close();
        }
    }

    private Bitmap loadBitmap(String url) {

        Bitmap bitmap = null;

        bitmap = getStorageBitmapInBakground(url);

        if (bitmap != null) {

            return bitmap;
        }

        return downloadCacheImage(url);
    }

    private Bitmap loadFileBitmap(String mUrl) {
        Uri uri = Uri.parse(mUrl);
        String path = uri.getPath();
        Map<String, String> pvs = Util.parseUriQuery(uri.getEncodedQuery());
        int size = 640;
        if (!CollectionUtil.isEmpty(pvs)) {
            try {
                String value = pvs.get("size");
                if (!TextUtils.isEmpty(value)) {
                    size = Integer.parseInt(value.trim());
                }

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        return GalleryUtil.getBitmap(path, size);
    }

    public Bitmap getStorageBitmapInBakground(String url) {

        Resource resource = null;
        byte[] data;

        try {
            if (mStorage != null) {
                long startTime = System.currentTimeMillis();
                HttpCacheEntry entry = mStorage.getEntry(url);

                if (entry != null) {
                    resource = entry.getResource();
                    data = readBytes(resource.getInputStream());
                    if (!ArrayUtils.isEmpty(data)) {
                        boolean iswebp = false;
                        if (entry.getAllHeaders() != null) {
                            for (Header h : entry.getAllHeaders()) {
                                if (StringUtil.equalsIgnoreCase(h.getName(), "Content-Type")
                                        && StringUtil.equalsIgnoreCase(h.getValue(), "image/webp")) {
                                    iswebp = true;

                                    break;
                                }
                            }
                        }

                        long readFromStoregeTime = 0;
                        if (Log.DEBUG) {
                            readFromStoregeTime = System.currentTimeMillis() - startTime;
                        }
                        startTime = System.currentTimeMillis();
                        Bitmap bitmap = iswebp ? LibWebpUtil.decoderWebpToBitmap(data, options)
                                : BitmapFactory.decodeByteArray(data, 0, data.length, options);
                        if (Log.DEBUG) {
                            Log.d(TAG,
                                    "From Storage time-consuming:" + readFromStoregeTime
                                            + ", decode image time-consuming："
                                            + (System.currentTimeMillis() - startTime));
                        }

                        if (bitmap != null) {

                            mLoadedBitmaps.put(url, bitmap);
                            return bitmap;
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public Bitmap downloadCacheImage(String url) {

        if (TextUtils.isEmpty(url)) {
            return null;
        }

        HttpEntity entity = null;
        HttpGet getRequest = null;
        Resource resource = null;
        byte[] data;

        try {
            getRequest = new HttpGet(url);
            long startTime = System.currentTimeMillis();
            HttpResponse response = mHttpClient.execute(getRequest);
            final int statusCode = response.getStatusLine().getStatusCode();

            if (statusCode != HttpStatus.SC_OK) {

                if (getRequest != null) {
                    getRequest.abort();
                }

                if (Log.DEBUG) {
                    Log.e(TAG, "Error " + statusCode + " while retrieving bitmap from " + url);
                }

                return null;
            }

            entity = response.getEntity();

            if (entity != null) {
                data = toByteArray(entity, false, null);

                EntityUtils.consume(entity);
                if (!ArrayUtils.isEmpty(data)) {
                    Date date = new Date();
                    resource = new HeapResource(data);
                    Header[] headers = response.getAllHeaders();

                    if (mStorage != null) {
                        HttpCacheEntry cacheEntry = new HttpCacheEntry(date, date,
                                response.getStatusLine(), headers, resource);
                        mStorage.putEntry(url, cacheEntry); // save to disk                            
                    }

                    boolean isWebp = false;
                    if (headers != null) {
                        for (Header h : headers) {
                            if (StringUtil.equalsIgnoreCase(h.getName(), "Content-Type")
                                    && StringUtil.equalsIgnoreCase(h.getValue(), "image/webp")) {
                                isWebp = true;
                                break;
                            }
                        }
                    }
                    if (Log.DEBUG) {
                        Log.d(TAG, "From net server  time-consuming："
                                + (System.currentTimeMillis() - startTime) + "  getContentLength= "
                                + entity.getContentLength() + "  url=" + url);
                    }
                    startTime = System.currentTimeMillis();
                    Bitmap bitmap = isWebp ? LibWebpUtil.decoderWebpToBitmap(data, options)
                            : BitmapFactory.decodeByteArray(data, 0, data.length, options);
                    if (Log.DEBUG) {
                        Log.d(TAG, "decode image time-consuming："
                                + (System.currentTimeMillis() - startTime));
                    }

                    if (bitmap != null) {

                        mLoadedBitmaps.put(url, bitmap); // save to memory
                        return bitmap;
                    }
                }

            }

        } catch (Exception e) {
            if (getRequest != null) {
                getRequest.abort();
            }
            Log.e(TAG, "1-Error in downloadBitmap - " + e + ", url=" + url);

        } finally {
            if (entity != null) {
                try {
                    EntityUtils.consume(entity);
                } catch (Exception e1) {
                    e1.printStackTrace();

                    if (getRequest != null) {
                        getRequest.abort();
                    }
                }
            }
        }

        return null;

    }

    public String downloadOfflineImage(String url) {

        if (TextUtils.isEmpty(url)) {
            return null;
        }

        HttpEntity entity = null;
        HttpGet getRequest = null;

        File imageFile = null;
        FileOutputStream fileOutputStream = null;

        byte[] data;

        try {

            getRequest = new HttpGet(url);
            HttpResponse response = mHttpClient.execute(getRequest);
            final int statusCode = response.getStatusLine().getStatusCode();

            if (statusCode != HttpStatus.SC_OK) {
                if (getRequest != null) {
                    getRequest.abort();
                }
                return null;
            }

            entity = response.getEntity();

            if (entity != null) {

                data = toByteArray(entity, false, null);
                EntityUtils.consume(entity);

                if (!ArrayUtils.isEmpty(data)) {

                    Header[] headers = response.getAllHeaders();

                    boolean isWebp = false;
                    if (headers != null) {
                        for (Header h : headers) {
                            if (StringUtil.equalsIgnoreCase(h.getName(), "Content-Type")
                                    && StringUtil.equalsIgnoreCase(h.getValue(), "image/webp")) {
                                isWebp = true;
                                break;
                            }
                        }
                    }

                    Bitmap bitmap = isWebp ? LibWebpUtil.decoderWebpToBitmap(data, options)
                            : BitmapFactory.decodeByteArray(data, 0, data.length, options);

                    if (bitmap != null) {

                        // Save to file
                        imageFile = FileUtil.generateOfflineImageFile(url);

                        imageFile.createNewFile();
                        fileOutputStream = new FileOutputStream(imageFile);
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
                        fileOutputStream.close();

                        String filename = imageFile.getName();
                        String title = TextUtils.substring(filename, 0, filename.length() - 4);

                        if (Log.DEBUG) {
                            Log.d(TAG, "doInBackground(), filename=" + filename + ", title="
                                    + title + ", imageFile.getPath()=" + imageFile.getPath());
                        }

                        ContentValues contentValues = new ContentValues();
                        contentValues.put(MediaStore.Images.ImageColumns.TITLE, title);
                        contentValues.put(MediaStore.Images.ImageColumns.DISPLAY_NAME, filename);
                        contentValues.put(MediaStore.Images.ImageColumns.DATE_TAKEN,
                                Long.valueOf(System.currentTimeMillis()));
                        contentValues.put(MediaStore.Images.ImageColumns.MIME_TYPE, "image/jpg");
                        contentValues.put(MediaStore.Images.ImageColumns.DATA, imageFile.getPath());

                        ContentResolver mResolver = AppContext.getContext().getContentResolver();
                        mResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                contentValues);
                    }
                }
            }
        } catch (Throwable t) {
            t.printStackTrace();

            if (getRequest != null) {
                getRequest.abort();
            }

        } finally {

            if (fileOutputStream != null) {
                try {
                    fileOutputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (entity != null) {
                try {
                    EntityUtils.consume(entity);
                } catch (Throwable t) {
                    t.printStackTrace();
                    if (getRequest != null) {
                        getRequest.abort();
                    }
                }
            }
        }

        if (imageFile != null && imageFile.exists()) {
            return imageFile.getPath();
        }

        return null;
    }

    public void addBitmapToCache(String uri, Bitmap bitmap) {
        if (bitmap != null && !TextUtils.isEmpty(uri)) {
            Bitmap oldBitmap = mLoadedBitmaps.put(uri, bitmap);
            if (oldBitmap != null && !oldBitmap.isRecycled()) {
                oldBitmap.recycle();
                oldBitmap = null;
            }
        }
    }

    public void removeBitmapNoRecycle(String uri) {
        if (!TextUtils.isEmpty(uri)) {
            mLoadedBitmaps.remove(uri);
        }
    }

    public void removeBitmapAndRecycle(String uri) {
        if (!TextUtils.isEmpty(uri)) {
            Bitmap bitmap = mLoadedBitmaps.remove(uri);
            if (bitmap != null && !bitmap.isRecycled()) {
                bitmap.recycle();
                bitmap = null;
            }
        }
    }

    public void clearCache(boolean isTemp) {
        mStorage.clearCache(isTemp);
    }

    public void fastClearCache() {
        mLoadedBitmaps.evictAll();
        mStorage.fastClearCache();
    }

    public int getTaskCount() {

        return mAllTasks.size();
    }

    public Bitmap getBitmap(String url) {
        if (!TextUtils.isEmpty(url)) {
            return mLoadedBitmaps.get(url);
        }
        return null;
    }

}
