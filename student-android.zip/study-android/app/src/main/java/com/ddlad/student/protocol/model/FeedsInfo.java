package com.ddlad.student.protocol.model;

import java.util.List;

/**
 * Created by chen007 on 2017/11/7 0007.
 */
public class FeedsInfo extends BaseInfo {

        private String video;
        /**
         * title : 试听课1
         * desc : 试听课1，这是一个描述哦哦哦
         * type : 0
         * startTime : 2017-11-11
         * joinCnt : 100
         * image : {"pattern":"http://img.z.ziduan.com/pB5jWyBGbj49RzEFBVF2BQ.png@{w}w_{h}h_75q","width":300,"height":200,"id":"pB5jWyBGbj49RzEFBVF2BQ"}
         * id : id
         */

        private List<CoursesLiveBean> trials;
        /**
         * title : 开课信息1
         * desc : 这是开课信息1, 描述描述
         * startTime : 2017-11-07
         * joinCnt : 100
         * image : {"pattern":"http://img.z.ziduan.com/pB5jWyBGbj49RzEFBVF2BQ.png@{w}w_{h}h_75q","width":300,"height":200,"id":"pB5jWyBGbj49RzEFBVF2BQ"}
         * id : id
         */

        private List<CoursesLiveBean> opencourses;
        /**
         * title : 资讯1
         * desc : 资讯一的描述，哦哦哦哦哦
         * publishTime : 2017-11-11
         * url : http://www.baidu.com
         * joinCnt : 100
         * image : {"pattern":"http://img.z.ziduan.com/pB5jWyBGbj49RzEFBVF2BQ.png@{w}w_{h}h_75q","width":300,"height":200,"id":"pB5jWyBGbj49RzEFBVF2BQ"}
         */

        private List<CoursesLiveBean> informations;

        public String getVideo() {
            return video;
        }

        public void setVideo(String video) {
            this.video = video;
        }

    public List<CoursesLiveBean> getTrials() {
        return trials;
    }

    public void setTrials(List<CoursesLiveBean> trials) {
        this.trials = trials;
    }

    public List<CoursesLiveBean> getOpencourses() {
        return opencourses;
    }

    public void setOpencourses(List<CoursesLiveBean> opencourses) {
        this.opencourses = opencourses;
    }

    public List<CoursesLiveBean> getInformations() {
        return informations;
    }

    public void setInformations(List<CoursesLiveBean> informations) {
        this.informations = informations;
    }
}
