package com.ddlad.student.protocol.model;

/**
 * Created by Administrator on 2017/1/19 0019.
 */

public class Lessons extends BaseInfo {

//    "cid": "Course001",                   # 课程id
//    "course": "装逼的技巧",       # 课程名
//    "cnt": 1,                      # 课时
//    "teacher": "wangsch",     # 老师
//    "time": "15:30 - 16:30"   # 时间
    private String cid;
    private String course;
    private int cnt;
    private String teacher;
    private String time;

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public int getCnt() {
        return cnt;
    }

    public void setCnt(int cnt) {
        this.cnt = cnt;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
