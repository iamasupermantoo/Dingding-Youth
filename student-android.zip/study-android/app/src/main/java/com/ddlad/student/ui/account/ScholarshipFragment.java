package com.ddlad.student.ui.account;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.request.ScholarshipRequest;
import com.ddlad.student.protocol.http.request.ScholarshipRetainApplyRequest;
import com.ddlad.student.protocol.model.ScholarshipInfo;
import com.ddlad.student.tools.Constants;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.tools.StringUtil;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseFragment;

/**
 * Created by chen007 on 2017/11/9 0009.
 */
public class ScholarshipFragment extends BaseFragment {


    private TextView balance_text;
    private TextView ask_withdrawals;
    private TextView record_withdrawals;
    private TextView call_text;

    private ViewGroup recharge_intro;

    private ScholarshipInfo mInfo;

    @Override
    protected void onInitData(Bundle bundle) {
        requestData();
    }


    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_scholarship;
    }



    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle("奖学金");
//        mActionbar.setRightText("银行卡");
//        mActionbar.setRightButtonOnClickListener(this);

        balance_text = (TextView) contentView.findViewById(R.id.balance_text);
        ask_withdrawals = (TextView) contentView.findViewById(R.id.ask_withdrawals);
        record_withdrawals = (TextView) contentView.findViewById(R.id.record_withdrawals);
        call_text = (TextView) contentView.findViewById(R.id.call_text);

        recharge_intro = (ViewGroup) contentView.findViewById(R.id.recharge_intro);

        call_text.setOnClickListener(this);
        ask_withdrawals.setOnClickListener(this);
        record_withdrawals.setOnClickListener(this);

        String temp1 = "3、如有疑问，请联系客服电话：";
        String temp2 = "，竭诚为您服务。";
        SpannableString msp = new SpannableString(temp1+Constants.servicePhone+temp2);
        int length=0;
        if (Constants.servicePhone == null){
            length = 4;
        }else {
            length = Constants.servicePhone.length();
        }

        msp.setSpan(new ForegroundColorSpan(Color.parseColor("#1d2b72")), temp1.length(), temp1.length()+length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        //设置下划线
        msp.setSpan(new UnderlineSpan(), temp1.length(), temp1.length()+length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        call_text.setText(msp);
    }

    private void requestData() {
        ScholarshipRequest request = new ScholarshipRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<ScholarshipInfo>() {
            @Override
            protected void onSuccess(ScholarshipInfo scholarshipInfo) {
                mInfo = scholarshipInfo;
                if (scholarshipInfo != null && scholarshipInfo.getInfo()!= null){
                    balance_text.setText(scholarshipInfo.getInfo().getTotalAmount().replaceAll("元",""));
                }
            }
        });
        request.perform();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.right_layout:
                navigateToBindCard();
                break;
            case R.id.ask_withdrawals:
                retainApply();
                break;
            case R.id.record_withdrawals:
                navigateToWithdrawalsCash();
                break;
            case R.id.call_text :
                callSomeOne(Constants.servicePhone);
                break;
        }
    }

    public void retainApply(){
        ScholarshipRetainApplyRequest request = new ScholarshipRetainApplyRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<ScholarshipInfo>() {
            @Override
            protected void onSuccess(ScholarshipInfo scholarshipInfo) {

            }

            @Override
            protected void onFail(ApiResponse<ScholarshipInfo> response) {
                if (response != null){
                    Toaster.toastShort(response.getErrorDescription());
                }
            }
        });
        request.perform();
    }


    public void navigateToBindCard(){
        Bundle bundle = new Bundle();
        if(mInfo !=null && mInfo.getInfo() !=null && mInfo.getInfo().isHasBankInfo()){
            bundle.putString("bankUser",mInfo.getInfo().getBankUser());
            bundle.putString("bankCardNum",mInfo.getInfo().getBankCardNum());
            bundle.putString("bankName",mInfo.getInfo().getBankName());
            bundle.putString("bankUserMobile",mInfo.getInfo().getBankUserMobile());
        }
        NavigateUtil.navigateToNormalActivity(getActivity(),new BindBankCardFragment(),bundle);
    }

    public void navigateToWithdrawalsCash(){
        Bundle bundle = new Bundle();

        NavigateUtil.navigateToNormalActivity(getActivity(),new WithdrawalsCashRecordFragment(),bundle);
    }



    private void callSomeOne(String num) {
        if (!requestCallPermission()){
            return;
        }
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:"+num));
        getActivity().startActivity(intent);
    }

    private boolean requestCallPermission() {
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            // 没有获得授权，申请授权
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                    Manifest.permission.CALL_PHONE)) {
                // 帮跳转到该应用的设置界面，让用户手动授权
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getActivity().getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
            }else {
                // 不需要解释为何需要该权限，直接请求授权
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.CALL_PHONE},
                        Constants.PERMISSION_CALL_PHONE);
            }
        }else {
            return true;
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode){
            case Constants.PERMISSION_CALL_PHONE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // 授权成功，继续打电话
                    callSomeOne(Constants.servicePhone);
                } else {
                    // 授权失败！
                    Toaster.toastShort("授权失败");
                }
                break;
            }
        }

    }

}
