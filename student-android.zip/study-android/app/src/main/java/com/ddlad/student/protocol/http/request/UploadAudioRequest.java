package com.ddlad.student.protocol.http.request;

import android.graphics.Bitmap;
import android.net.Uri;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.AudioInfo;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.protocol.http.internal.ApiResponse;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-10-19.
 */
////////////////暂时只支持文件路径 20170513
public class UploadAudioRequest extends AbstractRequest<AudioInfo> {

    private Uri mUri;

    private Bitmap mBitmap = null;

    private String mFilePath;

    public UploadAudioRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<AudioInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    public Uri getUri() {
        return mUri;
    }

    public void setUri(Uri uri) {
        this.mUri = uri;
    }

    public String getFilePath() {
        return mFilePath;
    }

    public void setFilePath(String filePath) {
        this.mFilePath = filePath;
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_HOMEWORK_COMMIT;
    }

    @Override
    public AudioInfo processInBackground(ApiResponse<AudioInfo> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, AudioInfo.class);
    }

    public void perform(String filePath,String hid,String cid,String lid) {
        mFilePath = filePath;
        RequestParams params = getParams();
        if (hid != null && !hid.equals("")){
            params.put(ProtocolConstants.PARAM_HID, hid);
        }
        params.put("cid",cid);
        params.put("lid",lid);
        params.put("type",2);
        perform();
    }

    public void perform(Uri uri) {
        mUri = uri;
        perform();
    }

    public void perform(File file) {
        RequestParams params = getParams();
        try {
            params.put("file", file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        perform();
    }



    @Override
    public void preProcessInBackground() throws PreProcessException {

        try {

            ByteArrayInputStream byteArrayInputStream;

            File file = new File(mFilePath);
            DataInputStream mDataInputStream = new DataInputStream(new FileInputStream(file));
            getParams().put("audio", mDataInputStream, "file", "multipart/form-data");
//            ByteArrayOutputStream bytestream = new ByteArrayOutputStream();
//            byte[] bb = new byte[2048];
//            int ch;
//            ch = mDataInputStream.read(bb);
//            while (ch != -1) {
//                bytestream.write(bb, 0, ch);
//                ch = mDataInputStream.read(bb);
//            }
//            by = bytestream.toByteArray();

//        byteArrayInputStream = BitmapUtil.compressedInputStream(mBitmap == null ? getBitmap() : mBitmap);

//            FileOutputStream fos = new FileOutputStream(tempWav);
//            byte[] ss = File.ReadAllBytes("E:\\Users\\Administrator\\Desktop\\测试.wma");
//            byte[] ss = File.createTempFile("E:\\Users\\Administrator\\Desktop\\测试.wma").;

            return;

        } catch (Throwable t) {
            t.printStackTrace();
        }

        throw new PreProcessException();
    }

}

