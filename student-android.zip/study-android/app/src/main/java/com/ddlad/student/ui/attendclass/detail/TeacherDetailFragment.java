package com.ddlad.student.ui.attendclass.detail;

import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.request.TeacherDetailRequest;
import com.ddlad.student.protocol.model.CourseMetas;
import com.ddlad.student.protocol.model.TeacherDetailInfo;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.GrideView.HeaderGridView;
import com.ddlad.student.R;
import com.ddlad.student.ui.widget.image.NetworkImageView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class TeacherDetailFragment extends BaseFragment {

    private NetworkImageView mAvatar;
    private TextView mFullName;
    private TextView mGender;
    private TextView mAlreadyLesson;
    private TextView mSynopsis;
    private HeaderGridView mGridView;
    private TeacherGrideViewAdapter grideViewAdapter;
    private ArrayList<CourseMetas> list = new ArrayList<>();
    private View headerView;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_teacher_detail;
    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle(R.string.teacher_detail);
        mGridView = (HeaderGridView) contentView.findViewById(R.id.teacher_gridview);
        headerView = LayoutInflater.from(getActivity()).inflate(R.layout.layout_teacher_header,null);

        mGridView.addHeaderView(headerView);
        mAvatar = (NetworkImageView) headerView.findViewById(R.id.teacher_detail_avatar);
        mFullName = (TextView) headerView.findViewById(R.id.teacher_detail_fullName);
        mGender = (TextView) headerView.findViewById(R.id.teacher_detail_gender);
        mAlreadyLesson = (TextView) headerView.findViewById(R.id.teacher_detail_already_lesson);
        mSynopsis = (TextView) headerView.findViewById(R.id.curriculum_detail_synopsis);
        getData();
    }

    private void getData() {
        TeacherDetailRequest request = new TeacherDetailRequest(this, mDefaultLoaderId, new AbstractCallbacks<TeacherDetailInfo>() {
            @Override
            protected void onSuccess(TeacherDetailInfo info) {
                setHeaderData(info);
                list.addAll(info.getCourseMetas());
                grideViewAdapter = new TeacherGrideViewAdapter(getActivity(),list);
                mGridView.setAdapter(grideViewAdapter);
            }
        });
        request.perform("T001");

    }

    private void setHeaderData(TeacherDetailInfo info) {
        mAvatar.setUrl(info.getTeacher().getHeadImg().getImageSmall());
        mFullName.setText(info.getTeacher().getName());
        mGender.setText(info.getTeacher().getGender());
        mSynopsis.setText(info.getTeacher().getDesc());
        mAlreadyLesson.setText(String.valueOf(info.getTeacher().getHours()));
    }


}
