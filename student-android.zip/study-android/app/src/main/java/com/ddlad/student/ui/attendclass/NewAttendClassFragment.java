package com.ddlad.student.ui.attendclass;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.R;
import com.ddlad.student.ui.choice.LiveCourseListFragment;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.course.CourseFragment;

/**
 * Created by Administrator on 2017/3/17 0017.
 */
public class NewAttendClassFragment extends BaseFragment {


    private boolean mselect = true;


    private ViewGroup mFrameLayout;
    private Fragment mNotFragment;
    private Fragment mAlreadyFragment;
    private FragmentTransaction transaction;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_evaluate;
    }

    @Override
    protected void onInitView(View contentView) {
        mFrameLayout = (ViewGroup) contentView.findViewById(R.id.evaluate_frame_layout);
        if (mNotFragment == null){
            mNotFragment = new AttendClassFragment();
        }
        if (mAlreadyFragment == null){
            mAlreadyFragment = new LiveCourseListFragment();
        }

        transaction =getFragmentManager().beginTransaction();
        if (mNotFragment.isAdded()){
            transaction.attach(mAlreadyFragment);
            transaction.attach(mNotFragment);

        }else {
            transaction.add(R.id.evaluate_frame_layout,mAlreadyFragment);
            transaction.add(R.id.evaluate_frame_layout,mNotFragment);
        }
        transaction.commitAllowingStateLoss();
        getChildFragmentManager().executePendingTransactions();
        mActionbar.setNewSwitchTitle("1对1", "大课", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mselect = true;
                mActionbar.setNewSwitchSelect(mselect);
                FragmentTransaction transaction1 =getFragmentManager().beginTransaction();
                transaction1.hide(mAlreadyFragment);
                transaction1.show(mNotFragment);
                transaction1.commit();
            }
        }, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mselect = false;
                mActionbar.setNewSwitchSelect(mselect);
                FragmentTransaction transaction2 =getFragmentManager().beginTransaction();
                transaction2.hide(mNotFragment).show(mAlreadyFragment);
                transaction2.commit();
//                showFragment(mNotFragment);
            }
        });
        mActionbar.setNewSwitchSelect(mselect);

    }

    @Override
    public void onResume() {
        super.onResume();

    }


    private void showFragment(Fragment fg){
        FragmentTransaction transaction =getFragmentManager().beginTransaction();
        if(!fg.isAdded()){
            transaction
                    .hide(mNotFragment)
                    .add(R.id.content,fg);
        }else{
            transaction
                    .hide(mNotFragment)
                    .show(fg);
        }
        mNotFragment = fg;
        transaction.commit();

    }

}
