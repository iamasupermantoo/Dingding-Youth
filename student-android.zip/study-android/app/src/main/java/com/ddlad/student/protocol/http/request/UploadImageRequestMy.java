package com.ddlad.student.protocol.http.request;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;


import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.model.UploadedImage;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.tools.BitmapUtil;
import com.ddlad.student.ui.common.BaseFragment;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-10-19.
 */
public class UploadImageRequestMy extends AbstractRequest<UploadedImage> {

    private Uri mUri;

    private Bitmap mBitmap = null;

    private String mFilePath;

    public UploadImageRequestMy(BaseFragment fragment, int loaderId, AbstractCallbacks<UploadedImage> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    public Uri getUri() {
        return mUri;
    }

    public void setUri(Uri uri) {
        this.mUri = uri;
    }

    public String getFilePath() {
        return mFilePath;
    }

    public void setFilePath(String filePath) {
        this.mFilePath = filePath;
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_IMAGE_UPLOAD;
    }

    @Override
    public UploadedImage processInBackground(ApiResponse<UploadedImage> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, UploadedImage.class);
    }

    public void perform(String filePath) {
        mFilePath = filePath;
        perform();
    }

    public void perform(Uri uri) {
        mUri = uri;
        perform();
    }

    public void perform(File file) {
        RequestParams params = getParams();
        try {
            params.put("file", file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        perform();
    }
    public void perform(Bitmap bitmap) {
        mBitmap = bitmap;
        perform();
    }

    private Bitmap getBitmap() {
        return BitmapFactory.decodeFile(mUri == null ? mFilePath : mUri.getPath());
    }

    @Override
    public void preProcessInBackground() throws PreProcessException {

        try {

            ByteArrayInputStream byteArrayInputStream;
            byteArrayInputStream = BitmapUtil.compressedInputStream(mBitmap == null ? getBitmap() : mBitmap);
            getParams().put(ProtocolConstants.PARAM_FILE, byteArrayInputStream, "file", "multipart/form-data");

            return;

        } catch (Throwable t) {
            t.printStackTrace();
        }

        throw new AbstractRequest.PreProcessException();
    }

}

