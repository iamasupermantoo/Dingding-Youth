package com.ddlad.student.ui.calendar.calendarview;

import android.content.Context;
import android.text.SpannableString;
import android.text.Spanned;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.R;

/**
 * Created by Albert
 * on 16-8-26.
 */
public class DayLayout extends FrameLayout {

    private DayView mDayView;

    private DecorView mDayDecor;

    public DayLayout(Context context, CalendarDay day) {
        super(context);

        setForegroundGravity(Gravity.CENTER);

        boolean isToday = day.equal(CalendarDay.today());
        mDayDecor = new DecorView(getContext(), day);
        mDayView = new DayView(getContext(), day, isToday);

        RelativeLayout bottom = new RelativeLayout(getContext());
        int ts = (int) ViewUtil.dpToPx(26);
        RelativeLayout.LayoutParams tp = new RelativeLayout.LayoutParams(ts, ts);
        tp.addRule(RelativeLayout.CENTER_HORIZONTAL);
        tp.topMargin = 15;
        bottom.addView(mDayView, tp);
        bottom.setBackgroundResource(R.drawable.bottom_line_bg);

        RelativeLayout top = new RelativeLayout(getContext());
        int bs = (int) ViewUtil.dpToPx(36);
        RelativeLayout.LayoutParams bp = new RelativeLayout.LayoutParams(bs, bs);
        bp.addRule(RelativeLayout.CENTER_IN_PARENT);
        top.addView(mDayDecor, bp);

        addView(bottom);
        addView(top);
    }

    public DayView getDayView() {
        return mDayView;
    }

    public DayView getDayDecor() {
        return mDayDecor;
    }

    void applyFacade(DayViewFacade facade) {

        mDayView.setEnabled();
        mDayDecor.setEnabled();

        mDayView.setCustomBackground(facade.getBackgroundDrawable());
        mDayView.setSelectionDrawable(facade.getSelectionDrawable());

        String label = mDayView.getLabel();

        // Facade has spans
        if (facade.getSpans().isEmpty()) {
            mDayDecor.setText(label);
        } else {
            SpannableString formattedLabel = new SpannableString(label);
            for (DayViewFacade.Span span : facade.getSpans()) {
                formattedLabel.setSpan(span.span, 0, label.length(),
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            mDayDecor.setText(formattedLabel);
        }

        mDayView.setText(label);
    }

}
