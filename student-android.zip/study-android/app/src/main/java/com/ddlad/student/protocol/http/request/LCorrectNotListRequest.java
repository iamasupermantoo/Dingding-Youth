package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.request.BaseListRequest;
import com.fasterxml.jackson.core.JsonParser;
import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.LCorrectNotInfo;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.protocol.http.internal.StreamingApiResponse;

import java.io.IOException;

/**
 * Created by chenjianing
 * on 17-04-21.
 */
public class LCorrectNotListRequest extends BaseListRequest<LCorrectNotInfo> {



    public LCorrectNotListRequest(BaseListFragment baseListFragment, int loaderId, AbstractStreamingCallbacks<AbstractListResponse<LCorrectNotInfo>> streamingApiCallbacks) {
        super(baseListFragment, loaderId, streamingApiCallbacks);
    }

    @Override
    protected String getBasePath() {
        return ProtocolConstants.URL_EVALUATE_LIST;
    }

    protected String getFieldKey() {
        return ProtocolConstants.JSON_FIELD_REACTIONS;
    }



    @Override
    public void processResponseField(String fieldName, JsonParser jsonParser,
                                     StreamingApiResponse<AbstractListResponse<LCorrectNotInfo>> streamingApiResponse) throws IOException {

        AbstractListResponse response = streamingApiResponse.getSuccessObject();
        if (response == null) {
            response = new AbstractListResponse() {
                @Override
                public LCorrectNotInfo getModelInfo(JsonParser jsonParser) {
                    try {
                        return LCorrectNotInfo.fromJsonParser(jsonParser);
                    } catch (Throwable t) {
                        t.printStackTrace();
                    }

                    return null;
                }
            };
        }
        response.parse(jsonParser, getFieldKey());
        streamingApiResponse.setSuccessObject(response);
    }



    public void perform(int status , String cursor) {
        RequestParams params = getParams();
        params.put("status", status);
        super.perform();
    }
}

