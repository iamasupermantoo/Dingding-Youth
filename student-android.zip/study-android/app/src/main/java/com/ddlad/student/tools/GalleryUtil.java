package com.ddlad.student.tools;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;


import com.ddlad.student.primary.AppContext;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.cache.LocalImageSize;

import java.io.File;
import java.io.IOException;

public class GalleryUtil {

    public static File chooseImage(Activity activity) {
        File galleryTempFile = FileUtil.generateTempImageFile();
        activity.startActivityForResult(Intent.createChooser(constructGalleryIntent(galleryTempFile),
                AppContext.getString(R.string.choose_source)), Constants.REQUEST_CODE_CHOOSE_IMAGE);
        return galleryTempFile;
    }

    private static Intent constructGalleryIntent(File file) {
        Intent intent = new Intent("android.intent.action.GET_CONTENT", null);
        intent.setType("image/*");
        if (file != null) {
            intent.putExtra("output", Uri.fromFile(file));
            intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.name());
        }
        return intent;
    }

    public static Bitmap getBitmap(String sdcardPath, int showSize) {
        File file = new File(sdcardPath);
        if (!file.exists()) {
            return null;
        }
        Options opts = new Options();
        opts.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(sdcardPath, opts);
        LocalImageSize srcSize = new LocalImageSize(opts.outWidth, opts.outHeight);
        if (showSize > opts.outWidth) {
            showSize = opts.outWidth;
        }
        int sampleSize = computeImageSampleSize(srcSize, false, showSize);
        opts.inSampleSize = sampleSize;
        opts.inJustDecodeBounds = false;
        Bitmap bitmap = BitmapFactory.decodeFile(sdcardPath, opts);

        ExifInterface exif;
        try {
            exif = new ExifInterface(sdcardPath);
            final int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, 1);
            int rotate = -1;
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_270:
                    rotate = 270;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    rotate = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_90:
                    rotate = 90;
                    break;
            }

            if (rotate != -1) {
                Matrix matrix = new Matrix();
                matrix.postRotate(rotate);
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(),
                        matrix, true);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return bitmap;
    }

    private static int computeImageSampleSize(LocalImageSize srcSize, boolean powerOf2Scale,
                                              int tagSize) {
        final int srcWidth = srcSize.getWidth();
        final int srcHeight = srcSize.getHeight();
        final int targetWidth = tagSize;
        final int targetHeight = tagSize;

        int scale = 1;

        if (powerOf2Scale) {
            final int halfWidth = srcWidth / 2;
            final int halfHeight = srcHeight / 2;
            while ((halfWidth / scale) > targetWidth && (halfHeight / scale) > targetHeight) { // &&
                scale *= 2;
            }
        } else {
            scale = Math.min(srcWidth / targetWidth, srcHeight / targetHeight); // min
        }

        if (scale < 1) {
            scale = 1;
        }
        scale = considerMaxTextureSize(tagSize, srcWidth, srcHeight, scale, powerOf2Scale);

        return scale;
    }

    private static int considerMaxTextureSize(int tagSize, int srcWidth, int srcHeight, int scale,
                                              boolean powerOf2) {
        while ((srcWidth / scale) > tagSize || (srcHeight / scale) > tagSize) {
            if (powerOf2) {
                scale *= 2;
            } else {
                scale++;
            }
        }
        return scale;
    }

}
