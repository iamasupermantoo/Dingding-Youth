package com.ddlad.student.ui.choice;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.ui.common.BaseFragment;

/**
 * Created by chen007 on 2017/6/30 0030.
 */
public class SelectedFragment extends BaseFragment {

    private TextView content;
    private TextView chinese_content;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_select_layout;
    }

    @Override
    protected void onInitData(Bundle bundle) {

        requestData();
    }

    private void requestData() {

    }

    @Override
    protected void onInitView(View contentView) {
        content = (TextView) contentView.findViewById(R.id.content);
        chinese_content = (TextView) contentView.findViewById(R.id.chinese_content);
    }


}
