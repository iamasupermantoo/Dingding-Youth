package com.ddlad.student.ui.choice;

import android.os.Bundle;
import android.view.View;

import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.webview.BaseWebView;

/**
 * Created by chen007 on 2017/11/7 0007.
 */
public class WebDetailFragment extends BaseFragment {

    private BaseWebView web_view;

    private String mUrl;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_web_detail;
    }

    @Override
    protected void onInitData(Bundle bundle) {
        mUrl = bundle.getString(ProtocolConstants.PARAM_URL);
    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle("资讯详情");
        web_view = (BaseWebView) contentView.findViewById(R.id.web_view);
        web_view.loadUrl(mUrl);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        web_view.clear();
    }
}
