package com.ddlad.student.ui.account;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.request.MyAccountBalanceRequest;
import com.ddlad.student.protocol.http.request.OrderSubmitRequest;
import com.ddlad.student.protocol.http.request.PayParamsRequest;
import com.ddlad.student.protocol.http.request.PayResultRequest;
import com.ddlad.student.protocol.model.GetChargeItemInfo;
import com.ddlad.student.protocol.model.OrderSubmitInfo;
import com.ddlad.student.protocol.model.PayParamsInfo;
import com.ddlad.student.protocol.model.PayResultInfo;
import com.ddlad.student.tools.Constants;
import com.ddlad.student.tools.PayUtil;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.dialog.ConfirmPayDialogBuilder;
import com.ddlad.student.ui.widget.dialog.IDialogClickListener;
import com.ddlad.student.wxapi.WXPayEntryActivity;

import org.w3c.dom.Text;

import java.util.ArrayList;

/**
 * Created by chen007 on 2017/11/9 0009.
 */
public class MyAccountBalanceFragment extends BaseFragment {


    private ViewGroup recharge_intro;
    private ViewGroup first_type_layout;
    private ViewGroup second_type_layout;
    private ViewGroup thrid_type_layout;
    private ViewGroup forth_type_layout;

    private ViewGroup charge_item_layout;

    private TextView balance_text;
    private TextView call_text;
    private TextView confirm_pay;

    private int currentType;

    private String productId;

    private String mCurrentPrice;

    private String fromWhere;
//    private RecyclerView recycle_view;
//    private MyAccountBalanceAdapter mAdapter;

    @Override
    protected void onInitData(Bundle bundle) {
        if (bundle != null){
            fromWhere = bundle.getString("fromWhere");
        }
        requestData();
    }

    private void requestData() {
        MyAccountBalanceRequest request = new MyAccountBalanceRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<GetChargeItemInfo>() {
            @Override
            protected void onSuccess(GetChargeItemInfo info) {
                if (info != null){
                    balance_text.setText(info.getTotalAmount()+"");
                    initChargeLayout(info);
                    selectItem(0);
                }
            }
        });
        request.perform();
    }
    ArrayList<View> views;
    private void initChargeLayout(final GetChargeItemInfo info) {
        charge_item_layout.removeAllViews();
        int j =0;
//        ArrayList<GetChargeItemInfo.ItemsBean> mInfos = (ArrayList<GetChargeItemInfo.ItemsBean>) info.getItems();
//        mInfos.addAll(info.getItems());
//        mInfos.addAll(info.getItems());
//        mInfos.addAll(info.getItems());
        views = new ArrayList<>();
        for (int i=info.getItems().size(); i > 0; i-=2 ){
            View view = LayoutInflater.from(getActivity()).inflate(R.layout.layout_charge_item_row,null);
            ViewGroup viewGroup_1 = (ViewGroup) view.findViewById(R.id.first_type_layout);
            ViewGroup viewGroup_2 = (ViewGroup) view.findViewById(R.id.second_type_layout);
            TextView  money_1 = (TextView) view.findViewById(R.id.money_1);
            TextView  money_2 = (TextView) view.findViewById(R.id.money_2);
            TextView  dd_1 = (TextView) view.findViewById(R.id.dd_1);
            TextView  dd_2 = (TextView) view.findViewById(R.id.dd_2);
            if (i>0){
                views.add(viewGroup_1);
                money_1.setText(info.getItems().get(j).getPrice()+"元");
                dd_1.setText(info.getItems().get(j).getPlusAmount()+"鼎币");
                final int finalJ = j;
                viewGroup_1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mCurrentPrice = info.getItems().get(finalJ).getPrice();
                        productId = info.getItems().get(finalJ).getProduct();
                        selectItem(finalJ);
                    }
                });
                j++;
            }
            if (i >1){
                views.add(viewGroup_2);
                money_2.setText(info.getItems().get(j).getPrice()+"元");
                dd_2.setText(info.getItems().get(j).getPrice()+"鼎币");
                final int finalJ = j;
                viewGroup_2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mCurrentPrice = info.getItems().get(finalJ).getPrice();
                        productId = info.getItems().get(finalJ).getProduct();
                        selectItem(finalJ);
                    }
                });
                j++;
            }else {
                viewGroup_2.setVisibility(View.INVISIBLE);
            }
            charge_item_layout.addView(view);
        }
    }

    private void selectItem(int postion) {
        for (int i =0; i < views.size(); i++){
            if (i==postion){
                views.get(i).setSelected(true);
                continue;
            }
            views.get(i).setSelected(false);
        }
    }

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_my_account_balance;
    }

    @Override
    protected void onInitView(View contentView) {

        mActionbar.setTitle("我的账户");
        recharge_intro = (ViewGroup) contentView.findViewById(R.id.recharge_intro);
        first_type_layout = (ViewGroup) contentView.findViewById(R.id.first_type_layout);
        second_type_layout = (ViewGroup) contentView.findViewById(R.id.second_type_layout);
        thrid_type_layout = (ViewGroup) contentView.findViewById(R.id.thrid_type_layout);
        forth_type_layout = (ViewGroup) contentView.findViewById(R.id.forth_type_layout);

        charge_item_layout = (ViewGroup) contentView.findViewById(R.id.charge_item_layout);

        balance_text = (TextView) contentView.findViewById(R.id.balance_text);
        call_text = (TextView) contentView.findViewById(R.id.call_text);
        confirm_pay = (TextView) contentView.findViewById(R.id.confirm_pay);

//        recycle_view = (RecyclerView) contentView.findViewById(R.id.recycle_view);
//        if (mAdapter == null){
//            mAdapter = new MyAccountBalanceAdapter(getActivity());
//        }
//        recycle_view.setLayoutManager(new GridLayoutManager(getActivity(),2));
//        recycle_view.setAdapter(mAdapter);

        first_type_layout.setOnClickListener(this);
        second_type_layout.setOnClickListener(this);
        thrid_type_layout.setOnClickListener(this);
        forth_type_layout.setOnClickListener(this);

        call_text.setOnClickListener(this);
        confirm_pay.setOnClickListener(this);


        String temp1 = "2、如存在无法充值、充值失败等问题，可直接联系客服电话：";
        String temp2 = "，竭诚为您服务。";
        SpannableString msp = new SpannableString(temp1+Constants.servicePhone+temp2);
        int length=0;
        if (Constants.servicePhone == null){
            length = 4;
        }else {
            length = Constants.servicePhone.length();
        }
        msp.setSpan(new ForegroundColorSpan(Color.parseColor("#1d2b72")), temp1.length(), temp1.length()+length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        //设置下划线
        msp.setSpan(new UnderlineSpan(), temp1.length(), temp1.length()+length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        call_text.setText(msp);

    }

    @Override
    public void onResume() {
        super.onResume();
        if (WXPayEntryActivity.payState){
            refreshPageInfo();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.first_type_layout :
                currentType = 1;
                refreshTypeState(true,false,false,false);
                break;
            case R.id.second_type_layout :
                currentType = 2;
                refreshTypeState(false,true,false,false);
                break;
            case R.id.thrid_type_layout :
                currentType = 3;
                refreshTypeState(false,false,true,false);
                break;
            case R.id.forth_type_layout :
                currentType = 4;
                refreshTypeState(false,false,false,true);
                break;
            case R.id.confirm_pay :
                showPayDialog();
                break;
            case R.id.call_text :
                callSomeOne(Constants.servicePhone);
                break;
        }
    }

    public void refreshPageInfo(){
        if (dialogBuilder != null){
            dialogBuilder.dismiss();
        }
        if ("NewLiveCourseDetailsFragment".equals(fromWhere)){
            getActivity().onBackPressed();
            return;
        }
        requestData();
    }

    private void refreshTypeState(boolean first,boolean second,boolean third,boolean forth) {
        first_type_layout.setSelected(first);
        second_type_layout.setSelected(second);
        thrid_type_layout.setSelected(third);
        forth_type_layout.setSelected(forth);
    }

    private void callSomeOne(String num) {
        if (!requestCallPermission()){
            return;
        }
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:"+num));
        getActivity().startActivity(intent);
    }

    private boolean requestCallPermission() {
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            // 没有获得授权，申请授权
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                    Manifest.permission.CALL_PHONE)) {
                // 帮跳转到该应用的设置界面，让用户手动授权
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getActivity().getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
            }else {
                // 不需要解释为何需要该权限，直接请求授权
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.CALL_PHONE},
                        Constants.PERMISSION_CALL_PHONE);
            }
        }else {
            return true;
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode){
            case Constants.PERMISSION_CALL_PHONE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // 授权成功，继续打电话
                    callSomeOne(Constants.servicePhone);
                } else {
                    // 授权失败！
                    Toaster.toastShort("授权失败");
                }
                break;
            }
        }

    }
///////////////////////////////////////支付////////////////////////////////////////////////////////

    private int payType;
    private ConfirmPayDialogBuilder dialogBuilder;
    public void showPayDialog(){
        if (dialogBuilder == null){
            dialogBuilder = new ConfirmPayDialogBuilder(this);
            dialogBuilder.setmListener(new IDialogClickListener() {
                @Override
                public void onClick(int type) {
                    payType = type;
                    if (type == 0 || type == 1){
                        performOrderSubmit();
                        return;
                    }

                }
            });
        }
        dialogBuilder.hideBalance();
        dialogBuilder.setPayNum(mCurrentPrice);
        dialogBuilder.create().show();
    }

    public void aliPay(PayParamsInfo payParamsInfo){
    PayUtil util = new PayUtil();
    util.AliPay(payParamsInfo.getParams().getAlipay().getOrderStr(), this, new IDialogClickListener() {
        @Override
        public void onClick(int type) {
            if (type == 1){
                //支付成功
                mChannel = 1;
                modifyRequest();
            }
            if (type == 0){
                //支付失败
            }
        }
    });
}

    public void wxPay(PayParamsInfo payParamsInfo){
        mChannel = 0;
        PayUtil util = new PayUtil();
        util.WxPay(payParamsInfo,getActivity());
    }

    public static boolean isPay = false;
    public  String mOrderSn = "";
    public  int mChannel;
    private void modifyRequest() {
        isPay = false;
        PayResultRequest request = new PayResultRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<PayResultInfo>() {
            @Override
            protected void onSuccess(PayResultInfo wxpayOrderInfo) {
                if (wxpayOrderInfo.getResult() == 1){
                    Toaster.toastShort("支付成功");
                    refreshPageInfo();
                }
            }

            @Override
            protected void onFail(ApiResponse<PayResultInfo> response) {
                Toaster.toastShort(response.getErrorDescription());
            }
        });
        request.perform(mOrderSn,payType);
    }

    public void performOrderSubmit(){
        OrderSubmitRequest request = new OrderSubmitRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<OrderSubmitInfo>() {
            @Override
            protected void onSuccess(OrderSubmitInfo info) {
                if (info != null){
                    payParamRequest(info.getOid());
                }

            }
        });
        request.perform(1,productId);
    }

    private void payParamRequest(String oid) {
        //请求预支付id
        PayParamsRequest request = new PayParamsRequest(this, ViewUtil.generateUniqueId(), new AbstractCallbacks<PayParamsInfo>() {
            @Override
            protected void onSuccess(PayParamsInfo payParamsInfo) {
                if (payParamsInfo == null){
                    return;
                }
                mOrderSn = payParamsInfo.getParams().getOrderSn();
                if (payType == 0){
                    wxPay(payParamsInfo);
                    return;
                }
                if (payType == 1){
                    aliPay(payParamsInfo);
                    return;
                }
            }

            @Override
            protected void onFail(ApiResponse<PayParamsInfo> response) {
                Toaster.toastShort(response.getErrorDescription());
            }
        });
        request.perform(oid,0,payType);
    }

/////////////////////////////////////////////////////////////////////////////////////////////////////

}
