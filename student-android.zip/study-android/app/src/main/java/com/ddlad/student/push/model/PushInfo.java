package com.ddlad.student.push.model;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.protocol.model.GoToPage;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class PushInfo implements Serializable {

    private static final long serialVersionUID = 1478453260536238019L;

    private int action;

    private String user;

    private com.ddlad.student.push.model.PushAps aps;

    private GoToPage gotoPage;

    private Map<String, String> extra;

    //用来存储客户端自己定义的需要传递的数据，这里边的数据不是与服务端约定的
    private Map<String, Object> customData = new HashMap<String, Object>();

    public void putCustomData(String key, Object value) {
        customData.put(key, value);
    }

    public Object getCustomData(String key) {
        return customData.get(key);
    }

    public int getAction() {
        return action;
    }

    public void setAction(int action) {
        this.action = action;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public com.ddlad.student.push.model.PushAps getAps() {
        return aps;
    }

    public void setAps(com.ddlad.student.push.model.PushAps aps) {
        this.aps = aps;
    }

    public GoToPage getGotoPage() {
        return gotoPage;
    }

    public void setGotoPage(GoToPage gotoPage) {
        this.gotoPage = gotoPage;
    }

    public Map<String, String> getExtra() {
        return extra;
    }

    public void setExtra(Map<String, String> extra) {
        this.extra = extra;
    }

    public static PushInfo fromJsonParser(JsonParser jsonParser) throws JsonParseException,
            IOException, JSONException {

        PushInfo push = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (push == null) {
                    push = new PushInfo();
                }

                if ("action".equals(fieldName)) {
                    jsonParser.nextToken();
                    push.action = jsonParser.getIntValue();
                    continue;
                }

                if ("aps".equals(fieldName)) {
                    jsonParser.nextToken();
                    push.aps = com.ddlad.student.push.model.PushAps.fromJsonParser(jsonParser);
                    continue;
                }

                if ("gotoPage".equals(fieldName)) {
                    jsonParser.nextToken();
                    push.gotoPage = GoToPage.fromJsonParser(jsonParser);
                    continue;
                }

                if ("extra".equals(fieldName)) {
                    jsonParser.nextToken();
                    Map<String, String> map = new HashMap<>();
                    JSONObject jsonObject = new JSONObject(jsonParser.getText());
                    Iterator it = jsonObject.keys();
                    while (it.hasNext()) {
                        String key = String.valueOf(it.next());
                        String value = (String) jsonObject.get(key);
                        map.put(key, value);
                    }
                    push.extra = map;
                    continue;
                }

                jsonParser.skipChildren();
            }
        }

        return push;
    }

}
