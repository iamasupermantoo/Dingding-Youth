package com.ddlad.student.protocol.model;

/**
 * Created by chen007 on 2017/11/10 0010.
 */
public class ScholarshipInfo extends BaseInfo {

        /**
         * totalAmount : 200元
         * servicePhone : 15712889750
         * bankUser : 王三成
         * retainMinAmount : 100元
         * bankCardNum : 8991991 9139419 19391499 11
         * bankName : 开户行
         * bankUserMobile : 15712889750
         */

        private InfoBean info;

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public static class InfoBean {
            private String totalAmount;
            private String servicePhone;
            private String bankUser;
            private String retainMinAmount;
            private String bankCardNum;
            private String bankName;
            private String bankUserMobile;
            private boolean hasBankInfo;

            public boolean isHasBankInfo() {
                return hasBankInfo;
            }

            public void setHasBankInfo(boolean hasBankInfo) {
                this.hasBankInfo = hasBankInfo;
            }

            public String getTotalAmount() {
                return totalAmount;
            }

            public void setTotalAmount(String totalAmount) {
                this.totalAmount = totalAmount;
            }

            public String getServicePhone() {
                return servicePhone;
            }

            public void setServicePhone(String servicePhone) {
                this.servicePhone = servicePhone;
            }

            public String getBankUser() {
                return bankUser;
            }

            public void setBankUser(String bankUser) {
                this.bankUser = bankUser;
            }

            public String getRetainMinAmount() {
                return retainMinAmount;
            }

            public void setRetainMinAmount(String retainMinAmount) {
                this.retainMinAmount = retainMinAmount;
            }

            public String getBankCardNum() {
                return bankCardNum;
            }

            public void setBankCardNum(String bankCardNum) {
                this.bankCardNum = bankCardNum;
            }

            public String getBankName() {
                return bankName;
            }

            public void setBankName(String bankName) {
                this.bankName = bankName;
            }

            public String getBankUserMobile() {
                return bankUserMobile;
            }

            public void setBankUserMobile(String bankUserMobile) {
                this.bankUserMobile = bankUserMobile;
            }
        }
}
