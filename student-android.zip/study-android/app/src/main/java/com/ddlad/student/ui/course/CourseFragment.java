package com.ddlad.student.ui.course;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.request.BaseListRequest;
import com.ddlad.student.protocol.http.request.LCourseMetaListRequest;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.CourseMetaListInfo;
import com.ddlad.student.ui.common.AbstractAdapter;

/**
 * A simple {@link BaseFragment} subclass.
 */
public class CourseFragment extends BaseListFragment<CourseMetaListInfo> {

    private int mLoaderId = ViewUtil.generateUniqueId();

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_course;
    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle("发现");
        mActionbar.setNewSwitchSelect(true);
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.layout_list_divider,null);
        mListView.addHeaderView(view,null,true);
        super.onInitView(contentView);
    }

    @Override
    protected BaseListRequest makeRequest(AbstractStreamingCallbacks<AbstractListResponse<CourseMetaListInfo>> streamingApiCallbacks) {
        return new LCourseMetaListRequest(this, mLoaderId, streamingApiCallbacks);
    }

    @Override
    protected void performRequest() {
        ((LCourseMetaListRequest)mDefaultRequest).perform(getNextCursorId());
    }

    @Override
    protected boolean isNeedFetch() {
        return true;
    }

    @Override
    protected AbstractAdapter getAdapter() {
        if (mAdapter == null) {
            mAdapter = new LCourseListAdapter(this);
        }
        return mAdapter;
    }

    @Override
    protected int getHeaderResource() {
        return R.layout.layout_course_head;
    }

    @Override
    protected void showEmptyView() {

        if (mEmptyView == null) {
            mEmptyView = (ViewGroup) LayoutInflater.from(getActivity()).inflate(R.layout.layout_empty_footer, null);
            mListView.addFooterView(mEmptyView, null, false);
        }

        if (mAdapter == null || mAdapter.isEmpty()) {
            TextView textView = (TextView) mEmptyView.findViewById(R.id.empty_text);
            textView.setText("这里什么都没有");
            mEmptyView.setVisibility(View.VISIBLE);
        } else {
            hideEmptyView();
        }

    }

    @Override
    protected void hideEmptyView() {
        if (mEmptyView != null) {
            mListView.removeFooterView(mEmptyView);
        }
        mEmptyView = null;
    }
}
