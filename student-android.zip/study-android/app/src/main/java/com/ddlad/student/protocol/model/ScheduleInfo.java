package com.ddlad.student.protocol.model;

import java.util.List;

/**
 * Created by Administrator on 2017/1/17 0017.
 */

public class ScheduleInfo extends BaseInfo {
//    "homeworks": "作业List（待定）",
//    "reactions": "课堂反馈List（待定）",
//    "lessons": [
    private List<Homeworks> homeworks;
    private List<Reactions> reactions;
    private List<Lessons> lessons;

    public List<Homeworks> getHomeworks() {
        return homeworks;
    }

    public void setHomeworks(List<Homeworks> homeworks) {
        this.homeworks = homeworks;
    }

    public List<Reactions> getReactions() {
        return reactions;
    }

    public void setReactions(List<Reactions> reactions) {
        this.reactions = reactions;
    }

    public List<Lessons> getLessons() {
        return lessons;
    }

    public void setLessons(List<Lessons> lessons) {
        this.lessons = lessons;
    }
}
