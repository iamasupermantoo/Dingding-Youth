package com.ddlad.student.ui.calendar.calendarview;

import android.annotation.SuppressLint;
import android.support.annotation.NonNull;

import java.util.Calendar;
import java.util.Collection;

import static java.util.Calendar.DATE;

/**
 * Display a month of {@linkplain DayView}s and
 * seven {@linkplain WeekDayView}s.
 */
@SuppressLint("ViewConstructor")
class MonthView extends CalendarPagerView {

    public MonthView(@NonNull DateView view, CalendarDay month, int firstDayOfWeek) {
        super(view, month, firstDayOfWeek);
    }

    @Override
    protected void buildDayViews(Collection<DayLayout> dayViews, Calendar calendar) {
        for (int r = 0; r < DEFAULT_MAX_WEEKS; r++) {
            for (int i = 0; i < DEFAULT_DAYS_IN_WEEK; i++) {
                CalendarDay day = CalendarDay.from(calendar);
                if (isMonthBreak(day)) {
                    return;
                } else {
                    addDayView(dayViews, day);
                    calendar.add(DATE, 1);
                }
            }
        }
    }

    public CalendarDay getMonth() {
        return getFirstViewDay();
    }

    @Override
    protected boolean isDayEnabled(CalendarDay day) {
        return day.getMonth() == getFirstViewDay().getMonth();
    }

    private boolean isMonthBreak(CalendarDay day) {
        return (day.getMonth() > getFirstViewDay().getMonth()) && (day.getDayOfWeek() == 1);
    }

    @Override
    protected int getRows() {
        return DEFAULT_MAX_WEEKS + DAY_NAMES_ROW;
    }

    private int getCustomRowCount() {
        CalendarDay firstDay = getFirstViewDay();
        int firstDayOfWeek = firstDay.getDayOfWeek();
        int dayCount = getMonthDayCount(firstDay.getCalendar());
        int weekCount = dayCount / DEFAULT_DAYS_IN_WEEK;
        int delta = dayCount % DEFAULT_DAYS_IN_WEEK;
        if (firstDayOfWeek + delta > DEFAULT_DAYS_IN_WEEK) {
            weekCount += 2;
        } else {
            weekCount += 1;
        }

        return weekCount + DAY_NAMES_ROW;
    }

    private int getMonthDayCount(Calendar calendar) {
        calendar.set(Calendar.DATE, 1);
        calendar.roll(Calendar.DATE, -1);
        int maxDate = calendar.get(Calendar.DATE);
        return maxDate;
    }
}
