package com.ddlad.student.protocol.model;

/**
 * Created by chen007 on 2017/11/10 0010.
 */
public class OrderSubmitInfo extends BaseInfo {
        private String orderSn;
        private String oid;

        public String getOrderSn() {
            return orderSn;
        }

        public void setOrderSn(String orderSn) {
            this.orderSn = orderSn;
        }

        public String getOid() {
            return oid;
        }

        public void setOid(String oid) {
            this.oid = oid;
        }
}
