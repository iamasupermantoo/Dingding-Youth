package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ddlad.student.ui.model.MultiImageInfo;

import java.io.IOException;
import java.util.List;

/**
 * Created by chenjianing on 2017/3/24 0024.
 */
public class CalendarReminderCourseInfo {

    private static final String TAG = "CalendarCourseInfo";
    private List<LessonsBean> lessons;

        public List<LessonsBean> getLessons() {
            return lessons;
        }

        public void setLessons(List<LessonsBean> lessons) {
            this.lessons = lessons;
        }

        public static class LessonsBean {
            private String course;
            private String lid;
            /**
             * pattern : http://img.z.ziduan.com/FCNC-zHElhA9RzEFBVF2BQ.png@{w}w_{h}h_75q
             * width : 200
             * height : 200
             * id : FCNC-zHElhA9RzEFBVF2BQ
             */

            private MultiImageInfo courseImage;
            private String time;
            private String teacher;
            private String cid;
            private int cnt;
            private int totalCnt;

            public String getCourse() {
                return course;
            }

            public void setCourse(String course) {
                this.course = course;
            }

            public String getLid() {
                return lid;
            }

            public void setLid(String lid) {
                this.lid = lid;
            }

            public MultiImageInfo getCourseImage() {
                return courseImage;
            }

            public void setCourseImage(MultiImageInfo courseImage) {
                this.courseImage = courseImage;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getTeacher() {
                return teacher;
            }

            public void setTeacher(String teacher) {
                this.teacher = teacher;
            }

            public String getCid() {
                return cid;
            }

            public void setCid(String cid) {
                this.cid = cid;
            }

            public int getCnt() {
                return cnt;
            }

            public void setCnt(int cnt) {
                this.cnt = cnt;
            }

            public int getTotalCnt() {
                return totalCnt;
            }

            public void setTotalCnt(int totalCnt) {
                this.totalCnt = totalCnt;
            }

            public static LessonsBean fromJsonParser(JsonParser jsonParser) throws IOException {

                LessonsBean info = null;

                if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

                    while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                        String fieldName = jsonParser.getCurrentName();

                        if (fieldName == null) {
                            continue;
                        }

                        if (info == null) {
                            info = new LessonsBean();
                        }

                        if ("course".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.course = jsonParser.getText();
                            continue;
                        }
                        if ("lid".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.lid = jsonParser.getText();
                            continue;
                        }
                        if ("courseImage".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.courseImage = MultiImageInfo.fromJsonParser(jsonParser);
                            continue;
                        }
                        if ("time".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.time = jsonParser.getText();
                            continue;
                        }
                        if ("teacher".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.teacher = jsonParser.getText();
                            continue;
                        }
                        if ("cid".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.cid = jsonParser.getText();
                            continue;
                        }
                        if ("cnt".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.cnt = jsonParser.getIntValue();
                            continue;
                        }
                        if ("totalCnt".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.totalCnt = jsonParser.getIntValue();
                            continue;
                        }
                        jsonParser.skipChildren();
                    }
                }
                return info;
            }
        }

    public static CalendarReminderCourseInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        CalendarReminderCourseInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new CalendarReminderCourseInfo();
                }

                if ("lessons".equals(fieldName)) {
                    jsonParser.nextToken();
                    ObjectMapper mapper = new ObjectMapper();
                    info.lessons = mapper.readValue(jsonParser, List.class);
                    continue;
                }


                jsonParser.skipChildren();
            }
        }
        return info;
    }

}
