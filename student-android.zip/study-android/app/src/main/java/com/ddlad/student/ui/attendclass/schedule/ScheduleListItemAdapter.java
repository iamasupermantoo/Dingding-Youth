package com.ddlad.student.ui.attendclass.schedule;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.protocol.model.ScheduleCourseInfo;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.R;
import com.ddlad.student.ui.widget.image.NetworkImageView;


/**
 * Created by Albert
 * on 16-10-20.
 */
public class ScheduleListItemAdapter {

    public static View createView(ViewGroup viewGroup) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.layout_lessons_item,
                null);

        ViewHolder holder = new ViewHolder(view);

        view.setTag(holder);

        return view;
    }

    public static void bindView(View view, final ScheduleCourseInfo mInfo, final BaseFragment fragment) {

        if (mInfo == null) {
            return;
        }

        ViewHolder holder = (ViewHolder) view.getTag();

        if (holder == null) {
            return;
        }
        if (mInfo != null){
            holder.mCourse.setText(mInfo.getCourse());
            holder.mLesson.setText(mInfo.getTotalCnt()+"");
            holder.mTeacher.setText(mInfo.getTeacher());
            holder.mTime.setText(mInfo.getTime());
            String url =  mInfo.getCourseImage().getPattern();
            holder.mImage.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}w")));
        }
    }

    private static class ViewHolder {
        private NetworkImageView mImage;
        private TextView mCourse;
        private TextView mLesson;
        private TextView mTeacher;
        private TextView mTime;

        public ViewHolder(View convertView) {
            mImage = (NetworkImageView) convertView.findViewById(R.id.lessons_item_image);
            mCourse = (TextView) convertView.findViewById(R.id.lessons_item_course);
            mLesson = (TextView) convertView.findViewById(R.id.lesson_item_time_my);
            mTeacher = (TextView) convertView.findViewById(R.id.lessons_item_teacher);
            mTime = (TextView) convertView.findViewById(R.id.lessons_item_time);
        }
    }
}
