package com.ddlad.student.primary;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;


import com.ddlad.student.primary.AppContext;
import com.ddlad.student.tools.StringUtil;
import com.ddlad.student.tools.Util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Created by Albert
 * on 16-6-2.
 */
public class DeviceInfo {
    //设备ID　默认取IMEI，当IMEI空时取MAC地址
    public String deviceId = "";//IMEI

    //mac 地址
    public String mac = "";//IMEI

    //浏览器版本号
    public int browserVersion;

    public String browserVersionName = "";

    //操作系统ID
    public String androidId = "";

    //Android SDK
    public int sdk;

    //Android系统版本
    public String version_release = "";

    //设备
    public String device = "";

    //设备生产厂商
    public String manufacturer = "";

    //设备型号
    public String model = "";

    //标识　１：安装、２：更新
    public int flag;

    public String version;

    private static DeviceInfo mDeviceInfo = null;

    private DeviceInfo(Context context) {

        this.deviceId = getDeviceId();
        this.mac = getLocalMacAddress();
        this.androidId = getAndroidId(context);
        this.model = android.os.Build.MODEL;
        this.sdk = android.os.Build.VERSION.SDK_INT;
        this.version_release = android.os.Build.VERSION.RELEASE;
        this.device = android.os.Build.DEVICE;
        this.manufacturer = android.os.Build.MANUFACTURER;
        try {
            PackageInfo browserPackageInfo = context.getPackageManager().getPackageInfo(
                    com.ddlad.student.primary.ZebraApp.PACKAGE_NAME, 0);

            this.browserVersion = browserPackageInfo.versionCode;
            this.browserVersionName = browserPackageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(
                    com.ddlad.student.primary.ZebraApp.PACKAGE_NAME, 0);
            this.version = packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static DeviceInfo getDeviceInfo(Context context) {
        if (mDeviceInfo == null) {
            mDeviceInfo = new DeviceInfo(context);
        }

        return mDeviceInfo;
    }

    private static String getAndroidId(Context context) {
        String androidId = Settings.System.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        if (TextUtils.isEmpty(androidId)) {
            androidId = "";
        }
        return androidId;
    }

    public static String getDeviceId() {

        String deviceId = null;

        try {
            TelephonyManager tm = (TelephonyManager) AppContext.getContext()
                    .getSystemService(Context.TELEPHONY_SERVICE);
            deviceId = tm.getDeviceId();
        } catch (Throwable t) {
            t.printStackTrace();
        }

        if (TextUtils.isEmpty(deviceId)) {
            deviceId = "";
        }

        return deviceId;
    }

    public static String getDeviceIdHash() {
        String deviceId = getDeviceId();
        if (!TextUtils.isEmpty(deviceId)) {
            try {
                final MessageDigest mDigest = MessageDigest.getInstance("MD5");
                mDigest.update(deviceId.getBytes());

                String id = Util.bytesToHexString(mDigest.digest());

                String[] ignoreIds = new String[]{"cfcd208495d565ef66e7dff9f98764da",//
                        "789b9efbdfcb6466d7e108cbd503db5d",//
                        "e97b0fdea398fc3ae071e65f4992dbb9",//
                        "5284047f4ffb4e04824a2fd1d1f0cd62", //
                        "57d286ceeedc4b2845f1c8d7ebe36519"};

                for (String ignoreId : ignoreIds) {
                    if (StringUtil.equals(id, ignoreId)) {
                        return "";
                    }
                }

                return id;
                //                return mDigest.digest().toString();
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        }

        return "";
    }

    public static String getAndroidId() {
        String androidId = Settings.Secure.getString(AppContext.getContext().getContentResolver(),
                Settings.Secure.ANDROID_ID);
        return androidId;
    }

    public static String getLocalMacAddress() {
        try {
            WifiManager wifi = (WifiManager) AppContext.getContext().getSystemService(
                    Context.WIFI_SERVICE);
            WifiInfo info = wifi.getConnectionInfo();
            return info.getMacAddress();
        } catch (Exception e) {
        }

        return "";
    }
}
