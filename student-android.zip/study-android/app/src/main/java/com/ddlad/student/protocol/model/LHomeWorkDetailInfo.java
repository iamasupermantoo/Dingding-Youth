package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.IOException;

/**
 * Created by chenjianing on 2017/5/8 0008.
 */
public class LHomeWorkDetailInfo extends BaseInfo {
        private String content;
        private String course;
        private String date;
        private String hid;
        private int status;
        private String student;
        private String teacher;
        private String time;
        private String title;

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getCourse() {
            return course;
        }

        public void setCourse(String course) {
            this.course = course;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public String getHid() {
            return hid;
        }

        public void setHid(String hid) {
            this.hid = hid;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getStudent() {
            return student;
        }

        public void setStudent(String student) {
            this.student = student;
        }

        public String getTeacher() {
            return teacher;
        }

        public void setTeacher(String teacher) {
            this.teacher = teacher;
        }

        public String getTime() {
            return time;
        }

        public void setTime(String time) {
            this.time = time;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }
        public static LHomeWorkDetailInfo fromJsonParser(JsonParser jsonParser) throws IOException {

            LHomeWorkDetailInfo info = null;

            if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

                while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                    String fieldName = jsonParser.getCurrentName();

                    if (fieldName == null) {
                        continue;
                    }

                    if (info == null) {
                        info = new LHomeWorkDetailInfo();
                    }

                    if ("date".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.date = jsonParser.getText();
                        continue;
                    }
                    if ("hid".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.hid = jsonParser.getText();
                        continue;
                    }
                    if ("time".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.time = jsonParser.getText();
                        continue;
                    }
                    if ("course".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.course = jsonParser.getText();
                        continue;
                    }
                    if ("ddlad".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.student = jsonParser.getText();
                        continue;
                    }
                    if ("teacher".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.teacher = jsonParser.getText();
                        continue;
                    }
                    if ("title".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.title = jsonParser.getText();
                        continue;
                    }
                    if ("content".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.content = jsonParser.getText();
                        continue;
                    }
                    if ("status".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.status = jsonParser.getIntValue();
                        continue;
                    }
                    jsonParser.skipChildren();
                }
            }
            return info;
        }
}
