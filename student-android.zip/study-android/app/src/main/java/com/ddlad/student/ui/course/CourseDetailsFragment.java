package com.ddlad.student.ui.course;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Html;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.ui.common.BaseListFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.request.BaseListRequest;
import com.ddlad.student.protocol.http.request.CourseDetailsRequest;
import com.ddlad.student.protocol.http.request.HomeworkRequest;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.CourseDetailsInfo;
import com.ddlad.student.protocol.model.HomeworkInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.attendclass.evaluate.EvaluateDetailsFragment;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.widget.dialog.DialogBuilder;
import com.ddlad.student.ui.widget.image.NetworkImageView;

/**
 * Created by chenjianing on 2017/3/24 0024.
 */
public class CourseDetailsFragment extends BaseListFragment<HomeworkInfo> {

    private int mLoaderFeedBackId = ViewUtil.generateUniqueId();
    private String mCmId;

    private CourseDetailsInfo mInfo;



    private NetworkImageView mCourseImage;
    private TextView mCourseName;
    private TextView mCourseTime;
    private TextView mTeacherName;
    private TextView mLevel;
    private TextView mPrice;
    private TextView mIntroduction;
    private TextView mConvention;


    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_course_details;
    }

    @Override
    protected int getHeaderResource() {
        return R.layout.fragment_course_detail_header;
    }

    @Override
    protected void onInitHeader(View contentView) {
        mCourseImage = (NetworkImageView) contentView.findViewById(R.id.evaluate_item_image);
        mCourseName = (TextView) contentView.findViewById(R.id.evaluate_item_course);
        mCourseTime = (TextView) contentView.findViewById(R.id.evaluate_item_class_time);
        mTeacherName = (TextView) contentView.findViewById(R.id.evaluate_item_teacher);
        mLevel = (TextView) contentView.findViewById(R.id.course_detai_item_level);
        mPrice = (TextView) contentView.findViewById(R.id.evaluate_item_price);
        mConvention = (TextView) contentView.findViewById(R.id.convention);
        mIntroduction = (TextView) contentView.findViewById(R.id.course_introduction);
    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle("课程详情");
        super.onInitView(contentView);
    }


    @Override
    protected BaseListRequest makeRequest(AbstractStreamingCallbacks<AbstractListResponse<HomeworkInfo>> streamingApiCallbacks) {
        return new HomeworkRequest(this, mLoaderFeedBackId, streamingApiCallbacks);
    }

    @Override
    protected void performRequest() {
        ((HomeworkRequest)mDefaultRequest).perform(getNextCursorId());
        requestData();
    }

    @Override
    protected boolean isNeedFetch() {
        return true;
    }

    @Override
    protected AbstractAdapter getAdapter() {
        if (mAdapter == null) {
            mAdapter = new LUserFeedBackListAdapter(this);
        }
        return mAdapter;
    }

    @Override
    protected void onInitData(Bundle bundle) {
        mCmId = (String) bundle.get("cmid");
//        requestData();
        super.onInitData(bundle);
    }

    private void requestData() {
        CourseDetailsRequest courseDetailsRequest = new CourseDetailsRequest(this, getDefaultLoaderId(), new AbstractCallbacks<CourseDetailsInfo>() {
            @Override
            protected void onSuccess(CourseDetailsInfo courseDetailsInfo) {
                mInfo = courseDetailsInfo;
                String url =  mInfo.getCourse().getImage().getPattern();
                mCourseImage.setUrl(url.substring(url.indexOf("http"),url.indexOf(".png"))+".png");
                mCourseName.setText(mInfo.getCourse().getName());

                mTeacherName.setText(mInfo.getCourse().getTeacher());
                mPrice.setText(mInfo.getCourse().getPrice());
//                mLevel.setText(mInfo.getCourse().getLevel());
//                mIntroduction.setText(mInfo.getCourse().getDesc());
                mIntroduction.setText(Html.fromHtml(mInfo.getCourse().getDesc()));
                //                mCourseTime  返回的数据中没有时间
//                mCourseTime.setText(mInfo.getCourse().getTotalCnt()+"节课");


                mConvention.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final DialogBuilder dialogBuilder = new DialogBuilder(getActivity());

                        dialogBuilder.setCanceledOnTouchOutside(false);
                        dialogBuilder.setTitle("提示")
                                .setMessage("您已约课成功，稍后我们的工作人员将会联系您进行确认!")
                                .setMessageGravity(Gravity.CENTER)
                                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogBuilder.dismiss();
                                    }
                                });
                        dialogBuilder.create().show();
                    }
                });
            }
        });
        courseDetailsRequest.perform(mCmId);
    }

    private void navigateCourseDetailsFragment() {
        NavigateUtil.navigateToNormalActivity(getActivity(), new EvaluateDetailsFragment(), null);
    }
}
