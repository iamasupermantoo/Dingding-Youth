package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;


import java.io.IOException;

/**
 * Created by Albert
 * on 16-10-10.
 */
public class FeedInfo extends BaseInfo {

//    private MultiImageInfo image;

//    private List<TagInfo> tags;

    private int favCount;
    private int commentCount;
    private int readCount;

    private String desc;
    private UserInfo author;

    private String brief;
    private String content;
    private String title;
    private String createTime;
    private String time;

    private int upDownFlag;

    private int upCount;
    private int downCount;
    private String qid;
    private String id;
    private boolean isFaved;

    private int follower;
    private int feed;
    private int message;
    private int pm;

    public int getPm() {
        return pm;
    }

    public void setPm(int pm) {
        this.pm = pm;
    }

    public int getFollower() {
        return follower;
    }

    public void setFollower(int follower) {
        this.follower = follower;
    }

    public int getFeed() {
        return feed;
    }

    public void setFeed(int feed) {

        this.feed = feed;
    }

    public int getMessage() {
        return message;
    }

    public void setMessage(int message) {
        this.message = message;
    }

    public int getUpDownFlag() {
        return upDownFlag;
    }

    public void setUpDownFlag(int upDownFlag) {
        this.upDownFlag = upDownFlag;
    }
    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    public int getUpCount() {
        return upCount;
    }

    public void setUpCount(int upCount) {
        this.upCount = upCount;
    }

    public int getDownCount() {
        return downCount;
    }

    public void setDownCount(int downCount) {
        this.downCount = downCount;
    }

    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid;
    }

//    "time":"2016-12-08",
//            "title":"这是标题",
//            "readCount":4,
//            "commentCount":1,
//            "upCount":1,
//            "downCount":0,
//            "author":Object{...},
//            "qid":"d4QOBPsPkMYM32EYjRVwMQ",
//            "id":"oAxf_pIjIAUM32EYjRVwMQ",
//            "content":"<div> Rwerewrwerwer1232143241234234234 </div>"

//    public MultiImageInfo getImage() {
//        return image;
//    }
//
//    public void setImage(MultiImageInfo image) {
//        this.image = image;
//    }
//
//    public List<TagInfo> getTags() {
//        return tags;
//    }
//
//    public void setTags(List<TagInfo> tags) {
//        this.tags = tags;
//    }

    public int getFavCount() {
        return favCount;
    }

    public void setFavCount(int favCount) {
        this.favCount = favCount;
    }

    public int getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(int commentCount) {
        this.commentCount = commentCount;
    }

    public int getReadCount() {
        return readCount;
    }

    public void setReadCount(int readCount) {
        this.readCount = readCount;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public UserInfo getAuthor() {
        return author;
    }

    public void setAuthor(UserInfo author) {
        this.author = author;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getBrief() {
        return brief;
    }

    public void setBrief(String brief) {
        this.brief = brief;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String time) {
        this.createTime = time;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public boolean getIsFaved() {
        return isFaved;
    }

    public void setIsFaved(boolean isFaved) {
        this.isFaved = isFaved;
    }

    public static FeedInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        FeedInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new FeedInfo();
                }

                if ("favCount".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.favCount = jsonParser.getIntValue();
                    continue;
                }

                if ("commentCount".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.commentCount = jsonParser.getIntValue();
                    continue;
                }

                if ("readCount".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.readCount = jsonParser.getIntValue();
                    continue;
                }

                if ("title".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.title = jsonParser.getText();
                    continue;
                }

                if ("author".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.author = UserInfo.fromJsonParser(jsonParser);
                    continue;
                }

                if ("content".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.content = jsonParser.getText();
                    continue;
                }

                if ("brief".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.brief = jsonParser.getText();
                    continue;
                }

                if ("id".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.id = jsonParser.getText();
                    continue;
                }
                if ("qid".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.qid = jsonParser.getText();
                    continue;
                }
                if ("upDownFlag".equals(fieldName)){
                    jsonParser.nextToken();
                    info.upDownFlag = jsonParser.getIntValue();
                }
                if ("upCount".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.upCount = jsonParser.getIntValue();
                    continue;
                }
                if ("downCount".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.downCount = jsonParser.getIntValue();
                    continue;
                }


                if ("type".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.type = jsonParser.getIntValue();
                    continue;
                }

//                if ("image".equals(fieldName)) {
//                    jsonParser.nextToken();
//                    info.image = MultiImageInfo.fromJsonParser(jsonParser);
//                    continue;
//                }

                if ("desc".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.desc = jsonParser.getText();
                    continue;
                }

                if ("createTime".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.createTime = jsonParser.getText();
                    continue;
                }

                if ("time".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.time = jsonParser.getText();
                    continue;
                }

                if ("isFaved".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.isFaved = jsonParser.getBooleanValue();
                    continue;
                }

//                if ("tags".equals(fieldName)) {
//
//                    jsonParser.nextToken();
//
//                    List<TagInfo> tags = new ArrayList<>();
//
//                    while (jsonParser.nextToken() != JsonToken.END_ARRAY) {
//                        TagInfo t = TagInfo.fromJsonParser(jsonParser);
//                        if (t != null) {
//                            tags.add(t);
//                        }
//                    }
//
//                    info.tags = tags;
//
//                    continue;
//                }

                jsonParser.skipChildren();
            }
        }

        return info;
    }

    public enum FeedType {

        Article(0), Image(1);

        private FeedType(int value) {
            this.mValue = value;
        }

        private int mValue;

        public int getValue() {
            return mValue;
        }
    }

}
