package com.ddlad.student.protocol.http.internal;

public class HttpResponseCode {

    public static int STATUS_CODE_OK = 200;

    public static int STATUS_CODE_NOT_MODIFIED = 304;

    public static int STATUS_CODE_TOKEN_INVALID = 401;

    public static int STATUS_CODE_NOT_FOUND = 404;

    public static int STATUS_CODE_SERVICE_UNAVAILABLE = 503;

    public static int STATUS_CODE_NOT_REGISTERED = 40042;

}
