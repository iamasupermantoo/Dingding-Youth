package com.ddlad.student.ui.attendclass;


import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.MainActivity;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.request.CourseNumRequest;
import com.ddlad.student.protocol.model.CourseNumInfo;
import com.ddlad.student.tools.Constants;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.ui.attendclass.evaluate.EvaluateFragment;
import com.ddlad.student.ui.attendclass.schedule.HomeworkListFragment;
import com.ddlad.student.ui.attendclass.schedule.ScheduleFragment;
import com.ddlad.student.ui.attendclass.student.CurriculumFragment;
import com.ddlad.student.ui.common.BaseFragment;

import org.w3c.dom.Text;

/**
 * A simple {@link BaseFragment} subclass.
 */
public class AttendClassFragment extends BaseFragment {

    private ViewGroup mAttendClassLayout;
    private ViewGroup mCourseLayout;
    private ViewGroup mHomeworkLayout;
    private ViewGroup mEvaluateLayout;
    private ViewGroup mEmptyLayout;

    private ImageView scheduleCourse;
    private ImageView course;
    private ImageView homework;
    private ImageView evaluate;

    private TextView call;

    private ImageView subscribe_course;
    private boolean isFirst = false;

    public static boolean isNeedRequest = true;
    public static boolean isHasCourse = false;


    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_attend_class;
    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle("上课");
        mActionbar.setNewSwitchSelect(true);
        mAttendClassLayout = (ViewGroup) contentView.findViewById(R.id.layout_attend_class);
        mCourseLayout = (ViewGroup) contentView.findViewById(R.id.layout_course);
        mHomeworkLayout = (ViewGroup) contentView.findViewById(R.id.layout_homework);
        mEvaluateLayout = (ViewGroup) contentView.findViewById(R.id.layout_evaluate);
        mEmptyLayout = (ViewGroup) contentView.findViewById(R.id.empty_layout);
        subscribe_course = (ImageView) contentView.findViewById(R.id.subscribe_course);

        scheduleCourse = (ImageView) contentView.findViewById(R.id.schedule_course);
        course = (ImageView) contentView.findViewById(R.id.course);
        homework = (ImageView) contentView.findViewById(R.id.homework);
        evaluate = (ImageView) contentView.findViewById(R.id.evaluate);

        call = (TextView) contentView.findViewById(R.id.call);

        scheduleCourse.setOnClickListener(this);
        course.setOnClickListener(this);
        homework.setOnClickListener(this);
        evaluate.setOnClickListener(this);
        mEmptyLayout.setOnClickListener(this);

        call.setVisibility(View.VISIBLE);
        call.setOnClickListener(this);
        call.setText(AppContext.getString(R.string.reservation_tel,Constants.servicePhone));

        mAttendClassLayout.setOnClickListener(this);
        mCourseLayout.setOnClickListener(this);
        mHomeworkLayout.setOnClickListener(this);

        mEvaluateLayout.setOnClickListener(this);
        if (isHasCourse){
            mEmptyLayout.setVisibility(View.GONE);
        }else {
            mEmptyLayout.setVisibility(View.VISIBLE);
        }
        subscribe_course.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateChoice();
            }
        });

        if (isNeedRequest){
            performRequest();
        }
    }

    @Override
    public void onResume() {
        if (isNeedRequest){
            performRequest();
        }

        super.onResume();
    }

    private void performRequest() {
        CourseNumRequest request = new CourseNumRequest(this, getDefaultLoaderId(), new AbstractCallbacks<CourseNumInfo>() {
            @Override
            protected void onSuccess(CourseNumInfo courseNumInfo) {
                isNeedRequest = false;
                if (courseNumInfo != null && courseNumInfo.getCourses() != null && courseNumInfo.getCourses().getList() != null && courseNumInfo.getCourses().getList().size() >0){
                    mEmptyLayout.setVisibility(View.GONE);
                    isHasCourse = true;
                }else {
                    mEmptyLayout.setVisibility(View.VISIBLE);
                    isHasCourse = false;
                }

            }
        });
        request.perform();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.layout_attend_class:
                navigateAttendClass();
                break;
            case R.id.layout_course:

                navigateCurriculum();

                break;
            case R.id.layout_homework:
                navigateHomework();
                break;
            case R.id.layout_evaluate:
                navigateEvaluate();
                break;

            case R.id.schedule_course:
                navigateAttendClass();
                break;
            case R.id.course:
                navigateCurriculum();
                break;
            case R.id.homework:
                navigateHomework();
                break;
            case R.id.evaluate:
                navigateEvaluate();
                break;
            case R.id.call:
                callSomeOne(Constants.servicePhone);
                break;
            case R.id.empty_layout:
                break;
        }
    }

    private void callSomeOne(String num) {
        if (!requestCallPermission()){
            return;
        }
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:"+num));
        getActivity().startActivity(intent);
    }

    private boolean requestCallPermission() {
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            // 没有获得授权，申请授权
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                    Manifest.permission.CALL_PHONE)) {
                // 帮跳转到该应用的设置界面，让用户手动授权
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getActivity().getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
            }else {
                // 不需要解释为何需要该权限，直接请求授权
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.CALL_PHONE},
                        Constants.PERMISSION_CALL_PHONE);
            }
        }else {
            return true;
        }
       return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode){
            case Constants.PERMISSION_CALL_PHONE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // 授权成功，继续打电话
                    callSomeOne("17600484003");
                } else {
                    // 授权失败！
                    Toaster.toastShort("授权失败");
                }
                break;
            }
        }

    }

    private void navigateAttendClass() {
//        NavigateUtil.navigateToNormalActivity(getActivity(),);
        NavigateUtil.navigateToNormalActivity(getActivity(), new ScheduleFragment(), null);
//        NavigateUtil.navigateToNormalActivity(getActivity(), new LScheduleFragment(), null);
    }

    private void navigateEvaluate() {
//        NavigateUtil.navigateToNormalActivity(getActivity(),new ,null
//        );
        NavigateUtil.navigateToNormalActivity(getActivity(), new EvaluateFragment(), null);
    }

    private void navigateHomework() {
//        NavigateUtil.navigateToNormalActivity(getActivity(),new ,null);
        NavigateUtil.navigateToNormalActivity(getActivity(), new HomeworkListFragment(), null);
    }

    private void navigateCurriculum() {
        NavigateUtil.navigateToNormalActivity(getActivity(), new CurriculumFragment(), null);
    }

    private void navigateChoice() {
        iToChoice.tochoice();
//        NavigateUtil.navigateToNormalActivity(getActivity(), new ChoiceFragment(), null);
    }
    @Override
    protected boolean isNeedFetch() {
        return true;
    }

    @Override
    protected boolean isHideBackBtn() {
        return true;
    }


    public interface IToChoice{
        void tochoice();
    }

    public IToChoice getiToChoice() {
        return iToChoice;
    }

    public void setiToChoice(IToChoice iToChoice) {
        this.iToChoice = iToChoice;
    }

    public static IToChoice iToChoice;
}
