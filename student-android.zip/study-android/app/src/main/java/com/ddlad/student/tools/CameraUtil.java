package com.ddlad.student.tools;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.MediaStore.Images;
import android.support.v4.app.Fragment;
import android.text.TextUtils;

import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;
import com.ddlad.student.ui.model.CourseImage;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class CameraUtil {

    public static final String TAG = "CameraUtil";

    public static String sImagePath;
    public static int sImageType;
    public static List<CourseImage> sCourseImages;
    public static String sCourseRemark;

    public static ImageFileProducer sImageFileProducer;

    public static final String DCIM = Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_DCIM).toString();

    public static final String DIRECTORY = DCIM + "/Camera";

    public static String getImagePath(String filename) {
        return FileUtil.getAppFolderPath() + "Image/" + filename + ".jpg";
    }

    public static File takePhoto(Activity activity) {
        initialize();
        File cameraTempFile = getPhotoOutputMediaFile();
        show(activity, Constants.REQUEST_CODE_TAKE_PHOTO, cameraTempFile);
        if (cameraTempFile == null) {
            SaveReport.infoLog("cameraTempFile", "is null");
        } else {
            SaveReport.infoLog("cameraTempFile", cameraTempFile.getAbsolutePath()
                    + ", " + (cameraTempFile.exists() ? "exist" : "not exist"));
        }
        return cameraTempFile;
    }

    private static void initialize() {
        if (sImageFileProducer == null) {
            sImageFileProducer = new ImageFileProducer(AppContext.getString(R.string.image_file_name_format));
        }
    }

    public static String createJpegName(long time) {
        synchronized (sImageFileProducer) {
            return sImageFileProducer.generateName(time);
        }
    }

    public static File getPhotoOutputMediaFile() {
        if (FileUtil.isSdcardValid()) {
            return new File(getImagePath(CameraUtil.createJpegName(System.currentTimeMillis())));
        } else {
            File file = null;
            try {
                file = new File(getImagePath(CameraUtil.createJpegName(System.currentTimeMillis())));
            } catch (Throwable t) {
                t.printStackTrace();
                SaveReport.crashLog(t);
            }
            return file;
        }
    }

    private static Intent constructIntent(Activity activity, Intent intent, File cameraTempFile,
                                          int requestCode) {

        Uri uri = null;
        if (cameraTempFile != null) {
            uri = Uri.fromFile(cameraTempFile);
        }
        if (uri == null) {
            uri = intent.getData();
        }

        return CropUtil.constructCropIntent(activity, uri, requestCode);
    }

    public static void handleActivityResult(Activity activity, Intent intent, File cameraTempFile,
                                            int requestCode) {
        activity.startActivityForResult(
                constructIntent(activity, intent, cameraTempFile, requestCode), requestCode);
    }

    public static void handleFragmentResult(Fragment fragment, Intent intent, File cameraTempFile,
                                            int requestCode) {
        if (fragment != null) {
            fragment.startActivityForResult(
                    constructIntent(fragment.getActivity(), intent, cameraTempFile, requestCode),
                    requestCode);
        }
    }

    private static Intent prepareIntent(ContentResolver contentResolver, File cameraTempFile) {
        try {
            cameraTempFile.getParentFile().mkdirs();
            cameraTempFile.createNewFile();
            Runtime.getRuntime().exec("chmod 0666" + cameraTempFile.getPath());
            String filename = cameraTempFile.getName();

            String title = filename;
            if (filename.length() > 4) {
                filename = TextUtils.substring(filename, 0, filename.length() - 4);
            }

            if (Log.DEBUG) {
                Log.d(TAG, "prepareIntent(), filename=" + filename + ", title=" + title);
            }

            ContentValues contentValues = new ContentValues();
            contentValues.put(Images.ImageColumns.TITLE, title);
            contentValues.put(Images.ImageColumns.DISPLAY_NAME, filename);
            contentValues.put(Images.ImageColumns.DATE_TAKEN,
                    Long.valueOf(System.currentTimeMillis()));
            contentValues.put(Images.ImageColumns.MIME_TYPE, "image/jpeg");
            contentValues.put(Images.ImageColumns.DATA, cameraTempFile.getPath());

            try {
                Uri uri = contentResolver.insert(Images.Media.EXTERNAL_CONTENT_URI, contentValues);
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);

                return intent;

            } catch (Exception e) {
                Log.e(TAG, "Unable to insert media into media store");
            }
        } catch (IOException e) {
            Log.e(TAG, "Error while trying to create photo file", e);
        }

        return null;
    }

    public static void show(Activity activity, int requestCode, File cameraTempFile) {
        try {
            if (activity != null) {
                activity.startActivityForResult(
                        prepareIntent(AppContext.getContext().getContentResolver(), cameraTempFile),
                        requestCode);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void deleteTempCameraFile(File cameraTempFile) {
        try {
            AppContext
                    .getContext()
                    .getContentResolver()
                    .delete(Images.Media.EXTERNAL_CONTENT_URI,
                            Images.Media.DATA + "=?",
                            new String[]{cameraTempFile.getAbsolutePath()});
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static class ImageFileProducer {

        private SimpleDateFormat mFormat;

        private long mLastDate;

        private int mSameSecondCount;

        public ImageFileProducer(String pattern) {
            mFormat = new SimpleDateFormat(pattern);
        }

        public String generateName(long time) {
            Date date = new Date(time);
            String name = mFormat.format(date);
            if (time / 1000L == mLastDate / 1000L) {
                mSameSecondCount = (1 + mSameSecondCount);
                name = name + "_" + mSameSecondCount;
            } else {
                mLastDate = time;
                mSameSecondCount = 0;
            }

            return name;
        }
    }
}
