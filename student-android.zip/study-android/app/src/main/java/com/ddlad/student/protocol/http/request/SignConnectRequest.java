package com.ddlad.student.protocol.http.request;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.UserInfo;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.model.Account;
import com.ddlad.student.tools.BitmapUtil;

import java.io.ByteArrayInputStream;

import ch.boye.httpclientandroidlib.Header;
import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-7-6.
 */
public class SignConnectRequest extends AbstractRequest<Account> {

    protected Uri mUri;

    protected Bitmap mBitmap = null;

    public SignConnectRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<Account> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        HttpUriRequest request = httpClient.postRequest(url, requestParam);
        Header header = getMultipartParams().getMultipartHeader();
        if (header != null) {
            request.setHeader(header);
        }
        return request;
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_MOBILE_SIGN_CONNECT;
    }

    @Override
    public Account processInBackground(ApiResponse<Account> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, Account.class);
    }

    protected Bitmap getBitmap() {
        return BitmapFactory.decodeFile(mUri.getPath());
    }

    @Override
    public void preProcessInBackground() throws PreProcessException {

        try {

            if (mBitmap == null && mUri == null) {
                getParams().put(ProtocolConstants.PARAM_HEAD_IMAGE, null, "file", "multipart/form-data");
            } else {
                ByteArrayInputStream byteArrayInputStream;
                byteArrayInputStream = BitmapUtil.compressedInputStream(mBitmap == null ? getBitmap() : mBitmap);
                getParams().put(ProtocolConstants.PARAM_HEAD_IMAGE, byteArrayInputStream, "file", "multipart/form-data");
            }

            return;

        } catch (Throwable t) {
            t.printStackTrace();
        }

        throw new PreProcessException();
    }

    //增加nickname
    public void perform(UserInfo user, String nickname, Uri headUri, String externalUserId, String accessToken, int type) {
        perform(user.getMobile(), user.getName(), nickname,user.getPassword(), type,
                user.getCode(), user.getSignature(), headUri,externalUserId,accessToken,"");
    }

    //增加nickname
    public void perform(UserInfo user, String nickname, Uri headUri, String externalUserId, String accessToken, int type,String birthday) {
        perform(user.getMobile(), user.getName(), nickname,user.getPassword(), type,
                user.getCode(), user.getSignature(), headUri,externalUserId,accessToken,birthday);
    }

    //增加nickname
    public void perform(Object mobile, Object name, String nickname, Object password, Object userType, Object code, Object signature, Uri headImage,Object externalUserId,Object accessToken,String birthday) {
        mUri = headImage;
        RequestParams params = getMultipartParams();
        params.put(ProtocolConstants.PARAM_TYPE,userType);
        params.put(ProtocolConstants.PARAM_EXTERNAL_USERID,externalUserId);
        params.put(ProtocolConstants.PARAM_ACCESSTOKEN,accessToken);
        params.put("mobile", mobile);
        params.put("name", name);
        params.put("nickname", nickname);
        params.put("password", password);
        params.put("signature", signature);
        params.put("birthday", birthday);
        super.perform();
    }
}
