package com.ddlad.student.protocol.model;

import com.ddlad.student.ui.model.MultiImageInfo;

import java.util.List;

/**
 * Created by Administrator on 2017/1/17 0017.
 */

public class TeacherDetailInfo extends BaseInfo {

    private Teacher teacher;
    private List<CourseMetas> courseMetas ;

    public List<CourseMetas> getCourseMetas() {
        return courseMetas;
    }

    public void setCourseMetas(List<CourseMetas> courseMetas) {
        this.courseMetas = courseMetas;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public static class Teacher{
//        "tid":"T001",
//        "name":"wangsch",
//        "headImg":Object{...},
//        "gender":0,
//        "hours":1000,
//        "desc":"这位老师，就是如神的存在！！！"
        private String tid;
        private String name;
        private MultiImageInfo headImg;
        private String gender;
        private String hours;
        private String desc;

        public String getTid() {
            return tid;
        }

        public void setTid(String tid) {
            this.tid = tid;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public MultiImageInfo getHeadImg() {
            return headImg;
        }

        public void setHeadImg(MultiImageInfo headImg) {
            this.headImg = headImg;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }

        public String getHours() {
            return hours;
        }

        public void setHours(String hours) {
            this.hours = hours;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }
    }


}
