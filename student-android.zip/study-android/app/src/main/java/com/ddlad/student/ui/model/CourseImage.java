package com.ddlad.student.ui.model;

import com.ddlad.student.primary.AppContext;

import java.util.List;

/**
 * Created by Albert
 * on 16-11-23.
 */
public class CourseImage extends ReactionImage {

    public static int COURSE_IMAGE_WIDTH = AppContext.getScreenWidth() / COURSE_MAX_IMAGE_COUNT;

    public static int COURSE_IMAGE_HEIGHT = COURSE_IMAGE_WIDTH * 3 / 4;

    private List<ImageInfo> images;

    public CourseImage() {

    }

    public CourseImage(ReactionImage reactionImage) {
        typeName = reactionImage.getTypeName();
        imageIds = reactionImage.getImageIds();
    }

//    public String getTitle() {
//        return ImageType.fromValue(typeName);
//    }
//
//    public int getImageCount() {
//        return CollectionUtil.isEmpty(imageIds) ? 0 : imageIds.size();
//    }
//
//    public List<ImageInfo> getImages() {
//        return images;
//    }
//
//    public boolean hasImages() {
//        return !CollectionUtil.isEmpty(images);
//    }
//
//    public void setImages(List<ImageInfo> images) {
//        this.images = images;
//    }
//
//    public boolean isNeedParse() {
//        return !CollectionUtil.isEmpty(imageIds) && CollectionUtil.isEmpty(images);
//    }
//
//    public void checkList() {
//        if (hasImages()) {
//            for (ImageInfo singleImage : images) {
//                if (!TextUtils.isEmpty(singleImage.getId())) {
//                    singleImage.setState(ImageState.Uploaded);
//                }
//            }
//        }
//    }
//
//    public void parseImage() {
//        if (images == null) {
//            images = new ArrayList<>(imageIds.size());
//        }
//        for (String imageId : imageIds) {
//            images.add(new ImageInfo(imageId, 100));
//        }
//    }
//
//    public ImageInfo insert(Uri uri, final InteractionStepSixFragment fragment,
//                            final InteractionStepSixAdapter adapter) {
//
//        if (imageIds == null) {
//            imageIds = new ArrayList<>(COURSE_MAX_IMAGE_COUNT);
//        }
//        if (images == null) {
//            images = new ArrayList<>(COURSE_MAX_IMAGE_COUNT);
//        }
//        if (images.size() < COURSE_MAX_IMAGE_COUNT) {
//            final ImageInfo image = new ImageInfo(uri);
//            new FetchImageTask(fragment.getActivity(), image) {
//
//                @Override
//                protected void onPostExecute(ImageInfo localImageInfo) {
//                    if (image.getBitmap() != null) {
//                        adapter.notifyDataSetChanged();
//                        fragment.onImageSaved(image);
//                    }
//                }
//            }.originalExecute();
//            imageIds.add(image.getId());
//            images.add(image);
//            return image;
//        } else {
//            Toaster.toastShort(R.string.image_upload_limit);
//            return null;
//        }
//    }
//
//    public void insert(final int index, final List<String> paths, final InteractionStepSixFragment fragment,
//                       final InteractionStepSixAdapter adapter) {
//
//        if (imageIds == null) {
//            imageIds = new ArrayList<>(COURSE_MAX_IMAGE_COUNT);
//        }
//        if (images == null) {
//            images = new ArrayList<>(COURSE_MAX_IMAGE_COUNT);
//        }
//        if (images.size() < COURSE_MAX_IMAGE_COUNT) {
//            final String path = paths.get(index);
//            final ImageInfo image = new ImageInfo(path);
//            new FetchImageTask(fragment.getActivity(), image) {
//
//                @Override
//                protected void onPostExecute(ImageInfo localImageInfo) {
//                    if (image.getBitmap() != null) {
//                        paths.remove(index);
//                        adapter.notifyDataSetChanged();
//                        fragment.onImageSaved(image, paths);
//                    }
//                }
//            }.originalExecute();
//            imageIds.add(image.getId());
//            images.add(image);
//        } else {
//            Toaster.toastShort(R.string.image_upload_limit);
//        }
//    }
}
