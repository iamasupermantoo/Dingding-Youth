package com.ddlad.student.tools;

import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.ConfigurationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.StrictMode;
import android.text.TextUtils;
import android.widget.ImageView;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;
import com.ddlad.student.primary.ZebraApp;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPOutputStream;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;

/**
 * Created by Albert
 * on 16-6-2.
 */
public class Util {
    private static final String TAG = "Utils";

    public static final int IO_BUFFER_SIZE = 8 * 1024;

    public static final Random RNG = new Random();

    private static final String TAG_MAIL_REX = "^\\s*\\w+(?:\\.{0,1}[\\w-]+)*@[a-zA-Z0-9]+(?:[-.][a-zA-Z0-9]+)*\\.[a-zA-Z]+\\s*$";

    public static Pattern AT_PATTERN = Pattern.compile("\\{@_([hstr]):(.*?)\\}");

    public static Pattern TAG_PATTERN = Pattern.compile("#([^#]*)#");

    public static String bytesToHexString(byte[] bytes) {
        // http://stackoverflow.com/questions/332079
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bytes.length; i++) {
            String hex = Integer.toHexString(0xFF & bytes[i]);
            if (hex.length() == 1) {
                sb.append('0');
            }
            sb.append(hex);
        }
        return sb.toString();
    }

    public static String getQQAppId() {
        String appId = null;
        try {
            ApplicationInfo ai = AppContext
                    .getContext()
                    .getPackageManager()
                    .getApplicationInfo(AppContext.getContext().getPackageName(),
                            PackageManager.GET_META_DATA);
            Object value = null;
            if (ai != null && ai.metaData != null) {
                value = ai.metaData.get("tencent_appid");
            }
            if (value != null) {
                appId = value.toString();
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return appId;
    }

    public static String getWechatAppId() {
        String appId = null;
        try {
            ApplicationInfo ai = AppContext
                    .getContext()
                    .getPackageManager()
                    .getApplicationInfo(AppContext.getContext().getPackageName(),
                            PackageManager.GET_META_DATA);
            Object value = null;
            if (ai != null && ai.metaData != null) {
                value = ai.metaData.get("wechat_appid");
            }
            if (value != null) {
                appId = value.toString();
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return appId;
    }

    public static String getWechatSecret() {
        String appId = null;
        try {
            ApplicationInfo ai = AppContext
                    .getContext()
                    .getPackageManager()
                    .getApplicationInfo(AppContext.getContext().getPackageName(),
                            PackageManager.GET_META_DATA);
            Object value = null;
            if (ai != null && ai.metaData != null) {
                value = ai.metaData.get("wechat_secret");
            }
            if (value != null) {
                appId = value.toString();
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return appId;
    }

    public static String getBaiduApiKey() {
        String apiKey = null;
        try {
            ApplicationInfo ai = AppContext
                    .getContext()
                    .getPackageManager()
                    .getApplicationInfo(AppContext.getContext().getPackageName(),
                            PackageManager.GET_META_DATA);
            Object value = null;
            if (ai != null && ai.metaData != null) {
                value = ai.metaData.get("api_key");
            }
            if (value != null) {
                apiKey = value.toString();
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return apiKey;
    }

    public static String getXiamiAppKey() {
        String appKey = null;
        try {
            ApplicationInfo ai = AppContext
                    .getContext()
                    .getPackageManager()
                    .getApplicationInfo(AppContext.getContext().getPackageName(),
                            PackageManager.GET_META_DATA);
            Object value = null;
            if (ai != null && ai.metaData != null) {
                value = ai.metaData.get("xiami_appkey");
            }
            if (value != null) {
                appKey = value.toString();
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return appKey;
    }

    public static String getXiamiAppSecret() {
        String appSecret = null;
        try {
            ApplicationInfo ai = AppContext
                    .getContext()
                    .getPackageManager()
                    .getApplicationInfo(AppContext.getContext().getPackageName(),
                            PackageManager.GET_META_DATA);
            Object value = null;
            if (ai != null && ai.metaData != null) {
                value = ai.metaData.get("xiami_appsecret");
            }
            if (value != null) {
                appSecret = value.toString();
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return appSecret;
    }

    public static String getLiveAppId() {
        String appKey = null;
        try {
            ApplicationInfo ai = AppContext
                    .getContext()
                    .getPackageManager()
                    .getApplicationInfo(AppContext.getContext().getPackageName(),
                            PackageManager.GET_META_DATA);
            Object value = null;
            if (ai != null && ai.metaData != null) {
                value = ai.metaData.get("live_appid");
            }
            if (value != null) {
                appKey = value.toString();
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
        return appKey;
    }

    public static String getChannel() {
        String channleId = "0";
        try {
            ApplicationInfo applicationInfo = AppContext
                    .getContext()
                    .getPackageManager()
                    .getApplicationInfo(AppContext.getContext().getPackageName(),
                            PackageManager.GET_META_DATA);
            Object value = applicationInfo.metaData.get("channel");
            if (value != null) {
                channleId = value.toString();
            }
        } catch (Exception e) {
        }

        return channleId;
    }

    public static String getUpdateVersion() {
        String updateVersion = "a";
        try {
            ApplicationInfo applicationInfo = AppContext
                    .getContext()
                    .getPackageManager()
                    .getApplicationInfo(AppContext.getContext().getPackageName(),
                            PackageManager.GET_META_DATA);
            Object value = applicationInfo.metaData.get("update_version");
            if (value != null) {
                updateVersion = value.toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return updateVersion;
    }

    /**
     * Get the memory class of this device (approx. per-app memory limit)
     *
     * @return
     */
    public static int getMemoryClass() {
        return ((ActivityManager) AppContext.getContext()
                .getSystemService(Context.ACTIVITY_SERVICE)).getMemoryClass();
    }

    public static boolean hasFroyo() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.FROYO;
    }

    public static boolean hasGingerbread() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD;
    }

    public static boolean hasHoneycomb() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB;
    }

    public static boolean hasHoneycombMR1() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR1;
    }

    public static boolean hasJellyBean() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN;
    }

    public static boolean hasJellyBeanMR1() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1;
    }

    public static boolean hasJellyBeanMR2() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2;
    }

    public static boolean hasKitkat() {
        return Build.VERSION.SDK_INT >= 19/*Build.VERSION_CODES.KITKAT*/;
    }

    public static boolean hasIceCreamSandwich() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH;
    }

    public static boolean isLollipop() {
        return Build.VERSION.SDK_INT == 21;
    }

    public static boolean hasMoonCake() {
        return Build.VERSION.SDK_INT >= 22;
    }

    public static boolean hasMarshmallow() {
        return Build.VERSION.SDK_INT >= 23;
    }

    /**
     * Get the size in bytes of a bitmap.
     *
     * @param bitmap
     * @return size in bytes
     */
    @TargetApi(12)
    public static int getBitmapSize(Bitmap bitmap) {
        if (Util.hasHoneycombMR1()) {
            return bitmap.getByteCount();
        }
        // Pre HC-MR1
        return bitmap.getRowBytes() * bitmap.getHeight();
    }

    /**
     * Constructs the version string of the application.
     *
     * @return the versions string of the application
     */
    public static String getVersionName() {
        // Get a version string for the app.
        try {
            PackageManager pm = AppContext.getContext().getPackageManager();
            PackageInfo pi = pm.getPackageInfo(ZebraApp.PACKAGE_NAME, 0);
            return pi.versionName;
        } catch (Exception e) {
            Log.e(TAG, "Could not retrieve package info", e);
        }
        return null;
    }

    //    /**
    //     * Check if OS version has built-in external cache dir method.
    //     *
    //     * @return
    //     */
    //    public static boolean hasExternalCacheDir() {
    //        return hasFroyo();
    //    }

    public static int sdkVersion() {
        return Build.VERSION.SDK_INT;
    }

    /**
     * Constructs the version string of the application.
     *
     * @return the versions code of the application
     */
    public static int getVersionCode() {
        try {
            PackageManager pm = AppContext.getContext().getPackageManager();
            PackageInfo pi = pm.getPackageInfo(ZebraApp.PACKAGE_NAME, 0);

            return pi.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(TAG, "Could not retrieve package info", e);
            return -1;
        }
    }

    //    private static final DecimalFormat dcmFmt = new DecimalFormat("0.000");

    public static String getFooterTimeString(long time) {
        Date date = new Date(time);
        java.text.DateFormat format = new java.text.SimpleDateFormat("yyyy.MM.dd",
                Locale.getDefault());
        return format.format(date);
    }

    /**
     * 判断邮箱是否合法
     */
    private static Pattern mMailAddressValidPattern = Pattern.compile(TAG_MAIL_REX);

    public static boolean isMailAddressValid(String data) {
        Matcher matcher = mMailAddressValidPattern.matcher(data);
        return matcher.matches();
    }

    /**
     * 判断手机是否合法，弱验证11位数字
     */
    private static Pattern mMobileValidPattern = Pattern.compile("^\\d{11}$");

    public static boolean isMobileValid(String data) {
        Matcher matcher = mMobileValidPattern.matcher(data);
        return matcher.matches();
    }

    /**
     * 判断手机是否合法，严格验证11位数字
     */
    private static Pattern mMobileStrictValidPattern = Pattern
            .compile("^((13[0-9])|(15[0-9])|(18[0-9]))\\d{8}$");

    public static boolean isMobileStrictValid(String data) {
        Matcher matcher = mMobileStrictValidPattern.matcher(data);
        return matcher.matches();
    }

    /**
     * 密码验证，仅数字或字母，6-20位
     */
    private static Pattern mPasswordValidPattern = Pattern.compile("^[0-9a-zA-Z]{6,20}$");

    public static boolean isPasswordValid(String data) {
        Matcher matcher = mPasswordValidPattern.matcher(data);
        return matcher.matches();
    }

    /**
     * 获取经纬度
     *
     * @param context
     * @return
     */
    public static double[] getLatitudeAndLongitude(Context context) {
        double[] latLong = null;

        //使用标准集合，让系统自动选择可用的最佳位置提供器，提供位置
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);//高精度
        criteria.setAltitudeRequired(false);//不要求海拔
        criteria.setBearingRequired(false);//不要求方位
        criteria.setCostAllowed(true);//允许有花费
        criteria.setPowerRequirement(Criteria.POWER_HIGH);//低功耗
        LocationManager loctionManager = (LocationManager) context
                .getSystemService(Context.LOCATION_SERVICE);
        //从可用的位置提供器中，匹配以上标准的最佳提供器
        String provider = loctionManager.getBestProvider(criteria, true);
        if (TextUtils.isEmpty(provider)) {
            provider = LocationManager.GPS_PROVIDER;
        }
        //获得最后一次变化的位置
        Location location = loctionManager.getLastKnownLocation(provider);
        if (location != null) {
            latLong = new double[2];
            latLong[0] = location.getLatitude();
            latLong[1] = location.getLongitude();
        } else {
            Log.d(TAG, "can't find Location info");
        }
        return latLong;
    }

    /**
     * 检测packageName是否已经安装
     *
     * @param packageName
     * @return
     */
    public static boolean checkInstalled(Context context, String packageName) {
        try {
            context.getPackageManager().getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            //            e.printStackTrace();
            return false;
        }
    }

    public static String getCoAudioTimeStr(long position) {
        return (position > 9 ? "" : "0") + position + "/90";
    }

    public static String formatTime(long time) {

        int resId = R.plurals.x_seconds_ago;
        int quantity = 0;

        int now = (int) (System.currentTimeMillis() / 1000);
        int timeInterval = (int) (now - time / 1000);

        if (timeInterval <= 0) {
            quantity = 1;
            resId = R.plurals.x_seconds_ago;
        } else if (timeInterval <= 60) {
            quantity = timeInterval;
            resId = R.plurals.x_seconds_ago;
        } else if ((timeInterval > 60) && (timeInterval <= 60 * 60)) {
            resId = R.plurals.x_minutes_ago;
            quantity = (timeInterval / 60);
        } else if ((timeInterval > 60 * 60) && (timeInterval <= 60 * 60 * 24)) {
            resId = R.plurals.x_hours_ago;
            quantity = (timeInterval / (60 * 60));
        } else if ((timeInterval > 60 * 60 * 24) && (timeInterval <= 60 * 60 * 24 * 30)) {
            resId = R.plurals.x_days_ago;
            quantity = (timeInterval / (60 * 60 * 24));
        } else if ((timeInterval > 60 * 60 * 24 * 30) && (timeInterval <= 60 * 60 * 24 * 365)) {
            resId = R.plurals.x_months_ago;
            quantity = (timeInterval / (60 * 60 * 24 * 30));
        } else if (timeInterval > 60 * 60 * 24 * 365) {
            resId = R.plurals.x_years_ago;
            quantity = (timeInterval / (60 * 60 * 24 * 365));
        }

        return AppContext.getQuantityString(resId, quantity, quantity);
    }

    public static long millisToSeconds(long millis) {
        return millis > 0 ? (Math.round((millis) / 1000f)) : 0;
    }

    public static long millisToSecondsFloor(long millis) {
        return millis > 0 ? (long) (Math.floor((millis) / 1000f)) : 0;
    }

    @TargetApi(11)
    public static void enableStrictMode() {
        if (Util.hasGingerbread()) {
            StrictMode.ThreadPolicy.Builder threadPolicyBuilder = new StrictMode.ThreadPolicy.Builder()
                    .detectAll().penaltyLog();
            StrictMode.VmPolicy.Builder vmPolicyBuilder = new StrictMode.VmPolicy.Builder()
                    .detectAll().penaltyLog();
            StrictMode.setThreadPolicy(threadPolicyBuilder.build());
            StrictMode.setVmPolicy(vmPolicyBuilder.build());
        }
    }

    /**
     * 将字符串数组转化为 逗号分割的字符串
     */
    public static String stringArray2StringWithComma(List<String> array) {

        if (CollectionUtil.isEmpty(array)) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < array.size(); i++) {
            sb.append(array.get(i));
            if (i != array.size() - 1) {
                sb.append(",");
            }
        }
        return sb.toString();
    }

    /**
     * 将字符串集合转化为 逗号分割的字符串
     */
    public static String stringSet2StringWithComma(HashSet<String> set) {

        if (CollectionUtil.isEmpty(set)) {
            return "";
        }

        StringBuilder sb = new StringBuilder();

        int size = set.size();
        int i = 0;
        for (String string : set) {
            sb.append(string);
            if (i != size - 1) {
                sb.append(",");
            }
            i++;
        }

        return sb.toString();
    }

    /**
     * 将字符串map转化为 逗号分割的字符串
     */
    public static String stringMap2StringWithComma(HashMap<String, String> map) {

        if (CollectionUtil.isEmpty(map)) {
            return "";
        }

        StringBuilder sb = new StringBuilder();

        int size = map.size();
        int i = 0;

        for (String string : map.keySet()) {
            sb.append(string);
            if (i != size - 1) {
                sb.append(",");
            }
            i++;
        }

        return sb.toString();
    }

    /**
     * 压缩文件，生成在File目录下的文件
     *
     * @param data
     * @param fileName
     */

    public static boolean doGzip(String data, String fileName) {
        boolean result = false;

        ByteArrayInputStream inputStream = null;
        BufferedReader in = null;
        BufferedOutputStream out = null;

        try {
            inputStream = new ByteArrayInputStream(data.getBytes());
            in = new BufferedReader(new InputStreamReader(inputStream));
            out = new BufferedOutputStream(new GZIPOutputStream(AppContext.getContext()
                    .openFileOutput(fileName, Context.MODE_PRIVATE)));
            int c;
            while ((c = in.read()) != -1) {
                out.write(String.valueOf((char) c).getBytes());
            }
        } catch (Exception e) {
            result = true;
            e.printStackTrace();
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }

                if (inputStream != null) {
                    inputStream.close();
                }

                if (in != null) {

                    in.close();
                }

                if (out != null) {
                    out.close();
                }

            } catch (IOException e) {
                result = true;
                e.printStackTrace();
            }
        }

        return result;
    }

    public static String stringToMD5(String data) {

        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(data.getBytes());
            byte b[] = md.digest();
            int i;
            StringBuffer buf = new StringBuffer("");
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0) i += 256;
                if (i < 16) buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            return buf.toString();

        } catch (NoSuchAlgorithmException e) {

            e.printStackTrace();
        }

        return null;

    }

    //
    public static String getErrorInfoFromException(Exception e) {
        try {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            return sw.toString();
        } catch (Exception e2) {
            return "bad getErrorInfoFromException";
        }
    }

    public static String getExceptionInfo(Throwable ex) {
        Writer writer = new StringWriter();
        PrintWriter pw = new PrintWriter(writer);
        ex.printStackTrace(pw);
        pw.close();
        String error = writer.toString();
        return error;
    }

    /**
     * 代替 imageView的setImageURI
     */
    public static boolean setImageURI(ImageView imageView, Uri uri) {
        InputStream is = null;
        try {
            if (uri != null) {
                is = AppContext.getContext().getContentResolver().openInputStream(uri);
                Drawable d = Drawable.createFromStream(is, null);
                imageView.setImageDrawable(d);
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Unable to set ImageView from URI: " + e.toString());
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return false;
    }

    public static Bitmap getBitmapFromUri(Uri uri) {
        Bitmap d = null;
        String scheme = uri.getScheme();

        if (ContentResolver.SCHEME_CONTENT.equals(scheme)
                || ContentResolver.SCHEME_FILE.equals(scheme)) {
            InputStream stream = null;
            try {
                stream = AppContext.getContext().getContentResolver().openInputStream(uri);
                //                d = Drawable.createFromStream(stream, null);
                d = BitmapFactory.decodeStream(stream);
            } catch (Exception e) {
                e.printStackTrace();
                //                Log.w("ImageView", "Unable to open content: " + uri, e);
            } finally {
                FileUtil.closeSilently(stream);
            }
        }
        return d;
    }

    /**
     * 是否支持EL2.0 ,如果不支持则不能使用滤镜
     *
     * @return
     */
    public static boolean supportsOpenGLES2() {
        ActivityManager activityManager = (ActivityManager) AppContext.getContext()
                .getSystemService(Context.ACTIVITY_SERVICE);
        ConfigurationInfo configurationInfo = activityManager.getDeviceConfigurationInfo();
        return configurationInfo.reqGlEsVersion >= 0x20000;
    }

    /**
     * 检查是否支持GL2.0，如果不支持就GLSurfaceView 不能进行任何操作
     *
     * @return
     */
    public static boolean checkGL20Support() {
        EGL10 egl = (EGL10) EGLContext.getEGL();
        EGLDisplay display = egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);

        int[] version = new int[2];
        egl.eglInitialize(display, version);

        int EGL_OPENGL_ES2_BIT = 4;
        int[] configAttribs = {EGL10.EGL_RED_SIZE, 4, EGL10.EGL_GREEN_SIZE, 4,
                EGL10.EGL_BLUE_SIZE, 4, EGL10.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
                EGL10.EGL_NONE};

        EGLConfig[] configs = new EGLConfig[10];
        int[] num_config = new int[1];
        egl.eglChooseConfig(display, configAttribs, configs, 10, num_config);
        egl.eglTerminate(display);
        return num_config[0] > 0;
    }

    public static String convertToPabiStr(long pabiPrice) {
        if (pabiPrice % 100 == 0) {
            return ((int) pabiPrice / 100) + "";
        } else {
            DecimalFormat df = new DecimalFormat();
            df.setMinimumFractionDigits(2);
            df.setMaximumFractionDigits(2);
            return df.format(pabiPrice / 100d);
        }
    }

    private static String getAuthorityFromPermission(Context context, String permission) {

        if (permission == null) return null;

        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);

        PackageInfo packageInfo = null;
        try {
            ResolveInfo resolveInfo = context.getPackageManager().resolveActivity(intent,
                    PackageManager.MATCH_DEFAULT_ONLY);
            String currentHomePackageName = resolveInfo.activityInfo.packageName;
            packageInfo = context.getPackageManager().getPackageInfo(currentHomePackageName,
                    PackageManager.GET_PROVIDERS);

            ProviderInfo[] providers = packageInfo.providers;
            if (providers != null) {
                for (ProviderInfo provider : providers) {
                    if (permission.equals(provider.readPermission)) return provider.authority;
                    if (permission.equals(provider.writePermission)) return provider.authority;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public static boolean hasShortCut(Context context) {
        boolean hasShortCut = false;

        String authority = Util.getAuthorityFromPermission(context,
                "com.android.launcher.permission.READ_SETTINGS");

        if (TextUtils.isEmpty(authority) && hasKitkat()) {
            authority = Util.getAuthorityFromPermission(context,
                    "com.android.launcher3.permission.READ_SETTINGS");
        }

        if (TextUtils.isEmpty(authority)) {
            return hasShortCut;
        }

        Cursor cursor = null;
        try {
            String uri = "content://" + authority + "/favorites?notify=true";
            ContentResolver resolver = context.getContentResolver();
            cursor = resolver.query(Uri.parse(uri), null, "title=?",
                    new String[]{context.getString(R.string.app_name)}, null);
            if (cursor != null && cursor.getCount() > 0) {
                hasShortCut = true;
            }
        } catch (Exception e) {

        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        return hasShortCut;
    }

    public static Map<String, String> parseUriQuery(String query) {

        if (TextUtils.isEmpty(query)) {
            return null;
        }

        Map<String, String> map = new HashMap<String, String>();
        String[] pvs = query.split("&");
        if (pvs.length > 0) {
            for (String pv : pvs) {
                int spe = pv.indexOf('=');
                if (spe < 0) {
                    continue;
                }
                if (spe > 0 && spe + 1 < pv.length()) {
                    map.put(Uri.decode(pv.substring(0, spe)), Uri.decode(pv.substring(spe + 1)));
                }
            }
        }

        return map;
    }

    public static String atInfoToJson(LinkedHashMap<String, String> atMap) {

        String atJson = "";

        Object[] ats = atMap.keySet().toArray();

        ObjectMapper objectMapper = new ObjectMapper();
        try {
            atJson = objectMapper.writeValueAsString(ats);
        } catch (JsonGenerationException e) {
            e.printStackTrace();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return atJson;
    }
}
