package com.ddlad.student.protocol.http.callbacks;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;

public abstract class AbstractStreamingCallbacks<T> extends AbstractCallbacks<T> {

    @Override
    public void onRequestFinished() {
    }

    @Override
    public void onRequestStart() {
    }

    @Override
    protected abstract void onSuccess(T t);
}
