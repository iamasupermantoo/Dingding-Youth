package com.ddlad.student.ui.attendclass.evaluate;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.request.EvaluateDetailsRequest;
import com.ddlad.student.protocol.http.request.EvaluateSubmitRequest;
import com.ddlad.student.protocol.model.EvaluateDetailsInfo;
import com.ddlad.student.protocol.model.MetaInfo;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.image.CircleImageView;

/**
 * Created by Administrator on 2017/3/17 0017.
 */
public class EvaluateAlreadyDetailsFragment extends BaseFragment {


    private boolean mselect = true;

    private EvaluateDetailsInfo mInfo;

    //date+time
    private TextView mCourseTime;

    private TextView mCourseName;
    private TextView mCourseAddress;
    private TextView mStudentName;
    private TextView mTeacherName;
    private TextView mEvaluateTeacherText;
    private RadioGroup mQualityRG;
    private RadioGroup mAcceptanceRG;
    private com.ddlad.student.ui.widget.RattingBar.RatingBar mStar;
    private TextView mRemark;
    private CircleImageView mTeacherHeadImage;
    private TextView mRadio1;
    private TextView mRadio2;
    private TextView mRadio3;
    private TextView mRadio4;
    private TextView mRadioAcceptance1;
    private TextView mRadioAcceptance2;
    private TextView mRadioAcceptance3;
    private TextView mRadioAcceptance4;

    private Button mSubmit;


    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_already_evaluate_details;
    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle("评价详情");
        mCourseTime = (TextView) contentView.findViewById(R.id.evaluate_attend_class_time);
        mCourseAddress = (TextView) contentView.findViewById(R.id.evaluate_course_address);
        mCourseName = (TextView) contentView.findViewById(R.id.evaluate_course_name);
        mStudentName = (TextView) contentView.findViewById(R.id.evaluate_student_name);
        mTeacherName = (TextView) contentView.findViewById(R.id.evaluate_teacher_name);
        mEvaluateTeacherText = (TextView) contentView.findViewById(R.id.evaluate_teacher_set_text);
        mQualityRG = (RadioGroup) contentView.findViewById(R.id.evaluate_quality_rg);
        mAcceptanceRG = (RadioGroup) contentView.findViewById(R.id.evaluate_acceptance_rg);
        mStar = (com.ddlad.student.ui.widget.RattingBar.RatingBar) contentView.findViewById(R.id.evaluate_rating_bar);
        mRemark = (TextView) contentView.findViewById(R.id.evaluate_remark);
        mTeacherHeadImage = (CircleImageView) contentView.findViewById(R.id.evaluate_teacher_head_image);

        mRadio1 = (TextView) contentView.findViewById(R.id.quality_1);
        mRadio2 = (TextView) contentView.findViewById(R.id.quality_2);
        mRadio3 = (TextView) contentView.findViewById(R.id.quality_3);
        mRadio4 = (TextView) contentView.findViewById(R.id.quality_4);

        mRadioAcceptance1 = (TextView) contentView.findViewById(R.id.acceptance_1);
        mRadioAcceptance2 = (TextView) contentView.findViewById(R.id.acceptance_2);
        mRadioAcceptance3 = (TextView) contentView.findViewById(R.id.acceptance_3);
        mRadioAcceptance4 = (TextView) contentView.findViewById(R.id.acceptance_4);

        mStar.setClickable(false);
        mSubmit = (Button) contentView.findViewById(R.id.evaluate_submit);
//        mSubmit.setOnClickListener(this);
    }

    @Override
    protected void onInitData(Bundle bundle) {
        super.onInitData(bundle);
        requestData();
    }

    @Override
    public void onResume() {

        super.onResume();


    }

    private void requestData() {
        startLoading();
        String lid = (String) getArguments().get("lid");
        String cid = (String) getArguments().get("cid");
        EvaluateDetailsRequest request = new EvaluateDetailsRequest(this, getDefaultLoaderId(), new AbstractCallbacks<EvaluateDetailsInfo>() {
            @Override
            protected void onSuccess(EvaluateDetailsInfo evaluateListInfo) {

                mInfo = evaluateListInfo;
                Log.i(TAG, "onSuccess: 评论详情页面数据请求成功oooooooooooooooooooooo");
                stopLoading();
                refreshData();
            }

            @Override
            protected void onFail(ApiResponse<EvaluateDetailsInfo> response) {

                Log.i(TAG, "onFail: 请求失败^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                stopLoading();
            }
        });
        request.perform(cid,lid);
    }

    private void refreshData() {
        if (mInfo != null) {
//            mActionbar.setTitle(mInfo.getReaction().getTeacher());
            mCourseTime.setText(mInfo.getReaction().getDate() + "  " + mInfo.getReaction().getTime());
//            mCourseAddress 设置地址
            mCourseName.setText(mInfo.getReaction().getCourse());
            mTeacherName.setText(mInfo.getReaction().getTeacher());
            /////////////////学生姓名暂时用的老师姓名////////////////////////////////////////////////////
            mStudentName.setText(mInfo.getReaction().getTeacher());
            mRemark.setText(mInfo.getReaction().getRemark());
            /////////////////////100分返回字段没有////////////////////////////////////////////////////////
            int fen = mInfo.getReaction().getStar()*20;
            mEvaluateTeacherText.setText(mInfo.getReaction().getTeacher()+"老师获得"+fen+"分");
//            String url =  mInfo.getReaction().getTeacherHeadImg().getPattern();
//            mTeacherHeadImage.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}w")));
            String url =  mInfo.getReaction().getTeacherHeadImg().getImageSmall();
            mTeacherHeadImage.setUrl(url);
            mStar.setStar(mInfo.getReaction().getStar());
            switch (mInfo.getReaction().getQuality()){
                case 1:
                    mRadio4.setVisibility(View.VISIBLE);
                    break;
                case 2:
                    mRadio3.setVisibility(View.VISIBLE);
                    break;
                case 3:
                    mRadio2.setVisibility(View.VISIBLE);
                    break;
                case 4:
                    mRadio1.setVisibility(View.VISIBLE);
                    break;
            }
            switch (mInfo.getReaction().getAcceptance()){
                case 1:
                    mRadioAcceptance4.setVisibility(View.VISIBLE);
                    break;
                case 2:
                    mRadioAcceptance3.setVisibility(View.VISIBLE);
                    break;
                case 3:
                    mRadioAcceptance2.setVisibility(View.VISIBLE);
                    break;
                case 4:
                    mRadioAcceptance1.setVisibility(View.VISIBLE);
                    break;
            }
        }
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.evaluate_submit:
                //提交数据
                EvaluateSubmitRequest submitRequest = new EvaluateSubmitRequest(this, getDefaultLoaderId(), new AbstractCallbacks<MetaInfo>() {
                    @Override
                    protected void onSuccess(MetaInfo info) {
                        Log.i(TAG, "onSuccess: 评价提交成功");
                    }

                    @Override
                    protected void onFail(ApiResponse<MetaInfo> response) {
                        Log.i(TAG, "onFail: 评价提交失败！！！！");
                    }
                });
                break;
            case R.id.titleInterlocution:

                break;

        }
    }


}
