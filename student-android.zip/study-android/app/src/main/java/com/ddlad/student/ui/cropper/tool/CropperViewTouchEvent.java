package com.ddlad.student.ui.cropper.tool;

public interface CropperViewTouchEvent {

    public void onTouchEventDown();

    public void onTouchEventUp();
}
