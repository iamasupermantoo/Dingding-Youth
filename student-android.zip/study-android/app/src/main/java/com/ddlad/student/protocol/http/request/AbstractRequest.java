package com.ddlad.student.protocol.http.request;


import android.content.Context;
import android.support.v4.app.LoaderManager;

import com.ddlad.student.primary.AppContext;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.callbacks.ApiRequestLoaderCallbacks;
import com.ddlad.student.protocol.http.callbacks.BaseApiLoaderCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ApiUrlHelper;
import com.ddlad.student.protocol.http.internal.RequestParams;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;


public abstract class AbstractRequest<T> {

    public static boolean domainChange = false;

    protected final AbstractCallbacks<T> mApiCallbacks;

    protected Context mContext;

    private final int mLoaderId;

    private final LoaderManager mLoaderManager;

    private RequestParams mParams;

    protected HttpUriRequest mRequest;

    public AbstractRequest(LoaderManager loaderManager, int loaderId,
                           AbstractCallbacks<T> apiCallbacks) {

        mContext = AppContext.getContext();
        mLoaderManager = loaderManager;
        mLoaderId = loaderId;
        mApiCallbacks = apiCallbacks;
        register();
    }

    protected abstract HttpUriRequest buildRequest(ApiHttpClient httpClient, String url,
                                                   RequestParams requestParam);

    protected ApiRequestLoaderCallbacks<T> constructLoaderCallbacks() {
        return new ApiRequestLoaderCallbacks<T>(mContext, this, mApiCallbacks);
    }

    public Context getContext() {
        return mContext;
    }

    public int getLoaderId() {
        return mLoaderId;
    }

    public LoaderManager getLoaderManager() {
        return mLoaderManager;
    }

    protected RequestParams getParams() {
        if (mParams == null) {
            mParams = new RequestParams();
        }
        return mParams;
    }

    protected RequestParams getMultipartParams() {
        if (mParams == null) {
            mParams = new RequestParams();
            mParams = new RequestParams(true);
        } else if (!mParams.isMultipart()) {
            mParams.setMultipart(true);
        }
        return mParams;
    }

    protected abstract String getPath();

    public HttpUriRequest getRequest() {
        if (mRequest == null) {
            mRequest = buildRequest(ApiHttpClient.getInstance(),
                    ApiUrlHelper.expandPath(getPath(), isSecure(), isExpandApiVersionPath()),
                    getParams());
        }
        if (domainChange){
            mRequest = buildRequest(ApiHttpClient.getInstance(),
                    ApiUrlHelper.expandPath(getPath(), isSecure(), isExpandApiVersionPath()),
                    getParams());
            domainChange = false;
        }

        return mRequest;
    }




    public void handleErrorInBackground(ApiResponse<T> apiResponse) {
    }

    protected boolean isSecure() {
        return Boolean.FALSE;
    }

    protected boolean isExpandApiVersionPath() {
        return Boolean.TRUE;
    }

    public void perform() {
        mRequest = null;
        mLoaderManager.restartLoader(mLoaderId, null, constructLoaderCallbacks());
    }

    public void preProcessInBackground() throws PreProcessException {

    }

    public abstract T processInBackground(ApiResponse<T> response);

    protected void register() {
        mLoaderManager.initLoader(mLoaderId, null, new BaseApiLoaderCallbacks<T>(mApiCallbacks,
                mContext, this));
    }

    public boolean shouldShowAlertForRequest(ApiResponse<T> apiResponse) {
        return Boolean.FALSE;
    }

    public static class PreProcessException extends Exception {

        /**
         *
         */
        private static final long serialVersionUID = 7931249828735794298L;
    }
}
