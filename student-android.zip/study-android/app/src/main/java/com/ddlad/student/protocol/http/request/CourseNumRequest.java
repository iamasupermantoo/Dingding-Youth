package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.model.CourseNumInfo;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-8-11.
 */
public class CourseNumRequest extends AbstractRequest<CourseNumInfo> {
    public CourseNumRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<CourseNumInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.getRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_CURRICULUM_LIST;
    }

    @Override
    public CourseNumInfo processInBackground(ApiResponse<CourseNumInfo> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, CourseNumInfo.class);
    }


}
