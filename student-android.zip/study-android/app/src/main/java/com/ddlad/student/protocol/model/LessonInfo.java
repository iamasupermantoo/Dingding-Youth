package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.IOException;

/**
 * Created by Administrator on 2017/1/17 0017.
 */

public class LessonInfo extends BaseInfo {

//    "lid":"LN003"
//    "cid":"CE002",
//    "label":"高级装逼技巧",
//    "status":0,
//    "date":"2017-01-19",
//    "time":"19:00 - 20:00"

    private String lid;
    private String cid;
    private String label;
    private int status;
    private String date;
    private String time;
    private String videoUrl;
    private int studentReactionStatus;
    private int teacherReactionStatus;
    private int homeworkStatus;

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public int getStudentReactionStatus() {
        return studentReactionStatus;
    }

    public void setStudentReactionStatus(int studentReactionStatus) {
        this.studentReactionStatus = studentReactionStatus;
    }

    public int getTeacherReactionStatus() {
        return teacherReactionStatus;
    }

    public void setTeacherReactionStatus(int teacherReactionStatus) {
        this.teacherReactionStatus = teacherReactionStatus;
    }

    public int getHomeworkStatus() {
        return homeworkStatus;
    }

    public void setHomeworkStatus(int homeworkStatus) {
        this.homeworkStatus = homeworkStatus;
    }

    public String getLid() {
        return lid;
    }

    public void setLid(String lid) {
        this.lid = lid;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public static LessonInfo fromJsonParser(JsonParser jsonParser) throws IOException {
        LessonInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new LessonInfo();
                }

                if ("lid".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.lid = jsonParser.getText();

                    continue;
                }

                if ("cid".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.cid = jsonParser.getText();
                    continue;
                }
                if ("label".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.label = jsonParser.getText();
                    continue;
                }

                if ("status".equals(fieldName)){
                    jsonParser.nextToken();
                    info.status = jsonParser.getIntValue();
                    continue;
                }

                if ("date".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.date = jsonParser.getText();
                    continue;
                }

                if ("time".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.time = jsonParser.getText();
                    continue;
                }
                if ("videoUrl".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.videoUrl = jsonParser.getText();
                    continue;
                }
                if ("studentReactionStatus".equals(fieldName)){
                    jsonParser.nextToken();
                    info.studentReactionStatus = jsonParser.getIntValue();
                    continue;
                }
                if ("teacherReactionStatus".equals(fieldName)){
                    jsonParser.nextToken();
                    info.teacherReactionStatus = jsonParser.getIntValue();
                    continue;
                }
                if ("homeworkStatus".equals(fieldName)){
                    jsonParser.nextToken();
                    info.homeworkStatus = jsonParser.getIntValue();
                    continue;
                }
                jsonParser.skipChildren();


            }
        }
        return info;
    }

    public enum LessonType {

        NoLesson(0), AlreadyLesson(1);

        private LessonType(int value) {
            this.mValue = value;
        }

        private int mValue;

        public int getValue() {
            return mValue;
        }
    }


}
