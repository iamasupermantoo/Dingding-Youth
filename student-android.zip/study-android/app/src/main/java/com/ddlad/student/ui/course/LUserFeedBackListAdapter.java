package com.ddlad.student.ui.course;

import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.protocol.model.HomeworkInfo;
import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.common.BaseFragment;

import java.util.List;

/**
 * Created by Albert
 * on 16-10-20.
 */
public class LUserFeedBackListAdapter extends AbstractAdapter<HomeworkInfo> {

    public LUserFeedBackListAdapter(BaseFragment fragment) {
        super(fragment);
    }


    //////////////////////////////////////////////////////正式需修改
    @Override
    public HomeworkInfo getItem(int position) {
        return mList.get(position);
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public int getItemViewType(int position) {
        return getItem(position).getType();
    }

    @Override
    protected View createView(int position, ViewGroup parent) {
        return UserFeedBackListItemAdapter.createView(parent);
    }

    @Override
    protected void bindView(int position, View view) {
        HomeworkInfo feed = getItem(position);
        UserFeedBackListItemAdapter.bindView(view, feed, mFragment);
    }

    @Override
    public void clearItem() {
        mList.clear();
    }

    @Override
    public void addItem(HomeworkInfo info) {
        mList.add(info);
    }

    @Override
    public void addItem(List<HomeworkInfo> list) {
        if (!CollectionUtil.isEmpty(list)) {
            mList.addAll(list);
        }
    }

    //////////////////////////////////////////////////////正式需修改
    @Override
    public int getCount() {
//        return 10;
        return mList.size();
    }

//    public enum ProfileViewType {
//
//        Article(0), Image(1);
//
//        private ProfileViewType(int value) {
//            this.mValue = value;
//        }
//
//        private int mValue;
//
//        public int getValue() {
//            return mValue;
//        }
//    }

}

