package com.ddlad.student.push;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.text.TextUtils;

import com.ddlad.student.push.PushClient;
import com.ddlad.student.push.PushClientGetui;
import com.igexin.sdk.PushConsts;
import com.ddlad.student.primary.Prefs;
import com.ddlad.student.push.service.Push;
import com.ddlad.student.tools.StringUtil;


public class PushReceiverGetui extends WakefulBroadcastReceiver {

    private static final String TAG = "PushReceiverGetui";

    private static final String CLIENT_ID = "clientid";

    private static final String PAYLOAD = "payload";

    @Override
    public void onReceive(Context context, Intent intent) {

        Bundle bundle = intent.getExtras();
        if (bundle == null) {
            return;
        }
        switch (bundle.getInt(PushConsts.CMD_ACTION)) {

            case PushConsts.GET_MSG_DATA:
                byte[] payload = bundle.getByteArray(PAYLOAD);
                if (payload != null) {
                    String message = new String(payload);
                    Push.getInstance().showPush(message);
                }
                break;
            case PushConsts.GET_CLIENTID:
                String cid = bundle.getString(CLIENT_ID);
                if (StringUtil.equals(Prefs.getInstance().getGetuiPushCid(), cid)) {
                    return;
                }
                Prefs.getInstance().saveGetuiPushCid(cid);
                if (!TextUtils.isEmpty(cid)) {
                    PushClient pushInterface = new PushClientGetui();
                    pushInterface.bindPush();
                }
                break;
        }
    }
}
