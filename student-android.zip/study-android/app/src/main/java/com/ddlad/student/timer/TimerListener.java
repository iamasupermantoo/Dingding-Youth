package com.ddlad.student.timer;

/**
 * Created by Albert
 * on 16-10-18.
 */
public interface TimerListener {
    public void onSchedule(long value, boolean active);
}
