package com.ddlad.student.ui.attendclass.schedule;

import java.util.List;

/**
 * @param
 * @author ldm
 * @description 录音实体类
 * @time 2016/6/25 11:04
 */
public class Recorder {
    float time;//时间长度
    String filePath;//文件路径
    private String imagePath;
    private String content;
    private int type;
    private List<String> photoImage;

    public Recorder(float time, String filePath, String imagePath, String content, int type, List<String> photoImage) {
        this.time = time;
        this.filePath = filePath;
        this.imagePath = imagePath;
        this.content = content;
        this.type = type;
        this.photoImage = photoImage;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }



    public List<String> getPhotoImage() {
        return photoImage;
    }

    public void setPhotoImage(List<String> photoImage) {
        this.photoImage = photoImage;
    }



    public Recorder(float time, String filePath) {
        super();
        this.time = time;
        this.filePath = filePath;
    }

    public float getTime() {
        return time;
    }

    public void setTime(float time) {
        this.time = time;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

}