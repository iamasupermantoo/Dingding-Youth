package com.ddlad.student.ui.attendclass;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.ddlad.student.R;
import com.ddlad.student.primary.Log;

import fm.jiecao.jcvideoplayer_lib.JCVideoPlayer;
import fm.jiecao.jcvideoplayer_lib.JCVideoPlayerStandard;


/**
 * Created by chen007 on 2017/6/26 0026.
 */
public class VideoPlayerActivityy extends AppCompatActivity {

    private JCVideoPlayerStandard jcVideoPlayerStandard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_vadio_play);
        Intent intent = getIntent();
        String url = intent.getStringExtra("url");
        Log.e("VideoPlayerActiv","url = "+url);
        jcVideoPlayerStandard = (JCVideoPlayerStandard) findViewById(R.id.video_player);
        JCVideoPlayerStandard.mBack = new JCVideoPlayerStandard.backInterface() {
            @Override
            public void back() {
                onBackPressed();
            }
        };
        jcVideoPlayerStandard.setUp(url
                , JCVideoPlayerStandard.SCREEN_WINDOW_FULLSCREEN, " ");
        jcVideoPlayerStandard.startButton.performClick();
//        JCVideoPlayerStandard.startFullscreen(this, JCVideoPlayerStandard.class, url, "TITLE");
//        jcVideoPlayerStandard.thumbImageView.setImage("http://p.qpic.cn/videoyun/0/2449_43b6f696980311e59ed467f22794e792_1/640");
    }

    @Override
    public void onBackPressed() {
        if (JCVideoPlayer.backPress()) {
            return;
        }
        super.onBackPressed();
    }


    @Override
    protected void onPause() {
        super.onPause();
        JCVideoPlayer.releaseAllVideos();
    }
}
