package com.ddlad.student.protocol.http.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.TextUtils;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;

import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;
import com.ddlad.student.tools.StringUtil;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import ch.boye.httpclientandroidlib.client.CookieStore;
import ch.boye.httpclientandroidlib.cookie.Cookie;

public class PersistentCookieStore implements CookieStore {

    private static final String COOKIE_NAME_PREFIX = "cookie_";

    private static final String COOKIE_NAME_STORE = "names";

    private static final String COOKIE_PREFS = "CookiePrefsFile";

    public static final String COOKIE_STORE_SERVICE = "com.udan.http.internal.PersistentCookieStore";

    private final SharedPreferences mCookiePrefs;

    private final ConcurrentHashMap<String, Cookie> mCookies;

    public PersistentCookieStore(Context context) {
        this.mCookiePrefs = context.getSharedPreferences(COOKIE_PREFS, Context.MODE_PRIVATE);
        this.mCookies = new ConcurrentHashMap<String, Cookie>();

        CookieSyncManager.createInstance(context);

        String names = this.mCookiePrefs.getString(COOKIE_NAME_STORE, null);

        if (names != null) {
            for (String name : TextUtils.split(names, ",")) {
                String value = this.mCookiePrefs.getString(COOKIE_NAME_PREFIX + name, null);
                if (value != null) {
                    Cookie cookie = decodeCookie(value);
                    if (cookie != null) {

                        this.mCookies.put(name, cookie);
                    }
                }
            }
            clearExpired(new Date());
        }
    }

    public static PersistentCookieStore getInstance() {
        PersistentCookieStore persistentCookieStore = (PersistentCookieStore) AppContext
                .getContext().getSystemService(COOKIE_STORE_SERVICE);

        if (persistentCookieStore == null) {
            throw new IllegalStateException("PersistentCookieStore not available");
        }

        return persistentCookieStore;
    }

    @Override
    public List<Cookie> getCookies() {
        return new ArrayList<Cookie>(this.mCookies.values());
    }

    @Override
    public void addCookie(Cookie cookie) {
        String cookieName = cookie.getName();
        this.mCookies.put(cookieName, cookie);

        Editor editor = this.mCookiePrefs.edit();
        editor.putString(COOKIE_NAME_STORE, TextUtils.join(",", this.mCookies.keySet()));
        editor.putString(COOKIE_NAME_PREFIX + cookieName, encodeCookie(new com.ddlad.student.protocol.http.internal.SerializableCookie(
                cookie)));
        editor.commit();

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setCookie(
                cookie.getDomain(),
                cookie.getName() + "=" + StringUtil.trim(cookie.getValue()) + "; domain="
                        + cookie.getDomain());
        CookieSyncManager.getInstance().sync();
    }

    @Override
    public void clear() {
        this.mCookies.clear();
        Editor editor = this.mCookiePrefs.edit();
        Iterator<String> iterator = this.mCookies.keySet().iterator();
        while (iterator.hasNext()) {
            editor.remove(COOKIE_NAME_PREFIX + iterator.next());
        }
        editor.remove(COOKIE_NAME_STORE);
        editor.commit();
        CookieManager.getInstance().removeAllCookie();
        CookieSyncManager.getInstance().sync();
    }

    @Override
    public boolean clearExpired(Date date) {
        boolean isClear = Boolean.FALSE;
        Editor editor = this.mCookiePrefs.edit();
        Iterator<Entry<String, Cookie>> iterator = this.mCookies.entrySet().iterator();
        while (iterator.hasNext()) {
            Entry<String, Cookie> entry = iterator.next();
            String cookieName = entry.getKey();

            Cookie cookie = entry.getValue();

            if (cookie.isExpired(date)) {

                this.mCookies.remove(cookieName);
                editor.remove(COOKIE_NAME_PREFIX + cookieName);
                isClear = Boolean.TRUE;
                CookieManager.getInstance().removeExpiredCookie();
            }
        }

        if (isClear) {
            editor.putString(COOKIE_NAME_STORE, TextUtils.join(",", this.mCookies.keySet()));
            CookieSyncManager.getInstance().sync();
        }

        editor.commit();
        CookieManager.getInstance().removeExpiredCookie();
        CookieSyncManager.getInstance().sync();

        return isClear;
    }

    protected Cookie decodeCookie(String value) {
        Cookie cookie = null;
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(
                hexStringToByteArray(value));
        try {
            cookie = ((com.ddlad.student.protocol.http.internal.SerializableCookie) new ObjectInputStream(byteArrayInputStream).readObject())
                    .getCookie();
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("PersistentCookieStore", "Error decoding cookie + " + value);
        }

        return cookie;
    }

    protected String encodeCookie(com.ddlad.student.protocol.http.internal.SerializableCookie serializableCookie) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            new ObjectOutputStream(byteArrayOutputStream).writeObject(serializableCookie);
            return byteArrayToHexString(byteArrayOutputStream.toByteArray());
        } catch (Exception e) {
            Log.e("PersistentCookieStore",
                    "Error encoding cookie + " + serializableCookie.toString());
        }

        return null;
    }

    protected byte[] hexStringToByteArray(String value) {
        int len = value.length();
        byte[] byteArray = new byte[len / 2];
        for (int j = 0; j < len; j += 2) {
            byteArray[(j / 2)] = (byte) ((Character.digit(value.charAt(j), 16) << 4) + Character
                    .digit(value.charAt(j + 1), 16));
        }
        return byteArray;
    }

    protected String byteArrayToHexString(byte[] bytes) {
        int len = bytes.length;
        StringBuilder stringBuilder = new StringBuilder(2 * len);

        for (int i = 0; i < len; i++) {
            int k = 0xFF & bytes[i];
            if (k < 16) {
                stringBuilder.append('0');
            }
            stringBuilder.append(Integer.toHexString(k));
        }

        return stringBuilder.toString().toUpperCase();
    }
}
