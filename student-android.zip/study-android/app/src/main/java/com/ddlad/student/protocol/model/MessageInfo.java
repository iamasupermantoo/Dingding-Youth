package com.ddlad.student.protocol.model;

/**
 * Created by chen007 on 2017/11/13 0013.
 */
public class MessageInfo extends BaseInfo {
    int type;
    int userType;
    String data;
    String fromName;

    public MessageInfo(){

    }

    public MessageInfo(int type,String fromName, String data){
        this.type = type;
        this.fromName = fromName;
        this.data = data;
    }

    public MessageInfo(int type,int userType, String fromName, String data){
        this.type = type;
        this.userType = userType;
        this.fromName = fromName;
        this.data = data;
    }

    public int getUserType() {
        return userType;
    }

    public void setUserType(int userType) {
        this.userType = userType;
    }

    @Override
    public int getType() {
        return type;
    }

    @Override
    public void setType(int type) {
        this.type = type;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getFromName() {
        return fromName;
    }

    public void setFromName(String fromName) {
        this.fromName = fromName;
    }
}
