package com.ddlad.student.protocol.model;

/**
 * Created by chen007 on 2017/6/23 0023.
 */
public class NewAccountSafeInfo extends BaseInfo {

    /**
     * QQ : {"type":"QQ","account":"笑","status":1}
     * WeiXin : {"type":"WeiXin","status":0}
     * Mobile : {"type":"Mobile","account":"15611510560","status":1}
     */

        /**
         * type : QQ
         * account : 笑
         * status : 1
         */

        private QQBean QQ;
        /**
         * type : WeiXin
         * status : 0
         */

        private QQBean WeiXin;
        /**
         * type : Mobile
         * account : 15611510560
         * status : 1
         */

        private QQBean Mobile;

        public QQBean getQQ() {
            return QQ;
        }

        public void setQQ(QQBean QQ) {
            this.QQ = QQ;
        }

        public QQBean getWeiXin() {
            return WeiXin;
        }

        public void setWeiXin(QQBean WeiXin) {
            this.WeiXin = WeiXin;
        }

        public QQBean getMobile() {
            return Mobile;
        }

        public void setMobile(QQBean Mobile) {
            this.Mobile = Mobile;
        }

        public static class QQBean {
            private String type;
            private String account;
            private int status;

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getAccount() {
                return account;
            }

            public void setAccount(String account) {
                this.account = account;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }
        }

}
