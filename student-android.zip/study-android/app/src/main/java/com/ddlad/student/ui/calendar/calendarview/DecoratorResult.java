package com.ddlad.student.ui.calendar.calendarview;


import com.ddlad.student.ui.calendar.decorator.DayViewDecorator;

class DecoratorResult {
    public final DayViewDecorator decorator;
    public final DayViewFacade result;

    DecoratorResult(DayViewDecorator decorator, DayViewFacade result) {
        this.decorator = decorator;
        this.result = result;
    }
}
