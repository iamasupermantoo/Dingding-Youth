package com.ddlad.student.protocol.http.request;

/**
 * Created by Albert
 * on 16-6-2.
 */
public enum ApiResponseStatus {

    ApiResponseStatusLoading(0), ApiResponseStatusOk(1), ApiResponseStatusObjectNotFound(2), ApiResponseStatusError(
            3);

    private int value;

    private ApiResponseStatus(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
