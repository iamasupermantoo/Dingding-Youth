package com.ddlad.student.ui.attendclass.evaluate;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.model.LCorrectNotInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.image.NetworkImageView;

public class EvaluateNotListItemAdapter {


    public static View createView(ViewGroup viewGroup) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.evaluate_item_layout,
                null);

        ViewHolder holder = new ViewHolder(view);

        view.setTag(holder);

        return view;
    }

    public static void bindView(View view, final LCorrectNotInfo mInfo, final BaseFragment fragment) {

        if (mInfo == null) {
            return;
        }

        ViewHolder viewHolder = (ViewHolder) view.getTag();

        if (viewHolder == null) {
            return;
        }
        viewHolder.mCourse.setText( mInfo.getCourse());
        viewHolder.mTeacher.setText(mInfo.getTeacher());
        viewHolder.mTime.setText(mInfo.getTime());
        viewHolder.mClassTime.setText(mInfo.getDate());
        String url =  mInfo.getImage().getPattern();
        viewHolder.mImage.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}")));
        viewHolder.mEvaluate.setText("去评价");
//        if (mInfo.getStatus() == 0){
//            viewHolder.mLayoutItme.setVisibility(View.VISIBLE);
//        }else {
//            viewHolder.mLayoutItme.setVisibility(View.GONE);
//        }

        viewHolder.mEvaluate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mHid = mInfo.getHid();
                EvaluateDetailsFragment correctNotDetailsFragment = new EvaluateDetailsFragment();
                Bundle bundle = new Bundle();
                bundle.putString("lid",mInfo.getLid());
                bundle.putString("cid",mInfo.getCid());
                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), correctNotDetailsFragment, bundle);
            }
        });

        viewHolder.mImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mHid = mInfo.getHid();
                EvaluateDetailsFragment correctNotDetailsFragment = new EvaluateDetailsFragment();
                Bundle bundle = new Bundle();
                bundle.putString("lid",mInfo.getLid());
                bundle.putString("cid",mInfo.getCid());
                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), correctNotDetailsFragment, bundle);
            }
        });
        viewHolder.mEvluateDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mHid = mInfo.getHid();
                EvaluateDetailsFragment correctNotDetailsFragment = new EvaluateDetailsFragment();
                Bundle bundle = new Bundle();
                bundle.putString("lid",mInfo.getLid());
                bundle.putString("cid",mInfo.getCid());
                NavigateUtil.navigateToNormalActivity(fragment.getActivity(), correctNotDetailsFragment, bundle);
            }
        });

    }


    public  interface OnRecyclerViewItemClickListener{
        void onItemClick(View view, int position);
        void onItemImageClick(View view, int position);
    }

    private static OnRecyclerViewItemClickListener mOnItemClickListener = null;

    public void setmOnItemClickListener(OnRecyclerViewItemClickListener onItemClickListener){
        mOnItemClickListener = onItemClickListener;
    }


    private static class ViewHolder {
        public TextView mCourse;
        public TextView mClassTime;
        public TextView mTeacher;
        public TextView mTime;
        public NetworkImageView mImage;
        public TextView mEvaluate;
        public ViewGroup mEvluateDetails;
        public ViewGroup mLayoutItme;
        public ViewHolder(View itemView) {
            mCourse = (TextView) itemView.findViewById(R.id.evaluate_item_course);
            mClassTime = (TextView) itemView.findViewById(R.id.evaluate_item_class_time);
            mTeacher = (TextView) itemView.findViewById(R.id.evaluate_item_teacher);
            mTime = (TextView) itemView.findViewById(R.id.evaluate_item_time);
            mImage = (NetworkImageView) itemView.findViewById(R.id.evaluate_item_image);
            mEvaluate = (TextView) itemView.findViewById(R.id.evaluate);
            mEvluateDetails = (ViewGroup) itemView.findViewById(R.id.evaluate_details);
            mLayoutItme = (ViewGroup) itemView.findViewById(R.id.layout_item);

        }
    }

}
