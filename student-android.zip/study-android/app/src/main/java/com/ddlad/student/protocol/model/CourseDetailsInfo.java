package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.ui.model.MultiImageInfo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by chenjianing on 2017/3/24 0024.
 */
public class CourseDetailsInfo {

        /**
         * level : 3
         * desc : 雅思考试作为全球最具影响力的国际语言测试体系，提供最具可信度的权威英语水准认证。良好的雅思成绩可以为您开启海外留学、移民和职业发展的大门，从而提供最广泛的机遇。雅思考试得到包括美国、加拿大、英国、澳大利亚及纽西兰等主要英语国家教育机构的认可，同时还得到职业机构、移民当局、以及其他政府部门的亲睐。  这一预备课程旨在协助学员熟习其测试模式包括：听力，阅读，写作和口语。课程著重于让学员掌握考试技巧，并透过试题操练，。协助学员儘快熟悉和掌握各种测试模式和应试策略，为考试作好准备，考取理想成绩。  适合对象：该课程适合即将参加雅思考试，计画升学或需要进行高水准英语能力工作的人士。
         * teacher : wangsch
         * image : {"pattern":"http://img.z.ziduan.com/FCNC-zHElhA9RzEFBVF2BQ.png@{w}w_{h}h_75q","width":200,"height":200,"id":"FCNC-zHElhA9RzEFBVF2BQ"}
         * price : 100w英镑
         * cmId : FCNC-zHElhA9RzEFBVF2BQ
         * totalCnt : 100
         * name : Java super课程
         */

        private CourseBean course;

        public CourseBean getCourse() {
            return course;
        }

        public void setCourse(CourseBean course) {
            this.course = course;
        }

        public static class CourseBean {
            private int level;
            private String desc;
            private String teacher;
            /**
             * pattern : http://img.z.ziduan.com/FCNC-zHElhA9RzEFBVF2BQ.png@{w}w_{h}h_75q
             * width : 200
             * height : 200
             * id : FCNC-zHElhA9RzEFBVF2BQ
             */

            private MultiImageInfo image;
            private String price;
            private String cmId;
            private String lmId;
            private int totalCnt;
            private int joinCnt;
            private String openTime;
            private String name;
            private int status;
            private int type;

            private String suitableCrowds;
            private List<String> subNotes;

            public String getLmId() {
                return lmId;
            }

            public void setLmId(String lmId) {
                this.lmId = lmId;
            }

            public int getJoinCnt() {
                return joinCnt;
            }

            public void setJoinCnt(int joinCnt) {
                this.joinCnt = joinCnt;
            }

            public String getOpenTime() {
                return openTime;
            }

            public void setOpenTime(String openTime) {
                this.openTime = openTime;
            }

            public String getSuitableCrowds() {
                return suitableCrowds;
            }

            public void setSuitableCrowds(String suitableCrowds) {
                this.suitableCrowds = suitableCrowds;
            }
            public List<String> getSubNotes() {
                return subNotes;
            }

            public void setSubNotes(List<String> subNotes) {
                this.subNotes = subNotes;
            }
            public int getLevel() {
                return level;
            }

            public void setLevel(int level) {
                this.level = level;
            }

            public String getDesc() {
                return desc;
            }

            public void setDesc(String desc) {
                this.desc = desc;
            }

            public String getTeacher() {
                return teacher;
            }

            public void setTeacher(String teacher) {
                this.teacher = teacher;
            }

            public MultiImageInfo getImage() {
                return image;
            }

            public void setImage(MultiImageInfo image) {
                this.image = image;
            }

            public String getPrice() {
                return price;
            }

            public void setPrice(String price) {
                this.price = price;
            }

            public String getCmId() {
                return cmId;
            }

            public void setCmId(String cmId) {
                this.cmId = cmId;
            }

            public int getTotalCnt() {
                return totalCnt;
            }

            public void setTotalCnt(int totalCnt) {
                this.totalCnt = totalCnt;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }


            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public static CourseBean fromJsonParser(JsonParser jsonParser) throws IOException {

                CourseBean info = null;

                if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

                    while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                        String fieldName = jsonParser.getCurrentName();

                        if (fieldName == null) {
                            continue;
                        }

                        if (info == null) {
                            info = new CourseBean();
                        }

                        if ("level".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.level = jsonParser.getIntValue();
                            continue;
                        }
                        if ("desc".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.desc = jsonParser.getText();
                            continue;
                        }
                        if ("teacher".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.teacher = jsonParser.getText();
                            continue;
                        }
                        if ("image".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.image = MultiImageInfo.fromJsonParser(jsonParser);
                            continue;
                        }
                        if ("price".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.price = jsonParser.getText();
                            continue;
                        }
                        if ("suitableCrowds".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.suitableCrowds = jsonParser.getText();
                            continue;
                        }
                        if ("cmId".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.cmId = jsonParser.getText();
                            continue;
                        }
                        if ("totalCnt".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.totalCnt = jsonParser.getIntValue();
                            continue;
                        }
                        if ("lmId".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.lmId = jsonParser.getText();
                            continue;
                        }
                        if ("joinCnt".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.joinCnt = jsonParser.getIntValue();
                            continue;
                        }
                        if ("status".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.status = jsonParser.getIntValue();
                            continue;
                        }
                        if ("type".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.type = jsonParser.getIntValue();
                            continue;
                        }
                        if ("openTime".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.openTime = jsonParser.getText();
                            continue;
                        }
                        if ("name".equals(fieldName)) {
                            jsonParser.nextToken();
                            info.name = jsonParser.getText();
                            continue;
                        }

                        if ("subNotes".equals(fieldName)) {

                            jsonParser.nextToken();

                            List<String> tags = new ArrayList<>();

                            while (jsonParser.nextToken() != JsonToken.END_ARRAY) {
                                String t = jsonParser.getText();
                                if (t != null) {
                                    tags.add(t);
                                }
                            }

                            info.subNotes = tags;

                            continue;
                        }
                        jsonParser.skipChildren();
                    }
                }

                return info;
            }
        }
    public static CourseDetailsInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        CourseDetailsInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new CourseDetailsInfo();
                }

                if ("course".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.course = CourseBean.fromJsonParser(jsonParser);
                    continue;
                }

                jsonParser.skipChildren();
            }
        }

        return info;
    }
}
