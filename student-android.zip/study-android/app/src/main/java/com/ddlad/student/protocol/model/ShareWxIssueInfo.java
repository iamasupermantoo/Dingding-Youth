package com.ddlad.student.protocol.model;

/**
 * Created by chen007 on 2017/7/20 0020.
 */
public class ShareWxIssueInfo extends BaseInfo {

        /**
         * appid : wx5209e129ae5a3441
         * secret : 04d10dd6899ce39feb0343956ec1d7a7
         * url : http://web.u.ziduan.com/post/details?sub=d4QOBPsPkMYM32EYjRVwMQ&issue=wSamATrtW72lGz5siAKQvA
         * title : 测试2
         * brief : 测试2
         * picUrl : http://img.s.ziduan.com/udan_wxs.png
         */

        private InfoBean info;

        public InfoBean getInfo() {
            return info;
        }

        public void setInfo(InfoBean info) {
            this.info = info;
        }

        public static class InfoBean {
            private String appid;
            private String secret;
            private String url;
            private String title;
            private String brief;
            private String picUrl;

            public String getAppid() {
                return appid;
            }

            public void setAppid(String appid) {
                this.appid = appid;
            }

            public String getSecret() {
                return secret;
            }

            public void setSecret(String secret) {
                this.secret = secret;
            }

            public String getUrl() {
                return url;
            }

            public void setUrl(String url) {
                this.url = url;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getBrief() {
                return brief;
            }

            public void setBrief(String brief) {
                this.brief = brief;
            }

            public String getPicUrl() {
                return picUrl;
            }

            public void setPicUrl(String picUrl) {
                this.picUrl = picUrl;
            }
        }
}
