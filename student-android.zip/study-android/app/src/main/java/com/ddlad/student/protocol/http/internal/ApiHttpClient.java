package com.ddlad.student.protocol.http.internal;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.WindowManager;


import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.DeviceInfo;
import com.ddlad.student.primary.Log;
import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.tools.HttpUtil;
import com.ddlad.student.tools.NetworkUtil;
import com.ddlad.student.tools.Util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.util.Locale;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.TrustManagerFactory;

import ch.boye.httpclientandroidlib.Header;
import ch.boye.httpclientandroidlib.HeaderElement;
import ch.boye.httpclientandroidlib.HttpEntity;
import ch.boye.httpclientandroidlib.HttpException;
import ch.boye.httpclientandroidlib.HttpHost;
import ch.boye.httpclientandroidlib.HttpRequest;
import ch.boye.httpclientandroidlib.HttpRequestInterceptor;
import ch.boye.httpclientandroidlib.HttpResponse;
import ch.boye.httpclientandroidlib.HttpResponseInterceptor;
import ch.boye.httpclientandroidlib.HttpVersion;
import ch.boye.httpclientandroidlib.client.entity.GzipDecompressingEntity;
import ch.boye.httpclientandroidlib.client.methods.HttpDelete;
import ch.boye.httpclientandroidlib.client.methods.HttpEntityEnclosingRequestBase;
import ch.boye.httpclientandroidlib.client.methods.HttpGet;
import ch.boye.httpclientandroidlib.client.methods.HttpPost;
import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;
import ch.boye.httpclientandroidlib.client.params.ClientPNames;
import ch.boye.httpclientandroidlib.conn.params.ConnRoutePNames;
import ch.boye.httpclientandroidlib.conn.scheme.PlainSocketFactory;
import ch.boye.httpclientandroidlib.conn.scheme.Scheme;
import ch.boye.httpclientandroidlib.conn.scheme.SchemeRegistry;
import ch.boye.httpclientandroidlib.conn.ssl.SSLSocketFactory;
import ch.boye.httpclientandroidlib.entity.mime.MultipartEntity;
import ch.boye.httpclientandroidlib.entity.mime.content.FileBody;
import ch.boye.httpclientandroidlib.entity.mime.content.StringBody;
import ch.boye.httpclientandroidlib.impl.client.DefaultHttpClient;
import ch.boye.httpclientandroidlib.impl.conn.tsccm.ThreadSafeClientConnManager;
import ch.boye.httpclientandroidlib.params.BasicHttpParams;
import ch.boye.httpclientandroidlib.params.CoreProtocolPNames;
import ch.boye.httpclientandroidlib.params.HttpConnectionParams;
import ch.boye.httpclientandroidlib.params.HttpProtocolParams;
import ch.boye.httpclientandroidlib.protocol.BasicHttpContext;
import ch.boye.httpclientandroidlib.protocol.HttpContext;
import ch.boye.httpclientandroidlib.protocol.SyncBasicHttpContext;

public class ApiHttpClient {

    private static final String TAG = "ApiHttpClient";

    private static final int DEFAULT_CONNECTION_TIMEOUT = 10 * 1000;

    private static final int SOCKET_TIMEOUT = 3 * 10 * 1000;

    public static final String HTTP_CLIENT_SERVICE = "com.udan.ApiHttpClient";

    public static String MAC_ADDRESS = DeviceInfo.getLocalMacAddress();

    public static String DEVICE_ID = DeviceInfo.getDeviceIdHash();

    public static String USER_AGENT = updateUserAgentString();

    private static String mAcceptsLanguage;

    private final DefaultHttpClient mHttpClient;

    private final SyncBasicHttpContext mHttpContext;

    private SSLContext mSSLContext = null;

    public ApiHttpClient(PersistentCookieStore persistentCookieStore) {

        BasicHttpParams basicHttpParams = new BasicHttpParams();
        HttpConnectionParams.setTcpNoDelay(basicHttpParams, true);
        HttpConnectionParams.setConnectionTimeout(basicHttpParams, DEFAULT_CONNECTION_TIMEOUT);
        HttpConnectionParams.setSoTimeout(basicHttpParams, SOCKET_TIMEOUT);
        HttpProtocolParams.setVersion(basicHttpParams, HttpVersion.HTTP_1_1);
        HttpProtocolParams.setUserAgent(basicHttpParams, USER_AGENT);

        SchemeRegistry schemeRegistry = new SchemeRegistry();
        schemeRegistry.register(new Scheme("http", 80, PlainSocketFactory.getSocketFactory()));
        schemeRegistry.register(new Scheme("https", 443, new SSLSocketFactory(getSSLContext())));

        ThreadSafeClientConnManager threadSafeClientConnManager = new ThreadSafeClientConnManager(
                schemeRegistry);
        threadSafeClientConnManager.setDefaultMaxPerRoute(20);
        mHttpContext = new SyncBasicHttpContext(new BasicHttpContext());

        mHttpClient = new DefaultHttpClient(threadSafeClientConnManager, basicHttpParams);
        mHttpClient.setCookieStore(persistentCookieStore);

        mHttpClient.addRequestInterceptor(new HttpRequestInterceptor() {

            @Override
            public void process(HttpRequest httpRequest, HttpContext httpContext)
                    throws HttpException, IOException {
                if (!httpRequest.containsHeader("Accept-Encoding")) {
                    httpRequest.addHeader("Accept-Encoding", "gzip");
                }

                if (!httpRequest.containsHeader("Accept-Language")) {
                    httpRequest.addHeader("Accept-Language", getCurrentAcceptLanguage());
                }

                if (!httpRequest.containsHeader(ProtocolConstants.PARAM_DEVICE_ID)) {
                    httpRequest.addHeader(ProtocolConstants.PARAM_DEVICE_ID, DEVICE_ID);
                }

                if (!httpRequest.containsHeader(ProtocolConstants.PARAM_DEVICE_MAC)) {
                    httpRequest.addHeader(ProtocolConstants.PARAM_DEVICE_MAC, MAC_ADDRESS);
                }

                //                                String authorization = AuthHelper.getInstance().getAuthorization();
                //                                if (!TextUtils.isEmpty(authorization)) {
                //                                    //                    if (Log.DEBUG) {
                //                                    //                        Log.d(TAG, "addRequestInterceptor, set Authorization Header,authorization="
                //                                    //                                + authorization);
                //                                    //                    }
                //                                    httpRequest.addHeader(ProtocolConstants.PARAM_AUTHORIZATION, authorization);
                //                                }
            }
        }, 0);

        mHttpClient.addResponseInterceptor(new HttpResponseInterceptor() {

            @Override
            public void process(HttpResponse httpResponse, HttpContext httpContext)
                    throws HttpException, IOException {

                Header header = null;

                if (httpResponse.getEntity() != null) {
                    header = httpResponse.getEntity().getContentEncoding();
                }

                if (header != null) {
                    HeaderElement[] headerElement = header.getElements();
                    for (HeaderElement element : headerElement) {
                        if (element.getName().equalsIgnoreCase("gzip")) {
                            httpResponse.setEntity(new GzipDecompressingEntity(httpResponse
                                    .getEntity()));
                        }
                    }
                }
            }
        });

        initProxySetting();
    }

    public void initProxySetting() {

        // 代理支持
        int netType = NetworkUtil.getAccessPointType(AppContext.getContext());
        if (netType == NetworkUtil.APN_PROXY) {

            try {
                HttpHost proxy = new HttpHost(NetworkUtil.getHostIp(), NetworkUtil.getHostPort());
                mHttpClient.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            try {
                mHttpClient.getParams().removeParameter(ConnRoutePNames.DEFAULT_PROXY);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // 测试抓包
        HttpUtil.captureRequest(mHttpClient);
    }

    public static ApiHttpClient getInstance() {
        ApiHttpClient apiHttpClient = (ApiHttpClient) AppContext.getContext().getSystemService(
                HTTP_CLIENT_SERVICE);

        if (apiHttpClient == null) {
            apiHttpClient = (ApiHttpClient) AppContext.getContext().getSystemService(
                    HTTP_CLIENT_SERVICE);
        }

        if (apiHttpClient == null) {
            throw new IllegalStateException("ApiHttpClient not available");
        }

        return apiHttpClient;
    }

    private SSLContext createEasySSLContext() {

        InputStream is = null;
        try {
            SSLContext context = SSLContext.getInstance("TLS");
            KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
            ks.load(null, null);
            CertificateFactory factory = CertificateFactory.getInstance("X.509");
            is = AppContext.getResources().openRawResource(R.raw.ca);
            Certificate certificate = factory.generateCertificate(is);
            ks.setCertificateEntry("dorado ca", certificate);
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory
                    .getDefaultAlgorithm());
            tmf.init(ks);
            context.init(null, tmf.getTrustManagers(), new SecureRandom());
            return context;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return null;
    }

    private SSLContext getSSLContext() {

        if (mSSLContext == null) {
            mSSLContext = createEasySSLContext();
        }

        return mSSLContext;
    }

    private HttpEntityEnclosingRequestBase addEntityToRequestBase(
            HttpEntityEnclosingRequestBase requestBase, HttpEntity httpEntity) {
        if (httpEntity != null) {
            requestBase.setEntity(httpEntity);
        }

        return requestBase;
    }

    private static void addLocaleToHttpAcceptLanguage(StringBuilder stringBuilder, Locale locale) {
        String lang = convertObsoleteLanguageCodeToNew(locale.getLanguage());
        if (lang != null) {
            stringBuilder.append(lang);
            String country = locale.getCountry();
            if (country != null) {
                stringBuilder.append("_");
                stringBuilder.append(country);
            }
        }
    }

    private static String convertObsoleteLanguageCodeToNew(String lang) {

        if (lang == null) {
            return null;
        }
        return lang;
    }

    public static String getCurrentAcceptLanguage() {
        Locale locale = Locale.getDefault();

        if (mAcceptsLanguage == null) {
            StringBuilder sb = new StringBuilder();
            addLocaleToHttpAcceptLanguage(sb, locale);
            mAcceptsLanguage = sb.toString();
        }

        return mAcceptsLanguage;
    }

    private String getUrlWithQueryString(String url, RequestParams requestParam) {
        if (requestParam != null) {
            String queryString = requestParam.getParamString();
            if (!TextUtils.isEmpty(queryString)) {
                url = url + ((url.indexOf("?") == -1) ? "?" : "&") + queryString;
            }
        }
        return url;
    }

    private HttpEntity paramsToEntity(RequestParams requestParam) {
        if (requestParam != null) {
            return requestParam.getEntity();
        }
        return null;
    }

    // (15/4.0.3; 240dpi; 480x800; unknown/samsung; GT-I9000; GT-I9000; aries)
    @TargetApi(8)
    public static String updateUserAgentString() {
        String userAgent = "(unknown build)";

        WindowManager windowManager = (WindowManager) AppContext.getContext().getSystemService(
                Context.WINDOW_SERVICE);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        int densityDpi = displayMetrics.densityDpi;
        int widthPixels = displayMetrics.widthPixels;
        int heightPixels = displayMetrics.heightPixels;
        String screen = String.format("%sdpi; %sx%s", densityDpi, widthPixels, heightPixels);

        try {
            String manufacturer = Build.MANUFACTURER;
            if (!Build.MANUFACTURER.equals(Build.BRAND)) {
                manufacturer = String.format("%s/%s", Build.MANUFACTURER, Build.BRAND);
            }

            userAgent = String.format("(%s/%s; %s; %s; %s; %s; %s)",
                    Build.VERSION.SDK_INT,
                    Build.VERSION.RELEASE,
                    screen,
                    manufacturer,
                    Build.MODEL,
                    Build.DEVICE,
                    Build.VERSION.SDK_INT >= 8 ? Build.HARDWARE : "");
        } catch (Exception e) {
            e.printStackTrace();
            try {
                userAgent = String.format("(%s/%s)", Integer.valueOf(Build.VERSION.SDK_INT),
                        Build.VERSION.RELEASE);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        return String.format("Dorado %s.%s (Android %s)", Util.getVersionName(),
                Util.getChannel(), userAgent);
    }

    public HttpPost constructPostRequest(String uri, HttpEntity httpEntity) {
        return (HttpPost) addEntityToRequestBase(new HttpPost(uri), httpEntity);
    }

    public HttpPost constructPostRequest(String uri, RequestParams requestParam) {
        return constructPostRequest(uri, paramsToEntity(requestParam));
    }

    public HttpResponse get(String url) {
        return get(url, null);
    }

    public HttpResponse get(String url,RequestParams requestParam) {
        return sendRequest(mHttpClient, mHttpContext,
                new HttpGet(getUrlWithQueryString(url, requestParam)));
    }

    public HttpResponse sendRequestGet(HttpGet httpGet) {
        return sendRequest(mHttpClient, mHttpContext, httpGet);
    }

    public HttpResponse getRedirects(String url) {
        HttpGet get = new HttpGet(getUrlWithQueryString(url, null));

        BasicHttpParams params = new BasicHttpParams();
        params.setParameter(ClientPNames.HANDLE_REDIRECTS, Boolean.TRUE);
        params.setParameter(CoreProtocolPNames.HTTP_CONTENT_CHARSET, "UTF-8"); // 默认为ISO-8859-1
        params.setParameter(CoreProtocolPNames.HTTP_ELEMENT_CHARSET, "UTF-8"); // 默认为US-ASCII
        params.setIntParameter(ClientPNames.MAX_REDIRECTS, 100);

        get.setParams(params);
        return sendRequest(mHttpClient, new SyncBasicHttpContext(new BasicHttpContext()), get);
    }

    public HttpGet getRequest(String url) {
        return new HttpGet(url);
    }

    public HttpGet getRequest(String url, RequestParams requestParam) {
        return new HttpGet(getUrlWithQueryString(url, requestParam));
    }

    public HttpResponse post(String url) {
        return post(url, (HttpEntity) null);
    }

    public HttpResponse post(String url, RequestParams requestParam) {
        return post(url, paramsToEntity(requestParam));
    }

    public HttpResponse uploadBigFile(String url, Map<String, String> params,
                                      Map<String, String> fileParams) {
        MultipartEntity entity = new MultipartEntity();
        try {
            if (!CollectionUtil.isEmpty(params)) {
                for (String key : params.keySet()) {
                    entity.addPart(key, new StringBody(params.get(key), Charset.forName("UTF-8")));
                }

            }
            if (!CollectionUtil.isEmpty(fileParams)) {
                for (String key : fileParams.keySet()) {
                    entity.addPart(key, new FileBody(new File(fileParams.get(key))));
                }
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return post(url, entity);
    }

    public HttpResponse post(String url, HttpEntity httpEntity) {
        return sendRequest(mHttpClient, mHttpContext,
                addEntityToRequestBase(new HttpPost(url), httpEntity));
    }

    public HttpUriRequest postRequest(String url,RequestParams requestParam) {
        return addEntityToRequestBase(new HttpPost(url), paramsToEntity(requestParam));
    }

    public HttpResponse delete(String url) {
        HttpDelete httpDelete = new HttpDelete(url);
        return sendRequest(mHttpClient, mHttpContext, httpDelete);
    }

    public HttpResponse sendRequest(HttpUriRequest httpUriRequest) {
        return sendRequest(mHttpClient, mHttpContext, httpUriRequest);
    }

    // loader
    public HttpResponse sendRequest(DefaultHttpClient defaultHttpClient, HttpContext httpContext,
                                    HttpUriRequest httpUriRequest) {

        if (Log.DEBUG) {
            Log.d(TAG, "sendRequest(), httpUriRequest.getURI()=" + httpUriRequest.getURI());
            Log.i(TAG, "sendRequest(), httpUriRequest.getURI()=" + httpUriRequest.getURI());
        }

        if (NetworkUtil.hasConnection()) {
            try {
                return defaultHttpClient.execute(httpUriRequest, httpContext);
            } catch (SSLPeerUnverifiedException SSLPeerUnverifiedException) {
                try {
                    return HttpUtil.getNewHttpClient(AppContext.getContext()).execute(
                            httpUriRequest, httpContext);
                } catch (Exception e) {
                    httpUriRequest.abort();
                    e.printStackTrace();
                    return null;
                }
            } catch (Exception e) {
                e.printStackTrace();
                httpUriRequest.abort();
                Log.e(TAG, "Send request failed");
                return null;
            }
        }

        return null;
    }

    public void setCookieStore(PersistentCookieStore persistentCookieStore) {
        mHttpClient.setCookieStore(persistentCookieStore);
    }

}
