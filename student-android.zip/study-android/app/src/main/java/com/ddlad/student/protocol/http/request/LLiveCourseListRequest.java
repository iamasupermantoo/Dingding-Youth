package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.internal.StreamingApiResponse;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.CourseMetaListInfo;
import com.ddlad.student.protocol.model.CoursesLiveBean;
import com.ddlad.student.ui.common.BaseListFragment;
import com.fasterxml.jackson.core.JsonParser;

import java.io.IOException;

/**
 * Created by chenjianing
 * on 17-04-21.
 */
public class LLiveCourseListRequest extends BaseListRequest<CoursesLiveBean> {



    public LLiveCourseListRequest(BaseListFragment baseListFragment, int loaderId, AbstractStreamingCallbacks<AbstractListResponse<CoursesLiveBean>> streamingApiCallbacks) {
        super(baseListFragment, loaderId, streamingApiCallbacks);
    }

    @Override
    protected String getBasePath() {
        return "opencourse/list";
    }

    protected String getFieldKey() {
        return "opencourses";
    }


    @Override
    public void processResponseField(String fieldName, JsonParser jsonParser,
                                     StreamingApiResponse<AbstractListResponse<CoursesLiveBean>> streamingApiResponse) throws IOException {

        AbstractListResponse response = streamingApiResponse.getSuccessObject();
        if (response == null) {
            response = new AbstractListResponse() {
                @Override
                public CoursesLiveBean getModelInfo(JsonParser jsonParser) {
                    try {
                        return CoursesLiveBean.fromJsonParser(jsonParser);
                    } catch (Throwable t) {
                        t.printStackTrace();
                    }

                    return null;
                }
            };
        }
        response.parse(jsonParser, getFieldKey());
        streamingApiResponse.setSuccessObject(response);
    }



    public void perform(String cursor) {
        RequestParams params = getParams();
//        params.put("hid", hid);
//        params.put("cursor", cursor);
        super.perform();
    }
}

