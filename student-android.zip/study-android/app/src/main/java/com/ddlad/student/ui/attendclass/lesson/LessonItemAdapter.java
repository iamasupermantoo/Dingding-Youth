package com.ddlad.student.ui.attendclass.lesson;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.tools.Toaster;
import com.ddlad.student.ui.agora.LiveRoomFragment;
import com.ddlad.student.ui.attendclass.VideoPlayerActivityy;
import com.ddlad.student.ui.attendclass.evaluate.EvaluateDetailsFragment;
import com.ddlad.student.ui.attendclass.schedule.PendingFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.model.LessonInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.ui.attendclass.evaluate.EvaluateAlreadyDetailsFragment;
import com.ddlad.student.ui.common.AbstractAdapter;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.course.CorrectPendingFragment;
import com.ddlad.student.ui.course.TeacherReactionDetailFragment;
import com.ddlad.student.ui.widget.dialog.IDialogClickListener;
import com.ddlad.student.ui.widget.dialog.ShareLessonDialogBuilder;
import com.ddlad.student.wxapi.WechatHelper;

/**
 * Created by Administrator on 2017/1/17 0017.
 */

public class LessonItemAdapter {

    public static View createView(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_lesson_layout, null);
        LessonHolder holder = new LessonHolder();
        holder.mLeeson = (TextView) view.findViewById(R.id.lesson_item_name);
        holder.mTime = (TextView) view.findViewById(R.id.lesson_item_time);
        holder.mStatus = (TextView) view.findViewById(R.id.lesson_item_status);
        holder.mPlayback = (TextView) view.findViewById(R.id.lesson_item_playback);
        holder.mEvaluate = (TextView) view.findViewById(R.id.lesson_item_evaluate);
        holder.mHomework = (TextView) view.findViewById(R.id.lesson_item_homework);
        holder.mFeedBack = (TextView) view.findViewById(R.id.lesson_item_feedback);
        holder.share_layout = (ViewGroup) view.findViewById(R.id.share_layout);
        view.setTag(holder);
        return view;
    }

    public static void bindView(View view, final LessonInfo lessonInfo, final BaseFragment fragment, final AbstractAdapter adapter,boolean allowShare){
        if (lessonInfo == null){
            return;
        }
        LessonHolder holder = (LessonHolder) view.getTag();
        if (holder == null){
            return;
        }

        holder.mPlayback.setSelected(false);
        holder.mPlayback.setTextColor(Color.parseColor("#ffffff"));

        holder.mHomework.setText("提交作业");
        holder.mHomework.setSelected(false);
        holder.mHomework.setTextColor(Color.parseColor("#ffffff"));

        holder.mFeedBack.setText("查看反馈");
        holder.mFeedBack.setTextColor(Color.parseColor("#ffffff"));
        holder.mFeedBack.setSelected(false);

        holder.mEvaluate.setText("评价");
        holder.mEvaluate.setTextColor(Color.parseColor("#ffffff"));
        holder.mEvaluate.setSelected(false);


        holder.mLeeson.setText(lessonInfo.getLabel());
        holder.mTime.setText(String.valueOf(lessonInfo.getDate()+"   "+lessonInfo.getTime()));
        if (lessonInfo.getStatus() == LessonInfo.LessonType.NoLesson.getValue()){
            holder.mPlayback.setText("回放");
            holder.mPlayback.setSelected(false);
            holder.mStatus.setText("未上课");
            holder.mStatus.setTextColor(Color.parseColor("#fe8d25"));

        }else if (lessonInfo.getStatus() == LessonInfo.LessonType.AlreadyLesson.getValue()){
            holder.mPlayback.setText("监督");
            holder.mPlayback.setSelected(true);
            holder.mStatus.setText("正在上课");
            holder.mStatus.setTextColor(Color.parseColor("#fe8d25"));
        }else if (lessonInfo.getStatus() ==2 ){
            holder.mPlayback.setText("回放");
            holder.mStatus.setText("已上课");
            holder.mStatus.setTextColor(Color.parseColor("#cccccc"));
            ///////////////////////////////////////////////
            holder.mPlayback.setSelected(true);
            holder.mPlayback.setTextColor(Color.parseColor("#000000"));
            ////////////////////////////////////////////////
            holder.mHomework.setText("提交作业");
            holder.mHomework.setSelected(true);
            holder.mHomework.setTextColor(Color.parseColor("#000000"));
            /////////////////////////////////////////////////////
            if (lessonInfo.getHomeworkStatus() == 2){
                holder.mHomework.setText("查看批改");
                holder.mHomework.setSelected(true);
                holder.mHomework.setTextColor(Color.parseColor("#000000"));
            }

            if (lessonInfo.getTeacherReactionStatus() == 1){
                holder.mFeedBack.setText("查看反馈");
                holder.mFeedBack.setTextColor(Color.parseColor("#000000"));
                holder.mFeedBack.setSelected(true);
            }

            if (lessonInfo.getStudentReactionStatus() == 1){
                holder.mEvaluate.setText("查看评价");
                holder.mEvaluate.setTextColor(Color.parseColor("#000000"));
                holder.mEvaluate.setSelected(true);
            }else {
                holder.mEvaluate.setText("评价");
                holder.mEvaluate.setTextColor(Color.parseColor("#000000"));
                holder.mEvaluate.setSelected(true);
            }

        }

        holder.mPlayback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lessonInfo.getStatus() == 2){
                    ////////////////////
                    Intent intent = new Intent(fragment.getActivity(),VideoPlayerActivityy.class);
                    intent.putExtra("url",lessonInfo.getVideoUrl());
                    fragment.getActivity().startActivity(intent);

                }else {
                    Bundle bundle = new Bundle();
                    bundle.putString("cid",lessonInfo.getCid());
                    bundle.putString("lid",lessonInfo.getLid());
                    NavigateUtil.navigateToLiveRoomActivity(fragment.getActivity(), new LiveRoomFragment(),bundle);
                }
            }
        });
        holder.mFeedBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lessonInfo.getStatus() == 2){
                    ///////////////////////////////
                    if(lessonInfo.getTeacherReactionStatus() == 1){
                        Bundle bundle = new Bundle();
                        bundle.putString("cid",lessonInfo.getCid());
                        bundle.putString("lid",lessonInfo.getLid());
                        NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new TeacherReactionDetailFragment(),bundle);
                    }else {
                        Toaster.toastShort("老师还未给予反馈信息");
                    }

                }else {
                    Toaster.toastShort("课程未完成");
                }

            }
        });
        holder.mEvaluate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lessonInfo.getStatus() == 2){
                    ///////////////////
                    Bundle bundle = new Bundle();
                    bundle.putString("lid",lessonInfo.getLid());
                    bundle.putString("cid",lessonInfo.getCid());
                    if (lessonInfo.getStudentReactionStatus() == 1){
                        NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new EvaluateAlreadyDetailsFragment(), bundle);
                    }else {
                        NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new EvaluateDetailsFragment(), bundle);
                    }

                }

            }
        });
        holder.mHomework.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lessonInfo.getStatus() == 2){
                    ///////////////////////////////////
                    Bundle bundle = new Bundle();
                    bundle.putString("cid",lessonInfo.getCid());
                    bundle.putString("lid",lessonInfo.getLid());
                    if (lessonInfo.getHomeworkStatus() == 2){
                        NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new CorrectPendingFragment(),bundle);
                    }else {
                        NavigateUtil.navigateToNormalActivity(fragment.getActivity(), new PendingFragment(),bundle);
                    }
                }

            }
        });

        holder.share_layout.setVisibility(View.GONE);
        if (allowShare){
            holder.share_layout.setVisibility(View.VISIBLE);
            holder.share_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (fragment.getClass() == LessonFragment.class){
                        ((LessonFragment)fragment).showShareDialog("","",lessonInfo.getLid());
                    }
                }
            });
        }

    }




    public static class LessonHolder{
        private TextView mLeeson;
        private TextView mTime;
        private TextView mStatus;
        private TextView mPlayback;
        private TextView mEvaluate;
        private TextView mHomework;
        private TextView mFeedBack;
        private ViewGroup share_layout;
    }

}
