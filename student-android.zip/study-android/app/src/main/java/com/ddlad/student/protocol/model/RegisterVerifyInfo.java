package com.ddlad.student.protocol.model;

/**
 * Created by Albert
 * on 16-7-6.
 */
public class RegisterVerifyInfo {

    public String code;
    public String mobile;

}
