package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.ui.model.MultiImageInfo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by chenjianing on 2017/5/8 0008.
 */
public class LHomeWorkInfo extends BaseInfo {
        private String id;
        private String text;
        private String time;
        private int audioLength;
        private String audio;
        private List<MultiImageInfo> images;

        public int getAudioLength() {
            return audioLength;
        }

        public void setAudioLength(int audioLength) {
            this.audioLength = audioLength;
        }

        public String getAudio() {
            return audio;
        }

        public void setAudio(String audio) {
            this.audio = audio;
        }

        public List<MultiImageInfo> getImages() {
            return images;
        }

        public void setImages(List<MultiImageInfo> images) {
            this.images = images;
        }

        private int type;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public String getTime() {
            return time;
        }

        public void setTime(String time) {
            this.time = time;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }

        public static LHomeWorkInfo fromJsonParser(JsonParser jsonParser) throws IOException {

            LHomeWorkInfo info = null;

            if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

                while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                    String fieldName = jsonParser.getCurrentName();

                    if (fieldName == null) {
                        continue;
                    }

                    if (info == null) {
                        info = new LHomeWorkInfo();
                    }

                    if ("audio".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.audio = jsonParser.getText();
                        continue;
                    }
                    if ("text".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.text = jsonParser.getText();
                        continue;
                    }
                    if ("id".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.id = jsonParser.getText();
                        continue;
                    }
                    if ("time".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.time = jsonParser.getText();
                        continue;
                    }
                    if ("audioLength".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.audioLength = jsonParser.getIntValue();
                        continue;
                    }
                    if ("type".equals(fieldName)) {
                        jsonParser.nextToken();
                        info.type = jsonParser.getIntValue();
                        continue;
                    }
                    if ("images".equals(fieldName)) {
                        jsonParser.nextToken();

                        List<MultiImageInfo> list = new ArrayList<>();

                        while (jsonParser.nextToken() != JsonToken.END_ARRAY) {
                            MultiImageInfo t = MultiImageInfo.fromJsonParser(jsonParser);
                            if (t != null) {
                                list.add(t);
                            }
                        }
                        info.images = list;
                        continue;
                    }

                    jsonParser.skipChildren();
                }
            }
            return info;
        }
}
