package com.ddlad.student.ui.attendclass.schedule;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.model.LHomeWorkInfo;

public class LHomeWorkTextListItemAdapter {

    public static View createView(ViewGroup viewGroup) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.pending_item_text,
                null);

        TextViewHolder holder = new TextViewHolder(view);

        view.setTag(holder);

        return view;
    }

    public static void bindView(View view, final LHomeWorkInfo mInfo, final BaseFragment fragment, final int position, boolean mIsModify, final LHomeWorkListAdapter.IRemoveAnswerListener listener) {

        if (mInfo == null) {
            return;
        }

        TextViewHolder textHolder = (TextViewHolder) view.getTag();

        if (textHolder == null) {
            return;
        }
        if (mIsModify){
            textHolder.xx.setVisibility(View.VISIBLE);
            textHolder.xx.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.removeAnswer(position,mInfo.getId(),fragment);
                }
            });
        }else {
            textHolder.xx.setVisibility(View.GONE);
        }
        if (mInfo.getText().length()<= 3){

            textHolder.mText.setText(mInfo.getText()+"      ");
        }else {
            textHolder.mText.setText(mInfo.getText());
        }
        textHolder.mTime.setText(mInfo.getTime());
    }


    public  interface OnRecyclerViewItemClickListener{
        void onItemClick(View view, int position);
        void onItemImageClick(View view, int position);
    }

    private static OnRecyclerViewItemClickListener mOnItemClickListener = null;

    public void setmOnItemClickListener(OnRecyclerViewItemClickListener onItemClickListener){
        mOnItemClickListener = onItemClickListener;
    }


    private static class TextViewHolder {
        private TextView mText;
        private TextView mTime;
        private ImageView xx;
        public TextViewHolder(View itemView) {
            mText = (TextView) itemView.findViewById(R.id.pending_item_text);
            xx = (ImageView) itemView.findViewById(R.id.xx);
            mTime = (TextView) itemView.findViewById(R.id.text_time);


        }
    }

}
