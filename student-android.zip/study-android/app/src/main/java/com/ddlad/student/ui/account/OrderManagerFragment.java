package com.ddlad.student.ui.account;

import android.app.Activity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.course.NewPayModeFragment;
import com.ddlad.student.R;
import com.ddlad.student.ui.choice.ChoiceFragment;

/**
 * Created by Administrator on 2017/3/17 0017.
 */
public class OrderManagerFragment extends BaseFragment {

    private RecyclerView mOrders;
    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_order_manager;
    }

    @Override
    protected void onInitView(View contentView) {

        mActionbar.setTitle("订单");

        mOrders = (RecyclerView) contentView.findViewById(R.id.order_rv);
        mOrders.setLayoutManager(new LinearLayoutManager(getContext()));
        OrderManagerAdapter adapter = new OrderManagerAdapter(getActivity());
        mOrders.setAdapter(adapter);
        adapter.setmOnItemClickListener(new OrderManagerAdapter.OnRecyclerViewItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                //跳入支付页面
                Toaster.toastShort("跳入支付页面");
                navigateToPayModeFragment(getActivity());
//                navigateToChoiceFragment(getActivity());

            }
        });

    }

    private void navigateToPayModeFragment(Activity context) {
        NavigateUtil.navigateToNormalActivity(context, new NewPayModeFragment(), null);
    }
    private void navigateToChoiceFragment(Activity context) {
        NavigateUtil.navigateToNormalActivity(context, new ChoiceFragment(), null);
    }
}
