package com.ddlad.student.protocol.http.request;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.model.Account;
import com.ddlad.student.protocol.model.UserInfo;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.tools.BitmapUtil;
import com.ddlad.student.ui.common.BaseFragment;

import java.io.ByteArrayInputStream;

import ch.boye.httpclientandroidlib.Header;
import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Albert
 * on 16-7-6.
 */
public class SignUpRequest extends AbstractRequest<Account> {

    protected Uri mUri;

    protected Bitmap mBitmap = null;

    public SignUpRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<Account> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        HttpUriRequest request = httpClient.postRequest(url, requestParam);
        Header header = getMultipartParams().getMultipartHeader();
        if (header != null) {
            request.setHeader(header);
        }
        return request;
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_MOBILE_SIGN_UP;
    }


    @Override
    public Account processInBackground(ApiResponse<Account> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, Account.class);
    }

    protected Bitmap getBitmap() {
        return BitmapFactory.decodeFile(mUri.getPath());
    }

    @Override
    public void preProcessInBackground() throws PreProcessException {

        try {

            if (mBitmap == null && mUri == null) {
                getParams().put(ProtocolConstants.PARAM_HEAD_IMAGE, null, "file", "multipart/form-data");
            } else {
                ByteArrayInputStream byteArrayInputStream;
                byteArrayInputStream = BitmapUtil.compressedInputStream(mBitmap == null ? getBitmap() : mBitmap);
                getParams().put(ProtocolConstants.PARAM_HEAD_IMAGE, byteArrayInputStream, "file", "multipart/form-data");
            }

            return;

        } catch (Throwable t) {
            t.printStackTrace();
        }

        throw new AbstractRequest.PreProcessException();
    }

    public void perform(UserInfo user, Uri headUri,String birthDay) {
        perform(user.getMobile(), user.getName(), user.getPassword(), user.getType(),
                user.getCode(), user.getSignature(), headUri,birthDay);
    }

    public void perform(Object mobile, Object name, Object password, Object userType, Object code, Object signature, Uri headImage,String birthDay) {
        mUri = headImage;
        RequestParams params = getMultipartParams();
        params.put("mobile", mobile);
        params.put("name", name);
        params.put("password", password);
        params.put("signature", signature);
        params.put("birthday", birthDay);
        super.perform();
    }
    public void perform(Object mobile, Object name, Object password, Object userType, Object code, Object signature, Uri headImage) {
        mUri = headImage;
        RequestParams params = getMultipartParams();
        params.put("mobile", mobile);
        params.put("name", name);
        params.put("password", password);
        params.put("signature", signature);
        super.perform();
    }
}
