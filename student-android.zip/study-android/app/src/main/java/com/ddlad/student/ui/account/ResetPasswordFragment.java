package com.ddlad.student.ui.account;

import android.graphics.Color;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.request.PasswordChangeRequest;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.ui.common.BaseFragment;

/**
 * Created by Administrator on 2017/3/17 0017.
 */
public class ResetPasswordFragment extends BaseFragment {

    private EditText mOldPasswordEdit;
    private EditText mPasswordEdit;
    private TextView mConfirmButton;
    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_reset_password;
    }

    @Override
    protected void onInitView(View contentView) {

        mActionbar.setTitle("密码修改");

        mOldPasswordEdit = (EditText) contentView.findViewById(R.id.old_password);
        mPasswordEdit = (EditText) contentView.findViewById(R.id.password);
        mConfirmButton = (TextView) contentView.findViewById(R.id.confirm_reset_password);

        mOldPasswordEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (mOldPasswordEdit.getText().toString().trim().length()> 0 && mPasswordEdit.getText().toString().trim().length() >0){
                    mConfirmButton.setTextColor(Color.parseColor("#333333"));
                    mConfirmButton.setSelected(true);
                }else {
                    mConfirmButton.setSelected(false);
                    mConfirmButton.setTextColor(Color.parseColor("#ffffff"));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        mPasswordEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (mOldPasswordEdit.getText().toString().trim().length()> 0 && mPasswordEdit.getText().toString().trim().length() >0){
                    mConfirmButton.setTextColor(Color.parseColor("#333333"));
                    mConfirmButton.setSelected(true);
                }else {
                    mConfirmButton.setSelected(false);
                    mConfirmButton.setTextColor(Color.parseColor("#ffffff"));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mConfirmButton.setSelected(false);
        mConfirmButton.setOnClickListener(this);


    }

    @Override
    public void onPause() {
        hideKeyboard();
        super.onPause();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.confirm_reset_password:
                Log.i(TAG, "onClick: click      click");
                if (TextUtils.isEmpty(mOldPasswordEdit.getText())) {
                    Toaster.toastShort(R.string.mobile_empty);
                    return;
                } else if (TextUtils.isEmpty(mPasswordEdit.getText())) {
                    Toaster.toastShort(R.string.password_empty);
                    return;
                }
                new PasswordChangeRequest(this, getDefaultLoaderId(), new AbstractCallbacks<String>() {
                    @Override
                    protected void onSuccess(String s) {
                        Toaster.toastShort("更改密码成功！");

                    }

                    @Override
                    protected void onFail(ApiResponse<String> response) {
                        Toaster.toastShort("更改密码失败！！！");
                        super.onFail(response);
                    }
                }).perform(mOldPasswordEdit.getText(),mPasswordEdit.getText());
        }
    }
}
