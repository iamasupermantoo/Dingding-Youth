package com.ddlad.student.protocol.http.cache;

import android.content.Context;
import android.support.v4.content.AsyncTaskLoader;

import com.ddlad.student.primary.Log;


public class DiskCacheLoader<T> extends AsyncTaskLoader<T> {

    private static final String TAG = "DiskCacheLoader";

    protected T mDiskCacheResult;

    protected boolean mDeliverOnly = true;

    public DiskCacheLoader(Context context) {
        super(context);
    }

    @Override
    public void deliverResult(T result) {
        if (Log.DEBUG) {
            Log.d(TAG, "deliverResult(), result=" + result + ", isReset=" + isReset()
                    + ", isStarted()=" + isStarted());
        }
        super.deliverResult(result);
    }

    @Override
    public T loadInBackground() {
        return null;
    }

    @Override
    protected void onReset() {

        super.onReset();
        onStopLoading();
        if (mDiskCacheResult != null) {
            mDiskCacheResult = null;
        }
    }

    @Override
    protected void onStartLoading() {

        if (mDiskCacheResult == null && !mDeliverOnly) {
            forceLoad();
        }

        if (mDiskCacheResult != null) {
            deliverResult(mDiskCacheResult);
        }
    }

    @Override
    protected void onStopLoading() {
        cancelLoad();
    }

    public void setDeliverOnly(boolean deliverOnly) {
        mDeliverOnly = deliverOnly;
    }

}
