package com.ddlad.student.protocol.model;

/**
 * Created by chen007 on 2017/8/26 0026.
 */
public class IntroInfo extends BaseInfo {
    public String video;

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }
}
