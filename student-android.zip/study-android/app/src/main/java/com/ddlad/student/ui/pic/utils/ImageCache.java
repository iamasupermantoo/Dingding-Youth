package com.ddlad.student.ui.pic.utils;

import android.graphics.Bitmap;
import android.os.Environment;
import android.support.v4.util.LruCache;

import java.io.File;

public class ImageCache {
	public static final int LRU_MAX_SIZE = (int) (Runtime.getRuntime()
			.maxMemory() / 8);
	public static final long DISK_MAX_SIZE = 1024 * 100 * 1024;
	public static final String DISK_FILE_PATH = Environment
			.getExternalStorageDirectory() + File.separator + "anada";

	private static ImageCache cache = new ImageCache();

	public static ImageCache getInstance() {
		return cache;
	}

	private LruCache<String, Bitmap> lruCache;
	private DiskLruCache diskLruCache;

	private ImageCache() {
		lruCache = new LruCache<String, Bitmap>(LRU_MAX_SIZE) {
			@Override
			protected int sizeOf(String key, Bitmap value) {
				return Utils.getBitmapSize(value);
			}

			@Override
			protected void entryRemoved(boolean evicted, String key,
					Bitmap oldValue, Bitmap newValue) {
				super.entryRemoved(evicted, key, oldValue, newValue);
			}
		};
		if (Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) {
			diskLruCache = DiskLruCache.openCache(null,
					new File(DISK_FILE_PATH), DISK_MAX_SIZE);
		}

	}

	public void putCache(String key, Bitmap value) {
		lruCache.put(key, value);
		if (diskLruCache != null) {
			diskLruCache.put(key, value);
		}
	}

	public void clearCache() {
		if (diskLruCache != null) {
			diskLruCache.clearCache();
		}
	}

	public Bitmap getCache(String key) {
		if (key == null) {
			return null;
		}

		Bitmap bitmap = lruCache.get(key);
		if (bitmap == null) {
			if (diskLruCache != null) {
				bitmap = diskLruCache.get(key);
			}
		}
		return bitmap;
	}
}
