package com.ddlad.student.ui.attendclass.evaluate;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.request.EvaluateListRequest;
import com.ddlad.student.protocol.model.EvaluateListInfo;
import com.ddlad.student.tools.NavigateUtil;

/**
 * Created by Administrator on 2017/3/17 0017.
 */
public class EvaluateFragment extends BaseFragment {


    private RecyclerView mEvaluateRv;
    private boolean mselect = true;

    private EvaluateListInfo mInfo;

    private EvaluateAdapter adapter;

    private ViewGroup mFrameLayout;
    private Fragment mNotFragment;
    private Fragment mAlreadyFragment;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_evaluate;
    }

    @Override
    protected void onInitView(View contentView) {
        mEvaluateRv = (RecyclerView) contentView.findViewById(R.id.evaluate_rv);
        mFrameLayout = (ViewGroup) contentView.findViewById(R.id.evaluate_frame_layout);
        mNotFragment = new EvaluateNotFragment();
        mAlreadyFragment = new EvaluateAlreadyFragment();
        FragmentTransaction transaction =getFragmentManager().beginTransaction();
//        Bundle bundle = new Bundle();
//        bundle.putString("oid","");
//        mAlreadyFragment.setArguments(bundle);
        transaction.add(R.id.evaluate_frame_layout,mAlreadyFragment);
        transaction.add(R.id.evaluate_frame_layout,mNotFragment);

        transaction.hide(mAlreadyFragment);
        transaction.commit();
        mActionbar.setEvaluateTitle("未评价", "已评价", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mselect = true;
                mActionbar.setEvaluateSelect(mselect);
                FragmentTransaction transaction1 =getFragmentManager().beginTransaction();
                transaction1.hide(mAlreadyFragment);
                transaction1.show(mNotFragment);
                transaction1.commit();
            }
        }, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mselect = false;
                mActionbar.setEvaluateSelect(mselect);
                FragmentTransaction transaction2 =getFragmentManager().beginTransaction();
                transaction2.hide(mNotFragment).show(mAlreadyFragment);
                transaction2.commit();
//                showFragment(mNotFragment);
            }
        });
        mActionbar.setEvaluateSelect(mselect);

        mEvaluateRv.setLayoutManager(new LinearLayoutManager(getContext()));






    }

    @Override
    public void onResume() {

        super.onResume();
//        requestData();

    }

    private void requestData() {
        startLoading();
        EvaluateListRequest request = new EvaluateListRequest(this, getDefaultLoaderId(), new AbstractCallbacks<EvaluateListInfo>() {
            @Override
            protected void onSuccess(EvaluateListInfo evaluateListInfo) {
                mInfo = evaluateListInfo;
                adapter= new EvaluateAdapter(evaluateListInfo);
                mEvaluateRv.setAdapter(adapter);

                adapter.setmOnItemClickListener(new EvaluateAdapter.OnRecyclerViewItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        //跳到个人详情

                    }

                    @Override
                    public void onItemImageClick(View view, int position) {
                        //去评价
                        navigateEvaluateDetailsFragment();
                    }

                });
                Log.i(TAG, "onSuccess: 请求成功oooooooooooooooooooooo");
                Log.i(TAG, "onSuccess: "+mInfo.getReactions().getList().get(0).getCourse()+mInfo.getReactions().getList().get(0).getCid()+
                        mInfo.getReactions().getList().get(0).getDate()+mInfo.getReactions().getList().get(0).getTeacher());
                stopLoading();
            }

            @Override
            protected void onFail(ApiResponse<EvaluateListInfo> response) {

                Log.i(TAG, "onFail: 请求失败^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                stopLoading();
            }
        });
        request.perform();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.titleDynamic:

                break;
            case R.id.titleInterlocution:

                break;
        }
    }

    private void showFragment(Fragment fg){
        FragmentTransaction transaction =getFragmentManager().beginTransaction();
        if(!fg.isAdded()){
            transaction
                    .hide(mNotFragment)
                    .add(R.id.content,fg);
        }else{
            transaction
                    .hide(mNotFragment)
                    .show(fg);
        }
        mNotFragment = fg;
//        transaction.replace(R.id.evaluate_frame_layout, fg);
        transaction.commit();

    }

    private void navigateEvaluateDetailsFragment() {
        NavigateUtil.navigateToNormalActivity(getActivity(), new EvaluateDetailsFragment(), null);
    }
    private void navigateCourseDetailsFragment() {
        NavigateUtil.navigateToNormalActivity(getActivity(), new EvaluateDetailsFragment(), null);
    }
}
