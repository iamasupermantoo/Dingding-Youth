package com.ddlad.student.primary;

import android.content.Context;
import android.support.v4.content.AsyncTaskLoader;

/**
 * Created by Albert
 * on 16-6-2.
 */
public abstract class ImmediateAsyncTaskLoaderAsyncTask<D> extends AsyncTaskLoader<D> {

    public ImmediateAsyncTaskLoaderAsyncTask(Context context) {
        super(context);
    }

    @Override
    public void deliverResult(D d) {
        super.deliverResult(d);
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
        super.onStartLoading();
    }

    @Override
    protected void onStopLoading() {
        cancelLoad();
    }
}
