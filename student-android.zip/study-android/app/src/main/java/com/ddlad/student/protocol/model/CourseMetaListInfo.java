package com.ddlad.student.protocol.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.ddlad.student.ui.model.MultiImageInfo;

import java.io.IOException;

/**
 * Created by chenjianing on 2017/5/13 0013.
 */
public class CourseMetaListInfo extends BaseInfo{

                private int level;
                /**
                 * pattern : http://img.z.ziduan.com/FCNC-zHElhA9RzEFBVF2BQ.png@{w}w_{h}h_75q
                 * width : 200
                 * height : 200
                 * id : FCNC-zHElhA9RzEFBVF2BQ
                 */

                private MultiImageInfo image;
                private int totalCnt;
                private String desc;
                private String cmId;
                private String name;

                public int getLevel() {
                    return level;
                }

                public void setLevel(int level) {
                    this.level = level;
                }

                public MultiImageInfo getImage() {
                    return image;
                }

                public void setImage(MultiImageInfo image) {
                    this.image = image;
                }

                public int getTotalCnt() {
                    return totalCnt;
                }

                public void setTotalCnt(int totalCnt) {
                    this.totalCnt = totalCnt;
                }

                public String getDesc() {
                    return desc;
                }

                public void setDesc(String desc) {
                    this.desc = desc;
                }

                public String getCmId() {
                    return cmId;
                }

                public void setCmId(String cmId) {
                    this.cmId = cmId;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }
    public static CourseMetaListInfo fromJsonParser(JsonParser jsonParser) throws IOException {

        CourseMetaListInfo info = null;

        if (jsonParser.getCurrentToken() != JsonToken.VALUE_NULL) {

            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {

                String fieldName = jsonParser.getCurrentName();

                if (fieldName == null) {
                    continue;
                }

                if (info == null) {
                    info = new CourseMetaListInfo();
                }

                if ("level".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.level = jsonParser.getIntValue();
                    continue;
                }
                if ("totalCnt".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.totalCnt = jsonParser.getIntValue();
                    continue;
                }
                if ("desc".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.desc = jsonParser.getText();
                    continue;
                }
                if ("cmId".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.cmId = jsonParser.getText();
                    continue;
                }
                if ("name".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.name = jsonParser.getText();
                    continue;
                }
                if ("image".equals(fieldName)) {
                    jsonParser.nextToken();
                    info.image = MultiImageInfo.fromJsonParser(jsonParser);
                    continue;
                }


                jsonParser.skipChildren();
            }
        }
        return info;
    }
}
