package com.ddlad.student.ui.calendar.calendarview;

import android.content.Context;
import android.util.TypedValue;

import com.ddlad.student.primary.AppContext;
import com.ddlad.student.R;

/**
 * Created by Albert
 * on 16-8-31.
 */
public class DecorView extends DayView {

    public DecorView(Context context, CalendarDay day) {
        super(context, day, false);
    }

    @Override
    protected void initTextStyle() {
        setTextColor(AppContext.getColor(R.color.transparent));
        setSelectionColor(AppContext.getColor(R.color.transparent));
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 6);
    }
}
