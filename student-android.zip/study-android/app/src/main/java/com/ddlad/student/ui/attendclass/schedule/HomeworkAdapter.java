package com.ddlad.student.ui.attendclass.schedule;

import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.protocol.model.HomeworkInfo;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.ui.common.AbstractAdapter;

import java.util.List;

/**
 * Created by Administrator on 2017/2/6 0006.
 */

public class HomeworkAdapter extends AbstractAdapter<HomeworkInfo> {
    public HomeworkAdapter(BaseFragment fragment) {
        super(fragment);
    }

    @Override
    public HomeworkInfo getItem(int position) {
        return mList.get(position);
    }

    @Override
    protected View createView(int position, ViewGroup parent) {
        return HomeworkItemAdapter.createView(parent);
    }

    @Override
    protected void bindView(int position, View view) {
        HomeworkItemAdapter.bindView(view,getItem(position),mFragment,this);
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public void clearItem() {
        mList.clear();
    }

    @Override
    public void addItem(HomeworkInfo homeworkInfo) {
        mList.add(homeworkInfo);
    }

    @Override
    public void addItem(List<HomeworkInfo> list) {
        if (!CollectionUtil.isEmpty(list)){
            mList.addAll(list);
        }
    }
}
