package com.ddlad.student.tools;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

public class RunnableHelper {

    private static final Handler sUIHandler = new Handler(Looper.getMainLooper());
    private static final Executor sSingleThread = Executors.newSingleThreadExecutor(getThreadFactory());
    private static final Executor sCacheThread = Executors.newCachedThreadPool(getThreadFactory());

    private static ThreadFactory getThreadFactory() {
        return new ThreadFactory() {
            @Override
            public Thread newThread(final Runnable runnable) {
                Thread thread = new Thread(runnable);
                thread.setPriority(Thread.NORM_PRIORITY - 2);
                return thread;
            }
        };
    }

    public static void runInUIThread(Runnable task) {
        sUIHandler.post(task);
    }

    public static void runInUIThread(Runnable task, long millis) {
        sUIHandler.postDelayed(task, millis);
    }

    public static void removeFromUIThread(Runnable task) {
        sUIHandler.removeCallbacks(task);
    }

    public static void runInWorkerThread(Runnable task) {
        sSingleThread.execute(task);
    }

    public static void runInBackground(Runnable task) {
        sCacheThread.execute(task);
    }
}
