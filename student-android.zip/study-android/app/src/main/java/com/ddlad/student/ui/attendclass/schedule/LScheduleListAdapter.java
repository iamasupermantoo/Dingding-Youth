package com.ddlad.student.ui.attendclass.schedule;

import android.view.View;
import android.view.ViewGroup;

import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.protocol.model.ScheduleCourseInfo;
import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.ui.common.AbstractAdapter;

import java.util.List;

/**
 * Created by Albert
 * on 16-10-20.
 */
public class LScheduleListAdapter extends AbstractAdapter<ScheduleCourseInfo> {

    public LScheduleListAdapter(BaseFragment fragment) {
        super(fragment);
    }

    @Override
    public ScheduleCourseInfo getItem(int position) {
        return mList.get(position);
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public int getItemViewType(int position) {
        return getItem(position).getType();
    }

    @Override
    protected View createView(int position, ViewGroup parent) {
        return ScheduleListItemAdapter.createView(parent);
    }

    @Override
    protected void bindView(int position, View view) {
        ScheduleCourseInfo feed = getItem(position);
        ScheduleListItemAdapter.bindView(view, feed, mFragment);
    }

    @Override
    public void clearItem() {
        mList.clear();
    }

    @Override
    public void addItem(ScheduleCourseInfo info) {
        mList.add(info);
    }

    @Override
    public void addItem(List<ScheduleCourseInfo> list) {
        if (!CollectionUtil.isEmpty(list)) {
            mList.addAll(list);
        }
    }

    @Override
    public int getCount() {
        return mList.size();
    }

//    public enum ProfileViewType {
//
//        Article(0), Image(1);
//
//        private ProfileViewType(int value) {
//            this.mValue = value;
//        }
//
//        private int mValue;
//
//        public int getValue() {
//            return mValue;
//        }
//    }

}

