package com.ddlad.student.protocol.http.cache;

import android.content.Context;
import android.util.Log;

import com.ddlad.student.primary.AppContext;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import ch.boye.httpclientandroidlib.client.cache.HttpCacheEntry;
import ch.boye.httpclientandroidlib.client.cache.HttpCacheEntrySerializer;
import ch.boye.httpclientandroidlib.client.cache.HttpCacheStorage;
import ch.boye.httpclientandroidlib.client.cache.HttpCacheUpdateCallback;
import ch.boye.httpclientandroidlib.client.cache.HttpCacheUpdateException;

public class PaHttpCacheStorage implements HttpCacheStorage {

    public static final String TAG = "PaHttpCacheStorage";

    public static final int MAX_SIZE = 30 * 1024 * 1024;

    private final DiskLruCache mDiskLruCache;

    private final HttpCacheEntrySerializer mSerializer;

    public PaHttpCacheStorage(Context context, HttpCacheEntrySerializer httpCacheEntrySerializer) {
        mSerializer = httpCacheEntrySerializer;

        try {
            mDiskLruCache = DiskLruCache.open(getCacheStorage(context), 0, 1, MAX_SIZE);
            return;
        } catch (IOException e) {
            e.printStackTrace();
        }

        throw new RuntimeException("Unable to open file cache");
    }

    private File getCacheStorage(Context context) throws IOException {
        File file = getCachePath(context);
        if (file != null) {
            file = new File(file + File.separator + "images");
        }
        return file;
    }

    private File getCachePath(Context context) throws IOException {
        File file = context.getCacheDir();

        if (file == null) {
            file = getExternalStorage(context);
        }

        if (file == null) {
            throw new IOException("Unable to open storage");
        }

        return file;
    }

    private File getExternalStorage(Context context) {
        return context.getExternalCacheDir();
    }

    private String getFilenameForKey(String filename) {
        return String.format("%s", Integer.toHexString(filename.hashCode()));
    }

    private HttpCacheEntry reconstituteEntry(InputStream inputStream) throws IOException {
        return mSerializer.readFrom(new BufferedInputStream(inputStream));
    }

    public HttpCacheEntry getEntry(String url) {
        DiskLruCache.Snapshot snapshot = null;

        try {

            snapshot = mDiskLruCache.get(getFilenameForKey(url));
            if (snapshot != null) {
                return reconstituteEntry(snapshot.getInputStream(0));
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (snapshot != null) {
                snapshot.close();
            }
        }

        return null;
    }

    public void putEntry(String url, HttpCacheEntry httpCacheEntry) {
        String key = getFilenameForKey(url);
        OutputStream out = null;
        BufferedOutputStream bufferedOutputStream = null;

        try {
            DiskLruCache.Snapshot snapshot = mDiskLruCache.get(key);
            if (snapshot == null) {
                final DiskLruCache.Editor editor = mDiskLruCache.edit(key);
                if (editor != null) {
                    out = editor.newOutputStream(0);
                    bufferedOutputStream = new BufferedOutputStream(out);
                    mSerializer.writeTo(httpCacheEntry, bufferedOutputStream);
                    editor.commit();

                    out.close();
                    bufferedOutputStream.close();
                }
            } else {
                snapshot.getInputStream(0).close();
            }
        } catch (final IOException e) {
            Log.e(TAG, "putEntry - " + e);
        } catch (Exception e) {
            Log.e(TAG, "putEntry - " + e);
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
            }

            try {
                if (bufferedOutputStream != null) {
                    bufferedOutputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void removeEntry(String url) throws IOException {
    }

    @Override
    public void updateEntry(String url, HttpCacheUpdateCallback httpCacheUpdateCallback)
            throws IOException, HttpCacheUpdateException {

        DiskLruCache.Snapshot snapshot = null;

        try {
            snapshot = mDiskLruCache.get(url);
            if (snapshot == null) {
                putEntry(url, httpCacheUpdateCallback.update(reconstituteEntry(null)));
            } else {
                reconstituteEntry(snapshot.getInputStream(0));
            }
        } finally {
            if (snapshot != null) {
                snapshot.close();
            }
        }
    }

    /**
     * 更改原来的文件夹名，新建文件夹
     */
    public void fastClearCache() {
        try {
            File file = getCacheStorage(AppContext.getContext());
            File tempFile = new File(getCachePath(AppContext.getContext()) + File.separator + "images_temp");

            if (tempFile.exists()) {
                clearCache(true);
            }

            if (file.exists() && !tempFile.exists()) {
                file.renameTo(tempFile);

                File file2 = getCacheStorage(AppContext.getContext());
                if (!file2.exists()) {
                    file2.mkdir();
                }
            }

        } catch (IOException e) {
        } catch (Exception e) {
        }

    }

    /**
     * Clear Cache
     */
    public void clearCache(boolean isTemp) {
        File[] files;
        File file;
        try {
            file = isTemp ? new File(getCachePath(AppContext.getContext()) + File.separator
                    + "images_temp") : getCacheStorage(AppContext.getContext());
            if (file.exists()) {
                files = file.listFiles();
                for (File child : files) {
                    child.delete();
                }
                file.delete();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
