package com.ddlad.student.protocol.http.response;

import java.io.Serializable;
import java.util.List;

public class LooseListResponse<T> implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 6764211085156147771L;

    private List<T> mList;

    private String mNextCursorId;

    private boolean mHasMore;

    public List<T> getList() {
        return mList;
    }

    public void setList(List<T> mList) {
        this.mList = mList;
    }

    public String getNextCursorId() {
        return mNextCursorId;
    }

    public void setNextCursorId(String mNextCursorId) {
        this.mNextCursorId = mNextCursorId;
    }

    public boolean getHasMore() {
        return mHasMore;
    }

    public void setHasMore(boolean mHasMore) {
        this.mHasMore = mHasMore;
    }

}
