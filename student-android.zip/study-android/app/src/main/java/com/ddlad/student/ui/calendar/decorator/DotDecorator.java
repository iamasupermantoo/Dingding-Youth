package com.ddlad.student.ui.calendar.decorator;

import com.ddlad.student.primary.AppContext;
import com.ddlad.student.tools.CollectionUtil;
import com.ddlad.student.ui.calendar.spans.DotSpan;
import com.ddlad.student.R;
import com.ddlad.student.ui.calendar.calendarview.CalendarDay;
import com.ddlad.student.ui.calendar.calendarview.DayViewFacade;

import java.util.HashSet;
import java.util.List;

/**
 * Created by Albert
 * on 16-8-25.
 */
public class DotDecorator implements DayViewDecorator {

    private int mMonth;
    private HashSet mDotedDays;

    public DotDecorator(int month, List<Integer> days) {
        mMonth = month;
        mDotedDays = new HashSet(days);
    }

    @Override
    public boolean shouldDecorate(CalendarDay calendarDay) {
        return (mMonth == calendarDay.getMonth()) &&
                (CollectionUtil.isEmpty(mDotedDays) ? false : mDotedDays.contains(calendarDay.getDay()));
    }

    @Override
    public void decorate(DayViewFacade dayViewFacade) {
        dayViewFacade.addSpan(new DotSpan(8, AppContext.getColor(R.color.gray)));
    }
}
