package com.ddlad.student.ui.homework;

import com.ddlad.student.R;
import com.ddlad.student.ui.common.BaseFragment;

/**
 * Created by Administrator on 2017/3/17 0017.
 */
public class HomeWorkListFragment extends BaseFragment {

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_job_list;
    }

}
