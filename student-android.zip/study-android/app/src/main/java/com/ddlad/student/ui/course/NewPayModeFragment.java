package com.ddlad.student.ui.course;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.alipay.sdk.app.AuthTask;
import com.alipay.sdk.app.PayTask;
import com.tencent.mm.sdk.modelpay.PayReq;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.ddlad.student.primary.Prefs;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.request.PayOrderInfoRequest;
import com.ddlad.student.protocol.http.request.PayParamsRequest;
import com.ddlad.student.protocol.model.PayOrderInfo;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.account.NewOrderMangerFragment;
import com.ddlad.student.ui.attendclass.AttendClassFragment;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.wxapi.WechatHelper;
import com.ddlad.student.AliPay.AuthResult;
import com.ddlad.student.AliPay.PayResult;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.model.PayParamsInfo;


import java.util.Map;


/**
 * Created by Administrator on 2017/3/17 0017.
 */
public class NewPayModeFragment extends BaseFragment {

    private int mChannel = -1;
    public static boolean isUpdate = false;

    private ViewGroup mZFBPay;
    private ViewGroup mWXPay;
    private TextView mPayAmount;
    private TextView mConfirmPay;
    private TextView course_name;

    private PayParamsInfo mParamInfo;
    private String mTrade;
    private String mCourseName;

    private int mPayOrderInfoId =  ViewUtil.generateUniqueId();
    private int mWxPayOrderInfoId =  ViewUtil.generateUniqueId();
    private int mAliPayOrderInfoId =  ViewUtil.generateUniqueId();


    /////WX
    private static final int MY_WX_PAY = 222;
    private IWXAPI api;
    private PayParamsInfo mWXInfo;
    private WechatHelper mWechatHelper;

    /////支付宝
    private String mAliPayOrderInfo;

    private static final int SDK_PAY_FLAG = 1;
    private static final int SDK_AUTH_FLAG = 2;

    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {
        @SuppressWarnings("unused")
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SDK_PAY_FLAG: {
                    @SuppressWarnings("unchecked")
                    PayResult payResult = new PayResult((Map<String, String>) msg.obj);
                    /**
                     对于支付结果，请商户依赖服务端的异步通知结果。同步通知结果，仅作为支付结束的通知。
                     */
                    String resultInfo = payResult.getResult();// 同步返回需要验证的信息
                    String resultStatus = payResult.getResultStatus();
                    // 判断resultStatus 为9000则代表支付成功
                    if (TextUtils.equals(resultStatus, "9000")) {
                        // 该笔订单是否真实支付成功，需要依赖服务端的异步通知。
                        //进入验证页面去和服务器验证是否支付成功
//                        navigateToPayResult();
                        NewOrderMangerFragment.isPay = true;
                        if (!AttendClassFragment.isHasCourse){
                            AttendClassFragment.isNeedRequest = true;
                        }
                        getActivity().onBackPressed();

                        Toast.makeText(getActivity(), "支付成功", Toast.LENGTH_SHORT).show();
                    } else {
                        // 该笔订单真实的支付结果，需要依赖服务端的异步通知。
                        Toast.makeText(getActivity(), "支付失败", Toast.LENGTH_SHORT).show();
                    }
                    break;
                }
                case SDK_AUTH_FLAG: {
                    @SuppressWarnings("unchecked")
                    AuthResult authResult = new AuthResult((Map<String, String>) msg.obj, true);
                    String resultStatus = authResult.getResultStatus();

                    // 判断resultStatus 为“9000”且result_code
                    // 为“200”则代表授权成功，具体状态码代表含义可参考授权接口文档
                    if (TextUtils.equals(resultStatus, "9000") && TextUtils.equals(authResult.getResultCode(), "200")) {
                        // 获取alipay_open_id，调支付时作为参数extern_token 的value
                        // 传入，则支付账户为该授权账户
                        Toast.makeText(getActivity(),
                                "授权成功\n" + String.format("authCode:%s", authResult.getAuthCode()), Toast.LENGTH_SHORT)
                                .show();
                    } else {
                        // 其他状态值则为授权失败
                        Toast.makeText(getActivity(),
                                "授权失败" + String.format("authCode:%s", authResult.getAuthCode()), Toast.LENGTH_SHORT).show();

                    }
                    break;
                }
                default:
                    break;
            }
        };
    };

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == MY_WX_PAY) {
                mWXInfo = (PayParamsInfo) msg.obj;
                mWechatHelper = new WechatHelper();
                api = WXAPIFactory.createWXAPI(getActivity(), mWechatHelper.getAppId(),false);
                boolean login = api.registerApp(mWechatHelper.getAppId());
                Log.i(TAG, "handleMessage: login is Success???"+login);
                PayReq request = new PayReq();
                request.packageValue = mWXInfo.getParams().getWeiXin().getPackageStr();
                request.appId = mWXInfo.getParams().getWeiXin().getAppid();
                request.sign= mWXInfo.getParams().getWeiXin().getSign();
                request.partnerId = mWXInfo.getParams().getWeiXin().getPartnerid();
                request.prepayId= mWXInfo.getParams().getWeiXin().getPrepayid();
                request.nonceStr= mWXInfo.getParams().getWeiXin().getNoncestr();
                request.timeStamp= mWXInfo.getParams().getWeiXin().getTimestamp();
                boolean sucess = api.sendReq(request);
                Log.i(TAG, "handleMessage: sendreq is Success???"+sucess);
                //退出当前支付方式页面
            }
            super.handleMessage(msg);
        }
    };


    @Override
    public void onPause() {
        super.onPause();
//        getActivity().onBackPressed();

    }

    @Override
    public void onResume() {
        super.onResume();
        if (isUpdate){
            getActivity().onBackPressed();
        }
        hideKeyboard();
    }

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_pay_mode;
    }

    @Override
    protected void onInitView(View contentView) {

        mActionbar.setTitle("支付");

        mZFBPay = (ViewGroup) contentView.findViewById(R.id.zfb_pay);
        mWXPay = (ViewGroup) contentView.findViewById(R.id.wx_pay);
        mPayAmount = (TextView) contentView.findViewById(R.id.payment_amount);
        mConfirmPay = (TextView) contentView.findViewById(R.id.confirm_pay);
        course_name = (TextView) contentView.findViewById(R.id.course_name);
        mZFBPay.setOnClickListener(this);
        mWXPay.setOnClickListener(this);
        mConfirmPay.setOnClickListener(this);

        course_name.setText(mCourseName+"");
        int yuan = mPrice/100;

        int fen = mPrice%100;

        if (fen == 0){
            mPayAmount.setText(yuan+"");
        }else {
            mPayAmount.setText(yuan+"."+fen+"");
        }
    }

    private String mSubId;
    private int mType;
    private int mPrice;
    @Override
    protected void onInitData(Bundle bundle) {
        super.onInitData(bundle);
        mSubId = bundle.getString("sub");
        mCourseName = bundle.getString("coursename");
        mType = bundle.getInt("type");
        mPrice = bundle.getInt("price");
        Prefs.getInstance().mPrefs.edit().putString("sub",mSubId).commit();
//        getPayOrderInfo();
    }


    private void getPayOrderInfo() {
        PayOrderInfoRequest request = new PayOrderInfoRequest(this, mPayOrderInfoId, new AbstractCallbacks<PayOrderInfo>() {
            @Override
            protected void onSuccess(PayOrderInfo payOrderInfo) {
                float money = (float) (payOrderInfo.getInfo().getTotalPrice()/100.00);
                mPayAmount.setText(money+"");
            }
        });
//        request.perform("111",0);
        request.perform(mSubId,"0");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.zfb_pay:
                mZFBPay.setSelected(true);
                mWXPay.setSelected(false);
                mChannel = 1;
//                aliPayRequest();

                break;
            case R.id.wx_pay:
                mWXPay.setSelected(true);
                mZFBPay.setSelected(false);
                mChannel = 0;
//                wxRequest();
                break;
            case R.id.confirm_pay:
                payRequest();
                break;

        }
        super.onClick(v);
    }

    private void payRequest() {
//        ExpertDetailsFragment.isUpdate = true;
        if (mChannel == 0){
            wxRequest();
        }else if (mChannel == 1){
            aliPayRequest();
        }
    }


    private void wxRequest() {
        //请求预支付id
        PayParamsRequest request = new PayParamsRequest(this, mWxPayOrderInfoId, new AbstractCallbacks<PayParamsInfo>() {
            @Override
            protected void onSuccess(PayParamsInfo payParamsInfo) {
                mParamInfo = payParamsInfo;
                SharedPreferences sp = (SharedPreferences ) PreferenceManager.getDefaultSharedPreferences(getActivity());
                sp.edit().putString("orderstr",payParamsInfo.getParams().getWeiXin().getPrepayid()).commit();
                sp.edit().putString("ordersn",payParamsInfo.getParams().getOrderSn()).commit();
                Prefs.getInstance().mPrefs.edit().putInt("channel",0).commit();
                NewOrderMangerFragment.mOrderSn = payParamsInfo.getParams().getOrderSn();
                NewOrderMangerFragment.mChannel = 0;
                Message message = Message.obtain();
                message.what = MY_WX_PAY;
                message.obj = payParamsInfo;
                handler.sendMessage(message);
            }

            @Override
            protected void onFail(ApiResponse<PayParamsInfo> response) {
                Toaster.toastShort(response.getErrorDescription());
            }
        });
        request.perform(mSubId,mType,0);
//        request.perform("123",0,0);

//        WxpayRequest requestWx = new WxpayRequest(this, getDefaultLoaderId(), new AbstractCallbacks<WxpayOrderInfo>() {
//            @Override
//            protected void onSuccess(WxpayOrderInfo wxpayOrderInfo) {
//                Log.i(TAG, "onSuccess: 获取微信预支付网络数据成功");
////                mWXInfo = wxpayOrderInfo.getInfo();
////                mWechatHelper = new WechatHelper();
////                api = WXAPIFactory.createWXAPI(getActivity(), mWechatHelper.getAppId());
////                api.registerApp(mWechatHelper.getAppId());
////
////                PayReq request = new PayReq();
////                request.appId = mWXInfo.getAppid();
////                request.partnerId = mWXInfo.getPartnerid();
////                request.prepayId= mWXInfo.getPrepayid();
////                request.packageValue = "Sign=WXPay";
////                request.nonceStr= mWXInfo.getNoncestr();
////                request.timeStamp= mWXInfo.getTimestamp();
////                request.sign= mWXInfo.getSign();
////                api.sendReq(request);
//                ////////////////////////
//                Message message = Message.obtain();
//                message.what = 222;
//                message.obj = wxpayOrderInfo.getInfo();
//                handler.sendMessage(message);
//            }
//
//            @Override
//            protected void onFail(ApiResponse<WxpayOrderInfo> response) {
//
//                Log.i(TAG, "onFail:获取微信预支付网络数据失败------失败 ");
//            }
//        });
//        requestWx.perform();
    }

    private void aliPayRequest() {

        //请求预支付id
        PayParamsRequest request = new PayParamsRequest(this, mAliPayOrderInfoId, new AbstractCallbacks<PayParamsInfo>() {
            @Override
            protected void onSuccess(PayParamsInfo payParamsInfo) {
                mParamInfo = payParamsInfo;
                mAliPayOrderInfo = payParamsInfo.getParams().getAlipay().getOrderStr();
                Prefs.getInstance().mPrefs.edit().putString("ordersn",payParamsInfo.getParams().getOrderSn()).commit();
                Prefs.getInstance().mPrefs.edit().putInt("channel",1).commit();
                mTrade = payParamsInfo.getParams().getAlipay().getOrderStr();
                NewOrderMangerFragment.mOrderSn = payParamsInfo.getParams().getOrderSn();
                NewOrderMangerFragment.mChannel = 1;

                Runnable payRunnable = new Runnable() {
                    @Override
                    public void run() {
                        PayTask alipay = new PayTask(getActivity());
                        Map<String, String> result = alipay.payV2(mAliPayOrderInfo, true);
                        Log.i("msp", result.toString());

                        Message msg = new Message();
                        msg.what = SDK_PAY_FLAG;
                        msg.obj = result;
                        mHandler.sendMessage(msg);
                    }
                };
                // 必须异步调用
                Thread payThread = new Thread(payRunnable);
                payThread.start();
            }

            @Override
            protected void onFail(ApiResponse<PayParamsInfo> response) {
                Toaster.toastShort(response.getErrorDescription());
            }
        });
        request.perform(mSubId,mType,1);
//        request.perform("123",1,1);
//        AliPayActionRequest aliPayRequest = new AliPayActionRequest(this, mDefaultLoaderId, new AbstractCallbacks<AlipayOrderInfo>() {
//            @Override
//            protected void onSuccess(final AlipayOrderInfo info) {
//                Log.i(TAG, "onSuccess: 请求支付宝OrderId成功");
//                mAliPayOrderInfo = info.getOrderStr();
//                Toast.makeText(getActivity(), info.getOrderStr(), Toast.LENGTH_SHORT).show();
//
//                Runnable payRunnable = new Runnable() {
//                    @Override
//                    public void run() {
//                        PayTask alipay = new PayTask(getActivity());
//                        Map<String, String> result = alipay.payV2(mAliPayOrderInfo, true);
//                        Log.i("msp", result.toString());
//
//                        Message msg = new Message();
//                        msg.what = SDK_PAY_FLAG;
//                        msg.obj = result;
//                        mHandler.sendMessage(msg);
//                    }
//                };
//                // 必须异步调用
//                Thread payThread = new Thread(payRunnable);
//                payThread.start();
//            }
//        });
//        aliPayRequest.perform();
    }


    /**
     * 支付宝账户授权业务
     *
     * @param v
     */
    public void authV2(View v) {
        /**
         * 这里只是为了方便直接向商户展示支付宝的整个支付流程；所以Demo中加签过程直接放在客户端完成；
         * 真实App里，privateKey等数据严禁放在客户端，加签过程务必要放在服务端完成；
         * 防止商户私密数据泄露，造成不必要的资金损失，及面临各种安全风险；
         *
         * authInfo的获取必须来自服务端；
         */
        Runnable authRunnable = new Runnable() {

            @Override
            public void run() {
                // 构造AuthTask 对象
                AuthTask authTask = new AuthTask(getActivity());
                // 调用授权接口，获取授权结果
                //此处应为AuthorInfo 由于不清楚服务器返回的数据，暂时写为malipayinfo
                Map<String, String> result = authTask.authV2(mAliPayOrderInfo, true);

                Message msg = new Message();
                msg.what = SDK_AUTH_FLAG;
                msg.obj = result;
                mHandler.sendMessage(msg);
            }
        };
        // 必须异步调用
        Thread authThread = new Thread(authRunnable);
        authThread.start();
    }

    /**
     * get the sdk version. 获取支付宝SDK版本号
     *
     */
    public void getSDKVersion() {
        PayTask payTask = new PayTask(getActivity());
        String version = payTask.getVersion();
        Toast.makeText(getActivity(), version, Toast.LENGTH_SHORT).show();
    }

    public static boolean checkAliPayInstalled(Context context) {

        Uri uri = Uri.parse("alipays://platformapi/startApp");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        ComponentName componentName = intent.resolveActivity(context.getPackageManager());
        return componentName != null;
    }

    private void navigateToPayResult() {
        Bundle bundle = new Bundle();
        bundle.putString("ordersn",mParamInfo.getParams().getOrderSn());
        bundle.putInt("channel",mChannel);
        bundle.putString("trade",mParamInfo.getParams().getAlipay().getOrderStr());
        bundle.putString("sub",mSubId);
//        NavigateUtil.navigateToDetailActivity(getActivity(), new ExpertDetailsFragment(), bundle);
        getActivity().onBackPressed();
    }



}
