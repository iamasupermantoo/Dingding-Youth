package com.ddlad.student.ui.choice;

import android.app.Activity;
import android.net.Uri;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageView;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.model.BannerInfo;
import com.ddlad.student.protocol.model.DiscoverTeacherInfo;
import com.ddlad.student.protocol.model.GoToPage;
import com.ddlad.student.ui.widget.image.NetworkImageView;
import com.facebook.drawee.view.SimpleDraweeView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Albert
 * on 16-10-13.
 */
public class DiscoverPagerAdapter extends PagerAdapter {

    protected Activity mActivity;

    private ArrayList<DiscoverTeacherInfo.TeachersBean.ListBean> mInfos;

    public DiscoverPagerAdapter(Activity activity) {
        mActivity = activity;
    }

    public DiscoverPagerAdapter(Activity activity, List<BannerInfo> list) {
        mActivity = activity;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
//        container.removeView((View) object);
    }

    @Override
    public void finishUpdate(View arg0) {
    }

    @Override
    public int getCount() {
        if (mInfos != null && mInfos.size()>0) {
            return mInfos.size();
        }
//        if (mImageList != null) {
//            return Integer.MAX_VALUE;
//        }
        return 0;
    }

    public void setData(ArrayList<DiscoverTeacherInfo.TeachersBean.ListBean> list) {
        mInfos = list;
    }

    @Override
    public Object instantiateItem(ViewGroup viewGroup, int position) {

        View view =  LayoutInflater.from(mActivity).inflate(R.layout.layout_discover_teacher_item,null,false);

        ViewParent viewParent = view.getParent();
        if (viewParent!=null){
            ViewGroup parent = (ViewGroup)viewParent;
            parent.removeView(view);
        }

        TextView teacher_name = (TextView) view.findViewById(R.id.teacher_name);
        TextView teacher_age = (TextView) view.findViewById(R.id.teacher_age);
        TextView teacher_desc = (TextView) view.findViewById(R.id.teacher_desc);
        com.facebook.drawee.view.SimpleDraweeView mImage = (SimpleDraweeView) view.findViewById(R.id.item_image);

        teacher_name.setText(mInfos.get(position).getName());
        teacher_age.setText(mInfos.get(position).getHours()+"岁");
        teacher_desc.setText(mInfos.get(position).getDesc());
        if (mInfos.get(position).getImage() != null){
            String url =  mInfos.get(position).getImage().getPattern();
            Uri uri = Uri.parse(url.substring(url.indexOf("http"),url.indexOf("@{w}w")));
            mImage.setImageURI(uri);
        }

        ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        viewGroup.addView(view, lp);

        return view;
    }

    @Override
    public boolean isViewFromObject(View arg0, Object arg1) {
        return (arg0 == arg1);
    }

    @Override
    public void restoreState(Parcelable arg0, ClassLoader arg1) {

    }

    @Override
    public Parcelable saveState() {
        return null;
    }

    @Override
    public void startUpdate(View arg0) {

    }

}
