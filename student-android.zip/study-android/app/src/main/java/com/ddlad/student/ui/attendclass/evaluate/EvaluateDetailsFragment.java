package com.ddlad.student.ui.attendclass.evaluate;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.protocol.convert.DataCenter;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.request.EvaluateDetailsRequest;
import com.ddlad.student.protocol.http.request.EvaluateSubmitRequest;
import com.ddlad.student.protocol.model.EvaluateDetailsInfo;
import com.ddlad.student.protocol.model.MetaInfo;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.ui.attendclass.lesson.LessonFragment;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.dialog.DialogBuilder;
import com.ddlad.student.ui.widget.image.CircleImageView;

/**
 * Created by Administrator on 2017/3/17 0017.
 */
public class EvaluateDetailsFragment extends BaseFragment {


    private boolean mselect = true;

    private EvaluateDetailsInfo mInfo;
    private String mCid;
    private String mLid;

    //date+time
    private TextView mCourseTime;

    private TextView mCourseName;
    private TextView mCourseAddress;
    private TextView mStudentName;
    private TextView mTeacherName;
    private TextView mEvaluateTeacherText;
    private RadioGroup mQualityRG;
    private RadioGroup mAcceptanceRG;
    private com.ddlad.student.ui.widget.RattingBar.RatingBar mStar;
    private EditText mRemark;
    private CircleImageView mTeacherHeadImage;
    private RadioButton mRadio1;
    private RadioButton mRadio2;
    private RadioButton mRadio3;
    private RadioButton mRadio4;
    private RadioButton mRadioAcceptance1;
    private RadioButton mRadioAcceptance2;
    private RadioButton mRadioAcceptance3;
    private RadioButton mRadioAcceptance4;

    private Button mSubmit;
    private int mAcceptanceValue = 4;
    private int mRadioValue = 4;
    private int mStartNum =0;



    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_evaluate_details;
    }

    @Override
    protected void onInitView(View contentView) {
        mActionbar.setTitle("评价");
        mActionbar.setLeftButtonOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog();
            }
        });
        mCourseTime = (TextView) contentView.findViewById(R.id.evaluate_attend_class_time);
        mCourseAddress = (TextView) contentView.findViewById(R.id.evaluate_course_address);
        mCourseName = (TextView) contentView.findViewById(R.id.evaluate_course_name);
        mStudentName = (TextView) contentView.findViewById(R.id.evaluate_student_name);
        mTeacherName = (TextView) contentView.findViewById(R.id.evaluate_teacher_name);
        mEvaluateTeacherText = (TextView) contentView.findViewById(R.id.evaluate_teacher_set_text);
        mQualityRG = (RadioGroup) contentView.findViewById(R.id.evaluate_quality_rg);
        mAcceptanceRG = (RadioGroup) contentView.findViewById(R.id.evaluate_acceptance_rg);
        mStar = (com.ddlad.student.ui.widget.RattingBar.RatingBar) contentView.findViewById(R.id.evaluate_rating_bar);
        mRemark = (EditText) contentView.findViewById(R.id.evaluate_remark);
        mTeacherHeadImage = (CircleImageView) contentView.findViewById(R.id.evaluate_teacher_head_image);

        mRadio1 = (RadioButton) contentView.findViewById(R.id.radio_1);
        mRadio2 = (RadioButton) contentView.findViewById(R.id.radio_2);
        mRadio3 = (RadioButton) contentView.findViewById(R.id.radio_3);
        mRadio4 = (RadioButton) contentView.findViewById(R.id.radio_4);

        mRadioAcceptance1 = (RadioButton) contentView.findViewById(R.id.acceptance_radio_1);
        mRadioAcceptance2 = (RadioButton) contentView.findViewById(R.id.acceptance_radio_2);
        mRadioAcceptance3 = (RadioButton) contentView.findViewById(R.id.acceptance_radio_3);
        mRadioAcceptance4 = (RadioButton) contentView.findViewById(R.id.acceptance_radio_4);

        mSubmit = (Button) contentView.findViewById(R.id.evaluate_submit);
        mSubmit.setOnClickListener(this);

        mAcceptanceRG.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.acceptance_radio_1:
                        mAcceptanceValue = 4;
                        break;
                    case R.id.acceptance_radio_2:
                        mAcceptanceValue = 3;
                        break;
                    case R.id.acceptance_radio_3:
                        mAcceptanceValue = 2;
                        break;
                    case R.id.acceptance_radio_4:
                        mAcceptanceValue = 1;
                        break;
                }
            }
        });
        mQualityRG.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.radio_1:
                        mRadioValue = 4;
                        break;
                    case R.id.radio_2:
                        mRadioValue = 3;
                        break;
                    case R.id.radio_3:
                        mRadioValue = 2;
                        break;
                    case R.id.radio_4:
                        mRadioValue = 1;
                        break;
                }
            }
        });
        mStar.setOnRatingChangeListener(new com.ddlad.student.ui.widget.RattingBar.RatingBar.OnRatingChangeListener() {
            @Override
            public void onRatingChange(float ratingCount) {
                mStartNum = (int) ratingCount;
            }
        });
    }


    @Override
    protected void onInitData(Bundle bundle) {
        super.onInitData(bundle);
        requestData();
    }

    @Override
    public void onResume() {

        super.onResume();


    }



    private void showDialog() {
        final DialogBuilder dialogBuilder = new DialogBuilder(getActivity());

        dialogBuilder.setCanceledOnTouchOutside(false);
        dialogBuilder.setTitle("提示")
                .setMessage("确定放弃评价?")
                .setMessageGravity(Gravity.CENTER)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogBuilder.dismiss();
                        getActivity().onBackPressed();
                    }
                })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialogBuilder.dismiss();
                    }
                });

        dialogBuilder.create().show();
    }


    private void requestData() {
        startLoading();
        mLid = (String) getArguments().get("lid");
        mCid = (String) getArguments().get("cid");
        EvaluateDetailsRequest request = new EvaluateDetailsRequest(this, getDefaultLoaderId(), new AbstractCallbacks<EvaluateDetailsInfo>() {
            @Override
            protected void onSuccess(EvaluateDetailsInfo evaluateListInfo) {

                mInfo = evaluateListInfo;
                Log.i(TAG, "onSuccess: 请求成功oooooooooooooooooooooo");
                stopLoading();
                refreshData();
            }

            @Override
            protected void onFail(ApiResponse<EvaluateDetailsInfo> response) {

                Log.i(TAG, "onFail: 请求失败^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                stopLoading();
            }
        });
        request.perform(mCid,mLid);
    }

    @Override
    public void onPause() {
        hideKeyboard();
        super.onPause();
    }

    private void refreshData() {
        if (mInfo != null) {
//            mActionbar.setTitle(mInfo.getReaction().getTeacher());
            mCourseTime.setText(mInfo.getReaction().getDate() + "  " + mInfo.getReaction().getTime());
//            mCourseAddress 设置地址
            mCourseName.setText(mInfo.getReaction().getCourse());
            mTeacherName.setText(mInfo.getReaction().getTeacher());
            mStudentName.setText(DataCenter.getUser().getName()+"");
//            mEvaluateTeacherText.setText("----------请为" + mInfo.getReaction().getTeacher() + "老师打分----------");
            mEvaluateTeacherText.setText("请为" + mInfo.getReaction().getTeacher() + "老师打分");
//            String url =  mInfo.getReaction().getTeacherHeadImg().getPattern();
//            mTeacherHeadImage.setUrl(url.substring(url.indexOf("http"),url.indexOf("@{w}w")));
            String url =  mInfo.getReaction().getTeacherHeadImg().getImageSmall();
            mTeacherHeadImage.setUrl(url);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.evaluate_submit:
                //提交数据
                mHandler.postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        jumpToEvaluate();
                    }
                }, 800);

                Log.i(TAG, "submit??????????????????????????????"+mRadioValue);
                Log.i(TAG, "submit??????????????????????????????"+mAcceptanceValue);
                Log.i(TAG, "submit??????????????????????????????"+mRemark.getText().toString());
                Log.i(TAG, "submit??????????????????????????????cid"+mCid);
                Log.i(TAG, "submit??????????????????????????????cidlid"+mLid);
                EvaluateSubmitRequest submitRequest = new EvaluateSubmitRequest(this, getDefaultLoaderId(), new AbstractCallbacks<MetaInfo>() {
                    @Override
                    protected void onSuccess(MetaInfo info) {
                        LessonFragment.isNeedRefresh = true;
                        Log.i(TAG, "onSuccess: 评价提交成功------------------------------------");
                        Toaster.toastShort("评价提交成功",1);
//                        jumpToEvaluate();
                    }

                    @Override
                    protected void onFail(ApiResponse<MetaInfo> response) {
                        Log.i(TAG, "onFail: 评价提交失败！！！！");
                        Toaster.toastShort(response.getErrorDescription());
                    }
                });
                submitRequest.perform(mRadioValue,mAcceptanceValue,mRemark.getText().toString(),mStartNum,mCid,mLid);
                break;
        }
    }

    private void jumpToEvaluate() {
        getActivity().onBackPressed();
//        NavigateUtil.navigateToNormalActivity(getActivity(),new EvaluateFragment(),null);
    }


}
