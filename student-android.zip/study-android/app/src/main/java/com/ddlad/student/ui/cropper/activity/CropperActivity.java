package com.ddlad.student.ui.cropper.activity;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;


import com.ddlad.student.primary.AppContext;
import com.ddlad.student.primary.Log;
import com.ddlad.student.tools.FileUtil;
import com.ddlad.student.tools.LibWebpUtil;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.tools.Util;
import com.ddlad.student.ui.cropper.tool.CropHelper;
import com.ddlad.student.ui.cropper.tool.CropperImageInfo;
import com.ddlad.student.ui.cropper.tool.CropperViewTouchEvent;
import com.ddlad.student.ui.cropper.widget.CropperView;
import com.ddlad.student.R;
import com.ddlad.student.task.BaseAsyncTask;

import java.io.InputStream;
import java.io.OutputStream;

public class CropperActivity extends FragmentActivity implements OnClickListener,
        CropperViewTouchEvent {

    private static final String TAG = "CropperActivity";

    private static final int DEFAULT_ASPECT_RATIO_VALUES = 10;

    private static final String ASPECT_RATIO_X = "ASPECT_RATIO_X";

    private static final String ASPECT_RATIO_Y = "ASPECT_RATIO_Y";

    // 裁减比例
    private int mAspectRatioX = DEFAULT_ASPECT_RATIO_VALUES;

    private int mAspectRatioY = DEFAULT_ASPECT_RATIO_VALUES;

    private Double mLatitude;

    private Double mLongitude;

    private int mOutputX;

    private int mOutputY;

    private Bitmap.CompressFormat mOutputFormat = LibWebpUtil.getDefaultFormat();

    /**
     * 存储图片的位置
     */
    private Uri mOutputUri;

    //    private Bitmap InputBitmap;

    private CropperImageInfo mFetchImageInfo;

    private Uri mImageUri;

    private final Handler mHandler = new Handler();

    private SaveCropperImageTask mSaveImageTask;

    private Bitmap mCroppedImage;

    private FetchImageTask mFetchImageTask;

    private ContentResolver mContentResolver;

    public static final String EXTRAS_LATITUDE = "EXTRAS_LATITUDE";

    public static final String EXTRAS_LONGITUDE = "EXTRAS_LONGITUDE";

    private ImageView mCropOverlayView;

    private ImageView mFullImageButton;

    private Button mCancelButton;

    private Button mOkButton;

    private boolean isFullImage = false;

    private CropperView mCropperView;

    // Saves the state upon rotating the screen/restarting the activity
    @Override
    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt(ASPECT_RATIO_X, mAspectRatioX);
        bundle.putInt(ASPECT_RATIO_Y, mAspectRatioY);
    }

    // Restores the state upon rotating the screen/restarting the activity
    @Override
    protected void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        mAspectRatioX = bundle.getInt(ASPECT_RATIO_X);
        mAspectRatioY = bundle.getInt(ASPECT_RATIO_Y);
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);

        setContentView(R.layout.activity_cropper);

        mCropOverlayView = (ImageView) findViewById(R.id.crop_overlay_view);
        mCropOverlayView.getLayoutParams().height = AppContext.getScreenWidth();
        mCropOverlayView.getLayoutParams().width = AppContext.getScreenWidth();
        mFullImageButton = (ImageView) findViewById(R.id.transparent_place);
        mFullImageButton.setOnClickListener(this);
        mCropperView = (CropperView) findViewById(R.id.cropper);
        mCropperView.setCropperViewTouchEvent(this);
        mCancelButton = (Button) findViewById(R.id.cancel);
        mOkButton = (Button) findViewById(R.id.ok);

        mContentResolver = getContentResolver();

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();

        mImageUri = intent.getData();
        if (mImageUri == null) {
            Toaster.toastShort(R.string.crop_uri_null);
            finish();
            return;
        }

        if (extras != null) {

            if (extras.containsKey(MediaStore.EXTRA_OUTPUT)) {
                mOutputUri = extras.getParcelable(MediaStore.EXTRA_OUTPUT);
            }
            //图片格式
            String outputFormatString = extras.getString("outputFormat");
            if (!TextUtils.isEmpty(outputFormatString)) {
                mOutputFormat = Bitmap.CompressFormat.valueOf(outputFormatString);
            }
            //裁剪框的比例，1：1  
            mAspectRatioX = extras.getInt("aspectX");
            mAspectRatioY = extras.getInt("aspectY");
            //裁剪后输出图片的尺寸大小
            mOutputX = extras.getInt("outputX");
            mOutputY = extras.getInt("outputY");
        }

        bindClickEvent();

        if (mFetchImageTask == null
                || mFetchImageTask.getStatus().equals(AsyncTask.Status.FINISHED)) {
            mFetchImageTask = new FetchImageTask();
            mFetchImageTask.originalExecute();
        }
    }

    private void bindClickEvent() {

        mCancelButton.setOnClickListener(new OnClickListener() {

            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });

        mOkButton.setOnClickListener(new OnClickListener() {

            public void onClick(View v) {
                saveCroppedImage();
            }
        });
    }

    private class FetchImageTask extends BaseAsyncTask<Void, Void, CropperImageInfo> {

        @Override
        protected CropperImageInfo doInBackground(Void... params) {
            return fetchImage(mImageUri);
        }

        @Override
        protected void onPostExecute(CropperImageInfo fetchImageInfo) {
            super.onPostExecute(fetchImageInfo);

            if (fetchImageInfo == null || fetchImageInfo.getBitmap() == null) {
                Toaster.toastShort(R.string.crop_fetch_bitmap);
                finish();
                return;
            }

            mCropperView.setImageBitmap(fetchImageInfo);
        }

    }

    private CropperImageInfo fetchImage(Uri uri) {

        CropperImageInfo fetchImageInfo = null;

        InputStream is = null;

        try {

            is = mContentResolver.openInputStream(uri);
            // 得到屏幕的宽和高
            int windowWidth = AppContext.getScreenWidth();
            int windowHeight = AppContext.getScreenHeight();

            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inJustDecodeBounds = true;

            BitmapFactory.decodeStream(is, null, opts);
            int bitmapWidth = opts.outWidth;
            int bitmapHeight = opts.outHeight;

            // 比较原图大小和屏幕宽高，大于屏幕的图片，将缩小显示到屏幕宽度
            if (bitmapHeight > windowHeight || bitmapWidth > windowWidth) {
                float scaleX = 1f * bitmapWidth / windowWidth;
                float scaleY = 1f * bitmapHeight / windowHeight;
                opts.inSampleSize = (int) Math.max(scaleX, scaleY);

            }

            FileUtil.closeSilently(is);

            opts.inJustDecodeBounds = false;
            is = mContentResolver.openInputStream(uri);

            Bitmap bitmap = BitmapFactory.decodeStream(is, null, opts);

            fetchImageInfo = new CropperImageInfo();
            fetchImageInfo.setBitmap(bitmap);
            fetchImageInfo.setHeight(bitmap.getHeight());
            fetchImageInfo.setWidth(bitmap.getWidth());

            fetchLocationData(uri);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            FileUtil.closeSilently(is);
        }

        return fetchImageInfo;

    }

    private void fetchLocationData(Uri uri) {

        try {

            String[] projection = new String[]{MediaStore.Images.Media.LATITUDE,
                    MediaStore.Images.Media.LONGITUDE};

            Cursor cursor = mContentResolver.query(uri, projection, null, null, null);

            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    if (!cursor.isNull(0)) {
                        mLatitude = Double.valueOf(cursor.getDouble(0));
                    }

                    if (!cursor.isNull(1)) {
                        mLongitude = Double.valueOf(cursor.getDouble(1));
                    }

                    if (Log.DEBUG) {
                        if (mLatitude == null) {
                            Log.d(TAG, "lat lon null");
                        }
                        Log.d(TAG, "lat " + mLatitude + " lon " + mLongitude);
                    }
                }
                cursor.close();
            }

        } catch (Exception e) {
            Log.e(TAG, "Exception caught getting location data", e);
        }
    }

    /*
     *  If there are GPS info in Exif of JPG, it can be read using ExifInterface.getAttribute(). 
     *  Refer to the source code in last post, Read Exif of JPG file using ExifInterface.
     *  TAG_GPS_LATITUDE and TAG_GPS_LONGITUDE return String in format of "num1/denom1,num2/denom2,num3/denom3". 
     *  It can be converted to degree using folowing method:
     *  Latitude (TAG_GPS_LATITUDE)= 22/1,16/1,5935883/125557= 22/1 + 16/(1*60) + 5935883/(125557*3600)= 22 + 0.266666666667 + 0.0131323334333= 22.2797990001
     *  if TAG_GPS_LATITUDE_REF == "N", it's positive; otherwise it's negative.
     *  Longitude (TAG_GPS_LONGITUDE)= 114/1,7/1,1429891026/483594097= 114/1 + 7/(1*60) + 1429891026/(483594097*3600)= 114 + 0.116666666667 + 0.000821333333328= 114.117488
     *  if TAG_GPS_LONGITUDE_REF == "E", it's positive; otherwise it's negative.
     *  
     *  eg: exif.mLatitude=39/1,58/1,57042/1000, exif.mLongitude=116/1,29/1,10353/1000
    */
    private Double convertToDegree(String stringDMS) {
        if (TextUtils.isEmpty(stringDMS)) {
            return null;
        }

        String[] DMS = stringDMS.split(",", 3);

        String[] stringD = DMS[0].split("/", 2);
        Double D0 = Double.valueOf(stringD[0]);
        Double D1 = Double.valueOf(stringD[1]);
        Double FloatD = D0 / D1;

        String[] stringM = DMS[1].split("/", 2);
        Double M0 = Double.valueOf(stringM[0]);
        Double M1 = Double.valueOf(stringM[1]);
        Double FloatM = M0 / M1;

        String[] stringS = DMS[2].split("/", 2);
        Double S0 = Double.valueOf(stringS[0]);
        Double S1 = Double.valueOf(stringS[1]);
        Double FloatS = S0 / S1;

        return Double.valueOf(FloatD + (FloatM / 60) + (FloatS / 3600));
    }

    private void saveCroppedImage() {

        mCroppedImage = mCropperView.getCroppedImage();
        mCroppedImage = CropHelper.transform(new Matrix(), mCroppedImage, mOutputX, mOutputY, true,
                CropHelper.RECYCLE_INPUT);

        if (mSaveImageTask == null || mSaveImageTask.getStatus().equals(AsyncTask.Status.FINISHED)) {
            mSaveImageTask = new SaveCropperImageTask() {

                @Override
                protected void onPostExecute(Void result) {
                    super.onPostExecute(result);

                    mHandler.post(new Runnable() {

                        public void run() {
                            if (mFetchImageInfo != null && mFetchImageInfo.getBitmap() != null
                                    && !mFetchImageInfo.getBitmap().isRecycled()) {
                                mFetchImageInfo.getBitmap().recycle();
                            }

                            if (mCroppedImage != null && !mCroppedImage.isRecycled()) {
                                mCroppedImage.recycle();
                            }

                        }
                    });

                    finish();
                }
            };
            mSaveImageTask.originalExecute();
        }
    }

    private class SaveCropperImageTask extends BaseAsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {

            String imagePath = null;

            if (mImageUri != null && !TextUtils.isEmpty(mImageUri.getPath())) {
                imagePath = mImageUri.getPath();
            }

            saveOutput(mCroppedImage);

            return null;
        }

    }

    private void addLocationExtras(Bundle bundle) {
        if ((mLatitude != null) && (mLongitude != null)) {
            bundle.putDouble(EXTRAS_LATITUDE, mLatitude.doubleValue());
            bundle.putDouble(EXTRAS_LONGITUDE, mLongitude.doubleValue());
        }
    }

    private void saveOutput(final Bitmap croppedImage) {

        OutputStream outputStream = null;

        try {

            long storageAvailableSize = FileUtil.getStorageAvailableSize();

            if (Util.IO_BUFFER_SIZE > storageAvailableSize) {
                mHandler.post(new Runnable() {

                    @Override
                    public void run() {
                        Toaster.toastShort(R.string.no_space);
                    }
                });
            }

            outputStream = mContentResolver.openOutputStream(mOutputUri);

            if (outputStream != null) {
                croppedImage.compress(mOutputFormat, 75, outputStream);
            }

        } catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, "Cannot open file: " + mOutputUri, e);
        } finally {
            FileUtil.closeSilently(outputStream);
        }

        Bundle extras = new Bundle();
        addLocationExtras(extras);
        setResult(RESULT_OK, new Intent(mOutputUri.toString()).putExtras(extras));

        if (Log.DEBUG) {
            Log.i(TAG, "mOutputUri=" + mOutputUri);
        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.transparent_place:
                isFullImage = !isFullImage;
                mCropperView.setFullImageAction(isFullImage);
                if (isFullImage) {
                    mFullImageButton.setSelected(Boolean.TRUE);
                } else {
                    mFullImageButton.setSelected(Boolean.FALSE);
                }
                break;

            default:
                break;
        }
    }

    @Override
    public void onTouchEventDown() {
        mFullImageButton.setEnabled(Boolean.FALSE);
        mCancelButton.setEnabled(Boolean.FALSE);
        mOkButton.setEnabled(Boolean.FALSE);
    }

    @Override
    public void onTouchEventUp() {
        mFullImageButton.setEnabled(Boolean.TRUE);
        mCancelButton.setEnabled(Boolean.TRUE);
        mOkButton.setEnabled(Boolean.TRUE);
    }

}
