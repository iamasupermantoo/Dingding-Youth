package com.ddlad.student.protocol.http.request;

import android.graphics.Bitmap;
import android.net.Uri;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.Account;
import com.ddlad.student.protocol.model.UserInfo;
import com.ddlad.student.protocol.http.request.SignUpRequest;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.wxapi.WechatAccount;

/**
 * Created by Albert
 * on 16-10-26.
 */
public class WechatSignUpRequest extends SignUpRequest {

    public WechatSignUpRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<Account> apiCallbacks) {
        super(fragment, loaderId, apiCallbacks);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_WECHAT_SIGN_UP;
    }

    public void perform(UserInfo user, Bitmap head) {
        perform(user.getMobile(), user.getName(), user.getPassword(), user.getType(), user.getCode(), user.getSignature(), head);
    }

    public void perform(Object mobile, Object name, Object password, Object userType, Object code, Object signature, Bitmap head) {
        mBitmap = head;
        WechatAccount wechatAccount = WechatAccount.get();
        RequestParams params = getMultipartParams();
        params.put("externalUserId", wechatAccount.getOpenId());
        params.put("accessToken", wechatAccount.getAccessToken());
        params.put("refreshToken", wechatAccount.getRefreshToken());
        params.put("mobile", mobile);
        params.put("name", name);
        params.put("password", password);
        params.put("userType", userType);
        params.put("code", code);
        params.put("signature", signature);
        super.perform();
    }

    @Override
    public void perform(Object mobile, Object name, Object password, Object userType, Object code, Object signature, Uri headImage) {
        mUri = headImage;
        WechatAccount wechatAccount = WechatAccount.get();
        RequestParams params = getMultipartParams();
        params.put("externalUserId", wechatAccount.getOpenId());
        params.put("accessToken", wechatAccount.getAccessToken());
        params.put("refreshToken", wechatAccount.getRefreshToken());
        params.put("mobile", mobile);
        params.put("name", name);
        params.put("password", password);
        params.put("userType", userType);
        params.put("code", code);
        params.put("signature", signature);
        super.perform();
    }
}
