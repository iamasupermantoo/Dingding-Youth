package com.ddlad.student.ui.account;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.primary.AppContext;
import com.ddlad.student.protocol.model.CoursesLiveBean;



/**
 * Created by Albert
 * on 17-6-2.
 */

public class WithdrawalsCashListItemAdapter {

    private WithdrawalsCashRecordFragment fragment;

    public WithdrawalsCashListItemAdapter(WithdrawalsCashRecordFragment fragment){
        this.fragment = fragment;
    }

    public View createView(ViewGroup viewGroup) {

        View view = View.inflate(viewGroup.getContext(), R.layout.layout_withdrawals_item, null);

        ViewHolder holder = new ViewHolder(view);


        view.setTag(holder);

        return view;
    }


    public void bindView(View view, final CoursesLiveBean info, final int totalPageCount, final int position,final int type) {

        if (info == null) {
            return;
        }

        final ViewHolder holder = (ViewHolder) view.getTag();

        if (holder == null) {
            return;
        }

        holder.withdrawals_state.setText(info.getTitle());
        holder.withdrawals_state.setTextColor(Color.parseColor("#333333"));
        holder.withdrawals_state.setTextColor(Color.parseColor("#ff5b5b"));
        holder.withdrawals_state.setTextColor(Color.parseColor("#5abe47"));
        holder.withdrawals_date.setText(info.getTitle());
        holder.cash_num.setText(info.getTitle());


    }



    private static class ViewHolder {

        TextView withdrawals_state;
        TextView withdrawals_date;
        TextView cash_num;

        public ViewHolder(View view){
            withdrawals_state = (TextView) view.findViewById(R.id.withdrawals_state);
            withdrawals_date = (TextView) view.findViewById(R.id.withdrawals_date);
            cash_num = (TextView) view.findViewById(R.id.cash_num);

        }
    }

}
