package com.ddlad.student.timer;

import java.util.Timer;

/**
 * Created by Albert
 * on 16-10-18.
 */
public class TimerController {

    private static Timer sTimer;

    private static boolean sActive;

    private static ValuedTimerTask sTask;

    public static void schedule(ValuedTimerTask task) {
        initTimer();
        sTask = task;
        sTimer.schedule(task, task.getDelay(), task.getPeriod());
    }

    public static boolean isActive() {
        return sActive;
    }

    public static String taskTag() {
        return sTask == null ? null : sTask.getTag();
    }

    public static String taskValue() {
        return sTask == null ? null : String.valueOf(sTask.getValue() / 1000);
    }

    public static void setListener(TimerListener listener) {
        if (sTask != null) {
            sTask.setListener(listener);
        }
    }

    private static void cancel() {
        if (sActive) {
            sTimer.cancel();
        }
    }

    private static void purge() {
        if (sActive) {
            sTimer.purge();
            sTimer = null;
            sTask = null;
            sActive = false;
        }
    }

    public static void release() {
        cancel();
        purge();
    }

    private static void initTimer() {
        if (sTimer == null) {
            sTimer = new Timer();
            sActive = true;
        } else if (sActive) {
            sTimer.cancel();
        }
    }
}
