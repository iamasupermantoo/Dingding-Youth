package com.ddlad.student.protocol.http.request;


import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.PayResultInfo;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.protocol.http.internal.ApiResponse;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by boge on 2017/3/2.
 */

public class PayResultRequest extends AbstractRequest<PayResultInfo> {
    public PayResultRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<PayResultInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return "pay/verify";
    }

    @Override
    public PayResultInfo processInBackground(ApiResponse<PayResultInfo> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA,PayResultInfo.class);
    }

    public void perform(String orderSn,int channel) {
        RequestParams params = getParams();
        params.put("orderSn", orderSn);
        params.put("channel", channel);
//        params.put("trade", trade);
        super.perform();
    }
}
