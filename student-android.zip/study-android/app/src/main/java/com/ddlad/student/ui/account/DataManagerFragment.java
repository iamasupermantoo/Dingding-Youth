package com.ddlad.student.ui.account;

import android.view.View;
import android.widget.TextView;

import com.ddlad.student.R;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.image.CircleImageView;

/**
 * Created by Administrator on 2017/3/16 0016.
 */
public class DataManagerFragment extends BaseFragment {

    private CircleImageView mHeadPortrait;
    private TextView mHome;
    private TextView mName;
    private TextView mSex;
    private TextView mGrade;
    private TextView mSign;

    private boolean enable = true;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_data_manager;
    }

    @Override
    protected void onInitView(View contentView) {

        mActionbar.setTitle("资料");
        mActionbar.setRightText("修改");

        mGrade = (TextView) contentView.findViewById(R.id.grade);
        mHome = (TextView) contentView.findViewById(R.id.home);
        mHeadPortrait = (CircleImageView) contentView.findViewById(R.id.head_protrait);
        mName = (TextView) contentView.findViewById(R.id.name);
        mSex = (TextView) contentView.findViewById(R.id.sex);
        mSign = (TextView) contentView.findViewById(R.id.sign);


        mActionbar.setRightButtonOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enable = !enable;
                mActionbar.setRightText(enable?"修改":"完成");
                setOnClickListener();
            }
        });



        super.onInitView(contentView);
    }

    private void setOnClickListener() {
        if (enable){
            return;
        }
        mGrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        mHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        mHeadPortrait.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        //////////////////////////////////
        mSign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        mSex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        mName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
    }
}
