package com.ddlad.student.protocol.http.request;

import android.text.TextUtils;


import com.ddlad.student.protocol.http.request.AbstractStreamingRequest;
import com.fasterxml.jackson.core.JsonParser;
import com.ddlad.student.protocol.http.callbacks.AbstractStreamingCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ApiUrlHelper;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.internal.StreamingApiResponse;
import com.ddlad.student.protocol.http.response.AbstractListResponse;
import com.ddlad.student.protocol.model.BaseInfo;
import com.ddlad.student.ui.common.BaseListFragment;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

public abstract class
BaseListRequest<T extends BaseInfo> extends AbstractStreamingRequest<AbstractListResponse<T>> {


    private BaseListFragment mFragment;

    public BaseListRequest(BaseListFragment baseListFragment, int loaderId,
                           AbstractStreamingCallbacks<AbstractListResponse<T>> streamingApiCallbacks) {
        super(baseListFragment.getLoaderManager(), loaderId, streamingApiCallbacks);

        mFragment = baseListFragment;
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParams) {
        return httpClient.getRequest(url, requestParams);
    }

    @Override
    public HttpUriRequest getRequest() {
        if (mRequest == null) {
            mRequest = buildRequest(ApiHttpClient.getInstance(), ApiUrlHelper.expandPath(getPath(),
                            isSecure(), isExpandApiVersionPath(), ApiUrlHelper.API_VERSION),
                    getParams());
        }

        if (mFragment.getRequestTimeStamp() != 0 && isClearOnAdd()) {
            mRequest.addHeader(ProtocolConstants.PARAM_X_TIMESTAMP,
                    String.valueOf(mFragment.getRequestTimeStamp()));
        } else {
            mRequest.removeHeaders(ProtocolConstants.PARAM_X_TIMESTAMP);
        }

        return mRequest;
    }

    protected abstract String getBasePath();

    protected String getLocationString() {
        return "";
    }

    protected String getNextCursorIdString() {
        if (isClearOnAdd()) {
            return "";
        }

        String lastId = mFragment == null ? null : mFragment.getNextCursorId();
        try {
            return TextUtils.isEmpty(lastId) ? "" : String.format("&%s=%s",
                    ProtocolConstants.PARAM_CURSOR, URLEncoder.encode(lastId, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        return null;
    }

    protected String getCountString() {
        int count = mFragment.getItemCountPerPage();
        return String.format("?%s=%s", ProtocolConstants.PARAM_COUNT, count > 0 ? count : 20);
    }

    @Override
    protected String getPath() {
        return String.format("%s%s%s%s", getBasePath(), getCountString(),
                getNextCursorIdString(), getLocationString());
    }

    @Override
    public void processResponseField(String fieldName, JsonParser jsonParser,
                                     StreamingApiResponse<AbstractListResponse<T>> streamingApiResponse) throws IOException {

        AbstractListResponse response = streamingApiResponse.getSuccessObject();
        if (response == null) {
            response = new AbstractListResponse() {

                @Override
                public BaseInfo getModelInfo(JsonParser jsonParser) {

                    try {
                        return T.fromJsonParser(jsonParser);
                    } catch (Throwable t) {
                        t.printStackTrace();
                    }

                    return null;
                }
            };
        }

        response.parse(jsonParser, ProtocolConstants.JSON_FIELD_RESULT);
        streamingApiResponse.setSuccessObject(response);
    }
}
