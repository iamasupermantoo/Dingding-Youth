package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.model.GetChargeItemInfo;
import com.ddlad.student.protocol.model.ShareWxIssueInfo;
import com.ddlad.student.ui.common.BaseFragment;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by Administrator on 2017/1/19 0019.
 */

public class ScholarWxShareRequest extends AbstractRequest<ShareWxIssueInfo> {
    public ScholarWxShareRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<ShareWxIssueInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.getRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return "scholarship/share";
    }

    @Override
    public ShareWxIssueInfo processInBackground(ApiResponse<ShareWxIssueInfo> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, ShareWxIssueInfo.class);
    }

    public void perform(String lm,String cid) {
        RequestParams params = getParams();
        params.put("lm", lm);
        params.put("cid", cid);
        super.perform();
    }
    public void perform(String cid) {
        RequestParams params = getParams();
        params.put("cid", cid);
        super.perform();
    }
}
