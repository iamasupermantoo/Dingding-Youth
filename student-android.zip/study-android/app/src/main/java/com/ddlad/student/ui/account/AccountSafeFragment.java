package com.ddlad.student.ui.account;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.tencent.connect.UserInfo;
import com.tencent.connect.auth.QQToken;
import com.tencent.connect.common.Constants;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.Tencent;
import com.tencent.tauth.UiError;
import com.ddlad.student.protocol.convert.DataCenter;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.http.request.ConnectBindListRequest;
import com.ddlad.student.protocol.http.request.ConnectLoginRequest;
import com.ddlad.student.protocol.http.request.UnbindRequest;
import com.ddlad.student.protocol.http.request.UserBindRequest;
import com.ddlad.student.protocol.model.Account;
import com.ddlad.student.protocol.model.OkBindListInfo;
import com.ddlad.student.protocol.model.PayParamsInfo;
import com.ddlad.student.protocol.model.UserBindListInfo;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.tools.Toaster;
import com.ddlad.student.tools.ViewUtil;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.ui.widget.dialog.DialogBuilder;
import com.ddlad.student.wxapi.WechatAccount;
import com.ddlad.student.wxapi.WechatHelper;
import com.ddlad.student.R;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.ui.sign.SignInFragment;
import com.zhy.http.okhttp.OkHttpUtils;
import com.zhy.http.okhttp.callback.StringCallback;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.Call;

/**
 * Created by Administrator on 2017/3/17 0017.
 */
public class AccountSafeFragment extends BaseFragment {

    private int mBindListRequestId = ViewUtil.generateUniqueId();
    private int mConnectBindRequestId = ViewUtil.generateUniqueId();
    private int mUnBindRequestId = ViewUtil.generateUniqueId();
    private int mABindListRequestId = ViewUtil.generateUniqueId();
//    private int mBindListRequestId = ViewUtil.generateUniqueId();


    public static SignInFragment.SignType signType = SignInFragment.SignType.Mobile;

    public static IWXAPI api;
    //初始化Tencent
    public Tencent mTencent;

    public static String externalUserId;

    public static String nickName;

    public static String accessToken;

    private Bitmap bitmap = null;

    public static String nicknameString;

    private WechatHelper mWechatHelper;

    private BaseUiListener baseUiListener;

    protected int mQQLoaderId = ViewUtil.generateUniqueId();


    private ViewGroup mResetPassword;
    private TextView mBindPhone;
    private TextView mBindQQ;
    private TextView mBindWX;

    private TextView mPhoneNumber;
    private TextView mQQName;
    private TextView mWXName;
    private TextView mResetBindWx;
    private TextView mResetBindQQ;
    private TextView mResetBindPhone;

    private OkBindListInfo mInfo;

    @Override
    protected int getLayoutResource() {
        return R.layout.fragment_bind_account;
    }

    @Override
    protected void onInitView(View contentView) {

        mActionbar.setTitle("账户安全");

        api = WXAPIFactory.createWXAPI(getActivity(), "wxeedfa061ec4d68c0",true);
        api.registerApp("wxeedfa061ec4d68c0");

        mResetPassword = (ViewGroup) contentView.findViewById(R.id.reset_password_layout);
//        mBindPhone = (ViewGroup) contentView.findViewById(R.id.bind_phone_layout);
//        mBindQQ = (ViewGroup) contentView.findViewById(R.id.bind_qq_layout);
//        mBindWX = (ViewGroup) contentView.findViewById(R.id.bind_wx_layout);
        mPhoneNumber = (TextView) contentView.findViewById(R.id.phone_number);
        mQQName = (TextView) contentView.findViewById(R.id.qq_name);
        mWXName = (TextView) contentView.findViewById(R.id.wx_name);

        mBindQQ = (TextView) contentView.findViewById(R.id.bind_qq_btn);
        mResetBindQQ = (TextView) contentView.findViewById(R.id.reset_bind_qq_btn);
        mBindWX = (TextView) contentView.findViewById(R.id.bind_wx_btn);
        mResetBindWx = (TextView) contentView.findViewById(R.id.reset_bind_wx_btn);
        setOnclickListener();
    }



    private void setOnclickListener() {
        mResetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToResetPassword();
            }
        });
        mBindQQ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                onBindAccount();
                QQlogin();
            }
        });
        mBindWX.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startLoading();
                authorizeWechat();
            }
        });
        ////////////////////////解绑//////////////////////////////////////
        mResetBindQQ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(1);
            }
        });
        mResetBindWx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(2);
            }
        });
    }

    private void unBindRequest(int type) {
        UnbindRequest request = new UnbindRequest(this, mUnBindRequestId, new AbstractCallbacks<PayParamsInfo>() {
            @Override
            protected void onSuccess(PayParamsInfo payParamsInfo) {
                Toaster.toastShort("解绑成功");
                requestData();
            }
        });
        request.perform(type);
    }


    public void onBindAccount(String nickname,int type,String externaluserId,String accesstoken) {
        UserBindRequest request = new UserBindRequest(this, mConnectBindRequestId, new AbstractCallbacks<String>() {
            @Override
            protected void onSuccess(String s) {
                Toaster.toastShort("绑定成功");
                requestData();
            }

            @Override
            protected void onFail(ApiResponse<String> response) {
                Toaster.toastShort(response.getErrorDescription());
            }
        });
        request.perform(nickname,type,externaluserId,accesstoken,"");
    }

    @Override
    protected void onInitData(Bundle bundle) {

        mWechatHelper = new WechatHelper();
        requestData();
    }

    public void okRequest(){
        String urlstring = "http://api."+ ProtocolConstants.DOMAIN+"/connect/bind/list?z="+ DataCenter.getAccount().getZ();
        OkHttpUtils
                .get()
                .url(urlstring)
                .build()
                .execute(new StringCallback() {
                    @Override
                    public void onError(Call call, Exception e, int id) {

                    }

                    @Override
                    public void onResponse(String response, int id) {
                        mInfo = JSON.parseObject(response,OkBindListInfo.class);
                        if (mInfo.getData().getMobile() != null && mInfo.getData().getMobile().getAccount() != null){
                            mPhoneNumber.setText(mInfo.getData().getMobile().getAccount());
                        }else {
                            mPhoneNumber.setVisibility(View.INVISIBLE);
                        }
                        if (mInfo.getData().getQQ() != null && mInfo.getData().getQQ().getAccount() != null){
                            mQQName.setText(mInfo.getData().getQQ().getAccount());
                            mQQName.setVisibility(View.VISIBLE);
                            mResetBindQQ.setVisibility(View.VISIBLE);
                            mBindQQ.setVisibility(View.GONE);
                        }else {
                            mQQName.setVisibility(View.INVISIBLE);
                            mResetBindQQ.setVisibility(View.GONE);
                            mBindQQ.setVisibility(View.VISIBLE);
                        }
                        if (mInfo.getData().getWeiXin() != null && mInfo.getData().getWeiXin().getAccount() != null){
                            mWXName.setText(mInfo.getData().getWeiXin().getAccount());
                            mWXName.setVisibility(View.VISIBLE);
                            mBindWX.setVisibility(View.GONE);
                            mResetBindWx.setVisibility(View.VISIBLE);
                        }else {
                            mWXName.setVisibility(View.INVISIBLE);
                            mBindWX.setVisibility(View.VISIBLE);
                            mResetBindWx.setVisibility(View.GONE);
                        }
                    }
                });
    }

    public void bindListRequest(){

        ConnectBindListRequest request1 = new ConnectBindListRequest(this, mBindListRequestId, new AbstractCallbacks<UserBindListInfo>() {
            @Override
            protected void onSuccess(UserBindListInfo userBindList) {
//                if (userBindList.getMobile() != null && userBindList.getMobile().getAccount() != null){
//                    mPhoneNumber.setText(userBindList.getMobile().getAccount());
//                }
//                if (userBindList.getQQ() != null && userBindList.getQQ().getAccount() != null){
//                    mQQName.setText(userBindList.getQQ().getAccount());
//                }
//                if (userBindList.getWeiXin() != null && userBindList.getWeiXin().getAccount() != null){
//                    mWXName.setText(userBindList.getWeiXin().getAccount());
//                }
                if (userBindList != null){

                }
                ////////////////////////////////////////////
//                if (userBindList.getMobile() != null && userBindList.getMobile().getAccount() != null){
//                    mPhoneNumber.setVisibility(View.VISIBLE);
//                    mPhoneNumber.setText(userBindList.getMobile().getAccount());
//                }else {
//                    mPhoneNumber.setVisibility(View.INVISIBLE);
//                }
//                if (userBindList.getQQ() != null && userBindList.getQQ().getAccount() != null){
//                    mQQName.setText(userBindList.getQQ().getAccount());
//                    mQQName.setVisibility(View.VISIBLE);
//                    mResetBindQQ.setVisibility(View.VISIBLE);
//                    mBindQQ.setVisibility(View.GONE);
//                }else {
//                    mQQName.setVisibility(View.INVISIBLE);
//                    mResetBindQQ.setVisibility(View.GONE);
//                    mBindQQ.setVisibility(View.VISIBLE);
//                }
//                if (userBindList.getWeiXin() != null && userBindList.getWeiXin().getAccount() != null){
//                    mWXName.setText(userBindList.getWeiXin().getAccount());
//                    mWXName.setVisibility(View.VISIBLE);
//                    mBindWX.setVisibility(View.GONE);
//                    mResetBindWx.setVisibility(View.VISIBLE);
//                }else {
//                    mWXName.setVisibility(View.INVISIBLE);
//                    mBindWX.setVisibility(View.VISIBLE);
//                    mResetBindWx.setVisibility(View.GONE);
//                }
            }
        });
        request1.perform();
    }
    private void requestData() {

//        UserBindListRequest request = new UserBindListRequest(this, mABindListRequestId, new AbstractCallbacks<NewUserBindListInfo>() {
//            @Override
//            protected void onSuccess(NewUserBindListInfo newAccountSafeInfo) {
//                if (newAccountSafeInfo != null){
//
//                }
//            }
//        });
//        request.perform();
        okRequest();
//        bindListRequest();


    }

    @Override
    public void onPause() {
        super.onPause();
        stopLoading();
    }

    @Override
    public void onResume() {
        super.onResume();
        //        wechatOnResume();
        if (signType == SignInFragment.SignType.QQ){
            requestData();
            stopLoading();
        }
        if (signType == SignInFragment.SignType.Wechat){
//            requestData();
            wechatOnResume();
            stopLoading();
        }
    }


    /////////////////////////////qq登陆
    private void QQlogin() {
        startLoading();
        signType = SignInFragment.SignType.QQ;
        mTencent = Tencent.createInstance( "1106222016" ,getActivity());
        baseUiListener = new BaseUiListener();
        mTencent.login(getActivity(),"all", baseUiListener);
    }

    private class BaseUiListener implements IUiListener {

        @Override
        public void onComplete(Object response) {

            try {
                externalUserId = ((JSONObject) response).getString("openid");
                accessToken = ((JSONObject)response).optString("access_token");
                mTencent.setAccessToken(accessToken, ((JSONObject)response).optString("expires_in"));
                mTencent.setOpenId(externalUserId);
                QQToken mQQToken = mTencent.getQQToken();
                UserInfo userInfo = new UserInfo(getActivity(), mQQToken);
                userInfo.getUserInfo(new IUiListener() {
                    @Override
                    public void onComplete(Object o) {
                        JSONObject userInfoJson = (JSONObject) o;
                        try {
                            nickName = userInfoJson.getString("nickname");
                            onBindAccount(nickName,1,externalUserId,accessToken);
//                            getQQLoginData(externalUserId,accessToken);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(UiError uiError) {

                    }

                    @Override
                    public void onCancel() {

                    }
                });

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        @Override
        public void onError(UiError uiError) {

        }
        @Override
        public void onCancel() {

        }
    }

///////////////////微信登录
    private void authorizeWechat() {

        if (getActivity() == null) {
            return;
        }

        signType = SignInFragment.SignType.Wechat;

        if (mWechatHelper.authorize(getActivity())) {
            startLoading();
        }
    }


    private void wechatOnResume() {
        if (signType == SignInFragment.SignType.Wechat) {
            if (WechatAccount.isAccessed()) {
                WechatAccount.setAccessed(false);
                startLoading();
                mWechatHelper.signWechat(this);
            } else {
                stopLoading();
            }
        }
    }

    public void setWxName(String name){
        if (name != null){
            mWXName.setText(name);
        }
        mWXName.setVisibility(View.VISIBLE);
        mBindWX.setVisibility(View.GONE);
        mResetBindWx.setVisibility(View.VISIBLE);
    }

    private void getQQLoginData(final String externalUserId , final String accessToken) {
        ConnectLoginRequest request = new ConnectLoginRequest(this, mQQLoaderId,
                new AbstractCallbacks<Account>() {

                    @Override
                    protected void onSuccess(Account account) {
                        requestData();
                    }

                    @Override
                    protected void onFail(ApiResponse<Account> response) {
                        Toaster.toastShort(response.getErrorDescription());
                    }
                });
        request.perform(externalUserId,1);

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == Constants.REQUEST_LOGIN) {

            if (resultCode == -1) {
                mTencent.onActivityResultData(requestCode, resultCode, data, baseUiListener);
                mTencent.handleResultData(data, baseUiListener);

            }

        }

    }

    private void showDialog(final int type) {
        final DialogBuilder dialogBuilder = new DialogBuilder(getActivity());

        dialogBuilder.setCanceledOnTouchOutside(false);
        dialogBuilder.setTitle("提示")
                .setMessage("确定取消绑定?")
                .setMessageGravity(Gravity.CENTER)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogBuilder.dismiss();
                        unBindRequest(type);
                    }
                })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialogBuilder.dismiss();
                    }
                });

        dialogBuilder.create().show();
    }


    private void navigateToResetPassword() {
        NavigateUtil.navigateToNormalActivity(getActivity(), new ResetPasswordFragment(), null);
    }
}
