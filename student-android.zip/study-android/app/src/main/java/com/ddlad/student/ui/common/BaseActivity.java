package com.ddlad.student.ui.common;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

import com.ddlad.student.ui.listener.OnInterceptKeyListener;
import com.umeng.analytics.MobclickAgent;
import com.ddlad.student.R;
import com.ddlad.student.primary.ClickManager;
import com.ddlad.student.tools.NavigateUtil;
import com.ddlad.student.tools.StatusBarUtil;
import com.ddlad.student.tools.StringUtil;
import com.ddlad.student.ui.widget.actionbar.Actionbar;

import java.util.List;

/**
 * Base activity for udan
 *
 * @author Albert
 */
public abstract class BaseActivity extends FragmentActivity implements View.OnClickListener {

    public static final String ARGUMENT_EXTRA_FRAGMENT_NAME = "com.ddlad.student.primary.activity.ARGUMENT_EXTRA_FRAGMENT_NAME";

    public static final String ARGUMENT_EXTRA_NO_ANIMATION = "com.ddlad.student.primary.activity.ARGUMENT_EXTRA_NO_ANIMATION";

    public static final String ARGUMENT_EXTRA_ANIMATION_UP = "com.ddlad.student.primary.activity.ARGUMENT_EXTRA_ANIMATION_UP";

    public static final String ARGUMENT_EXTRA_ANIMATION_CUSTOM = "com.ddlad.student.primary.activity.ARGUMENT_EXTRA_ANIMATION_CUSTOM";

    public static final String ARGUMENT_EXTRA_ANIMATION_FADE = "com.ddlad.student.primary.activity.ARGUMENT_EXTRA_ANIMATION_FADE";

    public static final String ARGUMENTS_ENTER_ANIMATION = "com.ddlad.student.primary.activity.ARGUMENTS_ENTER_ANIMATION";

    public static final String ARGUMENTS_EXIT_ANIMATION = "com.ddlad.student.primary.activity.ARGUMENTS_EXIT_ANIMATION";

    public static final String ARGUMENTS_FULL_SCREEN = "com.ddlad.student.primary.activity.ARGUMENTS_FULL_SCREEN";

    public static final String ACTION_SIGN_IN = "com.ddlad.student.action.sign.in";

    public static final String ACTION_PUBLISH_ARTICLE = "com.ddlad.student.primary.action.publish.article";

    public static final String ACTION_EDIT_IMAGE = "com.ddlad.student.action.primary.publish.edit.image";

    public static final String ACTION_PUBLISH_IMAGE = "com.ddlad.student.primary.action.publish.image";

    public static final String ACTION_FINISH_ME = "com.ddlad.student.primary.action.finish.me";

    protected boolean mNoAnimation;

    protected String mFragmentClassName;

    protected Handler mHandler = new Handler();

    protected Actionbar mActionbar;

    protected View mLoadingView;

    protected BaseFragment mContentFragment;

    protected ViewGroup mMainContain;

    private OnInterceptKeyListener mOnInterceptKeyListener;

    protected BroadcastReceiver mFinishMe = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            finish();
        }
    };

    public void refresh() {
        if (mContentFragment != null) {
            mContentFragment.onRefresh();
        }
    }

    protected int getLayoutResource() {
        return R.layout.activity_base;
    }

    protected void setContentView() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(getLayoutResource());

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//            Window window =  getWindow();
//            // Translucent status bar
//            window.setFlags(
//                    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,
//                    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//
//        }
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//            Window window = getWindow();
//            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
//                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
//            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
//                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
//                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
//            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
//            window.setStatusBarColor(Color.TRANSPARENT);
//            window.setNavigationBarColor(Color.TRANSPARENT);
//        }


        ViewGroup contentFrameLayout = (ViewGroup) findViewById(Window.ID_ANDROID_CONTENT);
        View parentView = contentFrameLayout.getChildAt(0);
        if (parentView != null && Build.VERSION.SDK_INT >= 14) {
            parentView.setFitsSystemWindows(true);
        }
        mActionbar = (Actionbar) findViewById(R.id.actionbar);
        mLoadingView = findViewById(R.id.loading_view);
        mMainContain = (ViewGroup) findViewById(R.id.layout_container_main);
        StatusBarUtil.statusBarLightMode(this);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        setContentView();

        initContentFragment();

        registerReceiver(mFinishMe, new IntentFilter(ACTION_FINISH_ME));
    }

    public Actionbar getActionbar() {
        return mActionbar;
    }

    public View getLoadingView() {
        return mLoadingView;
    }

    protected BaseFragment initContentFragment() {
        return null;
    }

    protected void startFragment(Fragment fragment) {

        mFragmentClassName = fragment.getClass().getName();

        NavigateUtil.replaceFragment(R.id.layout_container_main, getSupportFragmentManager(),
                fragment, null);
    }

    protected void loadFragment(Fragment fragment, Bundle bundle) {
        if (fragment == null) {
            finish();
        }
        mFragmentClassName = fragment.getClass().getName();
        NavigateUtil.replaceFragment(R.id.layout_container_main, getSupportFragmentManager(),
                fragment, bundle);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();

        MobclickAgent.onResume(this);

        ClickManager.getInstance().setFragmentManager(getSupportFragmentManager());
        ClickManager.getInstance().setCurrentActivity(this);
        ClickManager.getInstance().setHandler(mHandler);
    }

    @Override
    protected void onPause() {
        super.onPause();

        MobclickAgent.onPause(this);

        ClickManager.getInstance().setFragmentManager(null);
        ClickManager.getInstance().setCurrentActivity(null);
        ClickManager.getInstance().setHandler(null);
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        Fragment fragment = getSupportFragmentManager()
                .findFragmentById(R.id.layout_container_main);

        if (fragment != null) {
            fragment.onActivityResult(requestCode, resultCode, data);
        }

        super.onActivityResult(requestCode, resultCode, data);

    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {

        if (mOnInterceptKeyListener != null && mOnInterceptKeyListener.isInterceptKey(event)) {
            return true;
        }

        return super.dispatchKeyEvent(event);
    }


    public void hideKeyboard() {
        InputMethodManager localInputMethodManager = (InputMethodManager) this
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        View currentFocus = getCurrentFocus();
        if (currentFocus != null) {
            localInputMethodManager.hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
        }
    }

    public boolean isAppOnForeground() {

        ActivityManager activityManager = (ActivityManager) getApplicationContext()
                .getSystemService(Context.ACTIVITY_SERVICE);
        String packageName = getApplicationContext().getPackageName();

        List<RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
        if (appProcesses == null) return false;

        for (RunningAppProcessInfo appProcess : appProcesses) {
            if (StringUtil.equalsIgnoreCase(appProcess.processName, packageName)
                    && appProcess.importance == RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                return true;
            }
        }

        return false;
    }

    @Override
    public void onClick(View view) {

    }

    protected void unregister() {
        if (mFinishMe != null) {
            unregisterReceiver(mFinishMe);
            mFinishMe = null;
        }
    }

    @Override
    public void finish() {
        super.finish();

        unregister();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        unregister();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(null != this.getCurrentFocus()){
            /**
             * 点击空白位置 隐藏软键盘
             */
            InputMethodManager mInputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            return mInputMethodManager.hideSoftInputFromWindow(this.getCurrentFocus().getWindowToken(), 0);
        }
        return super.onTouchEvent(event);
    }

    public boolean intercept;

    @Override
    public void onBackPressed() {
        if (intercept){
            return ;
        }
        super.onBackPressed();
    }

}
