package com.ddlad.student.protocol.http.request;

import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.internal.ApiHttpClient;
import com.ddlad.student.protocol.http.internal.RequestParams;
import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.ddlad.student.ui.common.BaseFragment;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.ProtocolConstants;
import com.ddlad.student.protocol.model.PayParamsInfo;

import ch.boye.httpclientandroidlib.client.methods.HttpUriRequest;

/**
 * Created by chenjianing
 * on 17-05-11.
 */
public class UnbindRequest extends AbstractRequest<PayParamsInfo> {


    public UnbindRequest(BaseFragment fragment, int loaderId, AbstractCallbacks<PayParamsInfo> apiCallbacks) {
        super(fragment.getLoaderManager(), loaderId, apiCallbacks);
    }

    @Override
    protected HttpUriRequest buildRequest(ApiHttpClient httpClient, String url, RequestParams requestParam) {
        return httpClient.postRequest(url, requestParam);
    }

    @Override
    protected String getPath() {
        return ProtocolConstants.URL_UNBIND;
    }

    @Override
    public PayParamsInfo processInBackground(ApiResponse<PayParamsInfo> response) {
        return response.readRootValue(ProtocolConstants.JSON_FIELD_DATA, PayParamsInfo.class);
    }

    public void perform(int type) {
        RequestParams params = getParams();
        params.put("type", type);
        super.perform();
    }

}
