package com.ddlad.student.push;

public interface PushClient {

    void bindPush();

    void unbindPush();
}
