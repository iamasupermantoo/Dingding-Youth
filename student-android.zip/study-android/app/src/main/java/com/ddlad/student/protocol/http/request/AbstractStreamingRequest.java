package com.ddlad.student.protocol.http.request;

import android.support.v4.app.LoaderManager;

import com.ddlad.student.protocol.http.request.AbstractRequest;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.ddlad.student.protocol.http.callbacks.AbstractCallbacks;
import com.ddlad.student.protocol.http.callbacks.ApiRequestLoaderCallbacks;
import com.ddlad.student.protocol.http.callbacks.StreamingApiRequestLoaderCallbacks;
import com.ddlad.student.protocol.http.internal.ApiResponse;
import com.ddlad.student.protocol.http.internal.StreamingApiResponse;

import java.io.File;
import java.io.IOException;

public abstract class AbstractStreamingRequest<T> extends AbstractRequest<T> {

    private boolean mNeedCache;

    protected boolean mClearOnAdd;

    public AbstractStreamingRequest(LoaderManager loaderManager, int loaderId,
                                    AbstractCallbacks<T> apiCallbacks) {
        super(loaderManager, loaderId, apiCallbacks);
    }

    public boolean isNeedCache() {
        return mNeedCache;
    }

    /**
     * 缓存设置，除了设置 setNeedCache，还需要在request里重写cacheResponseFile
     */
    public void setNeedCache(boolean needCache) {
        this.mNeedCache = needCache;
    }

    public File cacheResponseFile() {
        return null;
    }

    @Override
    protected ApiRequestLoaderCallbacks<T> constructLoaderCallbacks() {
        return new StreamingApiRequestLoaderCallbacks<T>(mContext, this, mApiCallbacks);
    }

    public void handleErrorInBackground(StreamingApiResponse<T> streamingApiResponse) {
    }

    public void onResponseParsed(StreamingApiResponse<T> streamingApiResponse) {
    }

    @Override
    public T processInBackground(ApiResponse<T> apiResponse) {
        return null;
    }

    public abstract void processResponseField(String fieldName, JsonParser jsonParser,
                                              StreamingApiResponse<T> streamingApiResponse) throws JsonParseException, IOException;

    public boolean isClearOnAdd() {
        return mClearOnAdd;
    }

    public void setClearOnAdd(boolean clearOnAdd) {
        mClearOnAdd = clearOnAdd;
    }

}
