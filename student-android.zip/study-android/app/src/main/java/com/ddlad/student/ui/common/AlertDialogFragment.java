package com.ddlad.student.ui.common;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;

import com.ddlad.student.ui.widget.dialog.DialogBuilder;
import com.ddlad.student.R;

/**
 * Created by Albert
 * on 16-6-2.
 */
public class AlertDialogFragment extends DialogFragment {

    public static AlertDialogFragment newInstance(String message) {
        return newInstance(null, message);
    }

    public static AlertDialogFragment newInstance(String title, String message) {
        AlertDialogFragment alertDialogFragment = new AlertDialogFragment();
        Bundle bundle = new Bundle();
        bundle.putString("message", message);
        bundle.putString("title", title);
        alertDialogFragment.setArguments(bundle);
        return alertDialogFragment;
    }

    public static AlertDialogFragment newInstance(String title, String message, int buttonTextId) {
        AlertDialogFragment alertDialogFragment = new AlertDialogFragment();
        Bundle bundle = new Bundle();
        bundle.putString("message", message);
        bundle.putString("title", title);
        bundle.putInt("button", buttonTextId);
        alertDialogFragment.setArguments(bundle);
        return alertDialogFragment;
    }

    @Override
    public Dialog onCreateDialog(Bundle bundle) {
        Bundle argumentBundle = getArguments();
        String message = argumentBundle.getString("message");
        String title = null;
        int buttonTextId = R.string.cancel;

        if (argumentBundle.containsKey("title")) {
            title = argumentBundle.getString("title");
        }
        if (argumentBundle.containsKey("button")) {
            buttonTextId = argumentBundle.getInt("button");
        }

        DialogBuilder DoradoDialogBuilder = new DialogBuilder(getActivity())
                .setMessage(message);

        if (title != null) {
            DoradoDialogBuilder.setTitle(title);
        }

        return DoradoDialogBuilder.setPositiveButton(buttonTextId,
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).create();
    }
}
