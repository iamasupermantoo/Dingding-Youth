$(document).ready(function() {
	$('.add-chapter').click(function() {
		
	});
	
	$('.remove-chapter').click(function() {
		
	});

});

function add() {

}

function remove() {

}

function update() {

}

function saveCnts() {

}