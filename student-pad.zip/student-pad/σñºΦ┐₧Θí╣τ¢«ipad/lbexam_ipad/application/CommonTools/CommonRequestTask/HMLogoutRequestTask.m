//
//  HMLogoutRequestTask.m
//  UDan
//
//  Created by lilingang on 16/11/5.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMLogoutRequestTask.h"

@implementation HMLogoutRequestTask

- (NSString *)apiName{
    return @"/logout";
}

- (WSHTTPMethod)requestMethod{
    return WSHTTPMethodPOST;
}
@end
