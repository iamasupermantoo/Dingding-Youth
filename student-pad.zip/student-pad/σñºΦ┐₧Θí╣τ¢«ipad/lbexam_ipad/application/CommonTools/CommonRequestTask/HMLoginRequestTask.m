//
//  HMLoginRequestTask.m
//  UDan
//
//  Created by lilingang on 16/9/28.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMLoginRequestTask.h"
#import "HMUserHandler.h"

@implementation HMLoginMobileRequestTask

- (NSString *)apiName{
    if (self.accountType == HMAccountTypeQQ) {
        return @"login/qq";
    } else if (self.accountType == HMAccountTypeWechat){
        return @"login/weixin";
    } else {
        return @"login/mobile";
    }
}

- (WSHTTPMethod)requestMethod{
    return WSHTTPMethodPOST;
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (self.accountType == HMAccountTypeMobile) {
        if (!self.mobile || [self.mobile ddIsEmpty]) {
            return [NSError wsLocalParamErrorKey:@"mobile"];
        }
        
        if (!self.password || [self.password ddIsEmpty]) {
            return [NSError wsLocalParamErrorKey:@"password"];
        }
    } else {
        if (!self.externalUserId || [self.externalUserId ddIsEmpty]) {
            return [NSError wsLocalParamErrorKey:@"externalUserId"];
        }
    }
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    if (self.accountType == HMAccountTypeMobile) {
        [self.parameterDictionary setObject:self.mobile forKey:@"mobile"];
        [self.parameterDictionary setObject:self.password forKey:@"password"];
    } else {
        [self.parameterDictionary setObject:@(self.accountType) forKey:@"type"];
        [self.parameterDictionary setObject:self.externalUserId forKey:@"externalUserId"];
    }
}

- (NSError *)responseHanlderWithDataInfo:(NSDictionary *)info{
    NSError *error = [super responseHanlderWithDataInfo:info];
    if (error) {
        return error;
    }
    [HMUserHandler sharedInstance].ticket = info[@"z"];
    
    [HMUserHandler sharedInstance].userItem = [HMUserItem itemWithDictionary:info[@"user"]];
    
    [[HMUserHandler sharedInstance] saveToLocal];
    return nil;
}

@end

@implementation HMLoginConnectedBindRequestTask

- (NSString *)apiName{
    return @"login/connect";
}

- (WSHTTPMethod)requestMethod{
    return WSHTTPMethodPOST;
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.externalUserId || [self.externalUserId ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"externalUserId"];
    }
    if (self.accountType == HMAccountTypeMobile) {
        return [NSError wsLocalParamErrorKey:@"accountType"];
    }
    if (!self.nickname || [self.nickname ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"nickname"];
    }
    
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:self.externalUserId forKey:@"externalUserId"];
    [self.parameterDictionary setObject:@(self.accountType) forKey:@"type"];
    
    [self.parameterDictionary setObject:self.nickname forKey:@"nickname"];
}


- (NSError *)responseHanlderWithDataInfo:(NSDictionary *)info{
    NSError *error = [super responseHanlderWithDataInfo:info];
    if (error) {
        return error;
    }
    
    // 登陆成功  存储票z 和存储userItem
    [HMUserHandler sharedInstance].ticket = info[@"z"];
    [HMUserHandler sharedInstance].userItem = [HMUserItem itemWithDictionary:info[@"user"]];
    
    [[HMUserHandler sharedInstance] saveToLocal];
    return nil;
}
//- (NSError *)responseHanlderWithDataInfo:(NSDictionary *)info{
//    NSError *error = [super responseHanlderWithDataInfo:info];
//    if (error) {
//        return error;
//    }
//    self.resultObject = info[@"isBinded"];
//    return nil;
//}

@end
