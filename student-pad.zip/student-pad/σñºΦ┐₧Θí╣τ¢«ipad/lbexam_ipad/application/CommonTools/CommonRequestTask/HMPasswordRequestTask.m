//
//  HMPasswordRequestTask.m
//  UDan
//
//  Created by lilingang on 16/9/28.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMPasswordRequestTask.h"

@implementation HMBasePasswordRequestTask

- (NSString *)apiName{
    NSAssert(NO, @"密码设置请求父类不可直接被调用");
    return @"";
}

- (WSHTTPMethod)requestMethod{
    return WSHTTPMethodPOST;
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.mobile || [self.mobile ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"mobile"];
    }
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:self.mobile forKey:@"mobile"];
}

@end

@implementation HMPasswordGetCodeRequestTask

- (NSString *)apiName{
    return @"password/getCode";
}

@end

@implementation HMPasswordResetRequestTask

- (NSString *)apiName{
    return @"password/reset";
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.password || [self.password ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"password"];
    }
    if (!self.code || [self.code ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"code"];
    }
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:self.password forKey:@"password"];
    [self.parameterDictionary setObject:self.code forKey:@"code"];
}

@end
