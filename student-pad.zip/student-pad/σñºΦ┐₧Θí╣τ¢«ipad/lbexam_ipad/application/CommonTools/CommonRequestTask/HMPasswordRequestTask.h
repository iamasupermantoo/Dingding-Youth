//
//  HMPasswordRequestTask.h
//  UDan
//
//  Created by lilingang on 16/9/28.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface HMBasePasswordRequestTask : HMBaseRequestTask

@property (nonatomic, copy) NSString *mobile;

@end

@interface HMPasswordGetCodeRequestTask : HMBasePasswordRequestTask

@end

@interface HMPasswordResetRequestTask : HMBasePasswordRequestTask

@property (nonatomic, copy) NSString *password;
@property (nonatomic, copy) NSString *code;

@end
