//
//  HMRegisterExpandInfoRequestTask.h
//  UDan
//
//  Created by lilingang on 16/10/15.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface HMRegisterExpandInfoRequestTask : HMBaseRequestTask

@property (nonatomic, assign) HMUserType userType;

/** 省份*/
@property (nonatomic, copy) NSString *province;
/** 区*/
@property (nonatomic, copy) NSString *region;
/** 大学*/
@property (nonatomic, copy) NSString *school;
/** 学院*/
@property (nonatomic, copy) NSString *academy;
/** 大学入学年*/
@property (nonatomic, copy) NSString *year;

/**高中*/
@property (nonatomic, copy) NSString *seniorSchool;
/**高中入学年*/
@property (nonatomic, copy) NSString *seniorYear;

@end
