//
//  HMLoginRequestTask.h
//  UDan
//
//  Created by lilingang on 16/9/28.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseRequestTask.h"

#import "HMUserItem.h"

@interface HMLoginMobileRequestTask : HMBaseRequestTask

@property (nonatomic, assign) HMAccountType accountType;

/*账号类型为HMAccountTypeMobile使用下面两个字段*/
@property (nonatomic, copy) NSString *mobile;

@property (nonatomic, copy) NSString *password;

/*账号类型不是HMAccountTypeMobile使用下面一个字段*/
@property (nonatomic, copy) NSString *externalUserId;

@end

@interface HMLoginConnectedBindRequestTask : HMBaseRequestTask

@property (nonatomic, assign) HMAccountType accountType;

/**三方返回的useid*/
@property (nonatomic, copy) NSString *externalUserId;

@property(nonatomic,strong) NSString *nickname;

@end
