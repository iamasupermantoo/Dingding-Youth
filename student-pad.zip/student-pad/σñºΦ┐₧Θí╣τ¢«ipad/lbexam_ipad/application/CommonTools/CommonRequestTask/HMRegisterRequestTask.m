//
//  HMRegisterRequestTask.m
//  UDan
//
//  Created by lilingang on 16/9/28.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMRegisterRequestTask.h"

@implementation HMBaseRegisterRequestTask

- (NSString *)apiName{
    NSAssert(NO, @"注册请求父类不可直接被调用");
    return @"";
}

- (WSHTTPMethod)requestMethod{
    return WSHTTPMethodPOST;
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.mobile || [self.mobile ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"mobile"];
    }
    return nil;
}


- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:self.mobile forKey:@"mobile"];
    if (self.type==1 || self.type == 2) {
        [self.parameterDictionary setObject:@(self.type) forKey:@"type"];
    }
}

@end
// get verify code
@implementation HMRegisterGetCodeRequestTask

- (NSString *)apiName{
    return @"register/getCode";
}

@end

@implementation HMForgetGetCodeRequestTask

- (NSString *)apiName{
    return @"password/getCode";
}

@end

@implementation HMBindGetCodeRequestTask

- (NSString *)apiName{
    return @"connect/getCode";
}


@end

//---------------------------------------------------//
@implementation HMRegisterVerifyCodeRequestTask

- (NSString *)apiName{
    return @"register/verifyCode";
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.code || [self.code ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"code"];
    }
    return nil;
}


- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:self.code forKey:@"code"];
}

@end


@implementation HMForgetVerifyCodeRequestTask

- (NSString *)apiName{
    return @"password/reset";
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.code || [self.code ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"code"];
    }
    if (!self.newpassword || [self.newpassword ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"newpassword"];
    }
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:self.code forKey:@"code"];
    [self.parameterDictionary setObject:self.newpassword forKey:@"password"];
}

@end

@implementation HMNotBindButRegistedRequestTask
- (NSString *)apiName{
    return @"connect/login/bind";
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.code || [self.code ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"code"];
    }
    if (!self.type) {
        return [NSError wsLocalParamErrorKey:@"type"];
    }
    if (!self.externalUserId || [self.externalUserId ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"externalUserId"];
    }
    if (!self.accessToken || [self.accessToken ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"accessToken"];
    }
    
    if (!self.nickname || [self.nickname ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"nickname"];
    }
  
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:self.code forKey:@"code"];
    [self.parameterDictionary setObject:@(self.type) forKey:@"type"];
    [self.parameterDictionary setObject:self.externalUserId forKey:@"externalUserId"];
    [self.parameterDictionary setObject:self.accessToken forKey:@"accessToken"];
    [self.parameterDictionary setObject:self.nickname forKey:@"nickname"];
    if (self.refreshToken) {
         [self.parameterDictionary setObject:self.refreshToken forKey:@"refreshToken"];
    }
    
}


- (NSError *)responseHanlderWithDataInfo:(NSDictionary *)info{
    NSError *error = [super responseHanlderWithDataInfo:info];
    if (error) {
        return error;
    }
    [HMUserHandler sharedInstance].ticket = info[@"z"];
    [HMUserHandler sharedInstance].userItem = [HMUserItem itemWithDictionary:info[@"user"]];
    [[HMUserHandler sharedInstance] saveToLocal];
    return nil;
}

@end

//------------------------------------------------//

@implementation HMRegisterAccountRequstTask

- (WSHTTPMethod)requestMethod{
    return WSHTTPMethodMultipart;
}

- (NSString *)apiName{
    if (self.accountType == HMAccountTypeQQ) {
        return @"/register/qq";
    } else if (self.accountType == HMAccountTypeWechat){
        return @"/register/weixin";
    } else {
        return @"register/mobile";
    }
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.password || [self.password ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"password"];
    }
    if (!self.name || [self.name ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"name"];
    }

    if (self.accountType == HMAccountTypeQQ ||
        self.accountType == HMAccountTypeWechat) {
        if (!self.externalUserId || [self.externalUserId ddIsEmpty]) {
            return [NSError wsLocalParamErrorKey:@"externalUserId"];
        }
        if (!self.accessToken || [self.accessToken ddIsEmpty]) {
            return [NSError wsLocalParamErrorKey:@"accessToken"];
        }
    }
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:self.password forKey:@"password"];
    [self.parameterDictionary setObject:self.name forKey:@"name"];
//    [self.parameterDictionary setObject:@(self.userType) forKey:@"userType"];
    [self.parameterDictionary ddSetSafeObject:self.signature forKey:@"signature"];
    
    if (self.accountType == HMAccountTypeQQ ||
        self.accountType == HMAccountTypeWechat) {
        [self.parameterDictionary setObject:self.externalUserId forKey:@"externalUserId"];
        [self.parameterDictionary setObject:self.accessToken forKey:@"accessToken"];
        [self.parameterDictionary ddSetSafeObject:self.refreshToken forKey:@"refreshToken"];
    }
}



- (WSConstructingBlock)constructingBodyBlock{
    if (!self.headImage) {
        return nil;
    }
    return ^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:UIImageJPEGRepresentation(self.headImage,1.0) name:@"headImage" fileName:@"headImage.jpg" mimeType:@"image/jpeg"];
    };
}


- (NSError *)responseHanlderWithDataInfo:(NSDictionary *)info{
    NSError *error = [super responseHanlderWithDataInfo:info];
    if (error) {
        return error;
    }
    [HMUserHandler sharedInstance].ticket = info[@"z"];
    [HMUserHandler sharedInstance].userItem = [HMUserItem itemWithDictionary:info[@"user"]];
    [[HMUserHandler sharedInstance] saveToLocal];
    return nil;
}

@end

