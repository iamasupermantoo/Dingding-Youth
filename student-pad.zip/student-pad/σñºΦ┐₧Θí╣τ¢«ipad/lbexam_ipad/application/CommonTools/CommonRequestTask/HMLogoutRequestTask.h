//
//  HMLogoutRequestTask.h
//  UDan
//
//  Created by lilingang on 16/11/5.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface HMLogoutRequestTask : HMBaseRequestTask

@end
