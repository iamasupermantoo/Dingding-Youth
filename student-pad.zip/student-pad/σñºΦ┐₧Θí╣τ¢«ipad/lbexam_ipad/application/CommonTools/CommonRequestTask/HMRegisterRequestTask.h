//
//  HMRegisterRequestTask.h
//  UDan
//
//  Created by lilingang on 16/9/28.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface HMBaseRegisterRequestTask : HMBaseRequestTask

@property (nonatomic, copy) NSString *mobile;

@property(nonatomic,assign) HMAccountType type;
@end


/**
 手机号注册发送验证码
 */

@interface HMRegisterGetCodeRequestTask : HMBaseRegisterRequestTask
@end
/**
 忘记密码发送验证码
 */
@interface HMForgetGetCodeRequestTask : HMBaseRegisterRequestTask
@end

/**
 绑定发送验证码
 */
@interface HMBindGetCodeRequestTask : HMBaseRegisterRequestTask

@end

/*------------------验证手机和验证码------------------------*/
/**
 手机号注册验证手机号和验证码
 */
@interface HMRegisterVerifyCodeRequestTask : HMBaseRegisterRequestTask
@property (nonatomic, copy) NSString *code;

@end

@interface HMForgetVerifyCodeRequestTask : HMBaseRegisterRequestTask
@property (nonatomic, copy) NSString *code;
@property(nonatomic,strong) NSString *newpassword;
@end

@interface HMNotBindButRegistedRequestTask : HMBaseRegisterRequestTask
@property (nonatomic, copy) NSString *code;

@property(nonatomic,strong) NSString *externalUserId;
@property(nonatomic,strong) NSString *accessToken;
@property(nonatomic,strong) NSString *refreshToken;
@property(nonatomic,strong) NSString *nickname;
@end

//------------------------------------------------------//

/**
 手机号注册提交注册信息生成账号
 */
@interface HMRegisterAccountRequstTask : HMBaseRegisterRequestTask

@property (nonatomic, copy) NSString *password;
/** 用户名*/
@property (nonatomic, copy) NSString *name;
/** 用户类型*/
@property (nonatomic, assign) HMUserType userType;
/** 个性签名*/
@property (nonatomic, copy) NSString *signature;
/** 上传头像的图片data*/
@property (nonatomic, strong) UIImage *headImage;

/** 账号类型*/
@property (nonatomic, assign) HMAccountType accountType;
/** 外部账号id*/
@property (nonatomic, copy) NSString *externalUserId;
/** 授权获得到的access_token*/
@property (nonatomic, copy) NSString *accessToken;

/** 授权获得到的access_token*/
@property (nonatomic, copy) NSString *refreshToken;

@end


