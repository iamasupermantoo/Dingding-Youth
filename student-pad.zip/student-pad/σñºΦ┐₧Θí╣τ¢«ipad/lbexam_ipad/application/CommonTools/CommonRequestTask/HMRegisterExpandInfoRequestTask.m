//
//  HMRegisterExpandInfoRequestTask.m
//  UDan
//
//  Created by lilingang on 16/10/15.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMRegisterExpandInfoRequestTask.h"

@implementation HMRegisterExpandInfoRequestTask

+ (BOOL)needLogin{
    return YES;
}

- (NSString *)apiName{
    return self.userType == HMUserTypeUniversity ? @"/student/college/add" : @"/student/senior/add";
}

- (WSHTTPMethod)requestMethod{
    return WSHTTPMethodPOST;
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.province || [self.province ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"province"];
    }
    if (!self.region || [self.region ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"region"];
    }
    if (!self.seniorSchool || [self.seniorSchool ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"seniorSchool"];
    }
    if (self.userType == HMUserTypeUniversity) {
        if (!self.school || [self.school ddIsEmpty]) {
            return [NSError wsLocalParamErrorKey:@"school"];
        }
        if (!self.academy || [self.academy ddIsEmpty]) {
            return [NSError wsLocalParamErrorKey:@"academy"];
        }
        if (!self.year || [self.year ddIsEmpty]) {
            return [NSError wsLocalParamErrorKey:@"year"];
        }
    } else {
        if (!self.seniorYear || [self.seniorYear ddIsEmpty]) {
            return [NSError wsLocalParamErrorKey:@"seniorYear"];
        }
    }
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:self.province forKey:@"province"];
    [self.parameterDictionary setObject:self.region forKey:@"region"];
    [self.parameterDictionary setObject:self.seniorSchool forKey:@"seniorSchool"];
    if (self.userType == HMUserTypeUniversity) {
        [self.parameterDictionary setObject:self.school forKey:@"school"];
        [self.parameterDictionary setObject:self.academy forKey:@"academy"];
        [self.parameterDictionary setObject:self.year forKey:@"year"];
    } else {
        [self.parameterDictionary setObject:self.seniorYear forKey:@"seniorYear"];
    }
}

@end
