//
//  FKinitLabel.m
//  lbexam
//
//  Created by frankay on 17/1/13.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKinitLabel.h"
#import "UIFont+FKFont.h"
@implementation FKinitLabel

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initSettings];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initSettings];
    }
    return self;
}


- (void)initSettings{
    // 初始化label
    self.font = [UIFont fk_FontSize15];
    self.textColor = [UIColor hmTextBlackColor];
}

- (void)layoutSubviews{
    [super layoutSubviews];
//    self.layer.cornerRadius = 5.0f;
//    self.layer.masksToBounds = YES;
}


@end
