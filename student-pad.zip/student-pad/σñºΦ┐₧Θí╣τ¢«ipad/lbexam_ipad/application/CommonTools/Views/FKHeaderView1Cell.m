//
//  FKHeaderView1Cell.m
//  lbexam
//
//  Created by frankay on 17/1/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKHeaderView1Cell.h"

@interface FKHeaderView1Cell ()
@property (weak, nonatomic) IBOutlet FKinitLabel *Title;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomConstraint;

@end

@implementation FKHeaderView1Cell

- (void)initSettings{
    [super initSettings];
    self.Title.textColor = [UIColor hmTextBlackColor];
}

- (void)updateWithCellItem:(FKHeaderView1CellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    self.Title.text = cellItem.rawObject;
    self.bottomConstraint.constant = cellItem.Bottomconstant;
}
@end


@implementation FKHeaderView1CellItem

- (void)initSettings{
    [super initSettings];
    self.cellHeight = 40;
    self.canSelect = NO;
    self.separatorInset = UIEdgeInsetsMake(0, -8, 0, -8);
    self.hidenSeparator = YES;
}
@end
