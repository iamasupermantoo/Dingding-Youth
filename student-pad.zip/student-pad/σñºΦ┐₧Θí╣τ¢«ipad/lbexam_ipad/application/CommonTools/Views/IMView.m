//
//  IMView.m
//  03-Drawing
//
//  Created by feng-Mac on 16/10/21.
//  Copyright © 2016年 feng-Mac. All rights reserved.
//

#import "IMView.h"
#import "IMLine.h"

@interface IMView()
@property(nonatomic,strong) IMLine *line;
@property(nonatomic,assign) CGPoint prePoint;
@property(nonatomic,copy) NSArray *cpLines;
@property(nonatomic,copy) NSArray *cpselfLines;
@end

@implementation IMView

- (void)setSliderValue:(CGFloat)sliderValue{
    _sliderValue = sliderValue;
    
}

- (NSMutableArray *)lines{
    if (_lines == nil) {
        _lines = [NSMutableArray array];
    }
    return _lines;
}

- (NSMutableArray *)selfLines{
    if (_selfLines == nil) {
        _selfLines = [NSMutableArray array];
    }
    return _selfLines;
}

- (instancetype)init{

    self = [super init];
    if (self) {
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clear)];
        tap.numberOfTapsRequired = 5;
        [self addGestureRecognizer:tap];
    }
    return self;

}



- (void)drawRect:(CGRect)rect {
    
    @autoreleasepool {
        CGContextRef ctxRef = UIGraphicsGetCurrentContext();
        self.cpLines = self.lines;
        for (IMLine *line in self.cpLines) {
            
            NSMutableArray *points = line.points;
            
            for (int i=0; i< points.count; i++) {
                
                CGPoint point = [line.points[i] CGPointValue];
                
                if (i==0) {
                    CGContextMoveToPoint(ctxRef, point.x, point.y);
                }else{
                    CGContextAddLineToPoint(ctxRef, point.x, point.y);
                }
            }
            
            CGContextSetLineWidth(ctxRef, 8);
            CGContextSetLineCap(ctxRef, kCGLineCapRound);
            CGContextSetLineJoin(ctxRef, kCGLineJoinRound);
            CGContextSetStrokeColorWithColor(ctxRef, self.color.CGColor);
            CGContextStrokePath(ctxRef);
        }
        
        self.cpselfLines = self.selfLines;
        for (IMLine *line in self.cpselfLines) {
            
            NSMutableArray *points = line.points;
            
            for (int i=0; i< points.count; i++) {
                
                CGPoint point = [line.points[i] CGPointValue];
                
                if (i==0) {
                    CGContextMoveToPoint(ctxRef, point.x, point.y);
                }else{
                    CGContextAddLineToPoint(ctxRef, point.x, point.y);
                }
            }
            
            CGContextSetLineWidth(ctxRef, 8);
            CGContextSetLineCap(ctxRef, kCGLineCapRound);
            CGContextSetLineJoin(ctxRef, kCGLineJoinRound);
            CGContextSetStrokeColorWithColor(ctxRef, self.selfLineColor.CGColor);
            CGContextStrokePath(ctxRef);
        }
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    if (self.sliderValue == 0) {
        self.sliderValue = 0.5;
    }
    
    NSMutableArray *points = [NSMutableArray array];
    
    self.line = [[IMLine alloc] init];
    if (![self.selfLines containsObject:self.line]) {
        // 如果线条不包括线  就添加到数组
        [self.selfLines addObject:self.line];
    }
    CGPoint point = [self pointInTouches:touches];
    if (![[NSValue valueWithCGPoint:point] isEqualToValue:[NSValue valueWithCGPoint:self.prePoint]]) {
        [points addObject:[NSValue valueWithCGPoint:point]];
    }
    
    self.line.points = points;
    NSLog(@"%@",[NSValue valueWithCGPoint:point]);
    self.prePoint = point;
    
//    [self setNeedsDisplay];

}


- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    CGPoint point = [self pointInTouches:touches];
    if (![[NSValue valueWithCGPoint:point] isEqualToValue:[NSValue valueWithCGPoint:self.prePoint]]) {
        [self.line.points addObject:[NSValue valueWithCGPoint:point]];
    }
    
    [self setNeedsDisplay];

    self.prePoint = point;

}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(touchEndWithLines:)]) {
        [self.delegate touchEndWithLines:self.line];
    }
    [self setNeedsDisplay];
}


-(void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self touchesEnded:touches withEvent:event];
}


- (CGPoint)pointInTouches:(NSSet<UITouch *> *)touches{
    UITouch *touch = touches.anyObject;
    return [touch locationInView:touch.view];
}

- (void)back{
    
    //不知道为啥这个不能用
//    [self.lines removeLastObject];
    
    IMLine *line = [self.lines lastObject];
    [self.lines removeObject:line];
    
    [self setNeedsDisplay];
}


- (void)clear{
    
    [self.lines removeAllObjects];
    [self setNeedsDisplay];
}

- (void)clearSelfLines{
    
    [self.selfLines removeAllObjects];
    [self setNeedsDisplay];
}

- (void)clearAll{
     [self.selfLines removeAllObjects];
     [self.lines removeAllObjects];
     [self setNeedsDisplay];

}

@end
