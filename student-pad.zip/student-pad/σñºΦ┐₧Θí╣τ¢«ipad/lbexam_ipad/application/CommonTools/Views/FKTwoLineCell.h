//
//  FKTwoLineItemCell.h
//  lbexam
//
//  Created by frankay on 17/1/16.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"


@protocol  FKTwoLineCellDelegate<NSObject>

- (void)SelectedOneView:(NSDictionary *)info;

@end

@interface FKTwoLineCell : HMTableViewCell
@end


@interface FKTwoLineCellItem : HMTableViewCellItem
@property(nonatomic,assign) CGFloat imageCellWidth;
@property(nonatomic,strong) NSArray *cellImageItems;
@end
