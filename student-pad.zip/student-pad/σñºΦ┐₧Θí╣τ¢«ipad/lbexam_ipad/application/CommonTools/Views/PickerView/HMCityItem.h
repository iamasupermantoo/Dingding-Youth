//
//  HMCityItem.h
//  UDan
//
//  Created by lilingang on 16/10/19.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseItem.h"

@interface HMCityItem : HMBaseItem

@property (nonatomic, assign) NSInteger cityId;
@property (nonatomic, assign) NSInteger pid;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *spell;
@property (nonatomic, copy) NSArray<HMCityItem *> *children;

@end
