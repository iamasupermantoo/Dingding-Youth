//
//  HMSinglePickerView.m
//  UDan
//
//  Created by lilingang on 16/10/20.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMSinglePickerView.h"

@implementation HMSinglePickerView

- (void)confirmButtonAction:(id)sender{
    if (self.delegate && [self.delegate respondsToSelector:@selector(hmSinglePickerView:didIndex:)]) {
        NSInteger currentIndex = [self.pickerView selectedRowInComponent:0];
        [self.delegate hmSinglePickerView:self didIndex:currentIndex];
    }
    [super confirmButtonAction:sender];
}

#pragma mark - UIPickerViewDataSource
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if (self.dataSource && [self.dataSource respondsToSelector:@selector(hmNumberOfRowsInSinglePickerView:)]) {
        return [self.dataSource hmNumberOfRowsInSinglePickerView:self];
    } else {
        return [super pickerView:pickerView numberOfRowsInComponent:component];
    }
}

#pragma mark - UIPickerViewDelegate
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(nullable UIView *)view{
    UILabel *titleLabel = (UILabel *)[super pickerView:pickerView viewForRow:row forComponent:component reusingView:view];
    if (self.dataSource && [self.dataSource respondsToSelector:@selector(hmSinglePickerView:titleOfRow:)]) {
        titleLabel.text = [self.dataSource hmSinglePickerView:self titleOfRow:row];
    }
    return titleLabel;
}

@end
