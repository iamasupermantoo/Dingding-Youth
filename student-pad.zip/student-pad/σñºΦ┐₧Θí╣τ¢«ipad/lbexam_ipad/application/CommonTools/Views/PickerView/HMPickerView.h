//
//  HMPickerView.h
//  UIComponentsDemo
//
//  Created by lilingang on 16/9/26.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <UIKit/UIKit.h>

/**滚动选择器*/
@interface HMPickerView : UIView<UIPickerViewDataSource,UIPickerViewDelegate>

/**选取器*/
@property (weak, nonatomic) IBOutlet UIPickerView *pickerView;


/**
 展示选取器

 @param animated   是否需要动画
 @param completion 动画结束
 */
- (void)showAnimated:(BOOL)animated completion:(void (^)(BOOL finished))completion;

/**
 选取器消失

 @param animated   是否需要动画
 @param completion 动画结束
 */
- (void)dismissWithAnimated:(BOOL)animated completion:(void (^)(BOOL finished))completion;

/** 确定按钮点击事件*/
- (IBAction)confirmButtonAction:(id)sender;

@end
