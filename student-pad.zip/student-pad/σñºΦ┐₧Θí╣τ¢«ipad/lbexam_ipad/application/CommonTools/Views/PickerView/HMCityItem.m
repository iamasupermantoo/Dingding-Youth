//
//  HMCityItem.m
//  UDan
//
//  Created by lilingang on 16/10/19.
//  Copyright © 2016年 LiLingang. All rights reserved.
//


#import "HMCityItem.h"

@implementation HMCityItem

+ (NSDictionary *)modelCustomPropertyMapper {
    NSDictionary *dic=@{@"cityId" :@"id"};
    return dic;
}

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"children" : [HMCityItem class]};
}

@end
