//
//  HMSinglePickerView.h
//  UDan
//
//  Created by lilingang on 16/10/20.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMPickerView.h"

@protocol HMSinglePickerViewDataSource;
@protocol HMSinglePickerViewDelegate;


@interface HMSinglePickerView : HMPickerView

@property (nonatomic, weak) id<HMSinglePickerViewDelegate> delegate;
@property (nonatomic, weak) id<HMSinglePickerViewDataSource> dataSource;

/**标识拾取器内容,外部传入*/
@property (nonatomic, strong) id identify;

@end

@protocol HMSinglePickerViewDataSource <NSObject>

@required
- (NSInteger)hmNumberOfRowsInSinglePickerView:(HMSinglePickerView *)pickerView;

- (NSString *)hmSinglePickerView:(HMSinglePickerView *)pickerView titleOfRow:(NSInteger)row;

@end

@protocol HMSinglePickerViewDelegate <NSObject>

- (void)hmSinglePickerView:(HMSinglePickerView *)pickerView didIndex:(NSInteger)index;

@end
