//
//  HMCityPickerView.m
//  UDan
//
//  Created by lilingang on 16/10/19.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMCityPickerView.h"
#import "ObjectiveSugar.h"
@interface HMCityPickerView ()

@property (nonatomic, strong) NSArray *cityItems;

@property (nonatomic, weak) HMCityItem *currentCityItem;

@end

@implementation HMCityPickerView

- (void)initSettings{
    NSURL *plistUrl = [[NSBundle mainBundle] URLForResource:@"City" withExtension:@"plist"];
    NSArray *cityArray = [[NSArray alloc] initWithContentsOfURL:plistUrl];
    NSError *error = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:cityArray
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    NSString *jsonString = [[NSString alloc] initWithData:jsonData
                                                 encoding:NSUTF8StringEncoding];
    self.cityItems = [NSArray yy_modelArrayWithClass:[HMCityItem class] json:jsonString];
    self.currentCityItem = [self.cityItems first];
}

- (void)selectedProvince:(NSString *)province city:(NSString *)city animated:(BOOL)animated{
    __weak __typeof(&*self)weakSelf = self;
    __block NSInteger provinceIndex = 0;
    [self.cityItems enumerateObjectsUsingBlock:^(HMCityItem *obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj.name isEqualToString:province]) {
            weakSelf.currentCityItem = obj;
            provinceIndex = idx;
            *stop = YES;
        }
    }];
    
    __block NSInteger cityIndex = 0;
    [self.currentCityItem.children enumerateObjectsUsingBlock:^(HMCityItem * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj.name isEqualToString:city]) {
            cityIndex = idx;
            *stop = YES;
        }
    }];
    
    [self.pickerView selectRow:provinceIndex inComponent:0 animated:animated];
    [self.pickerView selectRow:cityIndex inComponent:1 animated:animated];
}


- (void)confirmButtonAction:(id)sender{
    if (self.delegate && [self.delegate respondsToSelector:@selector(hmCityPickerViewDidSelectedProvince:cityItem:)]) {
        NSInteger provinceIndex = [self.pickerView selectedRowInComponent:0];
        NSInteger cityIndex = [self.pickerView selectedRowInComponent:1];
        HMCityItem *provinceItem = self.cityItems[provinceIndex];
        HMCityItem *cityItem = provinceItem.children[cityIndex];
        [self.delegate hmCityPickerViewDidSelectedProvince:provinceItem cityItem:cityItem];
    }
    [super confirmButtonAction:sender];
}

#pragma mark - UIPickerViewDataSource

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 2;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if (component == 0) {
        return [self.cityItems count];
    } else {
        return [self.currentCityItem.children count];
    }
}

#pragma mark - UIPickerViewDelegate

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component{
    return CGRectGetWidth(pickerView.frame)/2.0;
}


- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(nullable UIView *)view{
    UILabel *label = (UILabel *)[super pickerView:pickerView viewForRow:row forComponent:component reusingView:view];
    if (component == 0) {
        HMCityItem *cityItem = self.cityItems[row];
        label.text = cityItem.name;
    } else {
        HMCityItem *selectedCityItem = self.currentCityItem.children[row];
        label.text = selectedCityItem.name;
    }
    return label;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    if (component == 0) {
        self.currentCityItem = self.cityItems[row];
        [pickerView reloadComponent:1];
    }
}
@end
