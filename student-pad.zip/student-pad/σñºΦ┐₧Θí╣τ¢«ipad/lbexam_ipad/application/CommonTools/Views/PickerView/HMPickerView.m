//
//  HMPickerView.m
//  UIComponentsDemo
//
//  Created by lilingang on 16/9/26.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMPickerView.h"

static const CGFloat HMSheetItemHeight = 44.0f;

@interface HMPickerView ()

@property (nonatomic, strong) UIWindow *alertWindow;

@property (nonatomic, strong) UIView *maskView;

@property (strong, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet UIView *dialogContentView;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *dialogContentViewBottomConstraint;

@end

@implementation HMPickerView

- (void)showAnimated:(BOOL)animated completion:(void (^)(BOOL finished))completion{
    
    __block CGRect dialogContentViewFrame =self.dialogContentView.frame;
    dialogContentViewFrame.origin.y = CGRectGetHeight(self.frame);
    self.dialogContentView.frame = dialogContentViewFrame;
    dialogContentViewFrame.origin.y = CGRectGetHeight(self.frame) - CGRectGetHeight(dialogContentViewFrame);
    
    __weak __typeof(&*self)weakSelf = self;
    void (^animationsBlock)(void) = ^{
        __strong __typeof(&*weakSelf)strongSelf = weakSelf;
        strongSelf.dialogContentView.frame = dialogContentViewFrame;
        strongSelf.maskView.alpha = 1.0;
    };
    void (^completionBlock)(void) = ^{
        __strong __typeof(&*weakSelf)strongSelf = weakSelf;
        strongSelf.dialogContentViewBottomConstraint.constant = 0;
        if (completion) {
            completion(YES);
        }
    };
    if (animated) {
        [UIView animateWithDuration:0.25 animations:^{
            animationsBlock();
        } completion:^(BOOL finished) {
            completionBlock();
        }];
    } else {
        animationsBlock();
        completionBlock();
    }
}

- (void)dismissWithAnimated:(BOOL)animated completion:(void (^)(BOOL finished))completion{
    __weak __typeof(&*self)weakSelf = self;
    void (^animationsBlock)(void) = ^{
        __strong __typeof(&*weakSelf)strongSelf = weakSelf;
        CGRect dialogContentViewFrame = strongSelf.dialogContentView.frame;
        dialogContentViewFrame.origin.y = CGRectGetHeight(strongSelf.frame);
        strongSelf.dialogContentView.frame = dialogContentViewFrame;
        strongSelf.maskView.alpha = 0.0;
    };
    
    void (^completionBlock)(void) = ^{
        __strong __typeof(&*weakSelf)strongSelf = weakSelf;
        strongSelf.dialogContentViewBottomConstraint.constant = - CGRectGetHeight(self.dialogContentView.frame);
        [strongSelf.dialogContentView removeFromSuperview];
//        strongSelf.alertWindow.hidden = YES;
        [strongSelf removeFromSuperview];
        if (completion) {
            completion(YES);
        }
    };
    if (animated) {
        [UIView animateWithDuration:0.25 animations:^{
            animationsBlock();
        } completion:^(BOOL finished) {
            completionBlock();
        }];
    } else {
        animationsBlock();
        completionBlock();
    }
}

#pragma mark - ButtonAction

- (IBAction)confirmButtonAction:(id)sender {
    [self dismissWithAnimated:YES completion:nil];
}


- (IBAction)cancelButtonAction:(id)sender {
    [self dismissWithAnimated:YES completion:nil];
}

#pragma mark - Private Methods

- (instancetype)init{
    return [self initWithFrame:CGRectMake(0, 0, IPAD_SCREENWIDTH, SCREENHEIGHT-64)];
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.maskView = [[UIView alloc] initWithFrame:self.bounds];
        self.maskView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
        self.maskView.alpha = 0.0;
        [self addSubview:self.maskView];
        
        [[NSBundle mainBundle] loadNibNamed:@"HMPickerView" owner:self options:nil];
        self.contentView.frame = self.bounds;
        [self addSubview:self.contentView];
        
        UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(cancelButtonAction:)];
        [self.maskView addGestureRecognizer:tapGestureRecognizer];
        [self initSettings];
    }
    return self;
}

- (void)initSettings{
    
}


#pragma mark - UIPickerViewDataSource

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return 0;
}

#pragma mark - UIPickerViewDelegate
- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component{
    return HMSheetItemHeight;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component{
    return CGRectGetHeight(pickerView.frame);
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(nullable UIView *)view{
    UILabel *titleLabel = (UILabel *)view;
    if (!titleLabel) {
        CGFloat width = [self pickerView:pickerView widthForComponent:component];
        CGFloat height = [self pickerView:pickerView rowHeightForComponent:component];
        titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, height)];
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.font = [UIFont systemFontOfSize:16.0f];
        titleLabel.textColor = [UIColor hmTextBlackColor];
    }
    return titleLabel;
}

#pragma mark - Getter and Setter

- (UIWindow *)alertWindow{
    if (!_alertWindow) {
        _alertWindow = [[UIWindow alloc] initWithFrame:self.frame];
        _alertWindow.windowLevel = UIWindowLevelAlert;
        _alertWindow.backgroundColor = [UIColor clearColor];
        _alertWindow.hidden = NO;
    }
    return _alertWindow;
}
@end
