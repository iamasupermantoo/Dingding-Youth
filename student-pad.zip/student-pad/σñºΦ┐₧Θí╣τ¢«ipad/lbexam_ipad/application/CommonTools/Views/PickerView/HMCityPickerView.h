//
//  HMCityPickerView.h
//  UDan
//
//  Created by lilingang on 16/10/19.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMPickerView.h"
#import "HMCityItem.h"

@protocol HMCityPickerViewDelegate <NSObject>

- (void)hmCityPickerViewDidSelectedProvince:(HMCityItem *)provinceItem cityItem:(HMCityItem *)cityItem;

@end

@interface HMCityPickerView : HMPickerView

@property (nonatomic, weak) id<HMCityPickerViewDelegate> delegate;

- (void)selectedProvince:(NSString *)province city:(NSString *)city animated:(BOOL)animated;

@end
