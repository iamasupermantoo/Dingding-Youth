//
//  HMSearchBar.h
//  UDan
//
//  Created by lilingang on 16/10/18.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HMSearchBar : UISearchBar

@end
