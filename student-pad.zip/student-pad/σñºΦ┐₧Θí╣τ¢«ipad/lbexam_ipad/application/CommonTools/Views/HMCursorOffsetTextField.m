//
//  HMCursorOffsetTextField.m
//  UDan
//
//  Created by lilingang on 16/10/14.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMCursorOffsetTextField.h"

@implementation HMCursorOffsetTextField

- (void)setPlaceholder:(NSString *)placeholder{
    NSDictionary *attributes = @{
                                 NSFontAttributeName:[UIFont systemFontOfSize:12.0],
                                 NSForegroundColorAttributeName:[UIColor colorWithHexString:@"#CCCCCC" alpha:1.0]
                                 };
    NSAttributedString *attributedPlaceholder = [[NSAttributedString alloc] initWithString:placeholder attributes:attributes];
    self.attributedPlaceholder = attributedPlaceholder;
}

// 修改文本展示区域，一般跟editingRectForBounds一起重写
- (CGRect)textRectForBounds:(CGRect)bounds{
    return UIEdgeInsetsInsetRect(bounds, UIEdgeInsetsMake(0, 20, 0, 20));
}

// 重写来编辑区域，可以改变光标起始位置，以及光标最右到什么地方，placeHolder的位置也会改变
-(CGRect)editingRectForBounds:(CGRect)bounds{
    return UIEdgeInsetsInsetRect(bounds, UIEdgeInsetsMake(0, 20, 0, 20));
}

@end
