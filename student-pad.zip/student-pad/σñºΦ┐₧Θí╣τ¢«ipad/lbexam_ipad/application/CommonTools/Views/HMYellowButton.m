//
//  HMYellowButton.m
//  UDan
//
//  Created by lilingang on 16/10/14.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMYellowButton.h"
#import "HPGrowingTextView.h"
@implementation HMYellowButton

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initSettings];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initSettings];
    }
    return self;
}

- (void)initSettings{
    self.adjustsImageWhenHighlighted = NO;
    self.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self setTitleColor:[UIColor whiteColor] forState:UIControlStateDisabled];
    [self setBackgroundImage:[UIImage ddImageWithColor:[UIColor hmYellowColor]] forState:UIControlStateNormal];
    [self setBackgroundImage:[UIImage ddImageWithColor:[UIColor fkcccColor]] forState:UIControlStateDisabled];
}

- (void)layoutSubviews{
    [super layoutSubviews];
    self.layer.cornerRadius = 5.0f;
    self.layer.masksToBounds = YES;
}

@end
