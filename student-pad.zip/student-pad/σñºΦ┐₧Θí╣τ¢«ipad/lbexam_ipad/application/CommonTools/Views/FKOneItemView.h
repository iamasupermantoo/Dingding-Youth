//
//  FKOneItemView.h
//  lbexam
//
//  Created by frankay on 17/1/16.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <UIKit/UIKit.h>
@class FKCourseItem;
@interface FKOneItemView : UIView

- (void)updateOneViewWith:(FKCourseItem *)courseItem WithImgWidth:(CGFloat)ImgWidth isloadLocalImage:(BOOL)load;
@end
