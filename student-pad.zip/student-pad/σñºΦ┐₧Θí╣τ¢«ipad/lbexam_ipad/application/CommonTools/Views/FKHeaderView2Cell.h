//
//  FKHeaderView2Cell.h
//  lbexam
//
//  Created by frankay on 17/1/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"

@interface FKHeaderView2Cell : HMTableViewCell
@end

@interface FKHeaderView2CellItem : HMTableViewCellItem
@property(nonatomic,strong) NSAttributedString *attributeString;

+ (FKHeaderView2CellItem *)cellWithTitle:(NSString *)title;
+ (FKHeaderView2CellItem *)TitleWithAttr:(NSAttributedString *)attr andCellHeight:(CGFloat)cellHeight;
+ (FKHeaderView2CellItem *)ordinaryCellItemWithTitle:(NSString *)title;
@end
