//
//  FKSeperationLine.m
//  lbexam_ipad
//
//  Created by frankay on 17/2/23.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKSeperationLine.h"

@implementation FKSeperationLine

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initSettings];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initSettings];
    }
    return self;
}


- (void)initSettings{
    // 初始化label
    self.backgroundColor = [UIColor hmBorderColor];
}

- (void)layoutSubviews{
    [super layoutSubviews];
    //    self.layer.cornerRadius = 5.0f;
    //    self.layer.masksToBounds = YES;
}



@end
