//
//  FKLevelShowView.h
//  lbexam
//
//  Created by frankay on 17/1/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FKLevelShowView : UIView


- (void)updateLevelWith:(NSInteger)type;
@end
