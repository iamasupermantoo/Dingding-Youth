//
//  FKOneItemView.m
//  lbexam
//
//  Created by frankay on 17/1/16.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKOneItemView.h"
#import "FKestalishCourseItem.h"

@interface FKOneItemView ()
@property (strong, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet UIImageView *CimageView;
@property (weak, nonatomic) IBOutlet UILabel *Cdescribtion;

@end
@implementation FKOneItemView

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super initWithCoder:aDecoder]) {
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        self.contentView.frame = self.bounds;
        [self addSubview:self.contentView];
    }
    return self;
}


- (void)updateOneViewWith:(FKestalishCourseItem *)courseItem WithImgWidth:(CGFloat)ImgWidth isloadLocalImage:(BOOL)load{
    [self.CimageView hmLoadImageURL:[courseItem.imageItem imageUrlWithSide:ImgWidth] local:load];
    
    if (load) {
        if (courseItem.issingleLine) {
            self.Cdescribtion.text = courseItem.brief;
        }else{
            self.Cdescribtion.attributedText = [courseItem.brief attributedStringWithTextFont:self.Cdescribtion.font];
        }
    }

}
@end
