//
//  FKHeaderView3Cell.h
//  lbexam
//
//  Created by frankay on 17/2/10.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"

@interface FKHeaderView3Cell : HMTableViewCell
@property (weak, nonatomic) IBOutlet FKinitLabel *title;

@end

@interface FKHeaderView3CellItem : HMTableViewCellItem
@property(nonatomic,assign) CGFloat bottomConstraint;
@property(nonatomic,assign) CGFloat leadConstraint;

@end
