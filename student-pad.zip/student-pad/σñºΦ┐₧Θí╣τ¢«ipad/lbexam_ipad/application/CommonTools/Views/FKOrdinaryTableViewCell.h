//
//  FKOrdinaryTableViewCell.h
//  lbexam
//
//  Created by frankay on 17/2/10.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"

@interface FKOrdinaryTableViewCell : HMTableViewCell

@end


@interface FKOrdinaryTableViewCellItem : HMTableViewCellItem
@property(nonatomic,strong) NSDictionary *dict;
@end
