//
//  FKOrdinaryTableViewCell.m
//  lbexam
//
//  Created by frankay on 17/2/10.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKOrdinaryTableViewCell.h"

@interface FKOrdinaryTableViewCell ()
@property (weak, nonatomic) IBOutlet UIImageView *tipImageView;
@property (weak, nonatomic) IBOutlet FKinitLabel *tipTitle;

@end

@implementation FKOrdinaryTableViewCell


-(void)updateWithCellItem:(FKOrdinaryTableViewCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    [self cellWithDict:cellItem.dict];
}

- (void)cellWithDict:(NSDictionary *)dict{
    self.tipImageView.image = IMG_NAME(dict[@"image"]) ;
    self.tipTitle.text = dict[@"title"];
}
@end


@implementation FKOrdinaryTableViewCellItem

- (void)initSettings{
    [super initSettings];
    self.separatorInset = kIpadNoGapSeperateInsets;
    self.cellHeight = 44;
}

@end
