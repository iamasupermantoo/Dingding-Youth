//
//  FKBaseChatItem.m
//  AgoraLiveTest
//
//  Created by frankay on 17/1/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKBaseChatItem.h"

@implementation FKBaseChatItem



@end
