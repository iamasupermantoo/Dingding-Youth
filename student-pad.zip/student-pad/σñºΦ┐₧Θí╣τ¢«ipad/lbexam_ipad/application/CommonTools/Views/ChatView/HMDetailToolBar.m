//
//  HMDetailToolBar.m
//  UDan
//
//  Created by lilingang on 16/10/30.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMDetailToolBar.h"
#import "UIColor+UDan.h"
@interface HMDetailToolBar ()<HPGrowingTextViewDelegate>

@property (strong, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet UIView *textContentView;
@property (weak, nonatomic) IBOutlet UIButton *shareButton;
@property (weak, nonatomic) IBOutlet UIButton *sendBtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *sendBtnLeading;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *shareBtnLeading;
@end

@implementation HMDetailToolBar


- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        self.contentView.frame = self.bounds;
        [self addSubview:self.contentView];
    }
    return self;
}

- (void)awakeFromNib{
    [super awakeFromNib];
    [self initSettings];
}

- (instancetype)initWithFrame:(CGRect)frame with:(BOOL)isSend withReturnType:(NSInteger)type{
    if (self = [super initWithFrame:frame]) {
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        self.contentView.frame = self.bounds;
        [self addSubview:self.contentView];
        self.isSend = isSend;
        self.returnkeyType = type;
        [self initSettings];
    }
    return self;

}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        self.contentView.frame = self.bounds;
        [self addSubview:self.contentView];
        [self initSettings];
    }
    return self;
}


- (void)initSettings{
    self.growTextView.placeholder = @"输入内容…";
    self.growTextView.delegate = self;
    self.growTextView.enablesReturnKeyAutomatically = YES;
    self.growTextView.isScrollable = NO;
    self.growTextView.returnKeyType = self.returnkeyType;
    self.growTextView.contentInset = UIEdgeInsetsMake(0, 5, 0, 0);
    self.growTextView.internalTextView.scrollIndicatorInsets = UIEdgeInsetsMake(5, 0, 5, 0);
    
    self.textContentView.layer.cornerRadius = 5.0f;
//    self.textContentView.layer.masksToBounds = YES;
    self.textContentView.layer.borderWidth = 0.5;
    self.textContentView.layer.borderColor = [UIColor hmBorderColor].CGColor;

    if (self.isSend) {
        self.sendBtn.layer.cornerRadius = 5.0;
        self.favorButton.hidden = YES;
        self.shareButton.hidden = YES;
        self.sendBtn.backgroundColor = [UIColor hmYellowColor];
        self.sendBtnLeading.constant = 15;
        self.sendBtnLeading.priority = 900;
        self.shareBtnLeading.priority = 800;
        [self layoutIfNeeded];
    }else{
        self.sendBtn.hidden = YES;
    }
    
}


- (void)resignTextViewFirstResponder{
    [self.growTextView resignFirstResponder];
}

- (void)clear{
    self.growTextView.text = @"";
}
- (IBAction)Send:(UIButton *)sender {
    if (self.deleagte && [self.deleagte respondsToSelector:@selector(fkDetailToolBarDelegateSendBtnActionWithText:)]) {
        [self.deleagte fkDetailToolBarDelegateSendBtnActionWithText:self.growTextView.text];
    }
}

- (IBAction)shareButtonAction:(id)sender {
    // 解决了点击分享按钮 被键盘遮挡问题
    [self.growTextView resignFirstResponder];
 
}

- (IBAction)favorButtonAction:(id)sender {

}

#pragma mark - HPGrowingTextViewDelegate

- (void)growingTextView:(HPGrowingTextView *)growingTextView willChangeHeight:(float)height {
    float diff = (growingTextView.frame.size.height - height);
//    [UIView animateWithDuration:0.25 animations:^{
//        
//    }];
    CGRect r = self.frame;
    r.size.height -= diff;
    r.origin.y += diff;
    self.frame = r;
    if (self.deleagte && [self.deleagte respondsToSelector:@selector(hmDetailToolBarDelegateDidChangedHeight:)]) {
        [self.deleagte hmDetailToolBarDelegateDidChangedHeight:self];
    }
}


- (BOOL)growingTextViewShouldReturn:(HPGrowingTextView *)growingTextView{
    if (self.deleagte && [self.deleagte respondsToSelector:@selector(hmDetailToolBarDelegateSendCommentWithText:)]) {
        [self.deleagte hmDetailToolBarDelegateSendCommentWithText:growingTextView.text];
    }
    return NO;
}
@end
