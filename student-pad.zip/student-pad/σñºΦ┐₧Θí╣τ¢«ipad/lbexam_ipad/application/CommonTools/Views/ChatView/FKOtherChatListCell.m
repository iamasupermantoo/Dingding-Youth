//
//  FKOtherChatListCell.m
//  UDan
//
//  Created by frankay on 16/12/15.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "FKOtherChatListCell.h"
#import "FKBaseChatItem.h"
#import "NSString+UDan.h"
@interface FKOtherChatListCell ()
@property (weak, nonatomic) IBOutlet UIImageView *icon;
@property (weak, nonatomic) IBOutlet UIImageView *bgImageView;
@property (weak, nonatomic) IBOutlet UILabel *SendContent;
@property (weak, nonatomic) IBOutlet UILabel *SendTime;
@property (weak, nonatomic) IBOutlet UIView *bubbleView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bubbleLeadingConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bubbleHeightConstraint;


@end
@implementation FKOtherChatListCell


- (void)awakeFromNib{
    [super awakeFromNib];
    self.bubbleView.layer.borderWidth = 0.5;
    self.bubbleView.layer.borderColor = [UIColor hmBorderColor].CGColor;
    self.bubbleView.layer.cornerRadius = 5.0;

}

- (void)updateCellWithItem:(FKBaseChatItem *)Item{
    self.SendContent.text = Item.Content;
//    UIFont *textFont = [UIFont systemFontOfSize:15];
//    CGFloat textHeight = ceil(textFont.lineHeight);
//    CGFloat maxsize = SCREENWIDTH - 160;
//    CGSize textSize;
//    //    if ([Item.text isEqualToString:@""]) {
//    //
//    //    }
//    
//    if (![Item.Content isSingleLineWithMaxWidth:maxsize textFont:textFont]) {
//        // 文字多行
//        textSize = [Item.Content sizeWithMaxWidth:maxsize textFont:textFont lineSpace:0.0 firstLineHeadIndent:0.0];
//        textHeight = textSize.height;
//        
//    }
//    self.bubbleHeightConstraint.constant = textHeight + 41;

}

@end

