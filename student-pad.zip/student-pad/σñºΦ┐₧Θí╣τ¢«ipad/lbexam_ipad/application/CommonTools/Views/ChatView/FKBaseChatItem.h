//
//  FKBaseChatItem.h
//  AgoraLiveTest
//
//  Created by frankay on 17/1/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "HMBaseItem.h"
@interface FKBaseChatItem : HMBaseItem;


@property(nonatomic,strong) NSString *iconurlstr;
@property(nonatomic,strong) NSString *Content;
@property(nonatomic,assign) NSInteger who; // 0是me 1是other

@end
