//
//  FKOtherChatListCell.h
//  UDan
//
//  Created by frankay on 16/12/15.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "FKOtherChatListCell.h"
@class FKBaseChatItem;

@protocol  FKOtherChatListCellDelegate<NSObject>
- (void)FKSessionListCelltapIcon:(NSDictionary *)info;
@end
@interface FKOtherChatListCell : UITableViewCell


- (void)updateCellWithItem:(FKBaseChatItem *)Item;

@end



