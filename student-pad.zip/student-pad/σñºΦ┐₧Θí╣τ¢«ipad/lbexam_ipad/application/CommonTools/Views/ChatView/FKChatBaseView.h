//
//  FKChatBaseView.h
//  AgoraLiveTest
//
//  Created by frankay on 17/1/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol  FKChatBaseViewDelegate<NSObject>
- (void)sendText:(NSString *)text;

@end

@class HMDetailToolBar;
@interface FKChatBaseView : UIView
@property(nonatomic,assign) CGFloat NavBarHeight;
@property(nonatomic,assign) CGFloat bottomHeight;
@property(nonatomic,strong,readonly) UITableView *tableView;
@property(nonatomic,strong,readonly) HMDetailToolBar *toolBar;
@property(nonatomic,strong) NSMutableArray *Items;
@property(nonatomic,strong) UIView *superView;
@property(nonatomic,weak) id <FKChatBaseViewDelegate> delegate;

- (instancetype)initWithSuperViewFrame:(CGRect)frame;
- (void)updateItems:(NSArray *)Items;
- (void)updateContentoffset;

@end
