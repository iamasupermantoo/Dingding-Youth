//
//  FKChatBaseView.m
//  AgoraLiveTest
//
//  Created by frankay on 17/1/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKChatBaseView.h"
#import "HMDetailToolBar.h"
#import "FKMyChatListCell.h"
#import "FKOtherChatListCell.h"
#import "FKBaseChatItem.h"
#import "NSString+UDan.h"

static CGFloat startPoint = 0.0;

@interface FKChatBaseView ()<UITableViewDelegate,UITableViewDataSource,HMDetailToolBarDelegate>
{
    CGFloat _keyboardHeight;
    CGRect  _chatSuperFrame;
}
@property(nonatomic,strong) UITableView *tableView;
@property(nonatomic,strong) HMDetailToolBar *toolBar;

@end

@implementation FKChatBaseView


- (instancetype)initWithSuperViewFrame:(CGRect)frame{
    if (self=[super init]) {
        self.Items = [NSMutableArray array];
        _chatSuperFrame = frame;
        self.frame = CGRectMake(0, 0, CGRectGetWidth(frame), CGRectGetHeight(frame));
        [self initView];
    }
    return self;
    
}

// 更新model数组
-(void)updateItems:(NSArray *)Items{
    self.Items = [[NSMutableArray alloc] initWithArray:Items];
    [self.tableView reloadData];
    [self updateContentoffset];
}

// 更新tableview偏移量
- (void)updateContentoffset{
    // 键盘出来的时候
    // 键盘没有弹出的时候
    [self setNewTableViewOffset];
    
}
- (void)initView{
    
    [self addSubview:self.tableView];
    [self addSubview:self.toolBar];
    
    // 键盘变化的时候通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChangeFrameNotification:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
}

// get
-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), self.frame.size.height-self.toolBar.ddHeight) style:UITableViewStylePlain];
        _tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
        _tableView.backgroundColor = [UIColor fkColorWithString:@"#d7d7d7"];
        _tableView.separatorColor = [UIColor fkColorWithString:@"#d7d7d7"];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}

-(HMDetailToolBar *)toolBar{
    if (!_toolBar) {
        
        _toolBar = [[HMDetailToolBar alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(self.frame)-49, CGRectGetWidth(self.frame), 49) with:YES withReturnType:UIReturnKeySend];
        _toolBar.deleagte = self;
    }
    return _toolBar;
}

#pragma -mark tableView Datasource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.Items.count;
}


// 显示cell
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    FKBaseChatItem *Item = self.Items[indexPath.row];
    if (Item.who == 0) {
        FKOtherChatListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"myCell"];
        if (cell==nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"FKOtherChatListCell" owner:nil options:nil] lastObject];
        }
        [cell updateCellWithItem:Item];
        return cell;
    }else{
        
        FKMyChatListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"otherCell"];
        if (cell==nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"FKMyChatListCell" owner:nil options:nil] lastObject];
        }
        [cell updateCellWithItem:Item];
        return cell;
    }
    
}

// cell的高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    // 根据聊天内容计算高度
    // 1、取出数组中聊天的内容
    FKBaseChatItem *chatItem = self.Items[indexPath.row];
    NSString *content = chatItem.Content;
    // 2、计算其余高度
    UIFont *textFont = [UIFont systemFontOfSize:15];
    CGFloat textHeight = ceil(textFont.lineHeight);
    CGFloat maxsize = self.frame.size.width - 155;
    CGSize textSize;
  
    if (![content isSingleLineWithMaxWidth:maxsize textFont:textFont]) {
        // 文字多行
        textSize = [content sizeWithMaxWidth:maxsize textFont:textFont lineSpace:0.0 firstLineHeadIndent:0.0];
        textHeight = textSize.height;
    }
    
    // 3、总高度
    return textHeight + 61;
}

// toolbar delegate

- (void)hmDetailToolBarDelegateSendCommentWithText:(NSString *)text{
    
    [self.toolBar resignTextViewFirstResponder];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(sendText:)]) {
        [self.delegate sendText:text];
    }

}

- (void)hmDetailToolBarDelegateDidChangedHeight:(HMDetailToolBar *)toolBar{
    
}

- (void)fkDetailToolBarDelegateSendBtnActionWithText:(NSString *)text{
    [self.toolBar resignTextViewFirstResponder];

    if (self.delegate && [self.delegate respondsToSelector:@selector(sendText:)]) {
        [self.delegate sendText:text];
    }
}

#pragma mark -keyboard
- (void)keyboardWillChangeFrameNotification:(NSNotification *)notification{
    CGRect keyboardRect = [notification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGFloat keyboardAnimationDuration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] floatValue];
    CGFloat keyboardY = CGRectGetMinY(keyboardRect);
    CGFloat keyboardH = CGRectGetHeight(keyboardRect);
    _keyboardHeight = keyboardH;
    [UIView animateWithDuration:keyboardAnimationDuration
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
                         // 键盘上面的视图整体上移
                         
                         if (keyboardY != SCREENHEIGHT-keyboardH) {
                         
                             _superView.frame = _chatSuperFrame;
                             self.tableView.frame = CGRectMake(0, 0, CGRectGetWidth(_chatSuperFrame), CGRectGetHeight(_chatSuperFrame)-self.toolBar.ddHeight);
                             self.toolBar.frame = CGRectMake(0, CGRectGetHeight(_chatSuperFrame)-self.toolBar.ddHeight, CGRectGetWidth(_chatSuperFrame), self.toolBar.ddHeight);
                             
                         }else{
                             if (_chatSuperFrame.size.height>SCREENHEIGHT-keyboardH-_NavBarHeight) {
                                 _superView.frame = CGRectMake(CGRectGetMinX(_chatSuperFrame), _NavBarHeight, CGRectGetWidth(_chatSuperFrame),keyboardY-_NavBarHeight);
                                 self.tableView.frame = CGRectMake(0, 0,CGRectGetWidth(_chatSuperFrame), keyboardY-_NavBarHeight-self.toolBar.ddHeight);
                                 self.toolBar.frame = CGRectMake(0, self.tableView.ddBottom, CGRectGetWidth(_chatSuperFrame), 49);
                             }else{
                                 _superView.frame = CGRectMake(CGRectGetMinX(_chatSuperFrame), CGRectGetMinY(_chatSuperFrame)-keyboardH, CGRectGetWidth(_chatSuperFrame), CGRectGetHeight(_chatSuperFrame));
                             }

                         }
                         // 为了能让键盘弹起来后 内容不被遮挡
                         [self setNewTableViewOffset];
                         
                     } completion:^(BOOL finished) {
                     }];
}

- (void)setNewTableViewOffset{
    if (self.tableView.contentSize.height > self.tableView.ddHeight) {
        self.tableView.contentOffset = CGPointMake(0, fabs(self.tableView.contentSize.height-self.tableView.frame.size.height));
    }
}

#pragma mark - UIScrollViewDeleagte
// 滚动tableview 让键盘取消第一响应

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    startPoint = scrollView.contentOffset.y;
}


-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (scrollView.contentOffset.y - scrollView.contentSize.height + scrollView.frame.size.height >200.0) {
        [self.toolBar becomeFirstResponder];
    }
}


// 结束拖拽的时候
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    
    if (startPoint - scrollView.contentOffset.y > 70 ||
        scrollView.contentOffset.y < -10 ||
        startPoint - scrollView.contentOffset.y < -70 ||
        scrollView.contentOffset.y > (scrollView.contentSize.height-scrollView.ddHeight-10)) {
        [self.toolBar resignTextViewFirstResponder];
    }
    
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
