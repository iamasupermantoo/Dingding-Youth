//
//  FKMyChatListCell.h
//  UDan
//
//  Created by frankay on 16/12/14.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "FKMyChatListCell.h"
@class FKBaseChatItem;
@protocol  FKMyChatListCellDelegate<NSObject>
- (void)FKSessionListCelltapIcon:(NSDictionary *)info;
@end


@interface FKMyChatListCell : UITableViewCell
- (void)updateCellWithItem:(FKBaseChatItem *)Item;
@end



