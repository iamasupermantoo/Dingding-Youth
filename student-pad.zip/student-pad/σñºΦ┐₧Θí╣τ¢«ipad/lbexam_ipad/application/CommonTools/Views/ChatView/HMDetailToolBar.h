//
//  HMDetailToolBar.h
//  UDan
//
//  Created by lilingang on 16/10/30.
//  Copyright © 2016年 LiLingang. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "HPGrowingTextView.h"

@class HMDetailToolBar;

@protocol HMDetailToolBarDelegate <NSObject>


@optional

- (void)hmDetailToolBarDelegateDidChangedHeight:(HMDetailToolBar *)toolBar;

- (void)hmDetailToolBarDelegateSendCommentWithText:(NSString *)text;

- (void)fkDetailToolBarDelegateSendBtnActionWithText:(NSString *)text;

@end

@interface HMDetailToolBar : UIView

@property (nonatomic, weak) id<HMDetailToolBarDelegate> deleagte;

@property (weak, nonatomic) IBOutlet HPGrowingTextView *growTextView;

@property(nonatomic,assign) UIReturnKeyType returnkeyType;
@property (weak, nonatomic) IBOutlet UIButton *favorButton;

@property(nonatomic,assign) BOOL isSend;
- (void)resignTextViewFirstResponder;

- (void)clear;

- (instancetype)initWithFrame:(CGRect)frame with:(BOOL)isSend withReturnType:(NSInteger)type;
@end
