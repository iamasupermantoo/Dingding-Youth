//
//  FKMyChatListCell.m
//  UDan
//
//  Created by frankay on 16/12/14.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "FKMyChatListCell.h"
#import "FKBaseChatItem.h"
#import "NSString+UDan.h"
@interface FKMyChatListCell ()
@property (weak, nonatomic) IBOutlet UIImageView *icon;
@property (weak, nonatomic) IBOutlet UILabel *sendTime;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bubbleTrailingConstraint;
@property (weak, nonatomic) IBOutlet UIImageView *bgImageView;
@property (weak, nonatomic) IBOutlet UILabel *Sendcontent;
@property (weak, nonatomic) IBOutlet UIView *bubbleView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bubbleHeightConstraint;

@end
@implementation FKMyChatListCell

-(void)awakeFromNib{
    [super awakeFromNib];
    
    self.bubbleView.layer.borderWidth = 0.5;
    self.bubbleView.layer.borderColor = [UIColor hmBorderColor].CGColor;
    self.bubbleView.layer.cornerRadius = 5.0;

}

- (void)updateCellWithItem:(FKBaseChatItem *)Item{
    self.Sendcontent.text = Item.Content;
//    UIFont *textFont = [UIFont systemFontOfSize:15];
//    CGFloat textHeight = ceil(textFont.lineHeight);
//    CGFloat maxsize = SCREENWIDTH - 160;
//    CGSize textSize;
//
//    
//    if (![Item.Content isSingleLineWithMaxWidth:maxsize textFont:textFont]) {
//        // 文字多行
//        textSize = [Item.Content sizeWithMaxWidth:maxsize textFont:textFont lineSpace:0.0 firstLineHeadIndent:0.0];
//        textHeight = textSize.height;
//        
//    }
//    self.bubbleHeightConstraint.constant = textHeight + 20;
////    self.cellHeight = textHeight + 59;
    
}
@end

