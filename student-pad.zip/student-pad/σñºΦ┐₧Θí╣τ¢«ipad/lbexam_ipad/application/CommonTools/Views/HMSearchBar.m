//
//  HMSearchBar.m
//  UDan
//
//  Created by lilingang on 16/10/18.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMSearchBar.h"

@implementation HMSearchBar

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
