//
//  FKHeaderView2Cell.m
//  lbexam
//
//  Created by frankay on 17/1/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKHeaderView2Cell.h"

@interface FKHeaderView2Cell ()
@property (weak, nonatomic) IBOutlet FKinitLabel *title;

@end

@implementation FKHeaderView2Cell

- (void)initSettings{
    [super initSettings];
    self.title.font = [UIFont boldSystemFontOfSize:16];
    self.title.textColor = [UIColor fkColorWithString:@"#529bfa"];
}

-(void)updateWithCellItem:(FKHeaderView2CellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    if (cellItem.rawObject) {
        self.title.text = cellItem.rawObject;
    }else{
        self.title.attributedText = cellItem.attributeString;
    }

}

@end

@implementation FKHeaderView2CellItem

- (void)initSettings{
    [super initSettings];
    self.cellHeight = 45;
    self.canSelect = NO;
    self.separatorInset = kIpadNoGapSeperateInsets;
}

+(FKHeaderView2CellItem *)cellWithTitle:(NSString *)title{
    NSDictionary *attridic = @{
                               NSForegroundColorAttributeName:[UIColor hmTextBlackColor],
                               NSFontAttributeName:[UIFont systemFontOfSize:14]
                               };
    NSMutableAttributedString *att = [[NSMutableAttributedString alloc] initWithString:title attributes:attridic];
    [att addAttribute:NSForegroundColorAttributeName value:[UIColor fkfe8d25Color] range:NSMakeRange(2, 1)];
    return [FKHeaderView2CellItem TitleWithAttr:att andCellHeight:45];
}


+ (FKHeaderView2CellItem *)ordinaryCellItemWithTitle:(NSString *)title{
    NSDictionary *attridic = @{
                               NSForegroundColorAttributeName:[UIColor hmTextBlackColor],
                               NSFontAttributeName:[UIFont systemFontOfSize:15]
                               };
    NSMutableAttributedString *att = [[NSMutableAttributedString alloc] initWithString:title attributes:attridic];
    
    return [FKHeaderView2CellItem TitleWithAttr:att andCellHeight:44];
}

+(FKHeaderView2CellItem *)TitleWithAttr:(NSAttributedString *)attr andCellHeight:(CGFloat)cellHeight{
    FKHeaderView2CellItem *cellItem = [[FKHeaderView2CellItem alloc] init];
    cellItem.attributeString = attr;
    return cellItem;
}
@end
