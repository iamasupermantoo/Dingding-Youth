//
//  IMLine.h
//  03-Drawing
//
//  Created by feng-Mac on 16/10/21.
//  Copyright © 2016年 feng-Mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface IMLine : NSObject

@property (nonatomic, strong) NSMutableArray *points;

@property (nonatomic, strong) UIColor *color;

@property (nonatomic, assign) CGFloat lineWidth;

@end
