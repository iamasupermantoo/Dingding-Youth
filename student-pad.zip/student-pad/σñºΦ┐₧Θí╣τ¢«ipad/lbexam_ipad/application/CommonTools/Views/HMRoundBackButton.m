//
//  HMRoundBackButton.m
//  UDan
//
//  Created by lilingang on 16/10/29.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMRoundBackButton.h"

@implementation HMRoundBackButton

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initSettings];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initSettings];
    }
    return self;
}

- (void)initSettings{
    self.adjustsImageWhenHighlighted = NO;
    [self setBackgroundImage:[[UIImage imageNamed:@"detail_round_white_back"] resizableImageWithCapInsets:UIEdgeInsetsMake(13, 18, 13, 18)] forState:UIControlStateNormal];
}

@end
