//
//  FKHeaderView3Cell.m
//  lbexam
//
//  Created by frankay on 17/2/10.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKHeaderView3Cell.h"

@interface FKHeaderView3Cell ()
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *leadingConstraint;

@end

@implementation FKHeaderView3Cell

- (void)updateWithCellItem:(FKHeaderView3CellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    
    self.title.text = cellItem.rawObject;
    self.bottomConstraint.constant = cellItem.bottomConstraint;
    self.leadingConstraint.constant = cellItem.leadConstraint;
}

@end

@implementation FKHeaderView3CellItem

- (void)initSettings{
    [super initSettings];
    self.leadConstraint = 15;
    self.bottomConstraint = 10;
    self.canSelect = NO;
    self.separatorInset = kIpadNoGapSeperateInsets;
    self.backgroundColor = [UIColor hmMainBgColor];
    self.cellHeight = 50;
}

@end
