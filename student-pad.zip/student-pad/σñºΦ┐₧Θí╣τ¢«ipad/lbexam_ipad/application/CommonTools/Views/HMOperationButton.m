//
//  HMOperationButton.m
//  UDan
//
//  Created by lilingang on 16/10/14.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMOperationButton.h"

@interface HMOperationButton ()
@end

@implementation HMOperationButton

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initSettings];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initSettings];
    }
    return self;
}

- (void)initSettings{
    self.relationStatus = HMRelationStatusUnFollow;
    [self setTitle:HMLocal(@"关注") forState:UIControlStateNormal];
    [self setImage:nil forState:UIControlStateNormal];
}

- (void)layoutSubviews{
    [super layoutSubviews];
    if (self.relationStatus == HMRelationStatusUnFollow ||
        self.relationStatus  == HMRelationStatusFollowed) {
        self.backgroundColor = [UIColor hmYellowColor];
        self.layer.cornerRadius = 4.0;
        self.layer.masksToBounds = YES;
    } else {
        self.backgroundColor = [UIColor clearColor];
    }
}

- (void)setRelationStatus:(HMRelationStatus)relationStatus{
    _relationStatus = relationStatus;
    if (self.relationStatus == HMRelationStatusUnFollow ||
        self.relationStatus  == HMRelationStatusFollowed) {
        [self setTitle:HMLocal(@"关注") forState:UIControlStateNormal];
        [self setImage:nil forState:UIControlStateNormal];
    } else if (self.relationStatus  == HMRelationStatusFollowing){
        [self setTitle:@"" forState:UIControlStateNormal];
        [self setImage:[UIImage imageNamed:@"common_following_icon"] forState:UIControlStateNormal];
    } else if (self.relationStatus  == HMRelationStatusFollowBoth){
        [self setTitle:@"" forState:UIControlStateNormal];
        [self setImage:[UIImage imageNamed:@"common_followboth_icon"] forState:UIControlStateNormal];
    }
}
@end
