//
//  IMView.h
//  03-Drawing
//
//  Created by feng-Mac on 16/10/21.
//  Copyright © 2016年 feng-Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@class IMLine;
@protocol IMViewDelegate <NSObject>

@optional
- (void)touchEndWithLines:(IMLine *)line;

@end

@interface IMView : UIView

@property (nonatomic, strong) NSMutableArray *lines;

@property (nonatomic,strong) NSMutableArray *selfLines;

@property (nonatomic, strong) UIColor *color;
@property (nonatomic, strong) UIColor *selfLineColor;
@property (nonatomic, assign) CGFloat sliderValue;

@property(nonatomic,weak)id<IMViewDelegate>delegate;
- (void)back;

- (void)clear;

- (void)clearSelfLines;

- (void)clearAll;
@end
