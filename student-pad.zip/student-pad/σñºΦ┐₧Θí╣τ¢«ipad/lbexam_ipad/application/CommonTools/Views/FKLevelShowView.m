//
//  FKLevelShowView.m
//  lbexam
//
//  Created by frankay on 17/1/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKLevelShowView.h"

@interface FKLevelShowView ()
@property (weak, nonatomic) IBOutlet UIImageView *level1;
@property (weak, nonatomic) IBOutlet UIImageView *level2;
@property (weak, nonatomic) IBOutlet UIImageView *level3;
@property (weak, nonatomic) IBOutlet UIImageView *level4;
@property (weak, nonatomic) IBOutlet UIImageView *level5;
@property (strong, nonatomic) IBOutlet UIView *contentView;

@end
@implementation FKLevelShowView


- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super initWithCoder:aDecoder]) {
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        self.contentView.frame = CGRectMake(0, 5, 200, 10);
        [self addSubview:self.contentView];
    }
    return self;
}

-(void)updateLevelWith:(NSInteger)type{

    switch (type) {
        case 0:
        {
            self.level1.hidden = YES;
            self.level2.hidden = YES;
            self.level3.hidden = YES;
            self.level4.hidden = YES;
            self.level5.hidden = YES;
        }
            break;
        case 1:
        {
            self.level2.hidden = YES;
            self.level3.hidden = YES;
            self.level4.hidden = YES;
            self.level5.hidden = YES;
        }
            break;
        case 2:
        {
            self.level3.hidden = YES;
            self.level4.hidden = YES;
            self.level5.hidden = YES;
        }
            break;
        case 3:
        {
            self.level4.hidden = YES;
            self.level5.hidden = YES;
        }
            break;
        case 4:
        {
            self.level5.hidden = YES;
        }
            break;
        case 5:
    
            break;
        default:
            break;
    }
}
@end
