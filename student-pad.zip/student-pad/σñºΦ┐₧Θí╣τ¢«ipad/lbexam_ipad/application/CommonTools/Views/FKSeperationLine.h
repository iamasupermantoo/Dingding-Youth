//
//  FKSeperationLine.h
//  lbexam_ipad
//
//  Created by frankay on 17/2/23.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FKSeperationLine : UIView

@end
