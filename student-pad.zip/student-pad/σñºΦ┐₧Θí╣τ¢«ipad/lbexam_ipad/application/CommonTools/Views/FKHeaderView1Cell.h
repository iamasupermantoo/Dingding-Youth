//
//  FKHeaderView1Cell.h
//  lbexam
//
//  Created by frankay on 17/1/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"
#import "HMTableViewCellItem.h"
@interface FKHeaderView1Cell : HMTableViewCell

@end


@interface FKHeaderView1CellItem : HMTableViewCellItem
@property(nonatomic,assign) CGFloat Bottomconstant;
@end
