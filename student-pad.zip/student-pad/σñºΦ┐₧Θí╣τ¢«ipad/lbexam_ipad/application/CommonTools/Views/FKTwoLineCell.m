//
//  FKTwoLineItemCell.m
//  lbexam
//
//  Created by frankay on 17/1/16.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKTwoLineCell.h"
#import "FKOneItemView.h"
#import "FKestalishCourseItem.h"
@interface FKTwoLineCell ()
@property (weak, nonatomic) IBOutlet FKOneItemView *leftItemView;
@property (weak, nonatomic) IBOutlet FKOneItemView *RightItemView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *leftbottomConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rightbottomConstraint;

@end

@implementation FKTwoLineCell

- (void)initSettings{
    [super initSettings];
    // 设置手势
    self.leftItemView.tag = 1001;
    self.RightItemView.tag = 1002;
    [self.leftItemView ddAddTarget:self tapAction:@selector(clickOneView:)];
    [self.leftItemView ddAddTarget:self tapAction:@selector(clickOneView:)];
}



- (void)updateWithCellItem:(FKTwoLineCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    
    // 数组
    // 1、如果数组count为1  设置leftview 隐藏rightview
    // 2、如果数组count 为2 分别设置leftview rightview
    // 如果带图片 则需要调用另一个方法
    NSArray *ImageCellItems = cellItem.cellImageItems;
    [self.leftItemView updateOneViewWith:ImageCellItems.firstObject WithImgWidth:cellItem.imageCellWidth isloadLocalImage:YES];
    if (ImageCellItems.count>1) {
        [self.RightItemView updateOneViewWith:ImageCellItems.lastObject WithImgWidth:cellItem.imageCellWidth isloadLocalImage:YES];
    }else{
        self.RightItemView.hidden = YES;
    }

}

- (void)showImagesWithCellItem:(FKTwoLineCellItem *)cellItem{
    [super showImagesWithCellItem:cellItem];
    NSArray *ImageCellItems = cellItem.cellImageItems;
    
    [self.leftItemView updateOneViewWith:ImageCellItems.firstObject WithImgWidth:cellItem.imageCellWidth isloadLocalImage:NO];
    if (ImageCellItems.count>1) {
        [self.RightItemView updateOneViewWith:ImageCellItems.lastObject WithImgWidth:cellItem.imageCellWidth isloadLocalImage:NO];
    }
}
// 手势事件

- (void)clickOneView:(UIGestureRecognizer *)tap{
    NSInteger index = tap.view.tag - 1000;
    [self.deleagte hmTableViewCell:self sender:nil selector:@selector(SelectedOneView:) userInfo:@(index)];
}


@end



@interface FKTwoLineCellItem ()
{
    CGFloat _maxLabelHeight;
}
@end

@implementation FKTwoLineCellItem

- (void)initSettings{
    [super initSettings];
    self.separatorInset = kIpadNoGapSeperateInsets;
    self.cellHeight = 240;
    self.canSelect = NO;
    _imageCellWidth = (SCREENWIDTH - 40)/2.0;
    _maxLabelHeight = 41;
}


- (void)setRawObject:(id)rawObject{
    // 1、每个item的值
    // 2、根据item的值计算图片的高度。label的高度
    // 3、根据两边内容的高度比较 cellheight的高度为最大的一方高度
    if (rawObject==nil) {
        return;
    }
    NSArray *imageItemCells = rawObject;
    self.cellImageItems = rawObject;
    UIFont *font = [UIFont systemFontOfSize:14];
    CGFloat leftlabelHeight = ceil(font.lineHeight);
    FKestalishCourseItem *leftImgItem = [imageItemCells firstObject];
    BOOL leftisSingle = [leftImgItem.brief isSingleLineWithMaxWidth:_imageCellWidth textFont:font];
    leftImgItem.issingleLine = leftisSingle;
    if (!leftisSingle) {
        leftlabelHeight = _maxLabelHeight;
    }
    
    CGFloat rightlabelHeight = ceil(font.lineHeight);
    if (imageItemCells.count>1) {
        FKestalishCourseItem *rightImgItem = [imageItemCells lastObject];
        BOOL rightisSingle = [rightImgItem.brief isSingleLineWithMaxWidth:_imageCellWidth textFont:font] ;
        
        leftImgItem.issingleLine = leftisSingle;
        if (!rightisSingle) {
            rightlabelHeight = _maxLabelHeight;
        }
    }
    // 15 +10 +10
    self.cellHeight = (rightlabelHeight>=leftlabelHeight ? rightlabelHeight:leftlabelHeight)+35+_imageCellWidth;
    
}


@end
