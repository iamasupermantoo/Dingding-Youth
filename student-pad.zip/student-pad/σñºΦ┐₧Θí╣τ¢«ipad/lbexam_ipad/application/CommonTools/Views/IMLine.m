//
//  IMLine.m
//  03-Drawing
//
//  Created by feng-Mac on 16/10/21.
//  Copyright © 2016年 feng-Mac. All rights reserved.
//

#import "IMLine.h"

@implementation IMLine

-(instancetype)init{
    if (self=[super init]) {
        _points =[NSMutableArray array];
    }
    return self;

}

@end
