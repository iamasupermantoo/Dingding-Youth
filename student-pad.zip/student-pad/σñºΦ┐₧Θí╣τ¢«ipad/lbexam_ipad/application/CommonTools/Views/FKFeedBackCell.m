//
//  FKFeedBackCell.m
//  lbexam
//
//  Created by frankay on 17/1/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKFeedBackCell.h"
#import "FKLevelShowView.h"
@interface FKFeedBackCell ()
@property (weak, nonatomic) IBOutlet UIImageView *Ficon;
@property (weak, nonatomic) IBOutlet UILabel *Fname;
@property (weak, nonatomic) IBOutlet FKLevelShowView *FlevelShow;
@property (weak, nonatomic) IBOutlet UILabel *Ftime;
@property (weak, nonatomic) IBOutlet UILabel *Fcontent;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *trailConstraint;
@property (weak, nonatomic) IBOutlet UIView *contentview;

@end

@implementation FKFeedBackCell

- (void)initSettings{
    [super initSettings];
    
    self.Fname.textColor = [UIColor hmTextBlackColor];
    self.Ftime.textColor = [UIColor hmTextGrayColor];
    self.Fcontent.textColor = [UIColor fk666Color];
}


-(void)updateWithCellItem:(FKFeedBackCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    

}
@end


@implementation FKFeedBackCellItem

- (void)initSettings{
    [super initSettings];
    self.cellHeight = 85;
    self.canSelect = NO;
    self.separatorInset = kIpadNoGapSeperateInsets;

}
@end
