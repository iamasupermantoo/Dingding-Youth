//
//  HMSplashViewController.m
//  UDan
//
//  Created by lilingang on 16/9/25.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMSplashViewController.h"
#import "HMUserHandler.h"
#import "HMRouterHandler.h"

@interface HMSplashViewController ()

@end

@implementation HMSplashViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.rightBarButtonItems = nil;
    self.navigationItem.leftBarButtonItems = nil;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if ([[HMUserHandler sharedInstance] hasLogin]) {
            [HMRouterHandler revertToMainController];
        } else {
            [HMRouterHandler revertToLoginController];
        }
    });
}

@end
