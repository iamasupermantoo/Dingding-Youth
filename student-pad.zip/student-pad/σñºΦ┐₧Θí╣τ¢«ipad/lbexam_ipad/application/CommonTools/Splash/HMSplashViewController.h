//
//  HMSplashViewController.h
//  UDan
//
//  Created by lilingang on 16/9/25.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HMSplashViewController : UIViewController

@end
