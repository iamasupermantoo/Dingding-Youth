//
//  HMButtonUtils.h
//  UDan
//
//  Created by 范文青 on 16/10/10.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMButtonUtils : NSObject
+ (UIButton *)navigationItemButton:(NSString *)title;
+ (UIButton *)backButton;
+ (UIButton *)buttonWithIcon:(NSString *)image;
@end
