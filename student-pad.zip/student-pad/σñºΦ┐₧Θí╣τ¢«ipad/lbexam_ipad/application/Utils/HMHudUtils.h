//
//  HMUtils.h
//  UDan
//
//  Created by 范文青 on 2016/10/29.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMHudUtils : NSObject
+ (void)showLoading;
+ (void)showMessage:(NSString *)message;
+ (void)dismissLoading;
@end
