//
//  RandomUtils.h
//  UDan
//
//  Created by 范文青 on 16/10/10.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMRandomUtils : NSObject
+ (NSInteger)randomWithLower:(NSInteger)lowerBound upper:(NSInteger)upper;
@end
