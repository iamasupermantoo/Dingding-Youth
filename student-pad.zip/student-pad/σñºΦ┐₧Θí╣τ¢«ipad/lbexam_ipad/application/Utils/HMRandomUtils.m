//
//  RandomUtils.m
//  UDan
//
//  Created by 范文青 on 16/10/10.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMRandomUtils.h"

@implementation HMRandomUtils
+ (NSInteger)randomWithLower:(NSInteger)lowerBound upper:(NSInteger)upperBound{
    NSInteger rndValue = lowerBound + arc4random() % (upperBound - lowerBound);
    return rndValue;
}
@end
