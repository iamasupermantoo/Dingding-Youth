//
//  HMUtils.m
//  UDan
//
//  Created by 范文青 on 2016/10/29.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMHudUtils.h"

@implementation HMHudUtils
+ (void)showLoading{
    [DDProgressHUD showHUDWithStatus:@"加载中..."];
}
+ (void)showMessage:(NSString *)message{
    [DDProgressHUD showWithStatus:message];
}
+ (void)dismissLoading{
    [DDProgressHUD dismiss];
}
@end
