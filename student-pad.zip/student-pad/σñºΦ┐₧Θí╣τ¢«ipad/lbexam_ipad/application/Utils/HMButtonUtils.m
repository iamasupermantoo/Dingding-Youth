//
//  HMButtonUtils.m
//  UDan
//
//  Created by 范文青 on 16/10/10.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMButtonUtils.h"

@implementation HMButtonUtils
+ (UIButton *)navigationItemButton:(NSString *)title{
    UIButton *button= [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:title forState:UIControlStateNormal];
    [[button titleLabel] setFont:[UIFont systemFontOfSize:16.0f]];
    [button setTitleColor:[UIColor hmTextBlackColor] forState:UIControlStateNormal];
    [button sizeToFit];
    [button setDdHeight:44];
    return button;
}
+ (UIButton *)buttonWithIcon:(NSString *)image{
    UIButton *button= [UIButton buttonWithType:UIButtonTypeCustom];
    [button setDdHeight:44];
    [button setDdWidth:44];
    [button setImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    return button;
}
+ (UIButton *)backButton{
    UIButton *button= [UIButton buttonWithType:UIButtonTypeCustom];
    [button setDdHeight:44];
    [button setDdWidth:8];
    [button setImage:[UIImage imageNamed:@"navigationbar_back_normal"] forState:UIControlStateNormal];
    return button;
}
@end
