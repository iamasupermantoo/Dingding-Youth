//
//  NSDictionary+WebService.h
//  UDan
//
//  Created by lilingang on 16/9/29.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (WebService)

/**
 将字典转换成字符串

 @param trim 是否去掉特殊符号

 @return NSString
 */
- (NSString *)wsDictionaryToJsonStringTrim:(BOOL)trim;

/**
 将字典转为Query字符串

 @return NSString
 */
- (NSString *)wsQueryString;

@end
