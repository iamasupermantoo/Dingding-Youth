//
//  NSDictionary+WebService.m
//  UDan
//
//  Created by lilingang on 16/9/29.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "NSDictionary+WebService.h"
#import "NSString+WebService.h"

@implementation NSDictionary (WebService)

- (NSString *)wsDictionaryToJsonStringTrim:(BOOL)trim{
    NSString *jsonString = @"";
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:self
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    if (! jsonData) {
        NSLog(@"dictionary to json error: %@", error);
    } else {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        if (trim) {
            jsonString = [jsonString wsTrimSpecialCode];
        }
    }
    return jsonString;
}

- (NSString *)wsQueryString{
    if ([[self allKeys] count] == 0) {
        return @"";
    }
    NSString *queryString = @"?";
    for (NSString *key in self) {
        queryString = [queryString stringByAppendingFormat:@"%@=%@&",key,self[key]];
    }
    queryString = [queryString substringToIndex:[queryString length] -1 ];
    return queryString;
}

@end
