//
//  WSMetaItem.m
//  UDan
//
//  Created by lilingang on 16/9/29.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "WSMetaItem.h"

@implementation WSMetaItem

- (instancetype)initWithDictionary:(NSDictionary *)dictionary{
    self = [super init];
    if (self) {
        self.code = [[dictionary objectForKey:@"code"] integerValue];
        self.desc = [dictionary objectForKey:@"desc"];
#ifdef DEBUG
        self.hostname = [dictionary objectForKey:@"hostname"];
        self.errInfo = [dictionary objectForKey:@"errInfo"];
        self.cost = [dictionary objectForKey:@"cost"];
        self.timestamp = [[dictionary objectForKey:@"timestamp"] doubleValue];
#endif
    }
    return self;
}

@end
