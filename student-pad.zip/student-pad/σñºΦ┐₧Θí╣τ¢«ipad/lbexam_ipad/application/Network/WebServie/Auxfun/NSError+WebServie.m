//
//  NSError+WebServie.m
//  HMRequestDemo
//
//  Created by lilingang on 15/7/23.
//  Copyright (c) 2015年 lilingang. All rights reserved.
//

#import "NSError+WebServie.h"


NSString * const WSErrorMetaItemKey = @"WSErrorMetaItemKey";

NSString * const WSErrorCustomErrorKey = @"WSErrorCustomErrorKey";
NSString * const WSErrorCodeKey        = @"WSErrorCodeKey";
NSString * const WSErrorTitleKey       = @"WSErrorTitleKey";
NSString * const WSErrorDetailKey      = @"WSErrorDetailKey";
NSString * const WSErrorUserInfoKey    = @"WSErrorUserInfoKey";

@implementation NSError (WebServie)

- (BOOL)isCustomError{
    return [[self.userInfo objectForKey:WSErrorCustomErrorKey] boolValue];
}

- (NSString *)wsTitle{
    return [self.userInfo objectForKey:WSErrorTitleKey];
}

- (NSString *)wsDetail{
    return [self.userInfo objectForKey:WSErrorDetailKey];
}

+ (NSError *)wsLocalHeaderErrorKey:(NSString *)key{
    return [NSError wsErrorWithCode:WSErrorCode_LocalHeaderError title:@"wsLocalHeaderError" description:[NSString stringWithFormat:@"%@ required parameter or invalid parameter",key]];
}

+ (NSError *)wsLocalParamErrorKey:(NSString *)key{
    return [NSError wsErrorWithCode:WSErrorCode_LocalParamError title:@"wsLocalParamError" description:[NSString stringWithFormat:@"%@",key]];
}

#pragma mark - web servives

+ (NSError *)wsNeedLoginError {
    return [NSError wsErrorWithCode:WSErrorCode_NeedLoginError title:@"wsNeedLoginError" description:HMLocal(@"你已经在另一台设备登录")];
}

+ (NSError *)wsNetworkNotAvalableError {
    return [NSError wsErrorWithCode:WSErrorCode_NetworkNotReachableError title:@"wsNetworkNotAvalableError" description:HMLocal(@"网络太差，潇洒不起来了，呜呜")];
}

+ (NSError *)wsSeverError {
    return [NSError wsErrorWithCode:WSErrorCode_SeverError title:@"wsResponseFormatError" description:HMLocal(@"服务器出错了\n请将错误反馈给我们")];
}

+ (NSError *)wsResponseFormatError {
    return [NSError wsErrorWithCode:WSErrorCode_ResponseFormatError title:@"wsResponseFormatError" description:HMLocal(@"服务器出错了\n请将错误反馈给我们")];
}

+ (NSError *)wsHttpResponseStatusError {
    return [NSError wsErrorWithCode:WSErrorCode_HTTPResponseStatusError title:@"wsHttpResponseStatusError" description:HMLocal(@"服务器出错了\n请将错误反馈给我们")];
}

+ (NSError *)wsMetaEmptyError {
    return [NSError wsErrorWithCode:WSErrorCode_MetaEmptyError title:@"wsMetaEmptyError" description:HMLocal(@"服务器出错了\n请将错误反馈给我们")];
}

+ (NSError *)wsUnknownError {
    return [NSError wsErrorWithCode:WSErrorCode_UnknownError title:@"wsUnknownError" description:HMLocal(@"服务器出错了\n请将错误反馈给我们")];
}

+ (NSError *)wsErrorWithCode:(NSInteger)code title:(NSString *)title description:(NSString *)description{
    return [self wsErrorWithCode:code title:title description:description otherInfo:nil];
}

+ (NSError *)wsErrorWithCode:(NSInteger)code title:(NSString *)title description:(NSString *)description otherInfo:(NSDictionary *)otherInfo{
    NSMutableDictionary *info = [[NSMutableDictionary alloc] init];
    [info setObject:@(code) forKey:WSErrorCodeKey];
    [info setObject:@(YES) forKey:WSErrorCustomErrorKey];
    if (title) {
        [info setObject:title forKey:WSErrorTitleKey];
    }
    if (description) {
        [info setObject:description forKey:WSErrorDetailKey];
    }
    if (otherInfo) {
        [info setObject:otherInfo forKey:WSErrorUserInfoKey];
    }
    return [NSError errorWithDomain:NSStringFromClass([self class]) code:code userInfo:info];
}

@end
