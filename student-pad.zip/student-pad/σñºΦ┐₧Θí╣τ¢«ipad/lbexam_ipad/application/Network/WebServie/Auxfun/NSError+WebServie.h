//
//  NSError+WebServie.h
//  HMRequestDemo
//
//  Created by lilingang on 15/7/23.
//  Copyright (c) 2015年 lilingang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WSMetaItem.h"

UIKIT_EXTERN NSString * const WSErrorMetaItemKey;
UIKIT_EXTERN NSString * const WSErrorCustomErrorKey;
UIKIT_EXTERN NSString * const WSErrorCodeKey;
UIKIT_EXTERN NSString * const WSErrorTitleKey;
UIKIT_EXTERN NSString * const WSErrorDetailKey;
UIKIT_EXTERN NSString * const WSErrorUserInfoKey;

typedef NS_ENUM(NSUInteger, WSErrorCode) {
    WSErrorCode_NeedLoginError = 401,
    WSErrorCode_NetworkNotReachableError = 408,
    
    WSErrorCode_SeverError = 500,
    
    WSErrorCode_LocalHeaderError = 600,
    WSErrorCode_LocalParamError,

    WSErrorCode_ResponseFormatError = 800,
    WSErrorCode_HTTPResponseStatusError,
    WSErrorCode_MetaEmptyError,
    WSErrorCode_MetaCodeError,
    
    WSErrorCode_UnknownError = 900,
};

@interface NSError (WebServie)

- (BOOL)isCustomError;
- (NSString *)wsTitle;
- (NSString *)wsDetail;

+ (NSError *)wsLocalHeaderErrorKey:(NSString *)key;
+ (NSError *)wsLocalParamErrorKey:(NSString *)key;
+ (NSError *)wsNeedLoginError;
+ (NSError *)wsNetworkNotAvalableError;
+ (NSError *)wsSeverError;
+ (NSError *)wsResponseFormatError;
+ (NSError *)wsHttpResponseStatusError;
+ (NSError *)wsMetaEmptyError;
+ (NSError *)wsUnknownError;


+ (NSError *)wsErrorWithCode:(NSInteger)code title:(NSString *)title description:(NSString *)description;

+ (NSError *)wsErrorWithCode:(NSInteger)code title:(NSString *)title description:(NSString *)description otherInfo:(NSDictionary *)otherInfo;

@end
