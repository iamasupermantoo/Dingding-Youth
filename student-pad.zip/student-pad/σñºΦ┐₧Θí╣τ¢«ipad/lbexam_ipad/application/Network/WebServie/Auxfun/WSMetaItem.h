//
//  WSMetaItem.h
//  UDan
//
//  Created by lilingang on 16/9/29.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WSMetaItem : NSObject

@property (nonatomic, assign) NSInteger code;
@property (nonatomic, copy) NSString *desc;

#ifdef DEBUG
@property (nonatomic, copy) NSString *hostname;
@property (nonatomic, copy) NSString *errInfo;
@property (nonatomic, copy) NSString *cost;
@property (nonatomic, assign) NSTimeInterval timestamp;
#endif

- (instancetype)initWithDictionary:(NSDictionary *)dictionary;

@end
