//
//  WSNetworkMonitor.h
//  UDan
//
//  Created by lilingang on 16/10/30.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WSNetworkMonitor : NSObject

+ (void)startMonitor;

+ (void)stopMonitor;

+ (BOOL)isReachable;

+ (BOOL)isWIFI;

+ (BOOL)isWWAN;

@end
