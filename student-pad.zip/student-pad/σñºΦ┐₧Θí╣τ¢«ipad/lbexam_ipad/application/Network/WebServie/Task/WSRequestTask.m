//
//  WSRequestTask.m
//  FitRunning
//
//  Created by lilingang on 15/11/21.
//  Copyright © 2015年 LiLingang. All rights reserved.
//

#import "WSRequestTask.h"
#import "WSNetWorkClient.h"
#import "HMRouterHandler.h"

static BOOL isShowAlertView = NO;

@interface WSRequestTask ()

/**@brief 完整的请求URL*/
@property (nonatomic, copy, readwrite) NSString *requestUrlString;

/**@brief 自定义的HEADER*/
@property (nonatomic, strong, readwrite) NSMutableDictionary *headerDictionary;

/**@brief 自定义的parameter*/
@property (nonatomic, strong, readwrite) NSMutableDictionary *parameterDictionary;

@property (nonatomic, assign, readwrite, getter=isLoading) BOOL loading;

/**@brief 实现请求的回调*/
@property (nonatomic, copy) WSCompleteHandle completeHandle;

@end

@implementation WSRequestTask

- (instancetype)init{
    self = [super init];
    if (self) {
        self.loading = NO;
    }
    return self;
}

#pragma mark - request config

- (NSURL *)baseUrl{
    NSAssert(NO, @"subclass must implement");
    return nil;
}

- (NSString *)apiName{
    return @"";
}

- (WSHTTPMethod)requestMethod{
    return WSHTTPMethodGET;
}

- (NSString *)apiVersion{
    return @"0.0";
}

- (NSError *)requestLocalCheckHeaderFieldValidity{
    return nil;
}

- (void)requestDefaultHeaderFieldConfiguration{
    self.headerDictionary = [[NSMutableDictionary alloc] init];
}

- (NSError *)requestLocalCheckParameterValidity{
    return nil;
}

- (void)requestParameterConfiguration{
    self.parameterDictionary = [[NSMutableDictionary alloc] init];
}

- (WSConstructingBlock)constructingBodyBlock{
    return nil;
}

- (NSData *)requestCustomUploadData{
    return nil;
}

#pragma mark - 策略
- (NSTimeInterval)timeoutInterval{
    return -1;
}

- (NSTimeInterval)requestTTL{
    return 0;
}

- (BOOL)shouldAllowCache{
    return NO;
}

#pragma mark - load

- (void)loadLocalWithComplateHandle:(WSCompleteHandle)complateHandle{
    self.completeHandle = complateHandle;
    [self loadLocal:YES];
}

- (void)loadWithComplateHandle:(WSCompleteHandle)complateHandle{
    self.completeHandle = complateHandle;
    [self loadLocal:NO];
}

- (void)load{
    [self loadLocal:NO];
}

- (void)cancel{
    [[WSNetWorkClient sharedInstance] cancelWithRequestId:self.taskIdentifier];
}

- (void)loadLocal:(BOOL)localData{
    self.shouldLoadLocalOnly = localData;
    if (self.isLoading) {
        NSLog(@"%@ is flying outside︿(￣︶￣)︿",[[self class] description]);
        return;
    }
    //local check
    NSError *error = [self requestLocalCheckHeaderFieldValidity];
    if (error) {
        [self requestDidFailWithError:error headers:nil];
        return;
    }
    error = [self requestLocalCheckParameterValidity];
    if (error) {
        [self requestDidFailWithError:error headers:nil];
        return;
    }
    [self requestDefaultHeaderFieldConfiguration];
    [self requestParameterConfiguration];
    self.loading = YES;
    self.resultObject = nil;
    [[WSNetWorkClient sharedInstance] loadWithRequestModel:self];
}

#pragma mark - parse

- (NSError *)responseHanlderWithDataInfo:(NSDictionary *)info{
    return nil;
    
}

#pragma mark - Web Servcie Response

- (void)requestDidSuccessWithObject:(id)responseObject headers:(NSDictionary *)headers{
    self.loading = NO;
    if (self.delegate && [self.delegate respondsToSelector:@selector(requestDidFinished:headers:response:localResult:)]) {
        [self.delegate requestDidFinished:self headers:headers response:responseObject localResult:self.shouldLoadLocalOnly];
    } else if (self.completeHandle){
        self.completeHandle(self,headers,responseObject,self.shouldLoadLocalOnly,nil);
        self.completeHandle = nil;
    }
}

- (void)requestDidFailWithError:(NSError *)error headers:(NSDictionary *)headers{
    if (error.code == 401) {
        [DDProgressHUD dismiss];
        if (isShowAlertView) {
            return;
        }
        PSTAlertController *alertController = [PSTAlertController alertControllerWithTitle:error.wsDetail message:@"" preferredStyle:PSTAlertControllerStyleAlert];
        PSTAlertAction *confirmAction = [PSTAlertAction actionWithTitle:@"重新登录" handler:^(PSTAlertAction * _Nonnull action) {
            isShowAlertView = NO;
            [HMRouterHandler revertToLoginController];
        }];
        [alertController addAction:confirmAction];
        [alertController showWithSender:nil controller:[UIApplication sharedApplication].keyWindow.rootViewController animated:YES completion:nil];
    } else {
   
        [DDProgressHUD showErrorWithStatus:[error.wsDetail stringByAppendingFormat:@"(%ld)",(long)error.code]];
    }
    self.loading = NO;
    if (self.delegate && [self.delegate respondsToSelector:@selector(requestDidFailed:headers:error:localResult:)]) {
        [self.delegate requestDidFailed:self headers:headers error:error localResult:self.shouldLoadLocalOnly];
    } else if (self.completeHandle){
        self.completeHandle(self,headers,nil,self.shouldLoadLocalOnly,error);
        self.completeHandle = nil;
    }
}

#pragma mark - Getter and setter

- (NSString *)taskIdentifier{
    return self.requestUrlString;
}

- (NSString *)requestUrlString{
    if (!_requestUrlString) {
        if ([[self apiName] length]) {
            _requestUrlString = [[NSURL URLWithString:[self apiName] relativeToURL:[self baseUrl]] absoluteString];
        } else {
            _requestUrlString = [[self baseUrl] absoluteString];
        }
    }
    return _requestUrlString;
}

@end
