//
//  WSRequestCallbackProtocol.h
//  UDan
//
//  Created by lilingang on 8/12/16.
//  Copyright © 2016 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>

@class WSRequestTask;

/**
 *  @brief 请求回调的block
 *
 *  @param request  WSRequestTask子类
 *  @param headers  请求的HEAD
 *  @param response 服务器返回的结果，NSDictionary类型
 *  @param localResult 是不是加载的本地数据
 *  @param error    请求失败的错误信息，eg. 参数错误，服务器错误,...
 */
typedef void (^WSCompleteHandle)(WSRequestTask *request,NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error);


/**
 *  @brief 回调协议
 */
@protocol WSRequestCallbackProtocol <NSObject>

/**
 *  @brief 请求成功的回调
 *
 *  @param request  WSRequestTask子类
 *  @param headers  请求的HEAD
 *  @param response 服务器返回的结果，NSDictionary类型
 *  @param localResult 是不是加载的本地数据
 */
- (void)requestDidFinished:(WSRequestTask *)request headers:(NSDictionary *)headers response:(NSDictionary *)response localResult:(BOOL)localResult;

/**
 *  @brief 请求失败的回调
 *
 *  @param request WSRequestTask子类
 *  @param headers 请求的HEAD 可为nil
 *  @param error   请求失败的错误信息，eg. 参数错误，服务器错误,...
 *  @param localResult 是不是加载的本地数据
 */
- (void)requestDidFailed:(WSRequestTask *)request headers:(NSDictionary *)headers error:(NSError *)error localResult:(BOOL)localResult;

@end
