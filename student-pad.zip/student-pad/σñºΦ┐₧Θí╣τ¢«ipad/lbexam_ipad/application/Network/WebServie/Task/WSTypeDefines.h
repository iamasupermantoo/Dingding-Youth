//
//  WSTypeDefines.h
//  UDan
//
//  Created by lilingang on 8/12/16.
//  Copyright © 2016 LiLingang. All rights reserved.
//

#ifndef WSTypeDefines_h
#define WSTypeDefines_h

/**
 *  @brief 定义请求方式
 */
typedef NS_ENUM(NSUInteger, WSHTTPMethod) {
    /**GET请求*/
    WSHTTPMethodGET,
    /**POST请求*/
    WSHTTPMethodPOST,
    /**Multipart POST请求*/
    WSHTTPMethodMultipart,
    /**PUT请求*/
    WSHTTPMethodPUT,
    /**DELETE请求*/
    WSHTTPMethodDELETE,
    /**PATCH请求*/
    WSHTTPMethodPATCH
};
#endif /* WSTypeDefines_h */
