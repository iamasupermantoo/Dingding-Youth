//
//  WSRequestTask.h
//  FitRunning
//
//  Created by lilingang on 15/11/21.
//  Copyright © 2015年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFNetworking.h>
#import "NSError+WebServie.h"
#import "WSTypeDefines.h"
#import "WSRequestCallbackProtocol.h"

/**
 *  @brief 实现MultipartFormData
 *
 *  @param formData AFMultipartFormData协议
 */
typedef void (^WSConstructingBlock)(id<AFMultipartFormData> formData);


/**
 *  @brief api请求的基类描述
 *  @note 任何api都何以继承该基类并配置参数完成一次请求
 */
@interface WSRequestTask : NSObject

/**@brief 强烈建议这种形式！！！ 设置网络回调接收者 同时实现block和delegate,则block设置会失效*/
@property (nonatomic, weak) id<WSRequestCallbackProtocol> delegate;

/**@brief  WSCompleteHandle 同时实现block和delegate,则block设置会失效*/
@property (nonatomic, copy, readonly) WSCompleteHandle completeHandle;

/**@brief 请求的唯一标识，默认为完整的URL，子类可自定义*/
@property (nonatomic, copy, readonly) NSString *taskIdentifier;

/**@brief  HTTP请求的完整的URLString eg.baseUrl/apiName*/
@property (nonatomic, copy, readonly) NSString *requestUrlString;

/**@brief  是否是加载的本地数据*/
@property (nonatomic, assign) BOOL shouldLoadLocalOnly;
/**@brief  是否正在加载数据*/
@property (nonatomic, assign, readonly, getter=isLoading) BOOL loading;

/**@brief 自定义的HEADER*/
@property (nonatomic, strong, readonly) NSMutableDictionary *headerDictionary;

/**@brief 自定义的parameter*/
@property (nonatomic, strong, readonly) NSMutableDictionary *parameterDictionary;

/** @brief  请求结束返回的数据 eg 原始数据 or 解析成model的数据*/
@property (nonatomic, strong) id resultObject;

#pragma mark - request config
/**
 * @brief  URL的Host eg. http://www.baidu.com
 */
- (NSURL *)baseUrl;

/**@brief  api名字 eg. /user/info*/
- (NSString *)apiName;

/**@brief  HTTP请求方法, default GET*/
- (WSHTTPMethod)requestMethod;

/**@brief api版本号*/
- (NSString *)apiVersion;

/**@brief 校验上行参数，避免由于参数错误导致发请求*/
- (NSError *)requestLocalCheckHeaderFieldValidity NS_REQUIRES_SUPER;

/**@brief 在HTTP报头添加的自定义参数*/
- (void)requestDefaultHeaderFieldConfiguration NS_REQUIRES_SUPER;

/**@brief 校验上行参数，避免由于参数错误导致发请求*/
- (NSError *)requestLocalCheckParameterValidity NS_REQUIRES_SUPER;

/**@brief 在HTTP请求中的参数*/
- (void)requestParameterConfiguration NS_REQUIRES_SUPER;

/**@brief multipartForm 方式上传文件子类需要实现该方法*/
- (WSConstructingBlock)constructingBodyBlock;

/**
 *  @brief HTTPBody 形式上传文件子类需要实现该方法
 *  @note 同时实现constructingBodyBlock则该方法无效
 */
- (NSData *)requestCustomUploadData;

#pragma mark - 策略
/**
 * @brief  请求超时的时间，默认采用统一session时间
 */
- (NSTimeInterval)timeoutInterval;

/**
 * @brief  允许发送请求的最小时间间隔,默认0
 */
- (NSTimeInterval)requestTTL;

/**
 *  @brief 是否允许对请求做缓存，默认NO
 *
 *  @return YES ? 允许 ：不允许
 */
- (BOOL)shouldAllowCache;

#pragma mark - load

/**@brief 本地加载数据*/
- (void)loadLocalWithComplateHandle:(WSCompleteHandle)complateHandle NS_REQUIRES_SUPER;

/**@brief 发送网络请求*/
- (void)load NS_REQUIRES_SUPER;

/**@brief 发送网络请求,并实现回调*/
- (void)loadWithComplateHandle:(WSCompleteHandle)complateHandle NS_REQUIRES_SUPER;

/**@brief 取消当前的请求*/
- (void)cancel NS_REQUIRES_SUPER;


#pragma mark - parse

/**
 解析服务器返回的Data数据

 @param info NSDictionary

 @return 解析错误返回Error 正确为nil
 */
- (NSError *)responseHanlderWithDataInfo:(NSDictionary *)info NS_REQUIRES_SUPER;


#pragma mark - Web Servcie Response

/** Web Servcie Response */
- (void)requestDidSuccessWithObject:(id)responseObject headers:(NSDictionary *)headers;

- (void)requestDidFailWithError:(NSError *)error headers:(NSDictionary *)headers;

@end
