//
//  WSNetWorkClient.m
//  FitRunning
//
//  Created by lilingang on 15/11/21.
//  Copyright © 2015年 LiLingang. All rights reserved.
//

#import "WSNetWorkClient.h"
#import <AFNetworking/AFNetworking.h>

#import "WSRequestTask.h"
#import "WSRequestAgent.h"
#import "WSRequestCache.h"
#import "WSMetaItem.h"
#import "NSDictionary+WebService.h"
#import "NSString+WebService.h"
#import "WSNetworkMonitor.h"

@interface WSNetWorkClient ()

/**@brief 整个app应该只持有一个sessionManager*/
@property (nonatomic, strong) AFURLSessionManager *sessionManger;

/**@brief 请求的持有类*/
@property (nonatomic, strong) WSRequestAgent *requestAgent;

@end

@implementation WSNetWorkClient

+ (WSNetWorkClient *)sharedInstance {
    static WSNetWorkClient *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

#pragma mark - Publick Methods
- (void)loadWithRequestModel:(WSRequestTask *)requestModel{
    if (![WSNetworkMonitor isReachable]) {
        NSError *error = [NSError wsNetworkNotAvalableError];
        [self handlerError:error headers:nil requestModel:requestModel];
        return;
    }
    if (![self.requestAgent shouldLoadRequestModel:requestModel]) {
        NSLog(@"\n%@ %@ URL:%@ request too frequently",NSStringFromClass([requestModel class]),[self reqeustMethod:requestModel.requestMethod],requestModel.requestUrlString);
        return;
    }
    NSError *error;
    NSMutableURLRequest *urlRequest = [self urlRequetWithRequestModel:requestModel error:&error];
    if (error) {
        NSLog(@"\ncreat %@ error :%@",NSStringFromClass([requestModel class]),error);
    }
//#ifdef DEBUG
    DDLog(@"\n%@ %@ URL:%@ \nHEAD:%@\n param:%@",NSStringFromClass([requestModel class]),[self reqeustMethod:requestModel.requestMethod],requestModel.requestUrlString, urlRequest.allHTTPHeaderFields,[requestModel.parameterDictionary wsDictionaryToJsonStringTrim:NO]);
//#endif
    
    if (requestModel.shouldLoadLocalOnly) {
        NSDictionary *result = [[WSRequestCache shareInstance] resultForUrl:requestModel.requestUrlString];
        NSDictionary *headers = [[WSRequestCache shareInstance] headersForUrl:requestModel.requestUrlString];
        if (nil != result) {
            [self afDidFinishedWithHeaders:headers responseObject:result error:nil requestModel:requestModel];
            return;
        } else {
            requestModel.shouldLoadLocalOnly = NO;
        }
    }
    
    NSURLSessionDataTask *dataTask = nil;
    __weak __typeof(&*self)weakSelf = self;
    dataTask = [self.sessionManger dataTaskWithRequest:urlRequest completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
        __strong __typeof(&*weakSelf)strongSelf = weakSelf;
//#ifdef DEBUG
        DDLog(@"\n%@ %@ URL:%@ \nresponseObject:%@\n error:%@",NSStringFromClass([requestModel class]),[strongSelf reqeustMethod:requestModel.requestMethod],requestModel.requestUrlString, responseObject,error);
//#endif
        [strongSelf afDidFinishedWithHeaders:((NSHTTPURLResponse *)response).allHeaderFields responseObject:responseObject error:error requestModel:requestModel];
    }];
    [dataTask resume];
    [self.requestAgent addDataTask:dataTask requestModel:requestModel];
}

- (BOOL)isLoadingWithRequestId:(NSString *)requestId{
    NSURLSessionDataTask *dataTask = [self.requestAgent dataTaskWithRequestId:requestId];
    return dataTask && (dataTask.state == NSURLSessionTaskStateRunning || dataTask.state == NSURLSessionTaskStateSuspended);
}

- (void)cancelWithRequestId:(NSString *)requestId{
    NSURLSessionDataTask *dataTask = [self.requestAgent dataTaskWithRequestId:requestId];
    if (dataTask) {
        [dataTask cancel];
    }
}

- (void)cancelAllRequest{
    NSArray *allReqeustIds = [self.requestAgent allRequestIds];
    for (NSString *requestId in allReqeustIds) {
        [self cancelWithRequestId:requestId];
    }
}

#pragma mark - Private Methods

- (NSMutableURLRequest *)urlRequetWithRequestModel:(WSRequestTask *)requestModel error:(NSError **)error{
    //根据不同服务器请求创建不同的RequestSerializer
    AFHTTPRequestSerializer *requestSerializer = [AFHTTPRequestSerializer serializer];
    //单独自定义超时时间
    if ([requestModel timeoutInterval] != -1) {
        [requestSerializer setTimeoutInterval:[requestModel timeoutInterval]];
    }
    //自定义的Header
    for (NSString *keyString in requestModel.headerDictionary.allKeys) {
        NSString *valueString = requestModel.headerDictionary[keyString];
        [requestSerializer setValue:valueString forHTTPHeaderField:keyString];
    }
    //配置request
    NSMutableURLRequest *urlRequest;
    NSString *methodString = [self reqeustMethod:[requestModel requestMethod]];
    if ([requestModel requestMethod] == WSHTTPMethodMultipart) {
        urlRequest = [requestSerializer multipartFormRequestWithMethod:methodString URLString:requestModel.requestUrlString parameters:requestModel.parameterDictionary constructingBodyWithBlock:requestModel.constructingBodyBlock error:error];
    } else {
        urlRequest = [requestSerializer requestWithMethod:methodString URLString:requestModel.requestUrlString parameters:requestModel.parameterDictionary error:error];
    }
    NSData *data = [requestModel requestCustomUploadData];
    if (data && !requestModel.constructingBodyBlock) {
        //华米自定义的上传文件模式
        [urlRequest setHTTPBody:data];
        [urlRequest setValue:@"" forHTTPHeaderField:@"Content-Type"];
    }
    return urlRequest;
}

- (NSString *)reqeustMethod:(WSHTTPMethod)httpMethod{
    if (httpMethod == WSHTTPMethodGET) {
        return @"GET";
    } else if (httpMethod == WSHTTPMethodPOST || httpMethod == WSHTTPMethodMultipart){
        return @"POST";
    } else if (httpMethod == WSHTTPMethodPUT){
        return @"PUT";
    } else if (httpMethod == WSHTTPMethodDELETE){
        return @"DELETE";
    } else if (httpMethod == WSHTTPMethodPATCH){
        return @"PATCH";
    } else {
        return @"GET";
    }
}

#pragma mark - AFNetworking CallBack

- (void)afDidFinishedWithHeaders:(NSDictionary *)headers
                   responseObject:(id)responseObject
                            error:(NSError *)error
                     requestModel:(WSRequestTask *)requestModel{
    
    if (error) {
        [self handlerError:error headers:headers requestModel:requestModel];
    } else {
        
        NSError *customError = nil;
        NSDictionary *responseDict = (NSDictionary *)responseObject;
        NSDictionary *metaDict = responseDict[@"meta"];
        if (nil == customError && !metaDict) {
            customError = [NSError wsMetaEmptyError];
        }
        
        WSMetaItem *metaItem = [[WSMetaItem alloc] initWithDictionary:metaDict];
        if (nil == customError && 1 != metaItem.code) {
            if (401 == metaItem.code) {
                customError = [NSError wsNeedLoginError];
            } else if (500 == metaItem.code){
                customError = [NSError wsErrorWithCode:WSErrorCode_SeverError title:metaItem.desc description:metaItem.desc];
            } else if(40012 == metaItem.code){}
            else if (40042 == metaItem.code){}
            else
            {
                customError = [NSError wsErrorWithCode:WSErrorCode_MetaCodeError title:[NSString stringWithFormat:@"wsMetaCodeError%lu", (unsigned long)metaItem.code] description:metaItem.desc otherInfo:@{WSErrorMetaItemKey : metaItem}];
            }
        }
        if (customError) {
            [self handlerError:customError headers:headers requestModel:requestModel];
            return;
        }
        
        NSDictionary *dataDict = [responseDict objectForKey:@"data"];
        if (nil == customError && (![responseDict isKindOfClass:[NSDictionary class]])) {
            customError = [NSError wsResponseFormatError];
        }
        
        // 返回数据成功把字典数据转换成模型Item;
        if (nil == customError) {
            customError = [requestModel responseHanlderWithDataInfo:dataDict];
        }
        
        if (customError) {
            [self handlerError:customError headers:headers requestModel:requestModel];
            return;
        }
        
        
        // 通过控制requestModel中的shouldAllowCache 来控制是否存入本地
        
        if ([requestModel shouldAllowCache] && !requestModel.shouldLoadLocalOnly) {
            [[WSRequestCache shareInstance] saveInfo:responseObject headers:headers forUrl:requestModel.requestUrlString];
        }
        
        [self.requestAgent removeRequestId:requestModel.requestUrlString success:YES];
        [requestModel requestDidSuccessWithObject:responseObject headers:headers];
    }
}

- (void)handlerError:(NSError *)error headers:(NSDictionary *)headers requestModel:(WSRequestTask *)requestTask{
    NSError *theError = error.isCustomError ? error : nil;
    NSHTTPURLResponse *httpResponse = error.userInfo[AFNetworkingOperationFailingURLResponseErrorKey];
    if (nil == theError && (-1009 == error.code || 408 == error.code)) {
        theError = [NSError wsNetworkNotAvalableError];
    }
    
    if (nil == theError && (401 == error.code || httpResponse.statusCode == 401)) {
        theError = [NSError wsNeedLoginError];
    }
    
    if (nil == theError && (500 == error.code || httpResponse.statusCode == 500)) {
        theError = [NSError wsSeverError];
    }
    
    if (nil == theError && 200 != error.code) {
        theError = [NSError wsHttpResponseStatusError];
    }
    
    if (nil == theError) {
        theError = [NSError wsUnknownError];
    }
    [self.requestAgent removeRequestId:requestTask.taskIdentifier success:NO];
    [requestTask requestDidFailWithError:theError headers:headers];
}

#pragma mark - Getter and Setter

- (AFURLSessionManager *)sessionManger{
    if (!_sessionManger) {
        NSURLSessionConfiguration *sessionConfiguration = [NSURLSessionConfiguration defaultSessionConfiguration];
        sessionConfiguration.HTTPMaximumConnectionsPerHost = 4;
        sessionConfiguration.timeoutIntervalForRequest = 60;
        sessionConfiguration.timeoutIntervalForResource = 60;
        sessionConfiguration.allowsCellularAccess = YES;
        //系统时间的秒值,同个应用的不同api请求的time值应该是递增的, 用于防replay攻击
        sessionConfiguration.HTTPAdditionalHeaders = @{@"callid":[NSString wsCallid],
                                                        //国家CN/US...
                                                        @"country":[NSString wsCountryCode],
                                                        //时区
                                                        @"timezone":[NSString wsSystemTimeZone],
                                                        //语言（中文繁体，中文香港等等）
                                                        @"lang":[NSString wsSystemLanguage],
                                                        //设备类型android_phone or ios_phone
                                                        @"appplatform":[NSString wsDeviceType],
                                                        //客户端版本号
                                                        @"cv":[NSString wsAppShortVersion],
                                                        };
        _sessionManger = [[AFURLSessionManager alloc] initWithSessionConfiguration:sessionConfiguration];
    }
    return _sessionManger;
}

- (WSRequestAgent *)requestAgent{
    if (!_requestAgent) {
        _requestAgent = [[WSRequestAgent alloc] init];
    }
    return _requestAgent;
}

@end
