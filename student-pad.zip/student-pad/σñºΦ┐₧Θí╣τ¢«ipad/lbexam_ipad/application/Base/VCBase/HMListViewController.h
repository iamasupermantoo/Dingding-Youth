//
//  HMListViewController.h
//  UDan
//
//  Created by lilingang on 16/10/11.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMTableViewController.h"

#import "HMListRequestTask.h"
#import "HMBaseItem.h"

/**
 带有网络请求的列表基类
 */
@interface HMListViewController : HMTableViewController<WSRequestCallbackProtocol>

/**主网络请求,需要子类初始化*/
@property (nonatomic, strong) HMListRequestTask *listRequestTask;

- (void)tableviewWillReloadData;

- (void)endHeaderRefresh;
/**
 返回当前List渲染的主要的CellItem类名

 @return HMTableViewCellItem子类
 */
- (Class)cellItemClass;


/**
 生成一组CellItems,子类可重载实现自己的逻辑不允许调用Super,针对一个cellItem渲染一个数据的时候子类可实现下面的方法

 @param requestTask 当前的主网络请求
 @param resultitems 请求返回的数据model

 @return 一组CellItems
 */
- (NSMutableArray <HMTableViewCellItem *>*)generateCellItemsWithReqeustTask:(HMListRequestTask *)requestTask resultItems:(NSArray *)resultitems;


/**
 是否允许渲染Model。YES ？将添加cellItem到数组 : 忽略这个Model

 @param cellItems 将要持有cellItem的数组
 @param item      渲染cell的数据源

 @return YES ? 允许添加 ： 不允许
 */
- (BOOL)cellItems:(NSMutableArray <HMTableViewCellItem *> *)cellItems shouldAddItem:(HMBaseItem *)item NS_REQUIRES_SUPER;

/**
 一个新创建的CellItem将要添加到数组中的时候调用该方法,若子类实现generateCellItemsWithReqeustTask：resultItems可忽略该方法

 @param cellItems 将要持有cellItem的数组
 @param cellItem  将要被添加的CellItem
 */
- (void)cellItems:(NSMutableArray <HMTableViewCellItem *> *)cellItems willAddCellItem:(HMTableViewCellItem *)cellItem NS_REQUIRES_SUPER;

/**
 一个新创建的CellItem已经添加到数组中的时候调用该方法,若子类实现generateCellItemsWithReqeustTask：resultItems可忽略该方法
 
 @param cellItems 已经持有cellItem的数组
 @param cellItem  已经被添加的CellItem
 */
- (void)cellItems:(NSMutableArray <HMTableViewCellItem *> *)cellItems didAddCellItem:(HMTableViewCellItem *)cellItem NS_REQUIRES_SUPER;


/**
 一组CellItem将要添加到列表数据源中调用该方法，子类可实现该方法做一些首次加载插入之类的操作

 @param cellItems   将要添加到列表数据源的数组
 @param requestTask 当前的主网络请求
 */
- (void)datasourceWillAddCellItems:(NSMutableArray <HMTableViewCellItem *> *)cellItems requestTask:(HMListRequestTask *)requestTask NS_REQUIRES_SUPER;


- (void)emptyViewWhenTableViewEmpty;

@end
