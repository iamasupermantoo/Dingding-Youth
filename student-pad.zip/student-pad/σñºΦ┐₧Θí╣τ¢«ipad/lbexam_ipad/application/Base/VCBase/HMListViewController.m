//
//  HMListViewController.m
//  UDan
//
//  Created by lilingang on 16/10/11.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMListViewController.h"
#import <MJRefresh/MJRefresh.h>

#import "HMPlaceholderCellItem.h"

@interface HMListViewController ()

@end

@implementation HMListViewController

- (BOOL)hasHeadRefresh{
    return NO;
}

- (BOOL)hasLoadMore{
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    if ([self hasHeadRefresh]) {
        self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(tableviewWillReloadData)];
    }
    
    if ([self hasLoadMore]) {
       self.tableView.mj_footer = [MJRefreshBackStateFooter footerWithRefreshingTarget:self refreshingAction:@selector(tableViewWillLoadingMore)];
    }
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if (!self.viewDidAppear && self.listRequestTask) {
        // 修改这里 更加方便的去控制将要加载view的时候用不用加载数据
         self.viewDidAppear = YES;
        self.listRequestTask.delegate = self;
        [self.listRequestTask loadLocalWithComplateHandle:nil];
    }
    [self reloadTableView];
}


#pragma mark - Refresh and LoadMore

- (void)tableviewWillReloadData {
    [self.listRequestTask load];
}

- (void)tableViewWillLoadingMore{
    [self.listRequestTask loadMoreWithComplateHandle:nil];
}

- (void)endHeaderRefresh{
    if ([self hasHeadRefresh]) {
        [self.tableView.mj_header endRefreshing];
    }
    [self.tableView.mj_footer resetNoMoreData];
}

- (void)endFooterRefreshingWithHiden:(BOOL)hiden{
    [self.tableView.mj_footer endRefreshing];
    if (hiden) {
        [self.tableView.mj_footer endRefreshingWithNoMoreData];
    }
}

#pragma mark - Template Methods

- (Class)cellItemClass{
    return nil;
}

//-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
//    [super tableView:tableView willDisplayCell:cell forRowAtIndexPath:indexPath];
//    if (indexPath.row == self.dataSource.cellCount-2) {
//        [self tableViewWillLoadingMore];
//    }
//}

// 此处是把item的数据赋值给cellItem
- (NSMutableArray *)generateCellItemsWithReqeustTask:(HMListRequestTask *)requestTask resultItems:(NSArray *)resultItems {
    NSMutableArray *cellItems = [NSMutableArray arrayWithCapacity:[resultItems count]];
    if (![self cellItemClass]) {
        return cellItems;
    }
    HMTableViewCellItem *cellItem = nil;
    for (HMBaseItem *baseItem in resultItems) {
        if (![self cellItems:cellItems shouldAddItem:baseItem]) {
            continue;
        }
        cellItem = [[[self cellItemClass] alloc] init];
        cellItem.rawObject = baseItem;
        [self cellItems:cellItems willAddCellItem:cellItem];
        [cellItems addObject:cellItem];
        [self cellItems:cellItems didAddCellItem:cellItem];
        cellItem = nil;
    }
    return cellItems;
}

- (BOOL)cellItems:(NSMutableArray <HMTableViewCellItem *> *)cellItems shouldAddItem:(HMBaseItem *)item{
    return YES;
}

- (void)cellItems:(NSMutableArray <HMTableViewCellItem *> *)cellItems willAddCellItem:(HMTableViewCellItem *)cellItem{
    
}

- (void)cellItems:(NSMutableArray <HMTableViewCellItem *> *)cellItems didAddCellItem:(HMTableViewCellItem *)cellItem{
    
}

- (void)datasourceWillAddCellItems:(NSMutableArray <HMTableViewCellItem *> *)cellItems requestTask:(HMListRequestTask *)requestTask{
    
}

#pragma mark - WSRequestCallbackProtocol

- (void)requestDidFinished:(HMListRequestTask *)request headers:(NSDictionary *)headers response:(NSDictionary *)response localResult:(BOOL)localResult{
    
    if (![request isKindOfClass:[HMListRequestTask class]]) {
        return;
    }
    if (!request.isLoadingMore) {
        [self.dataSource clear];
    }
    NSMutableArray *cellItems = [self generateCellItemsWithReqeustTask:request resultItems:request.resultItems];
    if ([[cellItems lastObject] isKindOfClass:[HMPlaceholderCellItem class]]) {
        [cellItems removeLastObject];
    }
    [self datasourceWillAddCellItems:cellItems requestTask:request];
    
    if (request.isLoadingMore) {
        [self.dataSource extendCellItems:cellItems];
    } else {
        [self.dataSource addCellItems:cellItems];
    }
    
    if ([self.dataSource isEmpty] && !request.shouldLoadLocalOnly) {
        [self emptyViewWhenTableViewEmpty];
    } else {
        [self.tableView emptyWithImage:nil title:nil];
    }
    
    if (request.shouldLoadLocalOnly) {
        [request load];
    }
    
    if (!request.isLoadingMore) {
        [self endHeaderRefresh];
        [self endFooterRefreshingWithHiden:!request.hasNext];
    } else {
        [self endFooterRefreshingWithHiden:!request.hasNext];
    }
    [self reloadTableView];
}

- (void)requestDidFailed:(HMListRequestTask *)request headers:(NSDictionary *)headers error:(NSError *)error localResult:(BOOL)localResult{
    if (request.shouldLoadLocalOnly) {
        [request load];
        return;
    }
    if ([self.dataSource isEmpty]) {
        //
    }
    [self.tableView reloadData];
    
    if (!request.isLoadingMore) {
        [self endHeaderRefresh];
    } else {
        [self endFooterRefreshingWithHiden:NO];
    }
}


-(void)emptyViewWhenTableViewEmpty{
    [self.tableView emptyWithImage:nil title:@"这里什么都没有"];
}
@end
