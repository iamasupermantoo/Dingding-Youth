//
//  HMTableViewController.m
//  UDan
//
//  Created by lilingang on 16/5/6.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMTableViewController.h"
#import "HMTableViewCell.h"

NSString *const HMTableViewCell_Action_Key_Cell = @"HMTableViewCellKeyCell";
NSString *const HMTableViewCell_Action_Key_CellItem = @"HMTableViewCellKeyCellItem";
NSString *const HMTableViewCell_Action_Key_IndexPath = @"HMTableViewCellKeyIndexPath";
NSString *const HMTableViewCell_Action_Key_Sender = @"HMTableViewCellKeySender";
NSString *const HMTableViewCell_Action_Key_UserInfo = @"HMTableViewCellUserInfo";

@interface HMTableViewController ()<HMTableViewCellDeleagte>

@end

@implementation HMTableViewController

- (void)dealloc{
    self.tableView.delegate = nil;
    self.tableView.dataSource = nil;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.separatorColor = [UIColor hmBorderColor];
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.backgroundView = nil;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    self.tableView.tableFooterView = [[UIView alloc] init];
    [self reloadDataSource];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if (!self.viewDidAppear) {
        [self delayLoadImagesForVisibleRowsAfter:0];
    }
}

#pragma mark - Templte Methods

- (void)reloadTableView{
    [self.tableView reloadData];
    [self loadImagesForVisibleRows];
}

- (void)reloadDataSource{
    [self.dataSource clear];
}

- (void)hmTableView:(UITableView *)tableView willUpdateCellWithCellItem:(HMTableViewCellItem *)cellItem{
    
}

- (void)hmTableView:(UITableView *)tableView didSelectCellItem:(HMTableViewCellItem *)cellItem{
    
}

- (void)hmTableView:(UITableView *)tableView deleteCellItem:(HMTableViewCellItem *)cellItem confirmBlock:(void(^)())confirmBlock cancelBlock:(void(^)())cancelBlock{
    if (cancelBlock) {
        cancelBlock();
    }
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataSource.cellCount;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    HMTableViewCellItem *cellItem = [self.dataSource cellItemAtIndex:indexPath.row];
    HMTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellItem.cellIdentifier];
    if (!cell) {
        if (cellItem.registerType == HMCellRegisterTypeXib) {
            [tableView registerNib:[UINib nibWithNibName:NSStringFromClass([cellItem cellClass]) bundle:nil] forCellReuseIdentifier:cellItem.cellIdentifier];
        } else if (cellItem.registerType == HMCellRegisterTypeCode){
            [tableView registerClass:cellItem.cellClass forCellReuseIdentifier:cellItem.cellIdentifier];
        }
        cell = [tableView dequeueReusableCellWithIdentifier:cellItem.cellIdentifier];
    }
    cell.accessoryType = cellItem.cellAccessoryType;
    cell.selectionStyle = cellItem.cellSelectionStyle;
    if ([cell isKindOfClass:[cellItem cellClass]]) {
        cell.deleagte = self;
        [self hmTableView:tableView willUpdateCellWithCellItem:cellItem];
        [cell updateWithCellItem:cellItem];
    } else {
        NSLog(@"指定的cell class不一致(cellClass = %@ is not cellItem.cellClass = %@)",NSStringFromClass([cell class]),NSStringFromClass([cellItem cellClass]));
    }
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    HMTableViewCellItem *cellItem = [self.dataSource cellItemAtIndex:indexPath.row];
    return cellItem.canEdit;
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath{
    HMTableViewCellItem *cellItem = [self.dataSource cellItemAtIndex:indexPath.row];
    return cellItem.canMove;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        HMTableViewCellItem *cellItem = [self.dataSource cellItemAtIndex:indexPath.row];
        [self hmTableView:tableView deleteCellItem:cellItem confirmBlock:^{
            [tableView beginUpdates];
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:cellItem.rowAnimation];
            [self.dataSource removeCellItemAtIndex:indexPath.row];
            [tableView endUpdates];
        } cancelBlock:^{
            [tableView reloadData];
        }];
    }
}


- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath{

}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    HMTableViewCellItem *cellItem = [self.dataSource cellItemAtIndex:indexPath.row];
    return cellItem.cellHeight;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    HMTableViewCellItem *cellItem = [self.dataSource cellItemAtIndex:indexPath.row];
    
    UIEdgeInsets separatorInset = cellItem.hidenSeparator ? UIEdgeInsetsMake(0, 0, 0, CGRectGetWidth(self.view.frame)) : cellItem.separatorInset;
    if (!UIEdgeInsetsEqualToEdgeInsets(separatorInset, UIEdgeInsetsZero)) {
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]){
            [cell setSeparatorInset:separatorInset];
        }
        if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]){
            [cell setPreservesSuperviewLayoutMargins:NO];
        }
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]){
            [cell setLayoutMargins:separatorInset];
        }
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    HMTableViewCellItem *cellItem = [self.dataSource cellItemAtIndex:indexPath.row];
    if (!cellItem.canSelect) {
        return;
    }
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    [self hmTableView:tableView didSelectCellItem:cellItem];
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath{
    HMTableViewCellItem *cellItem = [self.dataSource cellItemAtIndex:indexPath.row];
    return cellItem.canSelect;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    HMTableViewCellItem *cellItem = [self.dataSource cellItemAtIndex:indexPath.row];
    return cellItem.cellEditingStyle;
}

- (BOOL)tableView: (UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath{
    HMTableViewCellItem *cellItem = [self.dataSource cellItemAtIndex:indexPath.row];
    return cellItem.shouldIndentWhileEditing;
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    if (!decelerate) {
        [self loadImagesForVisibleRows];
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    [self loadImagesForVisibleRows];
}

- (void)loadImagesForVisibleRows{
    if ([self.dataSource cellCount] > 0) {
        NSArray *visiblePaths = [self.tableView indexPathsForVisibleRows];
        for (NSIndexPath *indexPath in visiblePaths) {
            HMTableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
            HMTableViewCellItem * cellItem = [self.dataSource cellItemAtIndex:indexPath.row];
            if ([cell isKindOfClass:cellItem.cellClass]) {
                if ([cell respondsToSelector:@selector(showImagesWithCellItem:)]) {
                    [cell showImagesWithCellItem:cellItem];
                }
            }
        }
    }
}

- (void)delayLoadImagesForVisibleRowsAfter:(NSTimeInterval)delay {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self loadImagesForVisibleRows];
    });
}

#pragma mark - HMTableViewCellDeleagte

- (void)hmTableViewCell:(HMTableViewCell *)cell sender:(id)sender selector:(SEL)selector userInfo:(id)userInfo{
    if ([self respondsToSelector:selector]) {
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
        [dict setObject:indexPath forKey:HMTableViewCell_Action_Key_IndexPath];
        HMTableViewCellItem *cellItem = [self.dataSource cellItemAtIndex:indexPath.row];
        if (cellItem) {
            [dict setObject:cellItem forKey:HMTableViewCell_Action_Key_CellItem];
        }
        if (cell) {
            [dict setObject:cell forKey:HMTableViewCell_Action_Key_Cell];
        }
        if (sender) {
            [dict setObject:sender forKey:HMTableViewCell_Action_Key_Sender];
        }
        if (userInfo) {
            [dict setObject:userInfo forKey:HMTableViewCell_Action_Key_UserInfo];
        }
        _Pragma("clang diagnostic push")
        _Pragma("clang diagnostic ignored \"-Warc-performSelector-leaks\"")
        [self performSelector:selector withObject:dict];
        _Pragma("clang diagnostic pop")
    } else {
        NSLog(@"%@未实现%@的点击事件@selector(%@)",NSStringFromClass([self class]),NSStringFromClass([cell class]),NSStringFromSelector(selector));
    }
}

#pragma mark - Getter and Setter

- (HMTableViewDataSource *)dataSource{
    if (!_dataSource) {
        _dataSource = [[HMTableViewDataSource alloc] init];
    }
    return _dataSource;
}


- (void)setTableViewContentInset:(UIEdgeInsets)tableViewContentInset{
    _tableViewContentInset = tableViewContentInset;
    self.tableView.contentInset = tableViewContentInset;
    self.tableView.scrollIndicatorInsets = tableViewContentInset;
}

@end
