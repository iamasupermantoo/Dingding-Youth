//
//  HMSearchViewController.h
//  UDan
//
//  Created by lilingang on 16/10/18.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMTableViewController.h"

#import "HMListRequestTask.h"

@class HMSearchItem;

typedef void (^HMSearchBlock)(UIViewController *viewController, HMSearchItem *item);

/**
 单个请求的搜索框基类不可直接调用
 */
@interface HMSearchViewController : HMTableViewController<WSRequestCallbackProtocol>

@property (nonatomic, copy) HMSearchBlock completeBlock;

/**search UI*/
@property (nonatomic, strong, readonly) UISearchBar *searchBar;

/**搜索网络请求,需要子类初始化*/
@property (nonatomic, strong) HMListRequestTask *searchRequestTask;

/**
 searchViewController 处于活跃状态
 */
- (void)activeSearchViewController;

- (void)deactiveSearchViewController;

/**
 取消按钮点击

 @param searchBar UISearchBar
 */
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar;

/**
 搜索key有改变会调用该方法

 @param text 搜索的Text
 */
- (void)updateSearchResultsWithText:(NSString *)text;

/**
 需要渲染的CellItem

 @return HMTableViewCellItem子类
 */
- (Class)cellItemClass;

@end
