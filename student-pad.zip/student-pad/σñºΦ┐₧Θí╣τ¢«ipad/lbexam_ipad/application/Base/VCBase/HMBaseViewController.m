//
//  HMBaseViewController.m
//  UDan
//
//  Created by lilingang on 16/9/25.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseViewController.h"
#import "AppDelegate.h"
@implementation HMBaseViewController
@synthesize rightBarButtonItem = _rightBarButtonItem;
@synthesize viewDidAppear = _viewDidAppear;


- (void)dealloc{
    [HMStat endLogPageView:NSStringFromClass([self class])];
    NSLog(@"%@ dealloc",NSStringFromClass([self class]));
}

- (instancetype)init{
    self = [super init];
    if (self) {
        self.shouldHidenNavigationBar = NO;
        self.shouldEnableInteractivePopGestureRecognizer = YES;
    }
    return self;
}

- (instancetype)initWithTitle:(NSString *)title{
    self = [self init];
    if (self) {
        self.title = title;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationItem.hidesBackButton = YES;
    self.navigationItem.hidesBackButton = YES;
    self.view.backgroundColor = [UIColor hmMainBgColor];
    self.navigationItem.leftBarButtonItem = nil;
    self.navigationItem.rightBarButtonItem = nil;

    UIBarButtonItem *fixedSpaceButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    
    NSString *leftBarTitle = [self leftBarButtonItemTitle];
    if ([leftBarTitle length] > 0) {
        UIButton *leftButton= [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 60, 29)];
        leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [leftButton setTitle:leftBarTitle forState:UIControlStateNormal];
        leftButton.titleLabel.font = [UIFont systemFontOfSize:16];
        [leftButton setTitleColor:[UIColor hmTextBlackColor] forState:UIControlStateNormal];
        [leftButton setTitleColor:[UIColor hmTextGrayColor] forState:UIControlStateDisabled];
        [leftButton addTarget:self action:@selector(leftButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *leftBarItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
        self.navigationItem.leftBarButtonItems = @[fixedSpaceButtonItem,leftBarItem];
    } else if ([self leftBarButtonItem]){
        self.navigationItem.leftBarButtonItems = @[fixedSpaceButtonItem,[self leftBarButtonItem]];
    } else {
        self.navigationItem.leftBarButtonItems = nil;
    }
    
    NSString *rightBarTitle = [self rightBarButtonItemTitle];
    _rightBarButtonItem = [self rightBarButtonItem];
    if (rightBarTitle && ![rightBarTitle ddIsEmpty]) {
        UIButton *rightButton= [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 60, 29)];
        rightButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        [rightButton setTitle:rightBarTitle forState:UIControlStateNormal];
        rightButton.titleLabel.font = [UIFont systemFontOfSize:16];
        [rightButton setTitleColor:[UIColor hmTextBlackColor] forState:UIControlStateNormal];
        [rightButton setTitleColor:[UIColor hmTextGrayColor] forState:UIControlStateDisabled];
        [rightButton addTarget:self action:@selector(rightButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        _rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
        self.navigationItem.rightBarButtonItems = @[fixedSpaceButtonItem,_rightBarButtonItem];
    } else if (_rightBarButtonItem){
        self.navigationItem.rightBarButtonItems = @[fixedSpaceButtonItem,_rightBarButtonItem];
    } else {
        self.navigationItem.rightBarButtonItems = nil;
    }
    [HMStat beginLogPageView:NSStringFromClass([self class])];
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
//    [self.navigationController.navigationBar setBackgroundImage:IMG_NAME(@"Sign-in_Navigation1_selected") forBarMetrics:UIBarMetricsDefault];
//    [self.navigationController.navigationBar  setShadowImage:[UIImage new]];
//    
//    self.navigationController.navigationBar.barTintColor = [UIColor hmMainBgColor];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:animated];
    [self.navigationController setNavigationBarHidden:self.shouldHidenNavigationBar animated:animated];
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = self.shouldEnableInteractivePopGestureRecognizer;
    }
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
}

#pragma mark - Template Methods

- (UIBarButtonItem *)leftBarButtonItem{
    UIButton *backButton= [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 10, 17)];
    [backButton setImage:[UIImage imageNamed:@"navigationbar_back_black_normal"] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(leftButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backBarItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
    return backBarItem;
}

- (NSString *)leftBarButtonItemTitle{
    return @"";
}

- (UIBarButtonItem *)rightBarButtonItem{
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(0, 0, 60, 29);
    [rightBtn setImage:IMG_NAME(@"LOGO") forState:UIControlStateNormal];
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:rightBtn];
    return item;
    
    
//    return _rightBarButtonItem;
}


- (NSString *)rightBarButtonItemTitle{
    return @"";
}


#pragma mark - Button Action

- (void)leftButtonAction:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)rightButtonAction:(id)sender{
    
}



// 旋转屏幕

-(void)changeScreenWith:(BOOL)allowRotation{
    AppDelegate *appdelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    appdelegate.allowRotation = allowRotation;
    [self setNewOrientation:allowRotation];
}


- (void)setNewOrientation:(BOOL)fullscreen

{
    
    if (fullscreen) {
        
        NSNumber *resetOrientationTarget = [NSNumber numberWithInt:UIInterfaceOrientationUnknown];
        
        [[UIDevice currentDevice] setValue:resetOrientationTarget forKey:@"orientation"];
        
        NSNumber *orientationTarget = [NSNumber numberWithInt:UIInterfaceOrientationLandscapeRight];
        
        [[UIDevice currentDevice] setValue:orientationTarget forKey:@"orientation"];
        
    }else{
        
        NSNumber *resetOrientationTarget = [NSNumber numberWithInt:UIInterfaceOrientationUnknown];
        
        [[UIDevice currentDevice] setValue:resetOrientationTarget forKey:@"orientation"];
        NSNumber *orientationTarget = [NSNumber numberWithInt:UIInterfaceOrientationLandscapeLeft];
        
        [[UIDevice currentDevice] setValue:orientationTarget forKey:@"orientation"];
        
    }
    
}




@end
