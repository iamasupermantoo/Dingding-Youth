//
//  HMBaseViewController.h
//  UDan
//
//  Created by lilingang on 16/9/25.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HMBaseViewController : UIViewController

@property (nonatomic, strong, readonly) UIBarButtonItem *rightBarButtonItem;

/**ViewController 是否显示了*/
@property (nonatomic, assign) BOOL viewDidAppear;

/** 是否允许侧滑返回手势, 默认YES*/
@property (nonatomic, assign) BOOL shouldEnableInteractivePopGestureRecognizer;

/** 是否隐藏导航栏, 默认NO*/
@property (nonatomic, assign) BOOL shouldHidenNavigationBar;

/**
 *  @brief 初始化
 *
 *  @param title 标题
 *
 *  @return 实例
 */
- (instancetype)initWithTitle:(NSString *)title;


/**
 NavigationBar左侧按钮,默认返回按钮
 
 @return UIBarButtonItem
 */
- (UIBarButtonItem *)leftBarButtonItem;

/**
 NavigationBar左侧按钮文案,默认nil,优先使用该方法
 
 @return 文案
 */
- (NSString *)leftBarButtonItemTitle;

/**
 NavigationBar右侧按钮,不实现则为nil
 
 @return 文案
 */
- (UIBarButtonItem *)rightBarButtonItem;

/**
 返回NavigationBar右侧按钮文案,不实现则为nil,优先使用该方法
 
 @return 文案
 */
- (NSString *)rightBarButtonItemTitle;

/**
 *  @brief 返回按钮点击触发的事件
 *
 *  @param sender 发送者
 */
- (void)leftButtonAction:(id)sender;

/**
 右侧文本按钮点击触发的事件

 @param sender 发送者
 */
- (void)rightButtonAction:(id)sender;


-(void)changeScreenWith:(BOOL)allowRotation;

@end
