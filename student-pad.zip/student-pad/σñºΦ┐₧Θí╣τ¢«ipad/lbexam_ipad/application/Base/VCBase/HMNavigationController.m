//
//  HMNavigationController.m
//  UDan
//
//  Created by lilingang on 16/9/25.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMNavigationController.h"
#import "AppDelegate.h"
@interface HMNavigationController ()

@end

@implementation HMNavigationController


- (void)viewDidLoad {
    [super viewDidLoad];
    UINavigationBar *navigationBar = [UINavigationBar appearance];
    navigationBar.barTintColor = [UIColor fkNavBackGroundColor];
    navigationBar.tintColor = [UIColor hmTextBlackColor];
    navigationBar.translucent = NO;
   
//    [navigationBar setBackgroundImage:IMG_NAME(@"Sign-in_Navigation1_selected") forBarMetrics:UIBarMetricsDefault];
//    [navigationBar setShadowImage:[UIImage new]];
    
    [navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : navigationBar.tintColor,
                      NSFontAttributeName: [UIFont systemFontOfSize:17.0]}];
}



@end
