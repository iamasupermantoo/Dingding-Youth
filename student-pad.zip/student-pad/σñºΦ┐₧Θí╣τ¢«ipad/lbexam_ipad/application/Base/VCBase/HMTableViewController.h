//
//  HMTableViewController.h
//  UDan
//
//  Created by lilingang on 16/5/6.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HMBaseViewController.h"
#import "HMTableViewDataSource.h"
#import "UITableView+HMEmptyView.h"

/**@brief 当前选中的cell*/
extern NSString *const HMTableViewCell_Action_Key_Cell;
/**@brief 当前选中的cell对应的model*/
extern NSString *const HMTableViewCell_Action_Key_CellItem;
/**@brief 当前选中的cell在tableView中的index*/
extern NSString *const HMTableViewCell_Action_Key_IndexPath;
/**@brief 当前选中的cell在tableView中的index*/
extern NSString *const HMTableViewCell_Action_Key_Sender;
extern NSString *const HMTableViewCell_Action_Key_UserInfo;

@interface HMTableViewController : HMBaseViewController<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;

/** tableView的数据源 */
@property (nonatomic, strong) HMTableViewDataSource *dataSource;

/** @brief tableView显示的范围 默认UIEdgeInsetsZero*/
@property (nonatomic, assign) UIEdgeInsets tableViewContentInset;

/**
 *  @brief 重新组建数据viewDidLoad的时候会调用一次,子类必须调用super
 */

- (void)reloadDataSource NS_REQUIRES_SUPER;

- (void)reloadTableView;

/**
 *  @brief 将要更新cell的时候调用
 *
 *  @param tableView 当前的TableView
 *  @param cellItem  将要更新cell的数据源
 */
- (void)hmTableView:(UITableView *)tableView willUpdateCellWithCellItem:(HMTableViewCellItem *)cellItem;

/**
 *  @brief cell选中触发的事件
 *
 *  @param tableView 当前的TableView
 *  @param cellItem  当前点击cell的数据源
 */
- (void)hmTableView:(UITableView *)tableView
didSelectCellItem:(HMTableViewCellItem *)cellItem;

/**
 *  @brief 删除cell事件
 *
 *  @param tableView    当前的tableView
 *  @param cellItem     渲染的Cell数据源
 *  @param confirmBlock 确认的block
 *  @param cancelBlock  取消删除block
 */

- (void)hmTableView:(UITableView *)tableView
   deleteCellItem:(HMTableViewCellItem *)cellItem
     confirmBlock:(void(^)())confirmBlock
      cancelBlock:(void(^)())cancelBlock;


//加载图片
- (void)loadImagesForVisibleRows;
- (void)delayLoadImagesForVisibleRowsAfter:(NSTimeInterval)delay;

@end
