//
//  HMSearchViewController.m
//  UDan
//
//  Created by lilingang on 16/10/18.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMSearchViewController.h"
#import "HMBaseItem.h"
#import "HMPlaceholderCellItem.h"

@interface HMSearchViewController ()<UISearchBarDelegate,UISearchControllerDelegate>

@property (nonatomic, strong) UISearchController *searchController;

@property (nonatomic, strong, readwrite) UISearchBar *searchBar;

@end

@implementation HMSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIView *statusBarView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREENWIDTH, 20)];
    statusBarView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:statusBarView];
    self.searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
    self.searchController.delegate = self;
    self.searchController.dimsBackgroundDuringPresentation = NO;
    self.searchBar = self.searchController.searchBar;
    self.searchBar.delegate = self;
    self.tableView.tableHeaderView = self.searchBar;
    
    self.searchBar.backgroundImage = [[UIImage alloc] init];
    [self.searchBar setBackgroundColor:[UIColor whiteColor]];
    UIView *searchTextField = nil;
    self.searchBar.barTintColor = [UIColor whiteColor];
    searchTextField = [[[self.searchBar.subviews firstObject] subviews] lastObject];
    searchTextField.backgroundColor = [UIColor hmBackGrayColor];
    [searchTextField setValue:[UIColor hmTextGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
    [searchTextField setValue:[UIFont systemFontOfSize:14] forKeyPath:@"_placeholderLabel.font"];
    
    NSDictionary *titleTextAttributesNormal = @{NSForegroundColorAttributeName:[UIColor hmTextBlackColor],
                                                 NSFontAttributeName : [UIFont systemFontOfSize:16]};
    UIBarButtonItem *searchBarButton = [UIBarButtonItem appearanceWhenContainedIn:[UISearchBar class], nil];
    [searchBarButton setTitleTextAttributes:titleTextAttributesNormal forState:UIControlStateNormal];
    [self.tableView emptyWithImage:[UIImage imageNamed:@"common_empty_icon"] title:@"这里什么都没有"];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if (!self.viewDidAppear) {
        self.searchRequestTask.delegate = self;
    }
}

#pragma mark - Template Methods

- (void)updateSearchResultsWithText:(NSString *)text{
    
}

- (Class)cellItemClass{
    return nil;
}

#pragma mark - Private Methods

- (void)activeSearchViewController{
    if (self.searchController.active) {
        return;
    }
    self.searchController.active = YES;
    self.searchBar.showsCancelButton = YES;
}

- (void)deactiveSearchViewController{
    if (!self.searchController.active) {
        return;
    }
    self.searchController.active = NO;
    self.searchBar.showsCancelButton = NO;
    [self.searchBar resignFirstResponder];
}

- (NSMutableArray *)generateCellItemsWithReqeustTask:(HMListRequestTask *)requestTask resultItems:(NSArray *)resultItems {
    NSMutableArray *cellItems = [NSMutableArray arrayWithCapacity:[resultItems count]];
    if (![self cellItemClass]) {
        return cellItems;
    }
    HMTableViewCellItem *cellItem = nil;
    for (HMBaseItem *baseItem in resultItems) {
        cellItem = [[[self cellItemClass] alloc] init];
        cellItem.rawObject = baseItem;
        [cellItems addObject:cellItem];
        cellItem = nil;
    }
    return cellItems;
}

- (void)hmTableView:(UITableView *)tableView didSelectCellItem:(HMTableViewCellItem *)cellItem{
    if (self.completeBlock) {
        self.completeBlock(self,cellItem.rawObject);
    }
    [self deactiveSearchViewController];
}

#pragma mark - UISearchBarDelegate

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    [self deactiveSearchViewController];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    if (!searchText || [searchText ddIsEmpty]) {
        [self.dataSource clear];
        [self.tableView reloadData];
    } else {
        [self updateSearchResultsWithText:searchText];
    }
}

#pragma mark - UISearchControllerDelegate

- (void)didPresentSearchController:(UISearchController *)searchController{
    [searchController.searchBar becomeFirstResponder];
}

#pragma mark -  WSRequestCallbackProtocol

- (void)requestDidFinished:(HMListRequestTask *)request headers:(NSDictionary *)headers response:(NSDictionary *)response localResult:(BOOL)localResult{
    if (![request isKindOfClass:[HMListRequestTask class]]) {
        return;
    }
    if (!request.isLoadingMore) {
        [self.dataSource clear];
    }
    NSMutableArray *cellItems = [self generateCellItemsWithReqeustTask:request resultItems:request.resultItems];
    if ([[cellItems lastObject] isKindOfClass:[HMPlaceholderCellItem class]]) {
        [cellItems removeLastObject];
    }
    if (request.isLoadingMore) {
        [self.dataSource extendCellItems:cellItems];
    } else {
        [self.dataSource addCellItems:cellItems];
    }
    
    if ([self.dataSource isEmpty] && !request.shouldLoadLocalOnly) {
        [self.tableView emptyWithImage:[UIImage imageNamed:@"common_empty_icon"] title:@"这里什么都没有"];
    } else {
        [self.tableView emptyWithImage:nil title:nil];
    }
    [self.tableView reloadData];
}

- (void)requestDidFailed:(HMListRequestTask *)request headers:(NSDictionary *)headers error:(NSError *)error localResult:(BOOL)localResult{
    if ([self.dataSource isEmpty]) {
        //空
    }
    [self.tableView reloadData];
}
@end
