//
//  HMConfigRequestTask.h
//  UDan
//
//  Created by lilingang on 16/11/5.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface HMConfigSaveRequestTask : HMBaseRequestTask

@property (nonatomic, assign) BOOL pushSwitch;

@end

@interface HMConfigGetRequestTask : HMBaseRequestTask

@property (nonatomic, assign) BOOL pushSwitch;

@end
