//
//  HMPushRequestTask.m
//  UDan
//
//  Created by lilingang on 16/11/5.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMPushRequestTask.h"

@implementation HMPushRequestTask

- (NSString *)apiName{
    return @"/push/bind";
}

- (WSHTTPMethod)requestMethod{
    return WSHTTPMethodPOST;
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.token || [self.token ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"token"];
    }
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:self.token forKey:@"token"];
}

@end
