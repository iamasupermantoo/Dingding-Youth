//
//  HMConfigRequestTask.m
//  UDan
//
//  Created by lilingang on 16/11/5.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMConfigRequestTask.h"
#import "HMUserHandler.h"

@implementation HMConfigSaveRequestTask

- (NSString *)apiName{
    return @"/config/save";
}

- (WSHTTPMethod)requestMethod{
    return WSHTTPMethodPOST;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:@"push" forKey:@"key"];
    [self.parameterDictionary setObject:self.pushSwitch ? @"true" : @"false" forKey:@"value"];
}

@end

@implementation HMConfigGetRequestTask

- (NSString *)apiName{
    return @"/config/get";
}

- (NSError *)responseHanlderWithDataInfo:(NSDictionary *)info{
    NSError * error = [super responseHanlderWithDataInfo:info];
    if (error) {
        return error;
    }
    NSDictionary *configDict = info[@"config"];
    self.pushSwitch = [configDict[@"push"] isEqualToString:@"true"] ? YES : NO;
    [HMUserHandler sharedInstance].pushSwitch = self.pushSwitch;
    return nil;
}
@end

