//
//  HMCheckVersionRequestTask.m
//  UDan
//
//  Created by lilingang on 16/11/18.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMCheckVersionRequestTask.h"

@implementation HMCheckVersionRequestTask

+ (BOOL)needLogin{
    return NO;
}

- (NSString *)apiName{
    return @"/client/version";
}

- (WSHTTPMethod)requestMethod{
    return WSHTTPMethodGET;
}

- (NSError *)responseHanlderWithDataInfo:(NSDictionary *)info{
    NSError *error = [super responseHanlderWithDataInfo:info];
    if (error) {
        return error;
    }
    
    if (info[@"version"]==nil) {
        self.isUpdate = NO;
    }else{
        self.isUpdate = YES;
        NSDictionary *versionDict = info[@"version"];
        self.descriptionString = versionDict[@"desc"];
        self.downloadUrl = versionDict[@"url"];
        self.force = [versionDict[@"force"] integerValue] == 1?YES:NO;
        self.title = versionDict[@"title"];
    }
    

    
    
    return nil;
}

@end
