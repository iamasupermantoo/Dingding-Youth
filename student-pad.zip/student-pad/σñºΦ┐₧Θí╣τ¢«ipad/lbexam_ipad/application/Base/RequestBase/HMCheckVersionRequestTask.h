//
//  HMCheckVersionRequestTask.h
//  UDan
//
//  Created by lilingang on 16/11/18.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface HMCheckVersionRequestTask : HMBaseRequestTask

@property(nonatomic,strong) NSString *title;
@property (nonatomic, copy) NSString *descriptionString;
@property (nonatomic, copy) NSString *downloadUrl;
@property(nonatomic,assign) BOOL isUpdate;
@property(nonatomic,assign) BOOL force;
@end
