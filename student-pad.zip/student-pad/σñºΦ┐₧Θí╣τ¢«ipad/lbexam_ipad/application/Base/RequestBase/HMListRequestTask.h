//
//  HMListRequestTask.h
//  UDan
//
//  Created by lilingang on 16/9/28.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface HMListRequestTask : HMBaseRequestTask

/**每页请求个数，默认为20*/
@property (nonatomic, assign) NSInteger count;

/**服务端列表结构最外层包含的关键字*/
@property (nonatomic, copy) NSString *resultItemsKeyword;

/**判断是否是加载的更多数据*/
@property (nonatomic, assign, getter=isLoadingMore) BOOL loadingMore;

/**服务端返回字段是否还有更多数据*/
@property (nonatomic, assign, readonly) BOOL hasNext;

/**数组Model*/
@property (nonatomic, copy) NSArray *resultItems;


/**
 加载更多数据

 @param complateHandle WSCompleteHandle
 */
- (void)loadMoreWithComplateHandle:(WSCompleteHandle)complateHandle;

/**
 列表返回的结构Model

 @return HMBaseItem 子类
 */
- (Class)itemClass;

/**
 数据解析,子类可不实现

 @param listArray 服务端返回的结构数组
 */
- (void)listWillHandleWithInfoArray:(NSArray *)listArray;

@end
