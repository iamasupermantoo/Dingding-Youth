//
//  HMListRequestTask.m
//  UDan
//
//  Created by lilingang on 16/9/28.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMListRequestTask.h"
#import "HMBaseItem.h"

@interface HMListRequestTask ()
/**游标,下一次请求使用*/
@property (nonatomic, strong) NSNumber *nextCursor;

@end

@implementation HMListRequestTask
@synthesize hasNext = _hasNext;

- (instancetype)init{
    self = [super init];
    if (self) {
        self.count = 20;
        _hasNext = NO;
        self.loadingMore = NO;
        self.shouldLoadLocalOnly = YES;
    }
    return self;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    if (self.nextCursor && self.isLoadingMore) {
        [self.parameterDictionary setObject:self.nextCursor forKey:@"cursor"];
    }
    if (self.count > 0) {
        [self.parameterDictionary setObject:@(self.count) forKey:@"limit"];
    }
}

- (void)loadLocalWithComplateHandle:(WSCompleteHandle)complateHandle{
    self.loadingMore = NO;
    [super loadLocalWithComplateHandle:complateHandle];
}

- (void)load{
    self.loadingMore = NO;
    [super load];
}

- (void)loadWithComplateHandle:(WSCompleteHandle)complateHandle{
    self.loadingMore = NO;
    [super loadWithComplateHandle:complateHandle];
}

- (void)loadMoreWithComplateHandle:(WSCompleteHandle)complateHandle{
    self.loadingMore = YES;
    [super loadWithComplateHandle:complateHandle];
}

- (void)cancel{
    self.loadingMore = NO;
    [super cancel];
}

- (NSError *)responseHanlderWithDataInfo:(NSDictionary *)info{
    NSError *error = [super responseHanlderWithDataInfo:info];
    if (error) {
        return error;
    }
    if (![info isKindOfClass:[NSDictionary class]]) {
        return [NSError wsResponseFormatError];
    }
    
    if (self.resultItemsKeyword) {
        id keywordObject = [info objectForKey:self.resultItemsKeyword];
        if (!keywordObject) {
            return nil;
        }
        if ([keywordObject isKindOfClass:[NSArray class]]) {
            if ([keywordObject count] > 0) {
                [self listWillHandleWithInfoArray:keywordObject];
            }
        } else if ([keywordObject isKindOfClass:[NSDictionary class]]) {
            NSArray *listArray = [keywordObject objectForKey:@"list"];
            if (![listArray isKindOfClass:[NSArray class]]) {
                return [NSError wsResponseFormatError];
            }
            _hasNext = [[keywordObject objectForKey:@"hasNext"] boolValue];
            self.nextCursor = [keywordObject objectForKey:@"nextCursor"];
            // 此处的写法 导致如果返回的数据 数组为空之前的resultItems是上个请求的 导致数据显示不正确
            if ([listArray count] > 0) {
                [self listWillHandleWithInfoArray:listArray];
            }else{
                //添加一个条件 如果不大于0 则清空resultItems
                self.resultItems = nil;
            }
        } else {
            return [NSError wsResponseFormatError];
        }
    }
    return nil;
}

- (Class)itemClass{
    return [HMBaseItem class];
}


// 对返回的数据进行Model化 ---换成item模型然后给resultItems
- (void)listWillHandleWithInfoArray:(NSArray *)listArray {
    NSMutableArray *items = [[NSMutableArray alloc] init];
    for (NSDictionary *dict in listArray) {
        @autoreleasepool {
            
            HMBaseItem *item = [[self itemClass] itemWithDictionary:dict];
            [items addObject:item];
        }
    }
    self.resultItems = items;
}
@end
