//
//  HMBaseRequestTask.h
//  UDan
//
//  Created by lilingang on 16/9/28.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "WSRequestTask.h"

@interface HMBaseRequestTask : WSRequestTask

/**
 是否需要登录,默认NO

 @return YES ？ 需要登录 : 不需要登录
 */

+ (BOOL)needLogin;

@end
