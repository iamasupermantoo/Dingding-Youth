//
//  HMBaseRequestTask.m
//  UDan
//
//  Created by lilingang on 16/9/28.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseRequestTask.h"
#import "HMUserHandler.h"

@interface HMBaseRequestTask ()

@end

@implementation HMBaseRequestTask

+ (BOOL)needLogin{
    return YES;
}

#pragma mark - Template Methods

- (NSURL *)baseUrl{
    NSString *baseURLString = @"http://api.ddlad.com";
    if ([[NSUserDefaults standardUserDefaults] objectForKey:@"FKDEBUG"]) {
        baseURLString = @"http://api.z.ziduan.com";
    }
    return [NSURL URLWithString:baseURLString];
}

- (void)load{
    if ([[self class] needLogin] && ![[HMUserHandler sharedInstance] hasLogin]) {
        NSLog(@"需要重新登录");
        [HMRouterHandler revertToLoginController];
    } else {
        [super load];
    }
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    if ([[HMUserHandler sharedInstance] hasLogin]) {
        [self.parameterDictionary ddSetSafeObject:[HMUserHandler sharedInstance].ticket forKey:@"z"];
    }
}

@end
