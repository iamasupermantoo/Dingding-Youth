//
//  HMTableViewCell.m
//  UDan
//
//  Created by lilingang on 16/5/6.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMTableViewCell.h"
#import "HMTableViewCellItem.h"


@implementation HMTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initSettings];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self initSettings];
}

#pragma mark - Template Methods

- (void)initSettings{
    
}

- (void)updateWithCellItem:(HMTableViewCellItem *)cellItem{
    if (cellItem.backgroundColor) {
        self.contentView.backgroundColor = cellItem.backgroundColor;
        self.backgroundColor = cellItem.backgroundColor;
        self.backgroundView.backgroundColor = cellItem.backgroundColor;
    }
    self.separatorInset = cellItem.separatorInset;
}

- (void)showImagesWithCellItem:(HMTableViewCellItem *)cellItem{
    
}
@end
