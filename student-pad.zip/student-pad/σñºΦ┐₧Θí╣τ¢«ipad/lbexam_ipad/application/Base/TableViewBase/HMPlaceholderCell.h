//
//  HMPlaceholderCell.h
//  UDan
//
//  Created by lilingang on 16/5/16.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMTableViewCell.h"

@interface HMPlaceholderCell : HMTableViewCell

@end
