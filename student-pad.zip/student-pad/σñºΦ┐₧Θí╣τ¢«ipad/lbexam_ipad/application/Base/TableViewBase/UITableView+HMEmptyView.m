//
//  UITableView+HMEmptyView.m
//  UDan
//
//  Created by lilingang on 16/5/12.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "UITableView+HMEmptyView.h"
#import <objc/runtime.h>
#import "HMTableEmptyView.h"

NSString *const HMTableViewEmptyViewKey = @"HMTableViewEmptyViewKey";

@implementation UITableView (HMEmptyView)

- (UIView *)emptyView{
    return objc_getAssociatedObject(self, &HMTableViewEmptyViewKey);
}

- (void)setEmptyView:(UIView *)emptyView{
    objc_setAssociatedObject(self, &HMTableViewEmptyViewKey,
                             emptyView,
                             OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)emptyWithImage:(UIImage *)image title:(NSString *)title{
    if (!self.emptyView){
        self.emptyView = [[HMTableEmptyView alloc] initWithFrame:self.bounds];
        [self addSubview:self.emptyView];
    }
    if (image || [title length] > 0) {
        self.emptyView.hidden = NO;
    } else {
        self.emptyView.hidden = YES;
    }
    HMTableEmptyView *noMessageView = (HMTableEmptyView *)self.emptyView;
    [noMessageView setImage:image title:title];
}

@end
