//
//  HMTableViewLongPressMoveHandler.h
//  UDan
//
//  Created by lilingang on 16/5/9.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>
@class UITableView;
/**
 必须实现如下两个协议
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath;
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath;
 */

@interface HMTableViewLongPressMoveHandler : NSObject

/**
 *  @brief 是否允许长按移动cell 默认NO
 */
@property (nonatomic, assign) BOOL shouldMove;

/**
 *  @brief 唯一初始化方法
 *
 *  @param tableView 需要添加长按移动tableView
 *
 *  @return HMTableViewLongPressMoveHandler实例
 */
- (instancetype)initWithTableView:(UITableView *)tableView;

@end
