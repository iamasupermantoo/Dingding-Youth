//
//  HMEmptyCell.m
//  UDan
//
//  Created by lilingang on 16/11/17.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMEmptyCell.h"

@implementation HMEmptyCellItem

- (void)initSettings{
    [super initSettings];
    self.canSelect = NO;
    self.hidenSeparator = YES;
    self.cellHeight = SCREENHEIGHT/2.0 - 44 - 44;
    self.backgroundColor = [UIColor hmMainBgColor];
}

@end



@interface HMEmptyCell ()
@property (weak, nonatomic) IBOutlet UIImageView *TipImageView;
@property (weak, nonatomic) IBOutlet UILabel *tipTitleLabel;

@end
@implementation HMEmptyCell

- (void)updateWithCellItem:(HMEmptyCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    if (cellItem.rawObject) {
        self.tipTitleLabel.text = cellItem.rawObject;
    }else{
        self.tipTitleLabel.text = HMLocal(@"这里什么都没有");
    }
    
    if (cellItem.imageStr) {
        self.TipImageView.image = IMG_NAME(cellItem.imageStr);
        
    }
    
    
}
@end
