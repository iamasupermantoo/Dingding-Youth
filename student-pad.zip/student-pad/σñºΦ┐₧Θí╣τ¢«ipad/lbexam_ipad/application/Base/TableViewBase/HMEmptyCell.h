//
//  HMEmptyCell.h
//  UDan
//
//  Created by lilingang on 16/11/17.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMTableViewCell.h"
#import "HMTableViewCellItem.h"

@interface HMEmptyCellItem : HMTableViewCellItem
@property(nonatomic,strong) NSString *imageStr;

@end

@interface HMEmptyCell : HMTableViewCell

@end
