//
//  HMPlaceholderCellItem.m
//  UDan
//
//  Created by lilingang on 16/5/16.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMPlaceholderCellItem.h"

@implementation HMPlaceholderCellItem

+ (HMPlaceholderCellItem *)placeholderCellItem{
    return [self cellItemWithCellHeight:10 title:nil];
}

+ (HMPlaceholderCellItem *)cellItemWithCellHeight:(CGFloat)cellHeight{
    return [self cellItemWithCellHeight:cellHeight title:nil];
}

+ (HMPlaceholderCellItem *)cellItemWithCellHeight:(CGFloat)cellHeight title:(NSString *)title{
    HMPlaceholderCellItem *cellItem = [[HMPlaceholderCellItem alloc] init];
    cellItem.cellHeight = cellHeight;
    cellItem.title = title;
    return cellItem;
}

- (instancetype)init{
    self = [super init];
    if (self) {
        self.cellHeight = 20.0;
        self.canSelect = NO;
        self.separatorInset = kIpadNoGapSeperateInsets;
        self.backgroundColor = [UIColor hmMainBgColor];
    }
    return self;
}

#pragma mark - Template Methods

- (HMCellRegisterType)registerType{
    return HMCellRegisterTypeCode;
}

@end
