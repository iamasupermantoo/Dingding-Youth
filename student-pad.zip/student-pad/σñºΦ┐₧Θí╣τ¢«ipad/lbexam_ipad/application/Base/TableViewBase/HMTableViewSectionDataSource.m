//
//  HMTableViewSectionDataSource.m
//  UDan
//
//  Created by lilingang on 16/5/6.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMTableViewSectionDataSource.h"

@interface HMTableViewSectionDataSource ()

@property (nonatomic, strong) NSMutableArray *cellItems;

@end

@implementation HMTableViewSectionDataSource

#pragma mark - Public Methods

- (HMTableViewCellItem *)cellItemAtIndex:(NSInteger)index{
    if (![self isValidAtIndex:index]) {
        return nil;
    }
    return self.cellItems[index];
}

- (void)addCellItem:(HMTableViewCellItem *)cellItem{
    if (![self isValidCellItem:cellItem]) {
        return;
    }
    [self.cellItems addObject:cellItem];
}

- (void)insertCellItem:(HMTableViewCellItem *)cellItem adIndex:(NSInteger)index{
    if (![self isValidInsertIndex:index]) {
        return;
    }
    if (![self isValidCellItem:cellItem]) {
        return;
    }
    [self.cellItems insertObject:cellItem atIndex:index];
}

- (void)replaceCellItemAtIndex:(NSInteger)index withCellItem:(HMTableViewCellItem *)cellItem{
    if (![self isValidAtIndex:index]) {
        return;
    }
    if (![self isValidCellItem:cellItem]) {
        return;
    }
    [self.cellItems replaceObjectAtIndex:index withObject:cellItem];
}

- (void)exchangeCellItemAtIndex:(NSUInteger)idx1 withCellItemAtIndex:(NSUInteger)idx2{
    if (![self isValidAtIndex:idx1] || ![self isValidAtIndex:idx2]) {
        return;
    }
    [self.cellItems exchangeObjectAtIndex:idx1 withObjectAtIndex:idx2];
}

- (void)removeLastCellItem{
    if (self.cellCount == 0) {
        NSLog(@"没有可删除的元素");
        return;
    }
    [self.cellItems removeLastObject];
}

- (void)removeCellItemAtIndex:(NSInteger)index{
    if (![self isValidAtIndex:index]) {
        return;
    }
    [self.cellItems removeObjectAtIndex:index];
}

- (void)clear{
    [self.cellItems removeAllObjects];
}

#pragma mark - Private Methods

- (BOOL)isValidAtIndex:(NSInteger)index{
    if (index >= self.cellCount || index < 0) {
        NSLog(@"Cell数组越界AtIndex = %ld,totalCount = %ld",(long)index,(unsigned long)self.cellCount);
        return NO;
    }
    return YES;
}

- (BOOL)isValidInsertIndex:(NSInteger)index{
    if (index > self.cellCount || index < 0) {
        NSLog(@"Cell数组越界InsertIndex = %ld,totalCount = %ld",(long)index,(unsigned long)self.cellCount);
        return NO;
    }
    return YES;
}

- (BOOL)isValidCellItem:(HMTableViewCellItem *)cellItem{
    if (!cellItem) {
        NSLog(@"cellItem不能为空");
        return NO;
    }
    return YES;
}

#pragma mark - Getter and Setter

- (NSMutableArray *)cellItems{
    if (!_cellItems) {
        _cellItems = [[NSMutableArray alloc] init];
    }
    return _cellItems;
}

- (NSUInteger)cellCount{
    return [self.cellItems count];
}
@end
