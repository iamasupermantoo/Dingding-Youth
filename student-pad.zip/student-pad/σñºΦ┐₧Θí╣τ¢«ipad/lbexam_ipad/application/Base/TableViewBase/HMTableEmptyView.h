//
//  HMTableEmptyView.h
//  UDan
//
//  Created by lilingang on 16/5/12.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HMTableEmptyView : UIView

- (void)setImage:(UIImage *)image title:(NSString *)title;

@end
