//
//  HMPlaceholderCell.m
//  UDan
//
//  Created by lilingang on 16/5/16.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMPlaceholderCell.h"
#import "HMPlaceholderCellItem.h"

@interface HMPlaceholderCell ()

@property (nonatomic, strong) UIView *topSeparatorView;

@property (nonatomic, strong) UILabel *titleLabel;

@end

@implementation HMPlaceholderCell

- (void)initSettings{
    [super initSettings];
    self.topSeparatorView = [[UIView alloc] init];
    [self.contentView addSubview:self.topSeparatorView];
    
    self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 0, 0)];
    self.titleLabel.textAlignment = NSTextAlignmentLeft;
    self.titleLabel.font = [UIFont systemFontOfSize:16];
    self.titleLabel.textColor = [UIColor hmTextBlackColor];
    [self.contentView addSubview:self.titleLabel];
}

#pragma mark - Template Methods

- (void)updateWithCellItem:(HMPlaceholderCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    self.topSeparatorView.backgroundColor = cellItem.separatorColor;
    if (cellItem.title) {
        self.titleLabel.hidden = NO;
        self.titleLabel.text = cellItem.title;
    } else {
        self.titleLabel.hidden = YES;
    }
}


- (void)layoutSubviews{
    [super layoutSubviews];
    self.topSeparatorView.frame = CGRectMake(-8, -8, CGRectGetWidth([UIScreen mainScreen].bounds), 0.5);
    self.titleLabel.frame = CGRectMake(15, CGRectGetHeight(self.frame) - 16 - 10, CGRectGetWidth([UIScreen mainScreen].bounds) - 15, 16);
}

@end
