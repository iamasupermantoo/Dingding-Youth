//
//  HMTableViewCell.h
//  UDan
//
//  Created by lilingang on 16/5/6.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HMTableViewCellItem;
@class HMTableViewCell;

@protocol HMTableViewCellDeleagte <NSObject>

@required
/**
 *  @brief HMTableViewCell分发事件的方法
 *
 *  @param cell     当前的cell实例 必填
 *  @param sender   事件的发送者 可为nil
 *  @param selector 触发的事件  必填
 *  @param userInfo 附带的信息 可为nil
 */
- (void)hmTableViewCell:(HMTableViewCell *)cell
                 sender:(id)sender
               selector:(SEL)selector
               userInfo:(id)userInfo ;

@end

@interface HMTableViewCell : UITableViewCell

@property (nonatomic, weak) id<HMTableViewCellDeleagte> deleagte;

/**
 *  @brief 初始化接口，负责UI的初始化
 */
- (void)initSettings NS_REQUIRES_SUPER;

/**
 *  @brief 更新UI操作，数据渲染
 *  @note 子类实现的时候需要调用super
 *
 *  @param cellItem HMTableViewCellItem对象
 */
- (void)updateWithCellItem:(HMTableViewCellItem *)cellItem NS_REQUIRES_SUPER;

/**
 *  @brief 加载网络图片逻辑
 *  @note 子类实现的时候需要调用super
 *
 *  @param cellItem HMTableViewCellItem对象
 */
- (void)showImagesWithCellItem:(HMTableViewCellItem *)cellItem NS_REQUIRES_SUPER;

@end
