//
//  HMTableViewDataSource.h
//  UDan
//
//  Created by lilingang on 16/5/6.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HMTableViewCellItem.h"

@interface HMTableViewDataSource : NSObject

@property (nonatomic, strong, readonly) NSMutableArray *cellItems;

/**
 *  @brief 返回section中所有cell的个数
 */
@property (readonly) NSUInteger cellCount;


/**
 是否有数据

 @return YES ? 有数据 ： 没有数据
 */
- (BOOL)isEmpty;


/**
 数据源中包含指定的cell实例

 @param cellItem HMTableViewCellItem实例

 @return YES ？ 包含 ： 不包含
 */
- (BOOL)hasCellItem:(HMTableViewCellItem *)cellItem;

/**
 *  @brief 通过给定的index返回一个cellItem对象
 *
 *  @param index cell的位置
 *
 *  @return cellItem HMTableViewCellItem对象
 */
- (HMTableViewCellItem *)cellItemAtIndex:(NSInteger)index;


/**
 返回数据源中的最后一个CellItem对象

 @return HMTableViewCellItem对象
 */
- (HMTableViewCellItem *)lastCellItem;

/**
 *  @brief 增加一个cellItem
 *
 *  @param cellItem HMTableViewCellItem对象
 */
- (void)addCellItem:(HMTableViewCellItem *)cellItem;

/**
 增加一组数据

 @param cellItems 数组
 */
- (void)addCellItems:(NSArray <HMTableViewCellItem *> *)cellItems;

/**
 *  @brief 在指定index插入一个cellItem
 *
 *  @param cellItem HMTableViewCellItem对象
 *  @param index    指定的index
 */
- (void)insertCellItem:(HMTableViewCellItem *)cellItem adIndex:(NSInteger)index;


/**
 在制定位置插入一组数据

 @param cellItems HMTableViewCellItem对象数组
 @param index     插入的index
 */
- (void)insertCellItems:(NSArray <HMTableViewCellItem *> *)cellItems adIndex:(NSInteger)index;

/**
 追加一组数据

 @param cellItems 数据
 */
- (void)extendCellItems:(NSArray <HMTableViewCellItem *> *)cellItems;

/**
 *  @brief 替换
 *
 *  @param index    指定的index
 *  @param cellItem HMTableViewCellItem对象
 */
- (void)replaceCellItemAtIndex:(NSInteger)index withCellItem:(HMTableViewCellItem *)cellItem;

/**
 *  @brief 交换cellItem
 *
 *  @param idx1 第一个cellItem位置
 *  @param idx2 第二个cellItem位置
 */
- (void)exchangeCellItemAtIndex:(NSUInteger)idx1 withCellItemAtIndex:(NSUInteger)idx2;


/**
 删除指定的CellItem

 @param cellItem 指定的CellItem
 */
- (void)removeCellItem:(HMTableViewCellItem *)cellItem;

/**
 *  @brief 移除最后一个cell元素
 */
- (void)removeLastCellItem;

/**
 *  @brief 根据给定的index删除指定的cell
 *
 *  @param index 位置
 */
- (void)removeCellItemAtIndex:(NSInteger)index;

/**
 *  @brief 清除所有元素
 */
- (void)clear;

@end
