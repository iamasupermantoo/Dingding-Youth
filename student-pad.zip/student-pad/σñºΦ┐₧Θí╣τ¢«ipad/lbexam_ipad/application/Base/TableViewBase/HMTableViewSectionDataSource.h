//
//  HMTableViewSectionDataSource.h
//  UDan
//
//  Created by lilingang on 16/5/6.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HMTableViewCellItem.h"

/**@brief 存储一个tableViewSection中的cell元素*/
@interface HMTableViewSectionDataSource : NSObject

/**
 *  @brief 返回section中所有cell的个数
 */
@property (readonly) NSUInteger cellCount;

/**
 *  @brief 通过给定的index返回一个cellItem对象
 *
 *  @param index cell的位置
 *
 *  @return cellItem HMTableViewCellItem对象
 */
- (HMTableViewCellItem *)cellItemAtIndex:(NSInteger)index;

/**
 *  @brief 增加一个cellItem
 *
 *  @param cellItem HMTableViewCellItem对象
 */
- (void)addCellItem:(HMTableViewCellItem *)cellItem;

/**
 *  @brief 在指定index插入一个cellItem
 *
 *  @param cellItem HMTableViewCellItem对象
 *  @param index    指定的index
 */
- (void)insertCellItem:(HMTableViewCellItem *)cellItem adIndex:(NSInteger)index;

/**
 *  @brief 替换
 *
 *  @param index    指定的index
 *  @param cellItem HMTableViewCellItem对象
 */
- (void)replaceCellItemAtIndex:(NSInteger)index withCellItem:(HMTableViewCellItem *)cellItem;

/**
 *  @brief 交换cellItem
 *
 *  @param idx1 第一个cellItem位置
 *  @param idx2 第二个cellItem位置
 */
- (void)exchangeCellItemAtIndex:(NSUInteger)idx1 withCellItemAtIndex:(NSUInteger)idx2;


/**
 *  @brief 移除最后一个cell元素
 */
- (void)removeLastCellItem;

/**
 *  @brief 根据给定的index删除指定的cell
 *
 *  @param index 位置
 */
- (void)removeCellItemAtIndex:(NSInteger)index;

/**
 *  @brief 清除所有元素
 */
- (void)clear;

@end
