//
//  HMTableViewCellItem.m
//  UDan
//
//  Created by lilingang on 16/5/6.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMTableViewCellItem.h"

CGFloat const HMTableViewCellContentViewOffset = 8.0;

@implementation HMTableViewCellItem

- (instancetype)init{
    self = [super init];
    if (self) {
        self.cellHeight = 44.0f;
        self.separatorInset = UIEdgeInsetsMake(0, HMTableViewCellContentViewOffset, 0, HMTableViewCellContentViewOffset);
        self.hidenSeparator = NO;
        self.canSelect = YES;
        [self initSettings];
    }
    return self;
}

- (void)initSettings{
    
}


#pragma mark - Getter and Setter

- (HMCellRegisterType)registerType{
    return HMCellRegisterTypeXib;
}

- (Class)cellClass{
    NSString *className = [NSStringFromClass([self class]) stringByReplacingOccurrencesOfString:@"Item" withString:@""];
    return NSClassFromString(className);
}

- (NSString *)cellIdentifier{
    return [NSStringFromClass([self cellClass]) stringByAppendingString:@"Identifier"];
}

- (UITableViewCellAccessoryType)cellAccessoryType{
    return UITableViewCellAccessoryNone;
}

- (BOOL)canMove{
    return NO;
}

- (UITableViewCellSelectionStyle)cellSelectionStyle{
    return UITableViewCellSelectionStyleNone;
}


- (BOOL)canEdit{
    return NO;
}

- (BOOL)shouldIndentWhileEditing{
    return NO;
}

- (UITableViewCellEditingStyle)cellEditingStyle{
    return UITableViewCellEditingStyleNone;
}

- (UITableViewRowAnimation)rowAnimation{
    return UITableViewRowAnimationNone;
}
@end
