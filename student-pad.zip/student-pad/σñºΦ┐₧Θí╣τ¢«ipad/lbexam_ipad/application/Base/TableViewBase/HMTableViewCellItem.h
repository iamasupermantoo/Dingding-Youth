//
//  HMTableViewCellItem.h
//  UDan
//
//  Created by lilingang on 16/5/6.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

extern CGFloat const HMTableViewCellContentViewOffset;

typedef NS_ENUM(NSUInteger, HMCellRegisterType) {
    HMCellRegisterTypeXib,       /**使用Xib创建*/
    HMCellRegisterTypeCode,      /**使用code创建*/
};

@interface HMTableViewCellItem : NSObject

/**
 *  @brief 返回当前cell的高度,默认44.0f
 */
@property (nonatomic, assign) CGFloat cellHeight;

/**
 *  @brief  需要渲染的数据对象
 */
@property (nonatomic, strong) id rawObject;


/**
 *  @brief 指定Cell的初始化类型，默认HMCellRegisterTypeXib
 */
@property (nonatomic, assign, readonly) HMCellRegisterType registerType;
/**
 *  @brief 该Model需要渲染的Cell
 */
@property (nonatomic, assign, readonly) Class cellClass;
/**
 *  @brief cell的唯一标识字符串
 */
@property (nonatomic, copy, readonly) NSString *cellIdentifier;

/**
 *  @brief 设置cell的背景色，默认系统颜色
 */
@property (nonatomic, strong) UIColor *backgroundColor;


/**
 *  @brief UITableViewCellAccessoryType default UITableViewCellAccessoryNone
 */
@property (nonatomic, assign, readonly) UITableViewCellAccessoryType cellAccessoryType;

/**
 *  @brief 隐藏Separator,默认NO
 */
@property (nonatomic, assign) BOOL hidenSeparator;
/**
 *  @brief 可以自定义separator的frame 默认UIEdgeInsetsMake(0, 8.0, 0, 8.0),如果hidenSeparator为yes则该设置是无效的
 */
@property (nonatomic, assign) UIEdgeInsets separatorInset;

/**
 *  @brief 是否可以移动Cell，默认NO
 */
@property (nonatomic, assign, readonly) BOOL canMove;
/**
 *  @brief 是否可以跨section移动
 *  @warning 只有在canMove为YES的情况下设置才会生效
 */
@property (nonatomic, assign, readonly) BOOL canAcrossSection;



/**
 *  @brief cell是否可以选中 默认YES
 */
@property (nonatomic, assign) BOOL canSelect;
/**
 *  @brief cell选中的颜色,默认不实现
 *  @warning 只有在selectable为YES的情况下设置才会生效
 */
@property (nonatomic, strong, readonly) UIColor *selectedColor;
/**
 *  @brief 标准的Cell选中的颜色,默认UITableViewCellSelectionStyleNone
 *  @warning 只有在selectable为YES且selectedColor为nil的情况下设置才会生效
 */
@property (nonatomic, assign, readonly) UITableViewCellSelectionStyle cellSelectionStyle;



/**
 *  @brief cell是否可以编辑 默认NO
 */
@property (nonatomic, assign, readonly) BOOL canEdit;
/**
 *  @brief Cell标准的编辑状态，默认UITableViewCellEditingStyleNone
 *  @warning 只有canEdit为YES的情况下才会生效
 */
@property (nonatomic, assign, readonly) UITableViewCellEditingStyle cellEditingStyle;
/**
 *  @brief 编辑模式下是否需要左侧缩进空白,默认NO
 *  @warning 只有canEdit为YES的情况下才会生效
 */
@property (nonatomic, assign, readonly) BOOL shouldIndentWhileEditing;
/**
 *  @brief cell插入删除时的动画，默认UITableViewRowAnimationNone
 *  @warning 只有canEdit为YES的情况下才会生效
 */
@property (nonatomic, assign, readonly) UITableViewRowAnimation rowAnimation;


- (void)initSettings NS_REQUIRES_SUPER;

@end
