//
//  HMPlaceholderCellItem.h
//  UDan
//
//  Created by lilingang on 16/5/16.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMTableViewCellItem.h"

@interface HMPlaceholderCellItem : HMTableViewCellItem

@property (nonatomic, copy) NSString *title;

@property (nonatomic, strong) UIColor *separatorColor;


/**
 高度为10分割cell

 @return HMPlaceholderCellItem
 */
+ (HMPlaceholderCellItem *)placeholderCellItem;

+ (HMPlaceholderCellItem *)cellItemWithCellHeight:(CGFloat)cellHeight;

+ (HMPlaceholderCellItem *)cellItemWithCellHeight:(CGFloat)cellHeight title:(NSString *)title;

@end
