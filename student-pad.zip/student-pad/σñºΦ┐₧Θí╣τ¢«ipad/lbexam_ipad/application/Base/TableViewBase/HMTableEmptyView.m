//
//  HMTableEmptyView.m
//  UDan
//
//  Created by lilingang on 16/5/12.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMTableEmptyView.h"

@interface HMTableEmptyView ()
@property (strong, nonatomic) IBOutlet UIView *contentView;

@property (weak, nonatomic) IBOutlet UIImageView *emptyImageView;
@property (weak, nonatomic) IBOutlet UILabel *emptyLabel;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *emptyImageViewHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *emptyImageViewWidthConstraint;
@end

@implementation HMTableEmptyView

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [[NSBundle mainBundle] loadNibNamed:@"HMTableEmptyView" owner:self options:nil];
        self.contentView.frame = self.bounds;
        [self addSubview:self.contentView];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [[NSBundle mainBundle] loadNibNamed:@"HMTableEmptyView" owner:self options:nil];
        self.contentView.frame = CGRectMake(0, 0, CGRectGetWidth([UIScreen mainScreen].bounds), CGRectGetHeight([UIScreen mainScreen].bounds));
        [self addSubview:self.contentView];
    }
    return self;
}

- (void)setImage:(UIImage *)image title:(NSString *)title{
    if (image) {
        self.emptyImageView.image = image;
        [self.emptyImageView sizeToFit];
    } else {
        self.emptyImageView.frame = CGRectZero;
    }
    self.emptyLabel.text = title;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    self.emptyImageViewWidthConstraint.constant = CGRectGetWidth(self.emptyImageView.frame);
    self.emptyImageViewHeightConstraint.constant = CGRectGetHeight(self.emptyImageView.frame);
}

@end
