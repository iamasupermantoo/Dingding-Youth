//
//  HMTableViewLongPressMoveHandler.m
//  UDan
//
//  Created by lilingang on 16/5/9.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMTableViewLongPressMoveHandler.h"
#import "HMTableViewCell.h"

static const NSTimeInterval HMMovableCellAnimationTime = 0.25;

@interface HMTableViewLongPressMoveHandler ()

/**
 *  @brief 当前的tableView
 */
@property (nonatomic, weak) UITableView *tableView;

/**
 *  @brief 移动过程中需要忽略的子View
 */
@property (nonatomic, strong) NSHashTable *ignoreViews;

/**
 *  @brief 长按收拾按钮
 */
@property (nonatomic, strong) UILongPressGestureRecognizer *longPressGestureRecognizer;

/**
 *  @brief 开始移动的cell的快照
 */
@property (nonatomic, strong) UIView *snapshotView;
/**
 *  @brief 开始移动的cell位置
 */
@property (nonatomic, strong) NSIndexPath *originIndexPath;
/**
 *  @brief 最终cell要移动的位置
 */
@property (nonatomic, strong) NSIndexPath *targetIndexPath;
/**
 *  @brief 监听边界
 */
@property (nonatomic, strong) CADisplayLink *edgeScrollTimer;

@end

@implementation HMTableViewLongPressMoveHandler

- (instancetype)initWithTableView:(UITableView *)tableView{
    self = [super init];
    if (self) {
        self.tableView = tableView;
    }
    return self;
}

#pragma mark - Private Methods

- (void)begainGestureRecognizer:(UILongPressGestureRecognizer *)gestureRecognizer{
    CGPoint location = [gestureRecognizer locationInView:self.tableView];
    NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:location];
    if (!indexPath) {
        return;
    }
    
    BOOL canMove = [self.tableView.dataSource tableView:self.tableView canMoveRowAtIndexPath:indexPath];

    if (!canMove) {
        return;
    }
    [self startEdgeScroll];
    self.originIndexPath = indexPath;
    self.targetIndexPath = indexPath;
    
    HMTableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
    self.snapshotView = [self snapshotViewWithInputView:cell];
    [self.tableView addSubview:self.snapshotView];
    
    [self updateCell:cell isMoving:YES];
    [UIView animateWithDuration:HMMovableCellAnimationTime animations:^{
        self.snapshotView.center = CGPointMake(self.snapshotView.center.x, location.y);
    }];
}

- (BOOL)changedGestureRecognizer:(UILongPressGestureRecognizer *)gestureRecognizer{
    CGPoint location = [gestureRecognizer locationInView:self.tableView];
    NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:location];
    if (!indexPath || indexPath.section != self.originIndexPath.section) {
        //不能跨过section 且 目标indexPath是有效的
        if (indexPath.section == 0 && self.originIndexPath.section == 0 && self.tableView.contentOffset.y > -self.tableView.contentInset.top) {
            //第一个section需要做特殊处理
            return YES;
        }
        return NO;
    }
    
    CGRect sectionRect = [self.tableView rectForSection:indexPath.section];
    CGRect headerRect = [self.tableView rectForHeaderInSection:indexPath.section];
    if (location.y <= (CGRectGetMinY(sectionRect) + CGRectGetHeight(headerRect)) ||
        location.y >= CGRectGetMaxY(sectionRect)) {
        //超过section了
        return NO;
    }
    
    BOOL canMove = [self.tableView.dataSource tableView:self.tableView canMoveRowAtIndexPath:indexPath];

    CGPoint screenLocation = [gestureRecognizer locationInView:self.tableView.superview];
    if (canMove && screenLocation.y > self.tableView.contentInset.top) {
        CGPoint center = self.snapshotView.center;
        center.y = location.y;
        self.snapshotView.center = center;
    }
    
    if (indexPath.row != self.targetIndexPath.row && canMove) {
        [self.tableView beginUpdates];
        [self.tableView moveRowAtIndexPath:self.targetIndexPath toIndexPath:indexPath];
        [self.tableView endUpdates];
        self.targetIndexPath = indexPath;
    }
    return YES;
}

- (void)endGestureRecognizer:(UILongPressGestureRecognizer *)gestureRecognizer{
    [self stopEdgeScroll];
    HMTableViewCell *cell = [self.tableView cellForRowAtIndexPath:self.targetIndexPath];
    [self.tableView.dataSource tableView:self.tableView moveRowAtIndexPath:self.originIndexPath toIndexPath:self.targetIndexPath];
    [UIView animateWithDuration:HMMovableCellAnimationTime animations:^{
        self.snapshotView.frame = cell.frame;
    } completion:^(BOOL finished) {
        [self updateCell:cell isMoving:NO];
        [self.snapshotView removeFromSuperview];
        self.snapshotView = nil;
    }];
}
#pragma mark - UILongPressGestureRecognizer

- (void)longPressGestureRecognized:(UILongPressGestureRecognizer *)sender{
    switch (sender.state) {
        case UIGestureRecognizerStateBegan: {
            [self begainGestureRecognizer:sender];
            break;
        }
        case UIGestureRecognizerStateChanged: {
            [self changedGestureRecognizer:sender];
            break;
        }
        default: {
            [self endGestureRecognizer:sender];
            break;
        }
    }
}


- (UIView *)snapshotViewWithInputView:(HMTableViewCell *)inputView{
    UIGraphicsBeginImageContextWithOptions(inputView.bounds.size, NO, 0);
    [inputView.contentView.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
    
    UIView *snapshot = [[UIView alloc] initWithFrame:inputView.frame];
    snapshot.backgroundColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1.0f];
    [snapshot addSubview:imageView];
    
    snapshot.layer.shadowColor = [UIColor blackColor].CGColor;
    snapshot.layer.masksToBounds = NO;
    snapshot.layer.cornerRadius = 0;
    snapshot.layer.shadowOffset = CGSizeMake(0, 2);
    snapshot.layer.shadowOpacity = 0.4;
    snapshot.layer.shadowRadius = 10;
    return snapshot;
}

- (void)updateCell:(HMTableViewCell *)cell isMoving:(BOOL)isMoving{
    for (UIView *view in cell.contentView.subviews) {
        if (isMoving) {
            if (!self.ignoreViews) {
                self.ignoreViews = [[NSHashTable alloc] initWithOptions:NSPointerFunctionsWeakMemory capacity:0];
            }
            if (view.hidden) {
                [self.ignoreViews addObject:view];
            } else {
                view.hidden = YES;
            }
        } else {
            if (![self.ignoreViews containsObject:view]) {
                view.hidden = NO;
            }
        }
    }
    if (!isMoving) {
        [self.ignoreViews removeAllObjects];
        self.ignoreViews = nil;
    }
}

#pragma mark - EdgeScroll

static const CGFloat HMBaseCellScrollDistance = 3.0;
static const CGFloat HMBottomScrollEdge = 20.0;

- (void)startEdgeScroll{
    self.edgeScrollTimer = [CADisplayLink displayLinkWithTarget:self selector:@selector(processEdgeScroll)];
    [self.edgeScrollTimer addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
}

- (void)processEdgeScroll{
    BOOL canScroll = [self changedGestureRecognizer:self.longPressGestureRecognizer];
    if (!canScroll) {
        return;
    }
    CGFloat minOffsetY = self.tableView.contentOffset.y + self.tableView.contentInset.top + self.tableView.sectionHeaderHeight;
    CGFloat maxOffsetY = self.tableView.contentOffset.y + self.tableView.bounds.size.height - HMBottomScrollEdge;
    CGPoint touchPoint = self.snapshotView.center;
    //处理滚动
    CGFloat contentOffsetY = self.tableView.contentOffset.y;
    CGFloat moveDistance = 0;
    if (touchPoint.y < minOffsetY) {
        //cell在往上移动
        CGFloat moveSpeed = (touchPoint.y - minOffsetY)/HMBaseCellScrollDistance;
        moveDistance = MIN(moveSpeed, 10.0) * HMBaseCellScrollDistance;
        contentOffsetY =  MAX(self.tableView.contentOffset.y + moveDistance, -self.tableView.contentInset.top);
    }else if (touchPoint.y > maxOffsetY) {
        //cell在往下移动
        CGFloat moveSpeed = (touchPoint.y - maxOffsetY)/HMBaseCellScrollDistance;
        moveDistance = MIN(moveSpeed, 5.0) * HMBaseCellScrollDistance;
        contentOffsetY = self.tableView.contentOffset.y + moveDistance;
    }
    [self.tableView setContentOffset:CGPointMake(self.tableView.contentOffset.x, contentOffsetY) animated:NO];
    self.snapshotView.center = CGPointMake(self.snapshotView.center.x, self.snapshotView.center.y + moveDistance);
}

- (void)stopEdgeScroll{
    if (self.edgeScrollTimer) {
        [self.edgeScrollTimer invalidate];
        self.edgeScrollTimer = nil;
    }
}

#pragma mark - Getter and Setter

- (void)setShouldMove:(BOOL)shouldMove{
    _shouldMove = shouldMove;
    if (shouldMove) {
        if (!self.longPressGestureRecognizer) {
            self.longPressGestureRecognizer = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressGestureRecognized:)];
            self.longPressGestureRecognizer.minimumPressDuration = 0.2;
            [self.tableView addGestureRecognizer:self.longPressGestureRecognizer];
        }
    } else {
        if (self.longPressGestureRecognizer) {
            [self.tableView removeGestureRecognizer:self.longPressGestureRecognizer];
            self.longPressGestureRecognizer = nil;
        }
    }
}


@end
