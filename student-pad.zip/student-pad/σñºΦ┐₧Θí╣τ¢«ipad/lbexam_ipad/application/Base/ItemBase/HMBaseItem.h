//
//  HMBaseItem.h
//  UDan
//
//  Created by lilingang on 16/5/31.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <YYModel/NSObject+YYModel.h>

@interface HMBaseItem : NSObject<YYModel>

@property (nullable, nonatomic, copy) NSString *udid;

/**
 *  @brief 通过json对象创建一个新的实例对象
 *
 *  @param json 一个json对象 eg `NSDictionary`, `NSString` or `NSData`
 *
 *  @return 通过json对象生成的实例(错误的话返回nil)
 */
+ (nullable instancetype)itemWithJsonObject:(nullable id)json;

/**
 *  @brief 通过字典创建一个新的实力对象
 *
 *  @param dictionary 键值对，无效的键值对会被忽略
 *
 *  @discussion 键值对中的key会对应实例的属性，value对应实例属性的值，如果值类型没有匹配到会按照如下的基础策略来转换:
 `NSString` or `NSNumber` -> c number, such as BOOL, int, long, float, NSUInteger...
 `NSString` -> NSDate, parsed with format "yyyy-MM-dd'T'HH:mm:ssZ", "yyyy-MM-dd HH:mm:ss" or "yyyy-MM-dd".
 `NSString` -> NSURL.
 `NSValue` -> struct or union, such as CGRect, CGSize, ...
 `NSString` -> SEL, Class.
 *
 *  @return 通过dictionary生成的实例(错误的话返回nil)
 */
+ (nullable instancetype)itemWithDictionary:(nullable NSDictionary *)dictionary;

/**
 *  @brief 将对象的所有属性生成为json对象
 *
 *  @return 返回json对象(失败的话返回nil)
 */
- (nullable id)toJsonObject;

/**
 *  @brief 将对象的所有属性生成为json字符串的data数据
 *
 *  @return 返回json字符串的data数据(失败的话返回nil)
 */
- (nullable NSData *)toJsonData;

/**
 *  @brief 将对象的所有属性生成为json字符串
 *
 *  @return 返回json字符串(失败的话返回nil)
 */
- (nullable NSString *)toJsonString;


/**
 *  @brief 对象存储到磁盘的文件名
 *
 *  @return NSString 默认为类的名字
 */
+ (nonnull NSString *)localSaveFileName;

/**
 *  @brief 从本地加载数据模型
 *
 *  @param directory 本地的存储目录
 *
 *  @return 对象实例，不存在则返回nil
 */
+ (nullable id)itemLoadFromDirectory:(nonnull NSString *)directory;


/**
 内容copy

 @param item HMBaseItem
 */
- (void)copyValueFormItem:(nonnull HMBaseItem *)item;


/**
 判断两个Model内容是否相同

 @param item HMBaseItem

 @return YES?内容相同:内容不同
 */
- (BOOL)isSameToItem:(nonnull HMBaseItem *)item;

/**
 *  @brief 将当前对象存储到指定的目录
 *
 *  @param directory 本地的存储目录
 */
- (void)saveToDirectory:(nonnull NSString *)directory;

/**
 *  @brief 将该类对象存储的数据从本地清除
 *
 *  @param directory 本地的存储目录
 */
- (void)clearFromDirectory:(nonnull NSString *)directory;

@end
