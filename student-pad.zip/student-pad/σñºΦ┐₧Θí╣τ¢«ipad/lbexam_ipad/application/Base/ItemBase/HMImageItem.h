//
//  HMImageItem.h
//  UDan
//
//  Created by lilingang on 16/10/8.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseItem.h"

@interface HMImageItem : HMBaseItem

- (NSString *)OriginImageUrl;

- (NSString *)imageUrlWithSize:(CGSize)size;
- (NSString *)imageUrlWithSide:(NSUInteger)side;
- (NSString *)imageUrlWithWidth:(NSUInteger)width height:(NSUInteger)height;
- (NSString *)imageUrlWithWidth:(NSUInteger)width height:(NSUInteger)height maxSide:(NSInteger)maxSide;

- (NSString *)avatatImageURL;
- (NSString *)avatatImageURL30;
- (NSString *)avatatImageURL31WhiteBorder;
- (NSString *)avatatImageURL35;
- (NSString *)avatatImageURL40;
- (NSString *)avatatImageURL45;
- (NSString *)avatatImageURL60;

- (NSString *)imageURL50;
- (NSString *)imageURL55;
- (NSString *)imageURL60;
- (NSString *)imageURL65;


- (NSString *)imageURLWithCornerRadius:(CGFloat)cornerRadius border:(CGFloat)border borderColor:(NSString *)borderColor alpha:(CGFloat)borderalpha;
@end
