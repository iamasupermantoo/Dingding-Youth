//
//  HMUserItem.m
//  UDan
//
//  Created by lilingang on 16/10/8.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMUserItem.h"

@implementation HMUserItem

- (instancetype)init{
    self = [super init];
    if (self) {
        self.headImage = [[HMImageItem alloc] init];
        self.verified = HMBOOLUnkown;
        self.type = HMUserTypeUnkown;
        self.gender = HMGenderTypeUnkown;
        self.verified = HMBOOLUnkown;
    }
    return self;
}

- (void)copyValueFormItem:(HMUserItem *)item{
    if (!item || ![item isKindOfClass:[HMUserItem class]]) {
        return;
    }
    [super copyValueFormItem:item];
    if (item.type != HMUserTypeUnkown) {
        self.type = item.type;
    }
    
    if (item.grade && ![item.grade ddIsEmpty]) {
        self.grade = item.grade;
    }
    
    if (item.headImage) {
        [self.headImage copyValueFormItem:item.headImage];
    }
    if (item.gender != HMGenderTypeUnkown) {
        self.gender = item.gender;
    }
    self.name = item.name;
    if (item.province && ![item.province ddIsEmpty]) {
        self.province = item.province;
    }
    if (item.region && ![item.region ddIsEmpty]) {
        self.region = item.region;
    }
    self.signature = item.signature;

    if (item.verified != HMBOOLUnkown) {
        self.verified = item.verified;
        self.verifiedInfo = item.verifiedInfo;
    }
}

- (BOOL)isSameToItem:(HMUserItem *)item{
    BOOL udidSame = [super isSameToItem:item];
    BOOL imageSame = [self.headImage isSameToItem:item.headImage];
    BOOL typeSame = self.type == item.type;
    BOOL genderSame = self.gender == item.gender;
    BOOL nameSame = [self.name isEqualToString:item.name];
    BOOL provinceSame = (!self.province&&!item.province) || [self.province isEqualToString:item.province];
    BOOL regionSame = (!self.region&&!item.region) || [self.region isEqualToString:item.region];
    BOOL signatureSame = (!self.signature&&!item.signature) || [self.signature isEqualToString:item.signature];
    return udidSame && imageSame && typeSame && genderSame && nameSame && provinceSame && regionSame && signatureSame;
}


//- (BOOL)isMine{
//    HMUserItem *mineItem = [HMUserHandler sharedInstance].personItem.userItem;
//    return [self.udid isEqualToString:mineItem.udid];
//}

- (BOOL)hasPerfected{
    BOOL isNamePerfected = self.name && [self.name length] > 0;
    BOOL isHomePerfected = self.region && [self.region length] > 0 && self.province && [self.province length] > 0;
    BOOL isGenderPerfected = self.gender != HMUserTypeUnkown;
    return isNamePerfected && isHomePerfected && isGenderPerfected;
}

@end
