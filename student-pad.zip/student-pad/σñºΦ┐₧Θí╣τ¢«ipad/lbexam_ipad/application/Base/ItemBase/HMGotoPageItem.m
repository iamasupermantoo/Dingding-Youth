//
//  HMGotoPageItem.m
//  UDan
//
//  Created by lilingang on 16/10/13.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMGotoPageItem.h"

@implementation HMGotoPageItem

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"paramItem"  : @"params"};
}

@end

@implementation HMGotoPageParamItem

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"udid"  : @"dataId"
           
             };
}

@end
