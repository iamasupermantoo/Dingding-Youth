//
//  HMBaseItem.m
//  UDan
//
//  Created by lilingang on 16/5/31.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseItem.h"
#import <YYModel/YYModel.h>

@interface HMBaseItem ()<NSCoding,NSCopying>

@end

@implementation HMBaseItem

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"udid"  : @"id"};
}

+ (nullable instancetype)itemWithJsonObject:(nullable id)json{
    return [self yy_modelWithJSON:json];
}

+ (nullable instancetype)itemWithDictionary:(nullable NSDictionary *)dictionary{
    return [self yy_modelWithDictionary:dictionary];
}

- (nullable id)toJsonObject{
    return [self yy_modelToJSONObject];
}

- (nullable NSData *)toJsonData{
    return [self yy_modelToJSONData];
}

- (nullable NSString *)toJsonString{
    return [self yy_modelToJSONString];
}

#pragma mark - NSKeyedArchiver && NSKeyedUnarchiver

+ (NSString *)localSaveFileName{
    return [[[self class] description] stringByAppendingString:@"File"];
}

+ (nullable id)itemLoadFromDirectory:(nonnull NSString *)directory{
    NSString *filePath = [directory stringByAppendingPathComponent:[self localSaveFileName]];
    if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        return [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
    } else {
        return nil;
    }
}

- (void)copyValueFormItem:(nonnull HMBaseItem *)item{
    if (!item || ![item isKindOfClass:[HMBaseItem class]]) {
        return;
    }
    if (item.udid && [item.udid length] > 0) {
        self.udid = item.udid;
    }
}

- (BOOL)isSameToItem:(nonnull HMBaseItem *)item{
    if (!self.udid && !item.udid) {
        return YES;
    }
    return [self.udid isEqualToString:item.udid];
}

- (void)saveToDirectory:(nonnull NSString *)directory{
    NSString *filePath = [directory stringByAppendingPathComponent:[[self class] localSaveFileName]];
    BOOL success = [NSKeyedArchiver archiveRootObject:self toFile:filePath];
    if (!success) {
        NSLog(@"保存失败");
    }
}

- (void)clearFromDirectory:(nonnull NSString *)directory{
    NSString *filePath = [directory stringByAppendingPathComponent:[[self class] localSaveFileName]];
    [[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];
}

#pragma mark - Template Methods

- (NSString *)description{
    return [self yy_modelDescription];
}

#pragma mark - NSObject

- (NSUInteger)hash {
    [super hash];
    return [self yy_modelHash];
}

- (BOOL)isEqual:(id)object {
    return [self yy_modelIsEqual:object];
}

#pragma mark - NSCoding

- (void)encodeWithCoder:(NSCoder *)aCoder {
    [self yy_modelEncodeWithCoder:aCoder];
}
- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];
    if (self) {
        return [self yy_modelInitWithCoder:aDecoder];
    }
    return nil;
}

#pragma mark - NSCopying
- (id)copyWithZone:(NSZone *)zone {
    return [self yy_modelCopy];
}

@end
