//
//  HMBannerItem.m
//  UDan
//
//  Created by lilingang on 16/10/8.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBannerItem.h"

@implementation HMBannerItem

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"imageItem" : [HMImageItem class],
             @"gotoPageItem" : [HMGotoPageItem class]};
}

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"imageItem"  : @"image",
             @"gotoPageItem" : @"gotoPage"};
}


@end
