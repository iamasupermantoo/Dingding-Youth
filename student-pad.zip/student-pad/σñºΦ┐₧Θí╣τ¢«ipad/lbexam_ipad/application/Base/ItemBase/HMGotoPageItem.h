//
//  HMGotoPageItem.h
//  UDan
//
//  Created by lilingang on 16/10/13.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseItem.h"

@class HMGotoPageParamItem;

@interface HMGotoPageItem : HMBaseItem

@property (nonatomic, assign) HMGotoPageType type;

@property (nonatomic, strong) HMGotoPageParamItem *paramItem;

@end

@interface HMGotoPageParamItem : HMBaseItem

@property (nonatomic, assign) HMFeedType feedType;
@property(nonatomic,strong) NSString *qid;
@property(nonatomic,strong) NSString *aid;
@end
