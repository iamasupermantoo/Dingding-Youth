//
//  HMBannerItem.h
//  UDan
//
//  Created by lilingang on 16/10/8.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseItem.h"
#import "HMImageItem.h"
#import "HMGotoPageItem.h"

@interface HMBannerItem : HMBaseItem

@property (nonatomic, strong) HMImageItem *imageItem;

@property (nonatomic, strong) HMGotoPageItem *gotoPageItem;

@end
