//
//  HMUserItem.h
//  UDan
//
//  Created by lilingang on 16/10/8.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseItem.h"
#import "HMImageItem.h"

@interface HMUserItem : HMBaseItem

@property (nonatomic, assign) HMUserType type;

@property (nonatomic, strong) HMImageItem *headImage;

@property (nonatomic, assign) HMGenderType gender;

@property (nonatomic, copy) NSString *name;

@property(nonatomic,strong) NSString *grade;

@property (nonatomic, copy) NSString *province;

@property (nonatomic, copy) NSString *region;

@property (nonatomic, copy) NSString *signature;

@property (nonatomic, assign) HMBOOL verified;

@property (nonatomic, copy) NSString *verifiedInfo;

- (void)copyValueFormItem:(HMUserItem *)item;

//- (BOOL)isMine;

- (BOOL)hasPerfected;
@end
