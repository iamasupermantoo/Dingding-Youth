//
//  HMImageItem.m
//  UDan
//
//  Created by lilingang on 16/10/8.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMImageItem.h"

@interface HMImageItem ()

@property (nonatomic, assign) CGFloat height;
@property (nonatomic, assign) CGFloat width;
@property (nonatomic, copy) NSString *pattern;

@end

@implementation HMImageItem

- (void)copyValueFormItem:(HMImageItem *)item{
    [super copyValueFormItem:item];
    self.height = item.height;
    self.width = item.width;
    self.pattern = item.pattern;
}

#pragma mark - Public Methods

- (NSString *)OriginImageUrl{
    if (nil == self.pattern) {
        return nil;
    }
 
    NSRange range = [self.pattern rangeOfString:@"@%dw_%dh_75q"];
    NSString *string;
    if ([self.pattern hasSuffix:@"@%dw_%dh_75q"]) {
        string = [self.pattern stringByReplacingCharactersInRange:range withString:@""];
    }
    return string;
}

- (NSString *)imageUrlWithSize:(CGSize)size{
    return [self imageUrlWithWidth:size.width height:size.height];
}

- (NSString *)imageUrlWithSide:(NSUInteger)side {
    return [self imageUrlWithWidth:side height:side];
}
- (NSString *)imageUrlWithWidth:(NSUInteger)width height:(NSUInteger)height {
    if (nil == self.pattern) {
        return nil;
    }
    width *= [[UIScreen mainScreen] scale];
    height *= [[UIScreen mainScreen] scale];
    return [NSString stringWithFormat:self.pattern, width, height];
}

- (NSString *)imageUrlWithWidth:(NSUInteger)width height:(NSUInteger)height maxSide:(NSInteger)maxSide{
    CGFloat nWidth = 0;
    CGFloat nHeight = 0;
    if (width > 0 && height > 0) {
        if (width > height) {
            nWidth = MIN(maxSide, width);
            nHeight = maxSide * height / width;
            nHeight = MIN(nHeight, height);
            if (nWidth > 2 * nHeight) {
                nHeight = ceil(nWidth / 2);
            }
        } else {
            nHeight = MIN(maxSide, height);
            nWidth = maxSide * width / height;
            nWidth = MIN(nWidth, width);
            if (nHeight > 2 * nWidth) {
                nWidth = ceil(nHeight / 2);
            }
        }
    }
    return [self imageUrlWithWidth:nWidth height:nHeight];
}

- (NSString *)avatatImageURL{
    return [self imageURLWithCornerRadius:0 border:0 borderColor:@"" alpha:1.0];
}
- (NSString *)avatatImageURL30{
    return [self imageURLWithCornerRadius:30 border:0 borderColor:@"" alpha:1.0];
}

- (NSString *)avatatImageURL31WhiteBorder{
    return [self imageURLWithCornerRadius:31 border:1 borderColor:@"FFFFFF" alpha:1.0];
}

- (NSString *)avatatImageURL35{
    return [self imageURLWithCornerRadius:30 border:0 borderColor:@"" alpha:1.0];
}

- (NSString *)avatatImageURL40{
    return [self imageURLWithCornerRadius:40 border:0 borderColor:@"" alpha:1.0];
}

- (NSString *)avatatImageURL45{
    return [self imageURLWithCornerRadius:45 border:0 borderColor:@"" alpha:1.0];
}

- (NSString *)avatatImageURL60{
    return [self imageURLWithCornerRadius:60 border:0 borderColor:@"" alpha:1.0];
}


- (NSString *)imageURL50{
    return [self imageUrlWithSide:50.0];
}

- (NSString *)imageURL55{
    return [self imageUrlWithSide:55.0];
}

- (NSString *)imageURL60{
    return [self imageUrlWithSide:60.0];
}

- (NSString *)imageURL65{
    return [self imageUrlWithSide:65.0];
}

#pragma mark - Getter and Setter

/**
 返回带有圆角和边框的图片URL
 
 @param cornerRadius 圆角半径
 @param border       边框宽度
 @param borderColor  边框色值，十六进制，eg.ffffff,不需要#号
 
 @return NSString
 */
- (NSString *)imageURLWithCornerRadius:(CGFloat)cornerRadius border:(CGFloat)border borderColor:(NSString *)borderColor alpha:(CGFloat)borderalpha{
    NSString *imageURLString = [self imageUrlWithWidth:cornerRadius height:cornerRadius];
    NSURL *imageURL = [NSURL URLWithString:imageURLString];
    NSString *query = imageURL.query;
    NSString *tmpString = imageURLString;
    
    if ([query length] > 0) {
        tmpString = [imageURLString stringByReplacingOccurrencesOfString:query withString:@""];
        [query stringByAppendingFormat:@"&=%.1f",cornerRadius];
    } else {
        query = [NSString stringWithFormat:@"?corner=%.1f",cornerRadius];
    }
    if (border > 0) {
        query = [query stringByAppendingFormat:@"&border=%.1f&color=%@",border,borderColor];
    }
    if (borderalpha<1.0 && borderalpha>0.0) {
        query = [query stringByAppendingFormat:@"&alpha=%f",borderalpha];
    }
    imageURLString = [tmpString stringByAppendingString:query];
    return imageURLString;
}

- (void)setPattern:(NSString *)pattern{
    if (nil == pattern) {
        return;
    }
    NSScanner *theScanner = [NSScanner scannerWithString:pattern];
    
    NSString *text = nil;
    NSMutableString *resUrlPattern = [NSMutableString string];
    
    BOOL hasLeftBrace = NO;
    while (![theScanner isAtEnd]) {
        // find start of tag
        [theScanner scanUpToString:@"{" intoString:&text];
        
        [resUrlPattern appendString:[text substringFromIndex:hasLeftBrace ? 1 : 0]];
        hasLeftBrace = YES;
        
        [theScanner scanUpToString:@"}" intoString:&text];
        text = [text substringFromIndex:1];
        
        if ([text isEqualToString:@"w"] || [text isEqualToString:@"h"]) {
            [resUrlPattern appendString:@"%d"];
        }
    }
    _pattern = resUrlPattern;
}

@end
