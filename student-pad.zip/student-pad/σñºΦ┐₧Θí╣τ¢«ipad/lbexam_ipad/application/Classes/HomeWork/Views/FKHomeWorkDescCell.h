//
//  FKHomeWorkDescCell.h
//  lbexam
//
//  Created by frankay on 17/2/4.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"

@interface FKHomeWorkDescCell : HMTableViewCell

@end


@interface FKHomeWorkDescCellItem : HMTableViewCellItem
@property(nonatomic,strong) NSAttributedString *attr;
@end
