//
//  FKImageCollecitionViewCell.m
//  lbexam
//
//  Created by frankay on 17/2/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKImageCollecitionViewCell.h"
#import "HMImageItem.h"
@implementation FKImageCollecitionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


- (void)updateImageWithUrl:(HMImageItem *)ImageItem{
    
    [self.imageView hmLoadImageURL:[ImageItem imageUrlWithSide:(IPAD_SCREENWIDTH-135)/3.0] placeholderImage:nil local:NO];

}
@end
