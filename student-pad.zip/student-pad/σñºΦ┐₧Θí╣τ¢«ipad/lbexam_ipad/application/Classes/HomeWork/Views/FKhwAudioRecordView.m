//
//  FKhwAudioRecordView.m
//  lbexam
//
//  Created by frankay on 17/2/9.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKhwAudioRecordView.h"

#import "D3RecordButton.h"
@interface FKhwAudioRecordView ()<D3RecordDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *microphoneView;
@property (weak, nonatomic) IBOutlet UIButton *cancelBtn;
@property (strong, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet D3RecordButton *MicrophoneBtn;

@property(nonatomic,strong) NSArray *picArr;
@property(nonatomic,assign) BOOL isRecording;

@property(nonatomic,strong) Mp3Recorder *mp3recorder;
@end
@implementation FKhwAudioRecordView

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        self.contentView.frame = CGRectMake(0, 0,SCREENWIDTH, 184);
        [self addSubview:self.contentView];
        [self initSetting];
    }
    return self;
}



- (void)initSetting{

    self.microphoneView.layer.shadowOffset = CGSizeMake(1, -1);
    self.microphoneView.layer.shadowColor = [UIColor hmBorderColor].CGColor;
    self.microphoneView.layer.shadowOpacity = 1.0;
//    [self.microphoneView ddAddTarget:self tapAction:@selector(tapMicrophoneView:)];
    self.cancelBtn.backgroundColor = [UIColor hmBorderColor];
    [self.cancelBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.MicrophoneBtn initRecord:self maxtime:180];
    self.isRecording = NO;
}

- (void)tapMicrophoneView:(UITapGestureRecognizer *)tap{
    //
    if (self.isRecording) {
         // 点击之前是正在录音
        self.isRecording = NO;
        [self.microphoneView.layer removeAllAnimations];
        self.microphoneView.image = IMG_NAME(@"hwlongpressAudio");
        
    }else{
        self.isRecording = YES;
        [self.microphoneView imageViewAnimationWithArray:self.picArr];
        [self.microphoneView startAnimating];
        // 开始录音
        
    }

}

- (IBAction)cancelBtnAction:(UIButton *)sender {
    if (self.delegate && [self.delegate respondsToSelector:@selector(recordCancelAction:)]) {
        [self.delegate recordCancelAction:sender];
    }
}

-(NSArray *)picArr{
    if (!_picArr) {
        _picArr = @[IMG_NAME(@"microphone1"),IMG_NAME(@"microphone2"),IMGNAME(@"microphone3")];
    }
    return _picArr;

}

-(void)failRecord{
    [DDProgressHUD showErrorWithStatus:@"录音时间不能低于3秒!"];
    [self.microphoneView.layer removeAllAnimations];
    self.microphoneView.image = IMG_NAME(@"hwlongpressAudio");
}


- (void)dragExit{
    // 取消录音
    [self.microphoneView.layer removeAllAnimations];
    self.microphoneView.image = IMG_NAME(@"hwlongpressAudio");
}

-(void)endRecord:(NSData *)voiceData{
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(endRecord2Commit:)]) {
        [self.delegate endRecord2Commit:voiceData];
    }
    [self.microphoneView.layer removeAllAnimations];
    self.microphoneView.image = IMG_NAME(@"hwlongpressAudio");
    
}

-(void)touchBeign{
    [self.microphoneView imageViewAnimationWithArray:self.picArr];
}





@end
