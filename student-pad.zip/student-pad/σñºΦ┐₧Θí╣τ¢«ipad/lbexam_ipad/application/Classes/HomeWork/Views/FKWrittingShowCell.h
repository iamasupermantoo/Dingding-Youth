//
//  FKWrittingShowCell.h
//  lbexam
//
//  Created by frankay on 17/2/6.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"

@protocol  FKWrittingShowCellDelegate<NSObject>

- (void)ClickCancelBtnAction:(NSDictionary *)info;

@end

@interface FKWrittingShowCell : HMTableViewCell

@end

@interface FKWrittingShowCellItem : HMTableViewCellItem
@property(nonatomic,assign) BOOL deleteIsHiden;
@property(nonatomic,strong) NSAttributedString *attr;
@end
