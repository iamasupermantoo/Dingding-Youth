//
//  FKhwAudioRecordView.h
//  lbexam
//
//  Created by frankay on 17/2/9.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol FKhwAudioRecordViewDelegate <NSObject>

@optional
- (void)recordCancelAction:(id)sender;
- (void)endRecord2Commit:(NSData *)data;

@end


@interface FKhwAudioRecordView : UIView
@property(nonatomic,weak) id<FKhwAudioRecordViewDelegate>delegate;
@end
