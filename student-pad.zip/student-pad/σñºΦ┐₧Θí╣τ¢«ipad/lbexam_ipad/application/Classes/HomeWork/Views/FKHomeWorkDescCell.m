//
//  FKHomeWorkDescCell.m
//  lbexam
//
//  Created by frankay on 17/2/4.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKHomeWorkDescCell.h"

#import "FKHomeworkListItem.h"
@interface FKHomeWorkDescCell ()
@property (weak, nonatomic) IBOutlet FKinitLabel *lesson;
@property (weak, nonatomic) IBOutlet FKinitLabel *lessonDesc;
@property (weak, nonatomic) IBOutlet FKinitLabel *lessonTime;
@property (weak, nonatomic) IBOutlet UIView *bgView;

@end

@implementation FKHomeWorkDescCell

- (void)initSettings{
    [super initSettings];
    self.lessonDesc.textColor = [UIColor fk666Color];
    self.lessonTime.textColor = [UIColor fk666Color];
    self.lesson.textColor = [UIColor hmTextBlackColor];
    
    self.backgroundColor = [UIColor whiteColor];
    self.contentView.backgroundColor = [UIColor whiteColor];
    self.layer.borderColor = [UIColor hmBorderColor].CGColor;
    self.layer.borderWidth = 0.5;
    
    self.backgroundColor = [UIColor clearColor];
}

- (void)updateWithCellItem:(FKHomeWorkDescCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    FKHomeworkListItem *descItem = cellItem.rawObject;
    self.lesson.text = descItem.title;
    self.lessonTime.text = descItem.time;
    if (cellItem.attr) {
        self.lessonDesc.attributedText = cellItem.attr;
    }else{
        self.lessonDesc.text = descItem.content;
    }
}

@end


@implementation FKHomeWorkDescCellItem
- (void)initSettings{
    [super initSettings];
//    self.hidenSeparator = YES;
    self.separatorInset = kIpadNoGapSeperateInsets;
    self.cellHeight = 100;
    
}

- (void)setRawObject:(id)rawObject{
    [super setRawObject:rawObject];
    if (rawObject==nil) {
        return;
    }
    
    FKHomeworkListItem *item = rawObject;
    UIFont *font = [UIFont systemFontOfSize:15];
    CGFloat contentHeight = [item.content HeightWithFont:font maxSize:360];
    if (contentHeight>ceil(font.lineHeight)) {
        self.attr = [item.content attributedStringWithTextFont:font];
    }
    
    self.cellHeight = contentHeight + 68;
}

@end
