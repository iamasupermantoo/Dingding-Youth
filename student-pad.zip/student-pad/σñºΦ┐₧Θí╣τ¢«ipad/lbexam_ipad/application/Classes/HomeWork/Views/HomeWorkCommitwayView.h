//
//  HomeWorkCommitwayView.h
//  lbexam
//
//  Created by frankay on 17/2/6.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol HomeWorkCommitwayViewDelegate <NSObject>

// 文字输入
- (void)HomeWorkWrittingBtnAction:(NSDictionary *)info;
// 录制语音
- (void)HomeWorkAudioRecodeBtnAction:(NSDictionary *)info;
// 相册选择
- (void)HomeWorkPhotoBtnAction:(NSDictionary *)info;
// 照相选择
- (void)HomeWorkCameraBtnAction:(NSDictionary *)info;


// 取消
- (void)HomeWorkCancelBtnAction:(id)sender;
@end
@interface HomeWorkCommitwayView : UIView
@property(nonatomic,weak) id<HomeWorkCommitwayViewDelegate>delegate;
@end
