//
//  FKHomeWorkListCell.m
//  lbexam
//
//  Created by frankay on 17/2/4.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKHomeWorkListCell.h"
#import "FKHomeworkListItem.h"
@interface FKHomeWorkListCell ()

@property (weak, nonatomic) IBOutlet FKinitLabel *HLesson;
@property (weak, nonatomic) IBOutlet FKinitLabel *Hcourse;
@property (weak, nonatomic) IBOutlet FKinitLabel *HteacherName;
@property (weak, nonatomic) IBOutlet FKinitLabel *Htime;
@property (weak, nonatomic) IBOutlet UILabel *Hstate;
@property (weak, nonatomic) IBOutlet UILabel *lessonName;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UIView *midLine1;

@end
@implementation FKHomeWorkListCell


- (void)initSettings{
    [super initSettings];
    self.lessonName.textColor = [UIColor fkfe8d25Color];
    self.midLine1.backgroundColor = [UIColor fkfe8d25Color];
    self.timeLabel.textColor = [UIColor fk666Color];
}

- (void)updateWithCellItem:(HMTableViewCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    FKHomeworkListItem *Item = cellItem.rawObject;
    self.HLesson.text = Item.title;
    self.lessonName.text = Item.label;
    self.timeLabel.text = Item.time;
    self.Hcourse.text = [NSString stringWithFormat:@"课程：%@",Item.course];
    self.HteacherName.text = [NSString stringWithFormat:@"老师：%@",Item.teacher];
    self.Htime.text = Item.time;
    [self updateState:Item.status];
    
}


- (void)updateState:(FKHomeWorkState)state{
    if (state == FKHomeWorkStateWaitingCommit) {
        // 待提交
        self.Hstate.text = @"待提交";
        self.Hstate.textColor = [UIColor fkde0303redColor];
    }
    
    if (state == FKHomeWorkStateWaitingMark) {
        // 待评分
        self.Hstate.text = @"待评分";
        self.Hstate.textColor = [UIColor fkfe8d25Color];
    }
    
    if (state == FKHomeWorkStateMarked) {
        // 已评分
        self.Hstate.text = @"已评分";
        self.Hstate.textColor = [UIColor hmTextGrayColor];
    }
}
@end


@implementation FKHomeWorkListCellItem

- (void)initSettings{
    [super initSettings];
    self.cellHeight = 110;
    self.separatorInset = kIpadNoGapSeperateInsets;
}

@end
