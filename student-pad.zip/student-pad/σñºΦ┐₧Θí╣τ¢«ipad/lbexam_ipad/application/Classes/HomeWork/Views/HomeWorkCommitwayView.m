//
//  HomeWorkCommitwayView.m
//  lbexam
//
//  Created by frankay on 17/2/6.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HomeWorkCommitwayView.h"
#import "FKToolListCell.h"
#define kviewHeight 360/4.0-35+40+94
@interface HomeWorkCommitwayView ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet FKinitLabel *labelway;
@property (strong, nonatomic) IBOutlet UIView *contentView;

@property (weak, nonatomic) IBOutlet UIButton *cancelBtn;
@property(nonatomic,strong) NSArray *tools;
@end
@implementation HomeWorkCommitwayView


- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super initWithCoder:aDecoder]) {
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        self.contentView.frame = CGRectMake(0, 0,SCREENWIDTH, kviewHeight);
        self.labelway.textColor = [UIColor hmTextGrayColor];
        self.cancelBtn.backgroundColor = [UIColor blueColor];
        [self.cancelBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        self.collectionView.backgroundColor = [UIColor whiteColor];
        
        [self.collectionView registerNib:[UINib nibWithNibName:@"FKToolListCell" bundle:nil] forCellWithReuseIdentifier:@"toolCell"];
        self.collectionView.delegate = self;
        self.collectionView.dataSource = self;
        [self addSubview:self.contentView];
    }
    
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        self.contentView.frame = CGRectMake(0, 0,SCREENWIDTH, kviewHeight);
        self.labelway.textColor = [UIColor hmTextGrayColor];
        self.cancelBtn.backgroundColor = [UIColor fkcccColor];
        [self.cancelBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        self.collectionView.backgroundColor = [UIColor whiteColor];
        
        [self.collectionView registerNib:[UINib nibWithNibName:@"FKToolListCell" bundle:nil] forCellWithReuseIdentifier:@"toolCell"];
        self.collectionView.delegate = self;
        self.collectionView.dataSource = self;
        [self addSubview:self.contentView];
    }
    return self;
}

#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    
    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.tools.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    FKToolListCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"toolCell" forIndexPath:indexPath];
    cell.titile.textColor = [UIColor hmTextGrayColor];
    cell.titile.font = [UIFont systemFontOfSize:14];
    [cell setcellWithDic:self.tools[indexPath.row]];
    
    return cell;
}

#pragma mark <UICollectionViewDelegate>

//
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 0;
}
// item size
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(360/4.0, 360/4.0-35+40);
}


-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.row) {
        case 0:
        {
            // 文字输入
            if (self.delegate && [self.delegate respondsToSelector:@selector(HomeWorkWrittingBtnAction:)]) {
                [self.delegate HomeWorkWrittingBtnAction:nil];
            }
            
        }
     
            break;
        case 1:
            // 录制语音
        {
            if (self.delegate && [self.delegate respondsToSelector:@selector(HomeWorkAudioRecodeBtnAction:)]) {
                [self.delegate HomeWorkAudioRecodeBtnAction:nil];
            }
            
        }
      
            break;
        case 2:
            // 相册
        {
            if (self.delegate && [self.delegate respondsToSelector:@selector(HomeWorkPhotoBtnAction:)]) {
                [self.delegate HomeWorkPhotoBtnAction:nil];
            }
            
        }
     
            break;
        case 3:
            // 相机
        {
            if (self.delegate && [self.delegate respondsToSelector:@selector(HomeWorkCameraBtnAction:)]) {
                [self.delegate HomeWorkCameraBtnAction:nil];
            }
            
        }
            break;
        default:
            break;
    }
    
}

- (IBAction)cancleBtnAction:(UIButton *)sender {
    if (self.delegate && [self.delegate respondsToSelector:@selector(HomeWorkCancelBtnAction:)]) {
        [self.delegate HomeWorkCancelBtnAction:sender];
    }
}


-(NSArray *)tools{
    if (!_tools) {
        _tools = @[@{@"img":@"hwwriting",@"title":@"输入文字"},@{@"img":@"hwaudio",@"title":@"录制语音"},@{@"img":@"hwphoto",@"title":@"相册选择"},@{@"img":@"hwcamera",@"title":@"拍照上传"}];
    }
    return _tools;
}

@end
