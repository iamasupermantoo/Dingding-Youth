//
//  FKToolListCell.m
//  lbexam
//
//  Created by frankay on 17/1/13.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKToolListCell.h"

@interface FKToolListCell ()
@property (weak, nonatomic) IBOutlet UIImageView *signImageView;


@end
@implementation FKToolListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setcellWithDic:(NSDictionary *)dict{
    self.signImageView.image = IMG_NAME(dict[@"img"]);
    self.titile.text = dict[@"title"];

}

@end
