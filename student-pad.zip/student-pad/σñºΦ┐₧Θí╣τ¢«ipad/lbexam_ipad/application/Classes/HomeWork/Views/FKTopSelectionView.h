//
//  FKTopSelectionView.h
//  lbexam_ipad
//
//  Created by frankay on 17/5/28.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol FKTopSelectionViewDelegate <NSObject>

- (void)fk_OneTitleTapAction;
- (void)fk_TwoTitleTapAction;

@optional
- (void)fk_ThreeTitleTapAction;


@end

@interface FKTopSelectionView : UIView
@property(nonatomic,weak)id<FKTopSelectionViewDelegate>delegate;

- (instancetype)initWithFrame:(CGRect)frame WithType:(NSInteger)type;
@end
