//
//  FKTopSelectionView.m
//  lbexam_ipad
//
//  Created by frankay on 17/5/28.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKTopSelectionView.h"

@interface FKTopSelectionView ()

@property (weak, nonatomic) IBOutlet UILabel *oneTitle;
@property (weak, nonatomic) IBOutlet UILabel *twoTitle;
@property (weak, nonatomic) IBOutlet UILabel *threeTitle;
@property (weak, nonatomic) IBOutlet UIView *bottomLine;
@property (strong, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *lineCenterX;

@end
@implementation FKTopSelectionView

- (instancetype)initWithFrame:(CGRect)frame WithType:(NSInteger)type{
    self = [super initWithFrame:frame];
    
    if (self) {
        //
         [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
         self.contentView.frame = self.bounds;
        self.contentView.layer.borderColor = [UIColor hmBorderColor].CGColor;
        self.contentView.layer.borderWidth = 0.5;
        [self initSetting];
        [self addSubview:self.contentView];
        
        if (type==0) {
            // 作业
            
        }else if (type==1){
            // 评价
            self.oneTitle.text = @"未评价";
            self.twoTitle.text = @"已评价";
            self.threeTitle.hidden = YES;
        }
        
    }
    return self;

}



- (void)initSetting{
    // 初始化
    self.oneTitle.textColor = [UIColor fkfe8d25Color];
    self.twoTitle.textColor = [UIColor hmTextBlackColor];
    self.threeTitle.textColor = [UIColor hmTextBlackColor];
    self.bottomLine.backgroundColor = [UIColor fkfe8d25Color];
    
    [self.oneTitle ddAddTarget:self tapAction:@selector(fkOneTitleAction:)];
    [self.twoTitle ddAddTarget:self tapAction:@selector(fkTwoTitleAction:)];
    [self.threeTitle ddAddTarget:self tapAction:@selector(fkThreeTitleAction:)];
    
}


- (void)fkOneTitleAction:(UIGestureRecognizer *)tap{
    self.oneTitle.textColor = [UIColor fkfe8d25Color];
    self.twoTitle.textColor = [UIColor hmTextBlackColor];
    self.threeTitle.textColor = [UIColor hmTextBlackColor];
    self.lineCenterX.constant = 0;
    [self.bottomLine layoutIfNeeded];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(fk_OneTitleTapAction)]) {
        [self.delegate fk_OneTitleTapAction];
    }
    

}



- (void)fkTwoTitleAction:(UIGestureRecognizer *)tap{
    self.oneTitle.textColor = [UIColor hmTextBlackColor];
    self.twoTitle.textColor = [UIColor fkfe8d25Color];
    self.threeTitle.textColor = [UIColor hmTextBlackColor];
    self.lineCenterX.constant = 46+122;
    [self.bottomLine layoutIfNeeded];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(fk_TwoTitleTapAction)]) {
        [self.delegate fk_TwoTitleTapAction];
    }
    
    
}


- (void)fkThreeTitleAction:(UIGestureRecognizer *)tap{
    self.oneTitle.textColor = [UIColor hmTextBlackColor];
    self.twoTitle.textColor = [UIColor hmTextBlackColor];
    self.threeTitle.textColor = [UIColor fkfe8d25Color];
    self.lineCenterX.constant = (46+122)*2;
    [self.bottomLine layoutIfNeeded];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(fk_ThreeTitleTapAction)]) {
        [self.delegate fk_ThreeTitleTapAction];
    }
    
    
}



@end
