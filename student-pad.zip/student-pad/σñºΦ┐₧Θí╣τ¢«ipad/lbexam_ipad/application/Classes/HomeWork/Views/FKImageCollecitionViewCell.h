//
//  FKImageCollecitionViewCell.h
//  lbexam
//
//  Created by frankay on 17/2/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HMImageItem;
@interface FKImageCollecitionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

- (void)updateImageWithUrl:(HMImageItem *)ImageItem;
@end
