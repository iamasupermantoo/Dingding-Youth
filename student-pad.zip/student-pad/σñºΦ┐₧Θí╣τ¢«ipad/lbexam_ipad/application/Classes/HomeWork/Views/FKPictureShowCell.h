//
//  FKPictureShowCell.h
//  lbexam
//
//  Created by frankay on 17/2/6.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"
#import "FKWrittingShowCell.h"
@protocol FKPictureShowCellDelegate <NSObject>

@optional
- (void)ImageCellClickCancelBtnAction:(NSDictionary *)info;

@end


@interface FKPictureShowCell : HMTableViewCell

@end

@interface FKPictureShowCellItem : HMTableViewCellItem
@property(nonatomic,assign) BOOL deleteIsHiden;

@end
