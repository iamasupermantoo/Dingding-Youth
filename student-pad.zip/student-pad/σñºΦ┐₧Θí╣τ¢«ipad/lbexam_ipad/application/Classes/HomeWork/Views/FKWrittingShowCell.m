//
//  FKWrittingShowCell.m
//  lbexam
//
//  Created by frankay on 17/2/6.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKWrittingShowCell.h"
#import "FKhwCiContentItem.h"

@interface FKWrittingShowCell ()
@property (weak, nonatomic) IBOutlet FKinitLabel *wrContent;
@property (weak, nonatomic) IBOutlet FKinitLabel *wrTime;
@property (weak, nonatomic) IBOutlet UIButton *wrDeleteBtn;
@property (weak, nonatomic) IBOutlet UIView *contentBgView;

@end
@implementation FKWrittingShowCell


- (void)initSettings{
    [super initSettings];
    self.backgroundColor = [UIColor fkColorWithString:@"#f6f6f6"];
    self.backgroundColor = [UIColor hmMainBgColor];

    self.wrTime.textColor = [UIColor fk666Color];
    self.contentBgView.layer.cornerRadius = 2;
    self.contentBgView.layer.borderWidth = 0.5;
    self.contentBgView.layer.borderColor = [UIColor hmBorderColor].CGColor;
    
    self.layer.shadowColor = [UIColor blackColor].CGColor;
    self.layer.shadowOpacity = 1.0;
    self.layer.shadowOffset = CGSizeMake(0, 3);
}

-(void)updateWithCellItem:(FKWrittingShowCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    FKhwCiContentItem *item = cellItem.rawObject;
    
    
    if (cellItem.deleteIsHiden) {
        self.wrDeleteBtn.hidden = YES;
    }else{
        self.wrDeleteBtn.hidden = NO;
    }
    self.wrTime.text = item.time;
    if (cellItem.attr) {
        self.wrContent.attributedText = cellItem.attr;
    }else{
        self.wrContent.text = item.text;
    }
    
}

- (IBAction)wrdeleteBtnAction:(UIButton *)sender {
    // 点击某个cell的删除
    [self.deleagte hmTableViewCell:self sender:sender selector:@selector(ClickCancelBtnAction:) userInfo:nil];
    
}

@end


@implementation FKWrittingShowCellItem

- (void)initSettings{
    [super initSettings];
    self.hidenSeparator = YES;
    self.canSelect = NO;
    self.deleteIsHiden = YES;
    self.cellHeight = 100;
}

- (void)setRawObject:(id)rawObject{
    [super setRawObject:rawObject];
    if (!rawObject) {
        return;
    }
    
    FKhwCiContentItem *item = rawObject;
    UIFont *font = [UIFont systemFontOfSize:15];
    CGFloat contentHeight = [item.text HeightWithFont:font maxSize:IPAD_SCREENWIDTH-200-96];
    if (contentHeight>ceil(font.lineHeight)) {
        self.attr = [item.text attributedStringWithTextFont:font];
    }
    
    self.cellHeight = contentHeight + 55;

}

@end
