//
//  FKPictureShowCell.m
//  lbexam
//
//  Created by frankay on 17/2/6.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKPictureShowCell.h"
#import "HMImageItem.h"
#import "FKhwCiContentItem.h"
#import "FKImageCollecitionViewCell.h"
#import "UIView+Shadow.h"
#import "STPhotoBrowserController.h"
#define kImageViewHeight (SCREENWIDTH-200)/3.0
@interface FKPictureShowCell ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,STPhotoBrowserDelegate>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet UIButton *deleteBtn;
@property(nonatomic,strong) NSArray *images;
@property (weak, nonatomic) IBOutlet UILabel *time;

//@property(nonatomic,strong) STPhotoBrowserController *photobrowser;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *trailingConstraint;

@end
@implementation FKPictureShowCell


- (void)initSettings{
    [super initSettings];
    self.backgroundColor = [UIColor hmMainBgColor];
    self.time.textColor = [UIColor fk666Color];
    self.collectionView.backgroundColor = [UIColor whiteColor];
    [self.collectionView registerNib:[UINib nibWithNibName:@"FKImageCollecitionViewCell" bundle:nil] forCellWithReuseIdentifier:@"imageCell"];
    self.collectionView.layer.cornerRadius = 2;
    self.collectionView.layer.borderWidth = 0.5;
    self.collectionView.layer.borderColor = [UIColor hmBorderColor].CGColor;
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
}

- (void)updateWithCellItem:(FKPictureShowCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    
    if (cellItem.deleteIsHiden) {
        self.deleteBtn.hidden = YES;
    }else{
        self.deleteBtn.hidden = NO;
    }
    
    // 给images数组赋值 并刷新collectionview
    FKhwCiContentItem *item = cellItem.rawObject;
    self.time.text = item.time;
    if (item.images.count>0) {
        self.images = item.images;
    }
    self.trailingConstraint.constant = 120+(3-self.images.count)*(kImageViewHeight+10);
    [self.collectionView reloadData];
    
}


- (IBAction)ClickDeleteBtnAction:(UIButton *)sender {
    // 删除
    [self.deleagte hmTableViewCell:self sender:sender selector:@selector(ImageCellClickCancelBtnAction:) userInfo:nil];
}



#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    
    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.images.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    FKImageCollecitionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"imageCell" forIndexPath:indexPath];
    [cell updateImageWithUrl:self.images[indexPath.row]];
    return cell;
}

#pragma mark <UICollectionViewDelegate>

//
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(10, 10, 0, 10);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}
// item size
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(kImageViewHeight, kImageViewHeight);
}


-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
   
    STPhotoBrowserController *_photobrowser = [[STPhotoBrowserController alloc] init];
     _photobrowser.currentPage = indexPath.row;
    _photobrowser.isExistSaveBtn = NO;
    _photobrowser.sourceImagesContainerView = collectionView;
    _photobrowser.countImage = self.images.count;
    _photobrowser.delegate = self;
    [_photobrowser show];
    
}

//
//- (STPhotoBrowserController *)photobrowser{
//    if (!_photobrowser) {
//        _photobrowser = [[STPhotoBrowserController alloc] init];
//        _photobrowser.isExistSaveBtn = NO;
//        _photobrowser.sourceImagesContainerView = self.collectionView;
//        _photobrowser.countImage = self.images.count;
//        _photobrowser.delegate = self;
//    }
//    return _photobrowser;
//}

#pragma mark - STPhotoBrowserDelegate

- (UIImage *)photoBrowser:(STPhotoBrowserController *)browser placeholderImageForIndex:(NSInteger)index
{
    return nil;
}


- (NSURL *)photoBrowser:(STPhotoBrowserController *)browser highQualityImageURLForIndex:(NSInteger)index
{
    HMImageItem *imageItem = self.images[index];
    NSURL *url  = [NSURL URLWithString:[imageItem OriginImageUrl]];
    return url;
}

@end

@implementation FKPictureShowCellItem

- (void)initSettings{
    [super initSettings];
    self.hidenSeparator = YES;
    self.canSelect = NO;
    self.deleteIsHiden = YES;
    UIFont *font = [UIFont systemFontOfSize:12];
    self.cellHeight = kImageViewHeight+ 39 + ceil(font.lineHeight);
}



@end
