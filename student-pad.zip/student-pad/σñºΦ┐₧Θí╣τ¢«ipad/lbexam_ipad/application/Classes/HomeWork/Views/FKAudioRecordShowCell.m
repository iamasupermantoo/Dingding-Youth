//
//  FKAudioRecordShowCell.m
//  lbexam
//
//  Created by frankay on 17/2/6.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKAudioRecordShowCell.h"
#import "FKhwCiContentItem.h"
@interface FKAudioRecordShowCell ()
@property (weak, nonatomic) IBOutlet UIView *audiobackground;
@property (weak, nonatomic) IBOutlet UIImageView *audioVoice;
@property (weak, nonatomic) IBOutlet UILabel *audioTime;
@property (weak, nonatomic) IBOutlet UIButton *deleteBtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *trailingConstraint;
@property (weak, nonatomic) IBOutlet UILabel *time;

@property(nonatomic,strong) NSArray *voiceArr;
@end
@implementation FKAudioRecordShowCell

- (void)initSettings{
    [super initSettings];
    self.time.textColor = [UIColor fk666Color];
    self.audioTime.textColor = [UIColor fk666Color];
    self.audiobackground.backgroundColor = [UIColor fkColorWithString:@"a2e65b"];
    self.audiobackground.layer.cornerRadius = 2;
    self.audiobackground.layer.borderWidth = 0.5;
    self.audiobackground.layer.borderColor = [UIColor fkColorWithString:@"73d730"].CGColor;
    
    [self.audiobackground ddAddTarget:self tapAction:@selector(playOrPauseAudio:)];
    self.backgroundColor = [UIColor fkColorWithString:@"#f6f6f6"];
    
    self.layer.shadowColor = [UIColor blackColor].CGColor;
    self.layer.shadowOpacity = 1.0;
    self.layer.shadowOffset = CGSizeMake(0, 3);
    
    self.backgroundColor = [UIColor hmMainBgColor];
}


- (void)updateWithCellItem:(FKAudioRecordShowCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    if (cellItem.deleteIsHiden) {
        self.deleteBtn.hidden = YES;
    }else{
        self.deleteBtn.hidden = NO;
    }
    
    if (cellItem.isPlaying) {
        // 正在播放
        [self.audioVoice imageViewAnimationWithArray:self.voiceArr];
    }else{
        [self.audioVoice.layer removeAllAnimations];
        self.audioVoice.image = IMG_NAME(@"voice3");
    }
    
    FKhwCiContentItem *item = cellItem.rawObject;
    self.time.text = item.time;
     self.audioTime.text = [NSString stringWithFormat:@"%@\"",[@(item.audioLength) stringValue]];
    if (item.audioLength>60) {
        self.trailingConstraint.constant = 100;
    }else{
        // 最短60
      self.trailingConstraint.constant = (IPAD_SCREENWIDTH-115-60)/60.0*(60-item.audioLength)+100;
        
    }
    
}

- (void)playOrPauseAudio:(UITapGestureRecognizer *)tap{
    
    [self.deleagte hmTableViewCell:self sender:tap selector:@selector(AudioPlayorPause:) userInfo:nil];
    
}
- (IBAction)deleteBtnAction:(UIButton *)sender {
    // 删除
    [self.deleagte hmTableViewCell:self sender:sender selector:@selector(AudioClickdeleteBtnAction:) userInfo:nil];
    
}


-(NSArray *)voiceArr{
    if (!_voiceArr) {
        _voiceArr = @[IMG_NAME(@"voice1"),IMG_NAME(@"voice2"),IMG_NAME(@"voice3")];
    }
    return _voiceArr;
}
@end


@implementation FKAudioRecordShowCellItem

- (void)initSettings{
    [super initSettings];
    self.hidenSeparator = YES;
    self.canSelect = NO;
    self.deleteIsHiden = YES;
    UIFont *font = [UIFont systemFontOfSize:12];
    self.cellHeight = 64 + ceil(font.lineHeight);
}
@end
