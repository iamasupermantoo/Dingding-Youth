//
//  FKAudioRecordShowCell.h
//  lbexam
//
//  Created by frankay on 17/2/6.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"

@protocol  FKAudioRecordShowCellDelegate<NSObject>

@optional
- (void)AudioClickdeleteBtnAction:(NSDictionary *)info;
- (void)AudioPlayorPause:(NSDictionary *)info;
@end

@interface FKAudioRecordShowCell : HMTableViewCell


@end
@interface FKAudioRecordShowCellItem : HMTableViewCellItem
@property(nonatomic,assign) BOOL deleteIsHiden;
@property(nonatomic,assign) BOOL isPlaying;
@end
