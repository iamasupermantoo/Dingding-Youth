//
//  FKCheckCorrectOfTeacherCell.m
//  lbexam
//
//  Created by frankay on 17/6/13.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCheckCorrectOfTeacherCell.h"

#import "FKCorrectedItem.h"
@interface FKCheckCorrectOfTeacherCell()

@property (weak, nonatomic) IBOutlet UILabel *degree;
@property (weak, nonatomic) IBOutlet UILabel *finished;
@property (weak, nonatomic) IBOutlet UILabel *quality;
@property (weak, nonatomic) IBOutlet UILabel *comment;


@property(nonatomic,strong) NSArray *degreesArr;
@property(nonatomic,strong) NSArray *finishAtTimeArr;
@property(nonatomic,strong) NSArray *QulityArr;
@end

@implementation FKCheckCorrectOfTeacherCell



- (void)initSettings{
    [super initSettings];
    self.backgroundColor = [UIColor fkColorWithString:@"fff6df"];
    self.layer.borderWidth = 0.5;
    self.layer.borderColor = [UIColor hmBorderColor].CGColor;
    self.degreesArr = @[@"100%",@"80%",@"60%",@"40%",@"20%"];
    self.finishAtTimeArr = @[HMLocal(@"是"),HMLocal(@"否")];
    self.QulityArr = @[@"A",@"B",@"C",@"D",@"E"];
}

- (void)updateWithCellItem:(HMTableViewCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    FKCorrectedItem *item = cellItem.rawObject;
    self.degree.text = self.degreesArr[[item.degree integerValue]];
    self.finished.text = [item.finished integerValue]==0?@"是":@"否";
    self.quality.text = self.QulityArr[[item.quality integerValue]];
    self.comment.text = item.comment;

}

@end


@implementation FKCheckCorrectOfTeacherCellItem

- (void)initSettings{
    [super initSettings];
    self.separatorInset = kIpadNoGapSeperateInsets;
}

- (void)setRawObject:(id)rawObject{
    [super setRawObject:rawObject];
    FKCorrectedItem *item = rawObject;
    float maxsize = SCREENWIDTH-80;
    UIFont *font = [UIFont systemFontOfSize:15];
    CGFloat commentHeight = [item.comment HeightWithFont:font maxSize:maxsize];
    self.cellHeight = 110+commentHeight;
}

@end
