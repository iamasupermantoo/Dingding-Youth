//
//  FKHomeWorkListContentView.m
//  lbexam_ipad
//
//  Created by frankay on 17/5/28.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKHomeWorkListContentView.h"
#import "FKHomeworkListVC.h"
#import "FKTopSelectionView.h"

@interface FKHomeWorkListContentView ()<FKTopSelectionViewDelegate>
@property(nonatomic,strong) FKTopSelectionView *topView;
@end

@implementation FKHomeWorkListContentView


- (instancetype)init{
    self = [super init];
    if (self) {
        // 不能进行view的初始化 不然会跳到viewdidload
        _containerEdgeInset = UIEdgeInsetsMake(0,0, 0, 0);
        
        FKHomeworkListVC *viewcontroller1 = [[FKHomeworkListVC alloc] initWithStatus:0];
        
        FKHomeworkListVC *viewcontroller2 = [[FKHomeworkListVC alloc] initWithStatus:1];
        
        FKHomeworkListVC *viewcontroller3 = [[FKHomeworkListVC alloc] initWithStatus:2];
        
        _viewControllers = @[viewcontroller1,viewcontroller2,viewcontroller3];
        _scrollEnable = YES;
        
    }
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.topView];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(FKTopSelectionView *)topView{
    if (!_topView) {
        _topView = [[FKTopSelectionView alloc] initWithFrame:CGRectMake(0, 36, IPAD_SCREENWIDTH, 53) WithType:0];
        _topView.delegate = self;
    }
    
    return _topView;
    
}


#pragma mark - FKTopSelectionViewDelegate

- (void)fk_OneTitleTapAction{
    [self switchToIndex:0 animated:YES];

}

- (void)fk_TwoTitleTapAction{
    [self switchToIndex:1 animated:YES];
}

- (void)fk_ThreeTitleTapAction{
    [self switchToIndex:2 animated:YES];

}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
