//
//  FKHomeworkListVC.h
//  lbexam
//
//  Created by frankay on 17/2/4.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMListViewController.h"

@interface FKHomeworkListVC : HMListViewController

- (instancetype)initWithStatus:(NSInteger)status;

@end
