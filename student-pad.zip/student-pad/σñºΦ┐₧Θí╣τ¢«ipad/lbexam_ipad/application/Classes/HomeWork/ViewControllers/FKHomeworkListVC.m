//
//  FKHomeworkListVC.m
//  lbexam
//
//  Created by frankay on 17/2/4.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKHomeworkListVC.h"
#import "FKHomeworkDetailVC.h"
#import "FKCorrectDetailVC.h"

// cellItem
#import "FKHeaderView2Cell.h"
#import "FKHomeWorkListCell.h"
#import "HMPlaceholderCellItem.h"

#import "FKHomeworkListRequestTask.h"

#import "FKHomeworkListItem.h"


@interface FKHomeworkListVC ()

@property(nonatomic,assign) NSInteger status;
@end

@implementation FKHomeworkListVC

- (BOOL)hasHeadRefresh{
    return YES;
}

- (instancetype)initWithStatus:(NSInteger)status{

    self =[super init];
    if (self) {
        self.status = status;
    }
    return self;

}

- (void)viewDidLoad {
    
    self.view.frame = CGRectMake(0, 0, IPAD_SCREENWIDTH, SCREENHEIGHT-64);
    [super viewDidLoad];
    self.title = @"作业列表";
    
    self.tableView.frame = CGRectMake(0, 89, IPAD_SCREENWIDTH, SCREENHEIGHT-64-89);
    
    // Do any additional setup after loading the view.
    
    FKHomeworkListRequestTask *task = [[FKHomeworkListRequestTask alloc] init];
    task.status = self.status;
    self.listRequestTask = task;
    
}

-(UIBarButtonItem *)leftBarButtonItem{
    return nil;
}


-(void)viewWillAppear:(BOOL)animated{
    self.viewDidAppear = NO;

    [super viewWillAppear:animated];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(Class)cellItemClass{
    return [FKHomeWorkListCellItem class];
}


- (void)datasourceWillAddCellItems:(NSMutableArray<HMTableViewCellItem *> *)cellItems requestTask:(HMListRequestTask *)requestTask{
    [super datasourceWillAddCellItems:cellItems requestTask:requestTask];
    if (!requestTask.isLoadingMore && cellItems.count>0) {
        HMPlaceholderCellItem *placeholderCellItem1 = [HMPlaceholderCellItem cellItemWithCellHeight:20];
        [self.dataSource insertCellItem:placeholderCellItem1 adIndex:0];
      
    }

}

-(void)hmTableView:(UITableView *)tableView didSelectCellItem:(HMTableViewCellItem *)cellItem{
     FKHomeworkListItem *item = cellItem.rawObject;
    if (self.status==0 || self.status==1) {
        // 跳到作业详情
        self.viewDidAppear = NO;
        
        FKHomeworkDetailVC *homeworkVC = [[FKHomeworkDetailVC alloc] init];
        homeworkVC.status = self.status;
        homeworkVC.hid = item.hid;
        [self.navigationController pushViewController:homeworkVC animated:YES];
    }else if (self.status==2){
        // 批改详情
        FKCorrectDetailVC *detailVC = [[FKCorrectDetailVC alloc] init];
        detailVC.hid = item.hid;
        [self.navigationController pushViewController:detailVC animated:YES];
    }
}

-(void)emptyViewWhenTableViewEmpty{
    NSString *title;
    if (self.status==0) {
        // 待提交
        title = HMLocal(@"还没有待提交信息");
    }else if (self.status==1){
        title = HMLocal(@"还没有待批改信息");
    }else{
        title = HMLocal(@"还没有已批改信息");
    }
    [self.tableView emptyWithImage:nil title:title];
}


@end
