//
//  FKHomeworkDetailVC.m
//  lbexam
//
//  Created by frankay on 17/2/6.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKHomeworkDetailVC.h"
#import "QBImagePickerController.h"

#import "HomeWorkCommitwayView.h"
#import "FKhwAudioRecordView.h"
#import "HMDetailToolBar.h"

#import "FKHomeWorkDescCell.h"
#import "FKWrittingShowCell.h"
#import "FKAudioRecordShowCell.h"
#import "FKPictureShowCell.h"
#import "HMPlaceholderCellItem.h"

#import "HMImagePickerHandler.h"
#import "FKAudioPlayerHandle.h"
// item
#import "FKHomeworkListItem.h"
#import "FKhwCiContentItem.h"
// task
#import "FKHomeWorkCiDetailRequestTask.h"
#import "FKhwCommitRequestTask.h"
#import "FKAnswerRemoveRequestTask.h"
#import "UIImage+RerectImageSize.h"
#import "FKSeperationLine.h"
#import "UIView+Shadow.h"
#import <AVFoundation/AVFoundation.h>
@interface FKHomeworkDetailVC ()<UINavigationControllerDelegate,UIImagePickerControllerDelegate,HomeWorkCommitwayViewDelegate,HMDetailToolBarDelegate,FKWrittingShowCellDelegate,QBImagePickerControllerDelegate,FKPictureShowCellDelegate,FKAudioRecordShowCellDelegate,FKhwAudioRecordViewDelegate,FKAudioPlayerHandleDelegate>


@property(nonatomic,strong) UIView *bottomView;
@property(nonatomic,strong) HomeWorkCommitwayView *commitwayView;
@property(nonatomic,strong) HMDetailToolBar *toolBar;
@property(nonatomic,strong) UIView *wrBottomView;
@property(nonatomic,strong) FKhwAudioRecordView *recordView;
@property(nonatomic,assign) BOOL ismodify;

@property(nonatomic,strong) FKHomeWorkCiDetailRequestTask *ciAnswerTask;
@property(nonatomic,strong) FKhwCommitRequestTask *commitTask;
@property(nonatomic,strong) FKAnswerRemoveRequestTask *removeTask;

@property(nonatomic,strong) NSMutableArray *answers;


@property(nonatomic,strong) FKAudioRecordShowCellItem *prePlayingCellItem;

@property(nonatomic,strong) FKAudioPlayerHandle *audioPlayer;

@property(nonatomic,strong) FKHomeworkListItem *descItem;

@end

@implementation FKHomeworkDetailVC


- (BOOL)hasLoadMore{
    return NO;
}

- (FKAudioPlayerHandle *)audioPlayer{
    if (!_audioPlayer) {
        _audioPlayer = [[FKAudioPlayerHandle alloc] init];
        _audioPlayer.delegate = self;
    }
    
    return _audioPlayer;
}
- (void)viewDidLoad {

    [super viewDidLoad];
    self.title = @"作业详情";
    
    self.tableView.separatorColor = [UIColor clearColor];
    if (self.status==2) {
        // 已评分
        self.tableView.frame = CGRectMake(0, 0, SCREENWIDTH, SCREENHEIGHT-64);
        
    }else{
        self.tableView.frame = CGRectMake(0, 0, SCREENWIDTH, SCREENHEIGHT-64-82);
        [self.view addSubview:self.bottomView];
    }
    
    // 获取数据
//    [DDProgressHUD showHUDWithStatus:@"加载中..."];
    [self.ciAnswerTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (error == nil) {
//            [DDProgressHUD dismiss];
            
            HMPlaceholderCellItem *placeCellItem = [HMPlaceholderCellItem cellItemWithCellHeight:36];
            [self.dataSource insertCellItem:placeCellItem adIndex:0];
            
            // 成功
            self.answers = [NSMutableArray array];
            NSArray *arr = response[@"data"][@"answers"];
            if (arr.count>0) {
                [arr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    // 提交的作业内容model
                    FKhwCiContentItem *contentItem = [FKhwCiContentItem yy_modelWithDictionary:obj];
                    
                    if (contentItem.type == 0) {
                        //文字
                        FKWrittingShowCellItem *writting = [[FKWrittingShowCellItem alloc] init];
                        writting.rawObject = contentItem;
                        [self.answers addObject:writting];
                    }else if(contentItem.type==1){
                        // 图片
                        FKPictureShowCellItem *picture = [[FKPictureShowCellItem alloc] init];
                        picture.rawObject = contentItem;
                        [self.answers addObject:picture];
                        
                    }else{
                        // 录音
                        FKAudioRecordShowCellItem *audioRecord = [[FKAudioRecordShowCellItem alloc] init];
                        audioRecord.isPlaying = NO;
                        audioRecord.rawObject = contentItem;
                        [self.answers addObject:audioRecord];
                    }
//                    [self.answers addObject:contentItem];
                    
                }];
                
                [self.dataSource addCellItems:self.answers];
            }
            
            // 作业描述
            FKHomeworkListItem *descItem = [FKHomeworkListItem yy_modelWithDictionary:response[@"data"][@"details"]];
            self.descItem = descItem;
            FKHomeWorkDescCellItem *descCellItem = [[FKHomeWorkDescCellItem alloc] init];
            descCellItem.rawObject = descItem;
            
            
            [self.dataSource insertCellItem:descCellItem adIndex:1];
            
            HMPlaceholderCellItem *placeCellItem1 = [HMPlaceholderCellItem placeholderCellItem];
            [self.dataSource insertCellItem:placeCellItem1 adIndex:2];
        }
        
        [self.tableView reloadData];
        
        
    }];
    
    // 监听键盘
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChangeFrameNotification:) name:UIKeyboardWillChangeFrameNotification object:nil];
}


-(void)viewWillAppear:(BOOL)animated{

    [super viewWillAppear:animated];
    
    
    
}


- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    if (self.audioPlayer) {
        [self.audioPlayer fk_close];
        self.audioPlayer = nil;
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    
}


- (NSString *)rightBarButtonItemTitle{
    if (self.status==2) {
        // 已评分  右边按钮不显示
        return nil;
    }
    self.ismodify = YES;
    return @"修改";
}

-(void)rightButtonAction:(id)sender{
    UIButton *titleBtn = sender;
    if (self.ismodify) {
        // 按钮是修改字样变成完成
        [titleBtn setTitle:@"完成" forState:UIControlStateNormal];
        self.ismodify = NO;
        for (id cellItem in self.dataSource.cellItems) {
            if ([cellItem isKindOfClass:[FKWrittingShowCellItem class]]) {
                FKWrittingShowCellItem *showCellItem = (FKWrittingShowCellItem *)cellItem;
                showCellItem.deleteIsHiden = NO;
            }
            
            if ([cellItem isKindOfClass:[FKPictureShowCellItem class]]) {
                FKPictureShowCellItem *picCellItem = (FKPictureShowCellItem *)cellItem;
                picCellItem.deleteIsHiden = NO;
            }
            if ([cellItem isKindOfClass:[FKAudioRecordShowCellItem class]]) {
                FKAudioRecordShowCellItem *picCellItem = (FKAudioRecordShowCellItem *)cellItem;
                picCellItem.deleteIsHiden = NO;
            }
        }
        
    }else{
        [titleBtn setTitle:@"修改" forState:UIControlStateNormal];
        self.ismodify = YES;
        for (id cellItem in self.dataSource.cellItems) {
            if ([cellItem isKindOfClass:[FKWrittingShowCellItem class]]) {
                FKWrittingShowCellItem *showCellItem = (FKWrittingShowCellItem *)cellItem;
                showCellItem.deleteIsHiden = YES;
            }
            
            if ([cellItem isKindOfClass:[FKPictureShowCellItem class]]) {
                FKPictureShowCellItem *picCellItem = (FKPictureShowCellItem *)cellItem;
                picCellItem.deleteIsHiden = YES;
            }
            if ([cellItem isKindOfClass:[FKAudioRecordShowCellItem class]]) {
                FKAudioRecordShowCellItem *picCellItem = (FKAudioRecordShowCellItem *)cellItem;
                picCellItem.deleteIsHiden = YES;
            }
        }
    }
    
    [self.tableView reloadData];
}

#pragma mark setter

- (UIView *)bottomView{
    if (!_bottomView) {
        
        _bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREENHEIGHT-64-82, SCREENWIDTH, 82)];
        _bottomView.backgroundColor = [UIColor whiteColor];
        UIButton *bottomBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        bottomBtn.frame = CGRectMake(150, 16, SCREENWIDTH-300, 50);
        [_bottomView addSubview:bottomBtn];
        bottomBtn.titleLabel.font = [UIFont systemFontOfSize:15];
        [bottomBtn setTitle:@"作业上传" forState:UIControlStateNormal];
        [bottomBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [bottomBtn setBackgroundImage:IMG_NAME(@"Sign-in_Sign_normal") forState:UIControlStateNormal];
        
        [bottomBtn ddAddTarget:self tapAction:@selector(commitHomework:)];
        
        // 加分割线
        UIView *sepLine = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREENWIDTH, 0.5)];
        sepLine.backgroundColor = [UIColor hmBorderColor];
        
        [_bottomView addSubview:sepLine];
    }
    return _bottomView;
}

- (HomeWorkCommitwayView *)commitwayView{
    if (!_commitwayView) {
        _commitwayView = [[HomeWorkCommitwayView alloc] initWithFrame:CGRectMake(0, SCREENHEIGHT-(360/4.0+40-35+94)-64, SCREENWIDTH, 360/4.0-35+40+94)];
        _commitwayView.delegate = self;
    }
    return _commitwayView;
}


-(UIView *)wrBottomView{
    if (!_wrBottomView) {
        _wrBottomView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREENHEIGHT-93-64, SCREENWIDTH, 93)];
        _wrBottomView.backgroundColor = [UIColor whiteColor];
        
        self.toolBar = [[HMDetailToolBar alloc] initWithFrame:CGRectMake(0, 0, SCREENWIDTH, 49) with:YES withReturnType:UIReturnKeyDefault];
        self.toolBar.deleagte = self;
        self.toolBar.growTextView.placeholder = @"请输入作业文字内容";
        [_wrBottomView addSubview:self.toolBar];
        
        UIButton *cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        cancelBtn.frame = CGRectMake(0, 49, SCREENWIDTH, 44);
        cancelBtn.backgroundColor = [UIColor fkcccColor];
        cancelBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        [cancelBtn setTitle:@"取消" forState:UIControlStateNormal];
        [cancelBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [cancelBtn addTarget:self action:@selector(writtingCancelBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [_wrBottomView addSubview:cancelBtn];
        self.tableView.ddHeight = _wrBottomView.ddTop;
    }
    return _wrBottomView;

}

- (FKhwAudioRecordView *)recordView{
    if (!_recordView) {
        _recordView = [[FKhwAudioRecordView alloc] initWithFrame:CGRectMake(0, SCREENHEIGHT-184-64, SCREENWIDTH, 184)];
        _recordView.delegate = self;
    }
    return _recordView;

}

- (FKHomeWorkCiDetailRequestTask *)ciAnswerTask{
    if (!_ciAnswerTask) {
        _ciAnswerTask = [[FKHomeWorkCiDetailRequestTask alloc] init];
        _ciAnswerTask.hid = self.hid;
        _ciAnswerTask.lid = self.lid;
        _ciAnswerTask.cid = self.cid;
    }
    return _ciAnswerTask;

}

- (FKhwCommitRequestTask *)commitTask{
    if (!_commitTask) {
        _commitTask = [[FKhwCommitRequestTask alloc] init];
        _commitTask.hid = self.descItem.hid;
        
    }
    return _commitTask;
}

- (FKAnswerRemoveRequestTask *)removeTask{
    if (!_removeTask) {
        _removeTask = [[FKAnswerRemoveRequestTask alloc] init];
        _removeTask.hid = self.descItem.hid;
    }
    return _removeTask;

}


// 输入文字的取消按钮事件
- (void)writtingCancelBtnAction:(id)sender{
    if (_wrBottomView) {
        [_wrBottomView removeFromSuperview];
        _wrBottomView = nil;
    }
}

- (void)commitHomework:(UIGestureRecognizer *)tap{
    // 作业上传
    if (!_commitwayView) {
        [self.view addSubview:self.commitwayView];
    }
}


#pragma mark - Notification

- (void)keyboardWillChangeFrameNotification:(NSNotification *)notification{
    CGRect keyboardRect = [notification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGFloat keyboardAnimationDuration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] floatValue];
    CGFloat keyboardY = CGRectGetMinY(keyboardRect);
    [UIView animateWithDuration:keyboardAnimationDuration
                          delay:0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
                         self.wrBottomView.ddBottom = keyboardY-64;
                         self.tableView.ddHeight = self.wrBottomView.ddTop;
                     } completion:^(BOOL finished) {
                     }];
}

#pragma mark - HMDetailToolBarDelegate
- (void)hmDetailToolBarDelegateSendCommentWithText:(NSString *)text{
    // 发送内容
}

-(void)fkDetailToolBarDelegateSendBtnActionWithText:(NSString *)text{
    // 发送内容
    [self.toolBar resignTextViewFirstResponder];
    if (text.length<=0) {
        return;
    }
    self.commitTask.images = nil;
    self.commitTask.audio = nil;
    self.commitTask.type = 0;
    self.commitTask.text = text;
    [self.commitTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            // 发送成功
            self.toolBar.growTextView.text = @"";
            FKhwCiContentItem *item = [FKhwCiContentItem yy_modelWithDictionary:response[@"data"][@"answer"]];
            FKWrittingShowCellItem *cellItem = [[FKWrittingShowCellItem alloc] init];
            cellItem.rawObject = item;
           
            if (!self.ismodify){
                cellItem.deleteIsHiden = NO;
            }
            [self.dataSource insertCellItem:cellItem adIndex:2];
            [self.tableView reloadData];
        }
        
    }];
    
}

#pragma mark - deleteBtn Action

- (void)ClickCancelBtnAction:(NSDictionary *)info{
    
    FKWrittingShowCellItem *cellItem = info[HMTableViewCell_Action_Key_CellItem];
    [self deleteAnAnswerWithCellItem:cellItem withRawObject:cellItem.rawObject];
  
}


- (void)ImageCellClickCancelBtnAction:(NSDictionary *)info{
    FKPictureShowCellItem *cellItem = info[HMTableViewCell_Action_Key_CellItem];
    [self deleteAnAnswerWithCellItem:cellItem withRawObject:cellItem.rawObject];
    
}

- (void)AudioClickdeleteBtnAction:(NSDictionary *)info{
    FKAudioRecordShowCellItem *cellItem = info[HMTableViewCell_Action_Key_CellItem];
     [self deleteAnAnswerWithCellItem:cellItem withRawObject:cellItem.rawObject];
}

// 播放某一cell 上面的语音
- (void)AudioPlayorPause:(NSDictionary *)info{
    // 如果上一条在播放 则停止上一条的播放 播放目前的这一条
    // 如果上一条和本条相同 且上一条的isplaying= yes 则暂停播放 如上一条为no 则开始重新播放
    FKAudioRecordShowCellItem *cellItem = info[HMTableViewCell_Action_Key_CellItem];
    FKhwCiContentItem *item = cellItem.rawObject;
    // 对播放后的url 做个缓存

    // 如果上一条和这一条是同一条语音
    if ([self.prePlayingCellItem isEqual:cellItem]) {
        if (self.prePlayingCellItem.isPlaying) {
            // 当前语音正在播放 则stop
            [self.audioPlayer fk_pause];
            self.audioPlayer = nil;
            cellItem.isPlaying = NO;
            
        }else{
            // 当前语音未播放 则重新play
            [self.audioPlayer createStreamWithUrl:item.audio];
            cellItem.isPlaying = YES;
        }
        
        [self.tableView reloadData];
        
        
    }else{
        self.prePlayingCellItem.isPlaying = NO;
        cellItem.isPlaying = YES;
        [self.audioPlayer createStreamWithUrl:item.audio];
        [self.tableView reloadData];
    }
    self.prePlayingCellItem = cellItem;
    
}

#pragma mark - FKAudioPlayerHandleDelegate

- (void)streamerWithStatus:(DOUAudioStreamerStatus)status{
    if (status == DOUAudioStreamerFinished) {
        // 完成
        self.prePlayingCellItem.isPlaying = NO;
        [self.audioPlayer fk_close];
        [self.tableView reloadData];
    }
    
}

#pragma mark - HomeWorkCommitwayViewDelegate

// 文字输入
- (void)HomeWorkWrittingBtnAction:(NSDictionary *)info{
    // 取消wayview
    [self HomeWorkCancelBtnAction:nil];
    [self.view addSubview:self.wrBottomView];
    
}

// 录制语音
- (void)HomeWorkAudioRecodeBtnAction:(NSDictionary *)info{
    [self HomeWorkCancelBtnAction:nil];
    [self.view addSubview:self.recordView];

}

// 相册
- (void)HomeWorkPhotoBtnAction:(NSDictionary *)info{
    
    [self HomeWorkCancelBtnAction:nil];

    QBImagePickerController *imagePicker1 = [[QBImagePickerController alloc] init];
    imagePicker1.mediaType = QBImagePickerMediaTypeImage;
    imagePicker1.allowsMultipleSelection = YES;
    imagePicker1.maximumNumberOfSelection = 3;
    imagePicker1.showsNumberOfSelectedAssets = YES;
    imagePicker1.delegate = self;
    [self presentViewController:imagePicker1 animated:YES completion:nil];
    
}

// 相机
- (void)HomeWorkCameraBtnAction:(NSDictionary *)info{
    [self HomeWorkCancelBtnAction:nil];

    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.allowsEditing = YES;
    
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:imagePicker animated:YES completion:^{}];
   
}


-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    // 成功了
    UIImage *image = info[UIImagePickerControllerEditedImage];
    
    if (image.size.width!=image.size.height) {
        image = [UIImage squareImageFromImage:image scaledToSize:image.size.width];
    }
    
    
    self.commitTask.text = nil;
    self.commitTask.audio = nil;
    self.commitTask.type = 1;
    self.commitTask.images = @[image];
    [self uploadPicture];

}

// 取消
- (void)HomeWorkCancelBtnAction:(id)sender{
    if (_commitwayView) {
        [self.commitwayView removeFromSuperview];
        self.commitwayView = nil;
    }
}


#pragma mark - FKhwAudioRecordViewDelegate
-(void)recordCancelAction:(id)sender{
    [self.recordView removeFromSuperview];
    self.recordView = nil;
}


-(void)endRecord2Commit:(NSData *)data{
    self.commitTask.audio = data;
    self.commitTask.type = 2;
    [DDProgressHUD showHUDWithStatus:@"正在上传语音作业..."];
    
    [self.commitTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        
        if (!error) {
            [DDProgressHUD showSucessWithStatus:@"提交语音作业成功!"];
            // 提交成功
            FKAudioRecordShowCellItem *cellItem = [[FKAudioRecordShowCellItem alloc] init];
            FKhwCiContentItem *item = [FKhwCiContentItem yy_modelWithDictionary:response[@"data"][@"answer"]];
            cellItem.rawObject = item;
            if (!self.ismodify){
                cellItem.deleteIsHiden = NO;
            }
            [self.dataSource insertCellItem:cellItem adIndex:2];
            [self.tableView reloadData];
        }
        
    }];
}
#pragma mark - QBImagePickerControllerDelegate
- (void)qb_imagePickerController:(QBImagePickerController *)imagePickerController didFinishPickingAssets:(NSArray *)assets{
    // 完成选择
    [imagePickerController dismissViewControllerAnimated:YES completion:nil];
    
    self.commitTask.text = nil;
    self.commitTask.audio = nil;
    self.commitTask.type = 1;
    NSMutableArray *arr = [NSMutableArray array];
    [assets enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        PHImageManager *manager = [PHImageManager defaultManager];
        PHImageRequestOptions *options = [[PHImageRequestOptions alloc] init];
        options.synchronous = YES;
       [manager requestImageForAsset:obj targetSize:CGSizeMake(SCREENWIDTH-10, SCREENWIDTH-10) contentMode:PHImageContentModeDefault options:options resultHandler:^(UIImage * _Nullable result, NSDictionary * _Nullable info) {
         
           [arr addObject:result];
       }];
        
    }];
    
    self.commitTask.images = arr;
    [self uploadPicture];
    
}
- (void)qb_imagePickerControllerDidCancel:(QBImagePickerController *)imagePickerController{
    // 取消
    [imagePickerController dismissViewControllerAnimated:YES completion:nil];
    
}

- (BOOL)qb_imagePickerController:(QBImagePickerController *)imagePickerController shouldSelectAsset:(PHAsset *)asset{
    // 将要选择一个asset的时候 用来提醒选择不能超过三个
    if (imagePickerController.selectedAssets.count>=3) {
        [DDProgressHUD showWithStatus:@"选择de图片不能超过三张!"];
        return NO;
    }
    return YES;
}


#pragma mark - upload picture
- (void)uploadPicture{
    [DDProgressHUD showHUDWithStatus:@"正在上传图片作业..."];
    [self.commitTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            [DDProgressHUD showSucessWithStatus:@"上传成功！"];
            FKhwCiContentItem *item = [FKhwCiContentItem yy_modelWithDictionary:response[@"data"][@"answer"]];
            FKPictureShowCellItem *cellItem = [[FKPictureShowCellItem alloc] init];
            cellItem.rawObject = item;
            if (!self.ismodify){
                cellItem.deleteIsHiden = NO;
            }
            [self.dataSource insertCellItem:cellItem adIndex:2];
            [self.tableView reloadData];
            
        }else{
            [DDProgressHUD dismiss];
        }
    }];
}


#pragma mark - delete a answer
- (void)deleteAnAnswerWithCellItem:(id)cellItem withRawObject:(id)rawObject{
    
    FKhwCiContentItem *item = rawObject;
    self.removeTask.aid = item.aid;
    [self.removeTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            [DDProgressHUD showSucessWithStatus:@"移除成功！"];
            [self.dataSource removeCellItem:cellItem];
            [self.tableView reloadData];
        }
    }];
    
}


@end
