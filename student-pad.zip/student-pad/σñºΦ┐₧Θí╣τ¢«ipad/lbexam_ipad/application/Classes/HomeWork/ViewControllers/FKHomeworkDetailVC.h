//
//  FKHomeworkDetailVC.h
//  lbexam
//
//  Created by frankay on 17/2/6.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMListViewController.h"

@interface FKHomeworkDetailVC : HMListViewController
@property(nonatomic,strong) NSString *hid;
@property(nonatomic,assign) NSInteger status;

@property(nonatomic,strong) NSString *cid;
@property(nonatomic,strong) NSString *lid;
@end
