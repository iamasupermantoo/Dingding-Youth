//
//  FKhwCiContentItem.h
//  lbexam
//
//  Created by frankay on 17/2/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseItem.h"

@interface FKhwCiContentItem : HMBaseItem
@property(nonatomic,strong) NSString *aid;
@property(nonatomic,assign) NSInteger type; // 作业类型 0 文字 1 图片 2 录音

@property(nonatomic,strong) NSString *time; // 时间

// 文字
@property(nonatomic,strong) NSString *text;

// 录音

@property(nonatomic,strong) NSString *audio; // audio url
@property(nonatomic,assign) NSInteger audioLength; // 录音时长

// 图片
@property(nonatomic,strong) NSArray *images;


@end
