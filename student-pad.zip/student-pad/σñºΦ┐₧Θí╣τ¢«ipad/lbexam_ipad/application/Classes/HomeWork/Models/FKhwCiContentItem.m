//
//  FKhwCiContentItem.m
//  lbexam
//
//  Created by frankay on 17/2/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKhwCiContentItem.h"
#import "HMImageItem.h"
@implementation FKhwCiContentItem

+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"images" : [HMImageItem class],
             };
}

+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{
             @"aid":@"id"
             };
}
@end
