//
//  FKCorrectedItem.h
//  lbexam_teacher
//
//  Created by frankay on 17/6/9.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseItem.h"

@interface FKCorrectedItem : HMBaseItem
@property(nonatomic,strong) NSString *degree;
@property(nonatomic,strong) NSString *finished;
@property(nonatomic,strong) NSString *quality;
@property(nonatomic,strong) NSString *comment;
@property(nonatomic,strong) NSString *teacher;
@property(nonatomic,strong) NSString *correctedTime;


@end
