//
//  FKCorrectedItem.m
//  lbexam_teacher
//
//  Created by frankay on 17/6/9.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCorrectedItem.h"

@implementation FKCorrectedItem

+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"correctedTime":@"date",@"degree":@"complete",@"finished":@"intime",@"comment":@"remark"};
}

@end
