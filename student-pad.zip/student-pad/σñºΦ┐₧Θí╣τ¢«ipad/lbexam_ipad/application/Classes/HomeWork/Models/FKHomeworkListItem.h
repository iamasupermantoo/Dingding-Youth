//
//  FKHomeworkListItem.h
//  lbexam
//
//  Created by frankay on 17/2/4.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseItem.h"

@interface FKHomeworkListItem : HMBaseItem
@property(nonatomic,strong) NSString *hid;
@property(nonatomic,strong) NSString *lesson;
@property(nonatomic,strong) NSString *course;
@property(nonatomic,strong) NSString *teacher;
@property(nonatomic,strong) NSString *title;
@property(nonatomic,assign) NSInteger status;
@property(nonatomic,strong) NSString *time;
@property(nonatomic,strong) NSString *date;
@property(nonatomic,strong) NSString *label;

@property(nonatomic,strong) NSString *content; // 作业题目的描述
@end
