//
//  FKHomeWorkCiDetailRequestTask.m
//  lbexam
//
//  Created by frankay on 17/2/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKHomeWorkCiDetailRequestTask.h"

@implementation FKHomeWorkCiDetailRequestTask
- (NSString *)apiName{
    return @"homework/details";
}



- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    if (self.hid && ![self.hid ddIsEmpty]) {
         [self.parameterDictionary setObject:self.hid forKey:@"hid"];
    }else{
        if (self.cid && ![self.cid ddIsEmpty]) {
            [self.parameterDictionary setObject:self.cid forKey:@"cid"];
        }
        
        if (self.lid && ![self.lid ddIsEmpty]) {
            [self.parameterDictionary setObject:self.lid forKey:@"lid"];
        }
    }
    
  
}

@end
