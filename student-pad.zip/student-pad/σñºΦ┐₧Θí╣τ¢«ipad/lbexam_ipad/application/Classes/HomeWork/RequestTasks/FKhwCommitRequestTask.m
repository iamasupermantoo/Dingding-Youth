//
//  FKhwCommitRequestTask.m
//  lbexam
//
//  Created by frankay on 17/2/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKhwCommitRequestTask.h"

@implementation FKhwCommitRequestTask

+ (BOOL)needLogin{
    return YES;
}

- (NSString *)apiName{
    return @"/homework/answer/commit";
}


- (WSHTTPMethod)requestMethod{
    return WSHTTPMethodMultipart;
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.hid && [self.hid ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"hid"];
    }
   
    return nil;
}


- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:self.hid forKey:@"hid"];
    [self.parameterDictionary setObject:@(self.type) forKey:@"type"];
    if (self.text && ![self.text ddIsEmpty]) {
        [self.parameterDictionary setObject:self.text forKey:@"text"];
    }
    
    
}

- (WSConstructingBlock)constructingBodyBlock{
//    if (self.images.count<=0) {
//        return nil;
//    }
    
    if (self.type==1) {
        return ^(id<AFMultipartFormData> formData) {
            
            for (int i=0; i<self.images.count; i++) {
                [formData appendPartWithFileData:UIImageJPEGRepresentation(self.images[i], 0.9) name:@"images[]" fileName:[NSString stringWithFormat:@"image%d.jpg",i]  mimeType:@"image/jpeg/png/jpg"];
            }
            
            //        [self.images enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            //
            //
            //        }];
            
        };
    }
    
    if (self.type == 2) {
        return ^(id<AFMultipartFormData> formData) {
            [formData appendPartWithFileData:self.audio name:@"audio" fileName:@"record.mp3" mimeType:@"audio/mp3"];
        };
    }
    
    return nil;
}


@end
