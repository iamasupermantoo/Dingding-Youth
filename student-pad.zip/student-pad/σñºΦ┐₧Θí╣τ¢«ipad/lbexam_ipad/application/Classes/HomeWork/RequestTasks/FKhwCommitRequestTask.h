//
//  FKhwCommitRequestTask.h
//  lbexam
//
//  Created by frankay on 17/2/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface FKhwCommitRequestTask : HMBaseRequestTask

@property(nonatomic,strong) NSString *hid;
@property(nonatomic,assign) NSInteger type;
@property(nonatomic,strong) NSString *text;


// 图片
@property(nonatomic,strong) NSArray *images;

// 文件
@property(nonatomic,strong) NSData *audio;
@end
