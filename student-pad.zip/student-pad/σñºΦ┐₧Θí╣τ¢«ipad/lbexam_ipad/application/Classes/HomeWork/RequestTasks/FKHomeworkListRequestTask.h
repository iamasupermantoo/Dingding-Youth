//
//  FKHomeworkListRequestTask.h
//  lbexam
//
//  Created by frankay on 17/2/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMListRequestTask.h"


@interface FKHomeworkListRequestTask : HMListRequestTask

@property(nonatomic,assign) NSInteger status;

@end
