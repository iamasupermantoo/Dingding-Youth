//
//  FKAnswerRemoveRequestTask.m
//  lbexam
//
//  Created by frankay on 17/2/8.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKAnswerRemoveRequestTask.h"

@implementation FKAnswerRemoveRequestTask

- (NSString *)apiName{
    return @"homework/answer/remove";
}

- (WSHTTPMethod)requestMethod{
    return WSHTTPMethodPOST;
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.aid && [self.aid ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"aid"];
    }
    if (!self.hid && [self.hid ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"hid"];
    }
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:self.aid forKey:@"aid"];
    [self.parameterDictionary setObject:self.hid forKey:@"hid"];
}

@end
