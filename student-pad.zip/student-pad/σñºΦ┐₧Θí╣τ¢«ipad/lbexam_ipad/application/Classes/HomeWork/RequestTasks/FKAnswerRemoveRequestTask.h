//
//  FKAnswerRemoveRequestTask.h
//  lbexam
//
//  Created by frankay on 17/2/8.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface FKAnswerRemoveRequestTask : HMBaseRequestTask
@property(nonatomic,strong) NSString *aid;
@property(nonatomic,strong) NSString *hid;
@end
