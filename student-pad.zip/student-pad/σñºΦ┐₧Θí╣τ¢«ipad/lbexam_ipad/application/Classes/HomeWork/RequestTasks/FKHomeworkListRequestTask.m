//
//  FKHomworkListRequestTask.m
//  lbexam
//
//  Created by frankay on 17/2/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKHomeworkListRequestTask.h"
#import "FKHomeworkListItem.h"
@implementation FKHomeworkListRequestTask

+ (BOOL)needLogin{
    return YES;
}


- (instancetype)init{
    self = [super init];
    if (self) {
        self.resultItemsKeyword = @"homeworks";
    }
    return self;
}

- (Class)itemClass{
    
    return [FKHomeworkListItem class];
}

- (NSString *)apiName{
    return @"/homework/list";
}

- (void)requestParameterConfiguration{
    
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:@(self.status) forKey:@"status"];

}

@end
