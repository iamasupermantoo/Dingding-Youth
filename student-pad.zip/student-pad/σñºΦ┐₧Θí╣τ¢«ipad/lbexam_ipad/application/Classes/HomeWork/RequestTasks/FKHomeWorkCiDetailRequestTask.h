//
//  FKHomeWorkCiDetailRequestTask.h
//  lbexam
//
//  Created by frankay on 17/2/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface FKHomeWorkCiDetailRequestTask : HMBaseRequestTask

@property(nonatomic,strong) NSString *hid;
@property(nonatomic,strong) NSString *lid;
@property(nonatomic,strong) NSString *cid;
@end
