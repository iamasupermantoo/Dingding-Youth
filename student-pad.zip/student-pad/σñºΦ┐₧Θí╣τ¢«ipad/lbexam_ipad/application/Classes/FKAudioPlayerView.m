//
//  FKAudioPlayerView.m
//  lbexam_ipad
//
//  Created by frankay on 17/2/20.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKAudioPlayerView.h"
#import "FKAudioPlayerHandle.h"
#import "FKValueTrackingSlider.h"
@interface FKAudioPlayerView ()<FKAudioPlayerHandleDelegate>
@property (weak, nonatomic) IBOutlet UILabel *leftTime;
@property (weak, nonatomic) IBOutlet FKValueTrackingSlider *slide;
@property (strong, nonatomic) IBOutlet UIView *contentView;

@property(nonatomic,strong) FKAudioPlayerHandle *playerHandle;

@end
@implementation FKAudioPlayerView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [[NSBundle mainBundle] loadNibNamed:@"FKAudioPlayerView" owner:self options:nil];
        self.contentView.frame = self.bounds;
        self.contentView.backgroundColor = [UIColor clearColor];
        [self addSubview:self.contentView];
        [self initSetting];
    }
    return self;
}


- (void)initSetting{
    
    _slide.value = 0;
    _slide.minimumTrackTintColor = [UIColor hmTextBlueColor];
    _slide.maximumTrackTintColor = [UIColor hmTextBlackColor];
    [_slide setThumbImage:IMG_NAME(@"slide") forState:UIControlStateNormal];
    _slide.userInteractionEnabled = NO;
    self.playerHandle = [[FKAudioPlayerHandle alloc] init];
    self.playerHandle.delegate = self;
    self.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.5];
    [self addNotifications];
}

- (void)createPlayerWithUrl:(NSString *)url{
    [self.playerHandle createStreamWithUrl:url];
}

- (void)play{
    // 定时器开启
    [self.playerHandle fk_play];
}

-(void)changeSlideValueWith:(CGFloat)value{
    [self.playerHandle fk_chageSlideToValue:value];
    
}

- (void)pause{
     // 定时器暂时关闭
    [self.playerHandle fk_pause];
}

- (void)close{
    
    [self.playerHandle fk_close];
     self.playerHandle = nil;
    
}

- (void)updateSlideValue:(CGFloat)value andTime:(NSString *)leftTime{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.slide setValue:value animated:YES];
        self.leftTime.text = leftTime;
    });
  
}


//- (IBAction)zanting:(id)sender {
//    [self pause];
//}
//
//- (IBAction)bofang:(id)sender {
//    [self play];
//}
//
//
//- (IBAction)chage:(ASValueTrackingSlider *)sender {
//    [self changeSlideValueWith:sender.value];
//}

- (void)addNotifications
{
    // app退到后台
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidEnterBackground) name:UIApplicationWillResignActiveNotification object:nil];
    
    // app进入前台
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidEnterPlayground) name:UIApplicationDidBecomeActiveNotification object:nil];
}

// 进入前台
- (void)appDidEnterPlayground{
    [self play];
}


// 进入后台
- (void)appDidEnterBackground{
   
     [self pause];
}

- (void)streamerWithStatus:(DOUAudioStreamerStatus)status{
    // 接收流的状态
}

-(void)dealloc{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
