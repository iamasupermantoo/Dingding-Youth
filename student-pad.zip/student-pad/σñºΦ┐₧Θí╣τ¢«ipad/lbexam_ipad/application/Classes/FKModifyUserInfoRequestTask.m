//
//  FKModifyUserInfoRequestTask.m
//  lbexam
//
//  Created by frankay on 17/2/25.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKModifyUserInfoRequestTask.h"

@implementation FKModifyUserInfoRequestTask

+ (BOOL)needLogin{
    return YES;
}

- (NSString *)apiName{
    return @"/mine/update";
}

-(WSHTTPMethod)requestMethod{
    return WSHTTPMethodPOST;
}

-(NSError *)responseHanlderWithDataInfo:(NSDictionary *)info{
    
    
    if (info[@"info"]) {
        
        [HMUserHandler sharedInstance].userItem = [HMUserItem itemWithDictionary:info[@"info"]];
        [[HMUserHandler sharedInstance] saveToLocal];
    }
    return [super responseHanlderWithDataInfo:info];
//    if (self.name && [self.name ddIsEmpty]) {
//        
//    }
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    
    [self.parameterDictionary setObject:self.name forKey:@"name"];
    [self.parameterDictionary setObject:self.grade forKey:@"grade"];
    [self.parameterDictionary setObject:self.province forKey:@"province"];
    [self.parameterDictionary setObject:self.region forKey:@"region"];
    
    if (self.signature && ![self.signature ddIsEmpty]) {
            [self.parameterDictionary setObject:self.signature forKey:@"signature"];
    }

    [self.parameterDictionary setObject:self.headImg forKey:@"headImg"];
    [self.parameterDictionary setObject:@(self.gender) forKey:@"gender"];
}

@end
