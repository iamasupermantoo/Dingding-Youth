//
//  FKCourseLessonItem.h
//  lbexam
//
//  Created by frankay on 17/1/16.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseItem.h"

@interface FKCourseLessonItem : HMBaseItem

@property(nonatomic,strong) NSString *lid;   // lession id
@property(nonatomic,strong) NSString *cid;   // 课程id
@property(nonatomic,strong) NSString *label; // lesson label
@property(nonatomic,assign) NSInteger status; // 0 待上课  1 已上课
@property(nonatomic,strong) NSString *date;   // 日期2017-01-19
@property(nonatomic,strong) NSString *time;  // 时间 19：00 - 23：00

@property(nonatomic,assign) NSInteger homeworkStatus; // 作业状态0待提交 1 待评价 2 已评价
@property(nonatomic,assign) NSInteger studentReactionStatus; // 学生评价的状态 0 待评价 1 已评价
@property(nonatomic,assign) NSInteger teacherReactionStatus; // 老师反馈的状态 0 待反馈 1 已反馈

@property(nonatomic,strong) NSString *videoUrl;
@end
