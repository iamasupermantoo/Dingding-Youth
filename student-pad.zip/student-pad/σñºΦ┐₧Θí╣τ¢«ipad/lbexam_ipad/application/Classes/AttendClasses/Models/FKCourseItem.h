//
//  FKCourseItem.h
//  lbexam
//
//  Created by frankay on 17/1/16.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseItem.h"
#import "HMImageItem.h"
@interface FKCourseItem : HMBaseItem

@property(nonatomic,strong) NSString *cid;      // 课程id
@property(nonatomic,strong) NSString *cmId;
@property(nonatomic,strong) HMImageItem *imageItem;
@property(nonatomic,strong) NSString *name;     // 课程名
@property(nonatomic,strong) NSString *totalCnt; // 总课次
@property(nonatomic,strong) NSString *teacher; // 课程教师
@property(nonatomic,assign) NSInteger level;   // 教师本课程的级别
@property(nonatomic,strong) NSString *desc;     // 课程描述
@property(nonatomic,strong) NSString *price;    // 课程定价
@property(nonatomic,strong) NSString *cnt;      // 第几课时
@property(nonatomic,strong) NSString *time;     // 时间
@property(nonatomic,strong) NSString *course;   // 课程名后台又起个不怪我
@property(nonatomic,strong) NSString *lid;
@property(nonatomic,assign) BOOL issingleLine; // 单行

@property(nonatomic,strong) NSString *date;

@property(nonatomic,assign) NSInteger status;// 0 待上课 1正在上课 2完成上课 3 失败 4 added 刚刚添加还未安排时间

@end
