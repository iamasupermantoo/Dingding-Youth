//
//  FKCourseItem.m
//  lbexam
//
//  Created by frankay on 17/1/16.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCourseItem.h"

@implementation FKCourseItem


+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"imageItem":@[@"courseImage",@"image"],
             };
}
@end
