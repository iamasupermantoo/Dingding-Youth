//
//  FKCourseTableVC.m
//  lbexam
//
//  Created by frankay on 17/1/16.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCourseTableVC.h"
#import "FKLiveRoomViewController.h"

#import "FKHeaderView2Cell.h"
#import "FKAttendedCourseCell.h"
#import "HMPlaceholderCellItem.h"
#import "FKCalendarViewCell.h"
#import "HMEmptyCell.h"

#import "FKCourseItem.h"
#import "FKCourseRemindTask.h"
#import "HMNavigationController.h"
@interface FKCourseTableVC ()<FKCalendarViewCellDelegate>

@property(nonatomic,strong) FKCalendarViewCellItem *calendar;
@property(nonatomic,strong) FKCourseRemindTask *remindTask;

@property(nonatomic,copy) NSDictionary *currentSelDic;
@end

@implementation FKCourseTableVC

- (BOOL)hasLoadMore{
    return NO;
}

- (void)viewDidLoad {

    self.view.frame = CGRectMake(0, 0, IPAD_SCREENWIDTH, SCREENHEIGHT-64);
    [super viewDidLoad];
    self.title = @"课表";
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.currentSelDic = nil;
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self getRemindData:self.currentSelDic];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(UIBarButtonItem *)leftBarButtonItem{
    return nil;
}

#pragma mark - FKCalendarViewCellDelegate

- (void)getRemindData:(NSDictionary *)info{
    
    if (info) {
        NSString *selectedday = info[HMTableViewCell_Action_Key_UserInfo];
        self.remindTask.day = selectedday;
        self.currentSelDic = info;
        
    }else{
        self.remindTask.day = [NSString dateStringWithDate:[NSDate date] formatter:@"yyyy-MM-dd"];
    }
    
    [self.dataSource clear];
    
    
    HMPlaceholderCellItem *placeholderCellItem1 = [HMPlaceholderCellItem cellItemWithCellHeight:36];
    
    [self.dataSource insertCellItem:placeholderCellItem1 adIndex:0];
    [self.dataSource insertCellItem:self.calendar adIndex:1];
    
    [self.remindTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            NSMutableArray *cellItems1 = [NSMutableArray array];
        
            HMPlaceholderCellItem *holder = [HMPlaceholderCellItem placeholderCellItem];
            FKHeaderView2CellItem *waitCellItem = [[FKHeaderView2CellItem alloc] init];
            waitCellItem.rawObject = @"即上课程";
   
            [cellItems1 addObject:holder];
            [cellItems1 addObject:waitCellItem];
      
            // 即将课程
            // 作业list
            // 课堂待反馈
            NSArray *arr1 = response[@"data"][@"lessons"];
            if (arr1.count>0) {
                for (NSDictionary *dict in arr1) {
                     FKCourseItem *goingclass = [FKCourseItem yy_modelWithDictionary:dict];
                     FKAttendedCourseCellItem *attendCellItem = [[FKAttendedCourseCellItem alloc] init];
                    if (goingclass.status==2) {
                        // 完成上课
                    }
                    
                     attendCellItem.rawObject = goingclass;
                     [cellItems1 addObject:attendCellItem];
                }
            }
            // 加入到datasource中
            if (cellItems1.count>2) {
                [self.dataSource addCellItems:cellItems1];
            }
           
            if (self.dataSource.cellCount==1) {
                //只有日历cellItem时
                HMEmptyCellItem *emptyCellItem = [[HMEmptyCellItem alloc] init];
                 emptyCellItem.rawObject = @"没有已预约的课时";
                [self.dataSource addCellItem:emptyCellItem];
            }
            
            [self reloadTableView];
        }
        
    }];

}




-(void)getEmptyData:(NSDictionary *)info{
    self.dataSource = nil;
    HMPlaceholderCellItem *placeholderCellItem1 = [HMPlaceholderCellItem cellItemWithCellHeight:36];
    [self.dataSource insertCellItem:placeholderCellItem1 adIndex:0];
    [self.dataSource insertCellItem:self.calendar adIndex:1];
    //只有日历cellItem时
    HMEmptyCellItem *emptyCellItem = [[HMEmptyCellItem alloc] init];
     emptyCellItem.rawObject = @"没有已预约的课时";
    [self.dataSource addCellItem:emptyCellItem];
    [self.tableView reloadData];
}

- (void)reloadCellHeight:(NSDictionary *)info{

    CGFloat height = [info[HMTableViewCell_Action_Key_UserInfo] integerValue];
    self.calendar.rawObject = @(height);
    
    [self.tableView reloadData];
        

}


-(void)hmTableView:(UITableView *)tableView didSelectCellItem:(HMTableViewCellItem *)cellItem{
    
    FKCourseItem *item = cellItem.rawObject;
    
    if (item.status==2) {
        // 已经完成了课程
        [DDProgressHUD showErrorWithStatus:@"本节课已经结束！"];
        return;
        
    }else if (item.status==0 || item.status==1){
        // 待上课
        FKLiveRoomViewController *liveVC = [[FKLiveRoomViewController alloc] init];
//        HMNavigationController *nav = [[HMNavigationController alloc] initWithRootViewController:liveVC];
        liveVC.videoProfile = AgoraRtc_VideoProfile_180P_4;
        liveVC.cid = item.cid;
        liveVC.lid = item.lid;
        liveVC.titleName = [NSString stringWithFormat:@"第%@节课-%@",item.cnt,item.course];
        [self.navigationController pushViewController:liveVC animated:YES];
    }
 
}

- (FKCourseRemindTask *)remindTask{
    if (!_remindTask) {
        _remindTask = [[FKCourseRemindTask alloc] init];
        _remindTask.cid = self.cid;
    }
    return _remindTask;

}

- (FKCalendarViewCellItem *)calendar{
    if (!_calendar) {
        _calendar = [[FKCalendarViewCellItem alloc] init];
        _calendar.cid = self.cid;
    }
    return _calendar;
}
@end
