//
//  FKCorrectDetailVC.m
//  lbexam
//
//  Created by frankay on 17/6/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCorrectDetailVC.h"
#import "FKhwAudioRecordView.h"
#import "FKHomeWorkDescCell.h"
#import "FKWrittingShowCell.h"
#import "FKAudioRecordShowCell.h"
#import "FKPictureShowCell.h"
#import "HMPlaceholderCellItem.h"
#import "FKCheckCorrectOfTeacherCell.h"
#import "FKHeaderView3Cell.h"

// item
#import "FKHomeworkListItem.h"
#import "FKhwCiContentItem.h"
#import "FKCorrectedItem.h"

#import "HMPlaceholderCellItem.h"
// task
#import "FKHomeWorkCiDetailRequestTask.h"


#import "FKAudioPlayerHandle.h"
@interface FKCorrectDetailVC ()<FKPictureShowCellDelegate,FKAudioRecordShowCellDelegate,FKhwAudioRecordViewDelegate,FKAudioPlayerHandleDelegate>
@property(nonatomic,strong) FKHomeWorkCiDetailRequestTask *ciAnswerTask;
@property(nonatomic,strong) NSMutableArray *answers;


@property(nonatomic,strong) FKAudioRecordShowCellItem *prePlayingCellItem;

@property(nonatomic,strong) NSMutableDictionary *dataDict;

@property(nonatomic,strong) FKHomeworkListItem *descItem;

@property(nonatomic,strong) FKAudioPlayerHandle *audioPlayer;

@end

@implementation FKCorrectDetailVC

- (BOOL)hasLoadMore{
    return NO;
}
- (NSMutableDictionary *)dataDict{
    if (!_dataDict) {
        _dataDict = [NSMutableDictionary dictionary];
    }
    return _dataDict;
}

- (FKAudioPlayerHandle *)audioPlayer{
    if (!_audioPlayer) {
        _audioPlayer = [[FKAudioPlayerHandle alloc] init];
        _audioPlayer.delegate = self;
    }
    
    return _audioPlayer;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = HMLocal(@"批改详情");
    
    self.tableView.frame = CGRectMake(0, 0, SCREENWIDTH, SCREENHEIGHT-64);
    
    self.tableView.separatorColor = [UIColor hmMainBgColor];
    // 获取数据
    [self.ciAnswerTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (error == nil) {
            // 成功
            
            HMPlaceholderCellItem *placeCellItem1 = [HMPlaceholderCellItem cellItemWithCellHeight:20];
            [self.dataSource addCellItem:placeCellItem1];
            
            // 批改清单
            FKCheckCorrectOfTeacherCellItem *checkCellItem = [[FKCheckCorrectOfTeacherCellItem alloc] init];
            FKCorrectedItem *correctedItem = [FKCorrectedItem yy_modelWithDictionary:response[@"data"][@"details"]];
            checkCellItem.rawObject = correctedItem;
            [self.dataSource addCellItem:checkCellItem];
            
            HMPlaceholderCellItem *placeCellItem2 = [HMPlaceholderCellItem cellItemWithCellHeight:15];
            [self.dataSource addCellItem:placeCellItem2];
            
//            // 批改作业
//            FKHeaderView3CellItem *headerCellItem = [[FKHeaderView3CellItem alloc] init];
//            headerCellItem.rawObject = HMLocal(@"批改作业");
//            headerCellItem.bottomConstraint = 12;
//            headerCellItem.leadConstraint = 40+15;
//            headerCellItem.cellHeight = 44;
//            [self.dataSource addCellItem:headerCellItem];
            
            // 作业描述
            FKHomeworkListItem *descItem = [FKHomeworkListItem yy_modelWithDictionary:response[@"data"][@"details"]];
            FKHomeWorkDescCellItem *descCellItem = [[FKHomeWorkDescCellItem alloc] init];
            descCellItem.rawObject = descItem;
            self.descItem = descItem;
            [self.dataSource addCellItem:descCellItem];
            
            self.answers = [NSMutableArray array];
            NSArray *arr = response[@"data"][@"answers"];
            if (arr.count>0) {
                [arr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    // 提交的作业内容model
                    FKhwCiContentItem *contentItem = [FKhwCiContentItem yy_modelWithDictionary:obj];
                    
                    if (contentItem.type == 0) {
                        //文字
                        FKWrittingShowCellItem *writting = [[FKWrittingShowCellItem alloc] init];
                        writting.rawObject = contentItem;
                        [self.answers addObject:writting];
                    }else if(contentItem.type==1){
                        // 图片
                        FKPictureShowCellItem *picture = [[FKPictureShowCellItem alloc] init];
                        picture.rawObject = contentItem;
                        [self.answers addObject:picture];
                        
                    }else{
                        // 录音
                        FKAudioRecordShowCellItem *audioRecord = [[FKAudioRecordShowCellItem alloc] init];
                        audioRecord.isPlaying = NO;
                        audioRecord.rawObject = contentItem;
                        [self.answers addObject:audioRecord];
                    }
                    //                    [self.answers addObject:contentItem];
                    
                }];
                
                [self.dataSource addCellItems:self.answers];
            }
        }
        
        [self.tableView reloadData];
        
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    if (self.audioPlayer.isPlaying) {
        [self.audioPlayer fk_close];
        self.audioPlayer = nil;
    }
    
}

- (FKHomeWorkCiDetailRequestTask *)ciAnswerTask{
    if (!_ciAnswerTask) {
        _ciAnswerTask = [[FKHomeWorkCiDetailRequestTask alloc] init];
        _ciAnswerTask.hid = self.hid;
        _ciAnswerTask.cid = self.cid;
        _ciAnswerTask.lid = self.lid;
    }
    return _ciAnswerTask;
    
}


// 播放某一cell 上面的语音
- (void)AudioPlayorPause:(NSDictionary *)info{
    // 如果上一条在播放 则停止上一条的播放 播放目前的这一条
    // 如果上一条和本条相同 且上一条的isplaying= yes 则暂停播放 如上一条为no 则开始重新播放
    FKAudioRecordShowCellItem *cellItem = info[HMTableViewCell_Action_Key_CellItem];
    FKhwCiContentItem *item = cellItem.rawObject;
    // 对播放后的url 做个缓存
    
    
    
    // 如果上一条和这一条是同一条语音
    if ([self.prePlayingCellItem isEqual:cellItem]) {
        if (self.prePlayingCellItem.isPlaying) {
            // 当前语音正在播放 则stop
            [self.audioPlayer fk_pause];
            self.audioPlayer = nil;
            cellItem.isPlaying = NO;
            
        }else{
            // 当前语音未播放 则重新play
            [self.audioPlayer createStreamWithUrl:item.audio];
            cellItem.isPlaying = YES;
        }
        
        [self.tableView reloadData];
        
        
    }else{
        self.prePlayingCellItem.isPlaying = NO;
        cellItem.isPlaying = YES;
        [self.audioPlayer createStreamWithUrl:item.audio];
        [self.tableView reloadData];
    }
    self.prePlayingCellItem = cellItem;
    
}

#pragma mark - FKAudioPlayerHandleDelegate

- (void)streamerWithStatus:(DOUAudioStreamerStatus)status{
    if (status == DOUAudioStreamerFinished) {
        // 完成
        self.prePlayingCellItem.isPlaying = NO;
        [self.audioPlayer fk_close];
        [self.tableView reloadData];
    }
    
}

@end
