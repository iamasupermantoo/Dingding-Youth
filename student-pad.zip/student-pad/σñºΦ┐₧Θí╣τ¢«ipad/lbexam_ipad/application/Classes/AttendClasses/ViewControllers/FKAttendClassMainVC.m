//
//  FKAttendClassMainVC.m
//  lbexam
//
//  Created by frankay on 17/1/13.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKAttendClassMainVC.h"
#import "FKToolListCell.h"
#import "FKCourseListVC.h"
#import "FKCourseTableVC.h"
#import "FKHomeworkListVC.h"
@interface FKAttendClassMainVC ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property(nonatomic,strong) UICollectionView *collectionView;
@property(nonatomic,strong) NSArray *tools;

@end

@implementation FKAttendClassMainVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.shouldHidenNavigationBar = NO;
    UICollectionViewFlowLayout *viewlayout = [[UICollectionViewFlowLayout alloc] init];
    viewlayout.itemSize = CGSizeMake(SCREENWIDTH/4.0, SCREENWIDTH/4.0);
    viewlayout.minimumInteritemSpacing = 0;
    viewlayout.minimumLineSpacing = 0;
    self.collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:viewlayout];
    self.collectionView.backgroundColor = [UIColor whiteColor];

    [self.collectionView registerNib:[UINib nibWithNibName:@"FKToolListCell" bundle:nil] forCellWithReuseIdentifier:@"toolCell"];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    [self.view addSubview:self.collectionView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
}

#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {

    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.tools.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    FKToolListCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"toolCell" forIndexPath:indexPath];
    [cell setcellWithDic:self.tools[indexPath.row]];
    
    return cell;
}

#pragma mark <UICollectionViewDelegate>

//
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}


// item size
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(SCREENWIDTH/4.0, SCREENWIDTH/4.0+20);
}


-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.row) {
        case 0:
            // 课表
        {
            FKCourseTableVC *tableVC = [[FKCourseTableVC alloc] init];
            [self.navigationController pushViewController:tableVC animated:YES];
        }
            break;
        case 1:
            // 课程
        {
            FKCourseListVC *vc = [[FKCourseListVC alloc] init];
            [self.navigationController pushViewController:vc animated:YES];

        }
            break;
        case 2:
            // 作业
        {
            FKHomeworkListVC *homeworkVC = [[FKHomeworkListVC alloc] init];
            [self.navigationController pushViewController:homeworkVC animated:YES];
        }
            break;
        case 3:
            // 评价
            break;
        default:
            break;
    }
}


-(NSArray *)tools{
    if (!_tools) {
        _tools = @[@{@"img":@"courseTable",@"title":@"课表"},@{@"img":@"courses",@"title":@"课程"},@{@"img":@"homework",@"title":@"作业"},@{@"img":@"appraise",@"title":@"评价"}];
    }
    return _tools;
}
@end
