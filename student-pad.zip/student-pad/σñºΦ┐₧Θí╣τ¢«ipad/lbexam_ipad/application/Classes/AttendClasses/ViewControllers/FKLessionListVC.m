//
//  FKLessionListVC.m
//  lbexam
//
//  Created by frankay on 17/1/17.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKLessionListVC.h"
#import "FKFeedBackToTeacherVC.h"
#import "FKFeedBackDetailVC.h"
#import "FKHomeworkDetailVC.h"
#import "FKCorrectDetailVC.h"
#import "FKAllPartCell.h"
#import "FKReplayVC.h"
#import "HMPlaceholderCellItem.h"
#import "FKLessonListRequestTask.h"
@interface FKLessionListVC ()<FKAllPartCellDelegate>
@property(nonatomic,strong) FKLessonListRequestTask *lessonTask;
@end

@implementation FKLessionListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"课次列表";
    
    self.tableView.separatorColor = [UIColor clearColor];
    
    self.tableView.frame = CGRectMake(0, 0, SCREENWIDTH, SCREENHEIGHT-64);
    self.listRequestTask = self.lessonTask;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (Class)cellItemClass{
    return [FKAllPartCellItem class];
}

-(NSMutableArray<HMTableViewCellItem *> *)generateCellItemsWithReqeustTask:(HMListRequestTask *)requestTask resultItems:(NSArray *)resultitems{
    NSMutableArray *cellItems = [NSMutableArray array];
    HMPlaceholderCellItem *placeCellItem = [HMPlaceholderCellItem placeholderCellItem];
    for (HMBaseItem *item in resultitems) {
        FKAllPartCellItem *partCellItem = [[FKAllPartCellItem alloc] init];
        partCellItem.rawObject = item;
        [cellItems addObject:placeCellItem];
        [cellItems addObject:partCellItem];
    }
    
    return cellItems;
}


// get
- (FKLessonListRequestTask *)lessonTask{
    if (!_lessonTask) {
        _lessonTask = [[FKLessonListRequestTask alloc] init];
        _lessonTask.cid = self.cid;
    }
    return _lessonTask;

}



#pragma mark - FKAllPartCellDelegate

- (void)PartComment:(NSDictionary *)info{
    // 评论
    UIButton *btn = info[HMTableViewCell_Action_Key_Sender];
    FKAllPartCellItem *cellItem = info[HMTableViewCell_Action_Key_CellItem];
    FKCourseLessonItem *lessonItem = cellItem.rawObject;
    
    if (btn.tag == 1001) {
        // 评论
        FKFeedBackToTeacherVC *goFeedBack = [[FKFeedBackToTeacherVC alloc] init];
        goFeedBack.cid = lessonItem.cid;
        goFeedBack.lid = lessonItem.lid;
        
        // 评论成功后  更改状态
        goFeedBack.statusBlock = ^(id userInfo){
            lessonItem.studentReactionStatus = 1;
        };
        [self.navigationController pushViewController:goFeedBack animated:YES];
        
    }else{
        // 查看评论
        FKFeedBackDetailVC *detailVC = [[FKFeedBackDetailVC alloc] init];
        detailVC.cid = lessonItem.cid;
        detailVC.lid = lessonItem.lid;
        [self.navigationController pushViewController:detailVC animated:YES];
    }
}


-(void)PartReplay:(NSDictionary *)info{
    // 回放
    FKAllPartCellItem *cellItem = info[HMTableViewCell_Action_Key_CellItem];
    FKCourseLessonItem *lessonItem = cellItem.rawObject;
    FKReplayVC *replayVC = [[FKReplayVC alloc] init];
    replayVC.videoURL = lessonItem.videoUrl;
    replayVC.videoTitle = lessonItem.label;
    [self.navigationController pushViewController:replayVC animated:YES];
    
}

- (void)PartFeedBack:(NSDictionary *)info{
    // 查看反馈
    FKAllPartCellItem *cellItem = info[HMTableViewCell_Action_Key_CellItem];
    FKCourseLessonItem *lessonItem = cellItem.rawObject;
    
    FKFeedBackDetailVC *detailVC = [[FKFeedBackDetailVC alloc] init];
    detailVC.cid = lessonItem.cid;
    detailVC.lid = lessonItem.lid;
    detailVC.type = 1;
    [self.navigationController pushViewController:detailVC animated:YES];
    
}


- (void)PartHomework:(NSDictionary *)info{
    // 作业 未批改    已批改
    // 未批改进入作业  已批改进入老师评语
    FKAllPartCellItem *cellItem = info[HMTableViewCell_Action_Key_CellItem];
    FKCourseLessonItem *lessonItem = cellItem.rawObject;
    if (lessonItem.homeworkStatus == 0 || lessonItem.homeworkStatus == 1) {
        // 待提交  待评分 跳转到作业详情
        FKHomeworkDetailVC *detailVC = [[FKHomeworkDetailVC alloc] init];
        detailVC.cid = lessonItem.cid;
        detailVC.lid = lessonItem.lid;
        [self.navigationController pushViewController:detailVC animated:YES];
        
//        FKCorrectDetailVC *vc = [[FKCorrectDetailVC alloc] init];
//        vc.cid = lessonItem.cid;
//        vc.lid = lessonItem.lid;
//        [self.navigationController pushViewController:vc animated:YES];
    }else if (lessonItem.status==2){
        
        FKCorrectDetailVC *vc = [[FKCorrectDetailVC alloc] init];
        vc.cid = lessonItem.cid;
        vc.lid = lessonItem.lid;
        [self.navigationController pushViewController:vc animated:YES];
    
    }
}



- (void)emptyViewWhenTableViewEmpty{

    [self.tableView emptyWithImage:nil title:@"您还没排的课程"];
}
@end
