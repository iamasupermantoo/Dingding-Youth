//
//  FKCourseDetailVC.m
//  lbexam
//
//  Created by frankay on 17/1/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCourseDetailVC.h"
#import "FKTeacherDetailVC.h"

// cellItem
#import "FKCourseDetailBriefCell.h"
#import "FKSomethingBriefCell.h"
#import "FKHeaderView1Cell.h"
#import "FKFeedBackCell.h"
#import "HMPlaceholderCellItem.h"
// request task
#import "FKCourseDetailRequestTask.h"

// item
#import "FKCourseItem.h"
@interface FKCourseDetailVC ()<FKCourseDetailBriefCellDelegate>
@property(nonatomic,strong) FKCourseDetailRequestTask *detailTask;
@end

@implementation FKCourseDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = HMLocal(@"课程详情");
    [self getCourseInfo];
    FKHeaderView1CellItem *header1CellItem = [[FKHeaderView1CellItem alloc] init];
    header1CellItem.rawObject = @"用户反馈";
    FKFeedBackCellItem *feedbackCellItem1 = [[FKFeedBackCellItem alloc] init];
    FKFeedBackCellItem *feedbackCellItem2 = [[FKFeedBackCellItem alloc] init];
    FKFeedBackCellItem *feedbackCellItem3 = [[FKFeedBackCellItem alloc] init];
    FKFeedBackCellItem *feedbackCellItem4 = [[FKFeedBackCellItem alloc] init];
    NSArray *arr = @[header1CellItem,feedbackCellItem1,feedbackCellItem2,feedbackCellItem3,feedbackCellItem4];
    [self.dataSource addCellItems:arr];
    [self.tableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}



- (void)getCourseInfo{
    [self.detailTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            HMPlaceholderCellItem *placeholder = [HMPlaceholderCellItem placeholderCellItem];
            NSDictionary *course = response[@"data"][@"course"];
            NSMutableArray *cellItems = [NSMutableArray array];
            FKCourseItem *courseItme = [FKCourseItem yy_modelWithDictionary:course];
            FKCourseDetailBriefCellItem *briefCellItem = [[FKCourseDetailBriefCellItem alloc] init];
            briefCellItem.rawObject = courseItme;
            [cellItems addObject:briefCellItem];
            [cellItems addObject:placeholder];
           
            FKSomethingBriefCellItem *somebriefCellItem = [[FKSomethingBriefCellItem alloc] init];
            somebriefCellItem.rawObject = courseItme.desc;
            somebriefCellItem.Btitle = @"课程简介";
            [cellItems addObject:somebriefCellItem];
            [cellItems addObject:placeholder];
            
            [self.dataSource insertCellItems:cellItems adIndex:0];
            [self.tableView reloadData];
        }
    
    }];

}

// 立即约课
-(void)CheckCourse:(NSDictionary *)info{
    // 暂时跳转教师详情
    FKTeacherDetailVC *teacher = [[FKTeacherDetailVC alloc] init];
    [self.navigationController pushViewController:teacher animated:YES];
}


- (FKCourseDetailRequestTask *)detailTask{
    if (!_detailTask) {
        _detailTask = [[FKCourseDetailRequestTask alloc] init];
        _detailTask.cmid = self.cmid;
    }
    return _detailTask;
}
@end
