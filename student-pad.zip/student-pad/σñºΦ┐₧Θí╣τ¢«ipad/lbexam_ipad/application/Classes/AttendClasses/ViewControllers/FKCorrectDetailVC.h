//
//  FKCorrectDetailVC.h
//  lbexam
//
//  Created by frankay on 17/6/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMListViewController.h"

@interface FKCorrectDetailVC : HMListViewController
@property(nonatomic,strong) NSString *hid;
@property(nonatomic,strong) NSString *cid;
@property(nonatomic,strong) NSString *lid;
@end
