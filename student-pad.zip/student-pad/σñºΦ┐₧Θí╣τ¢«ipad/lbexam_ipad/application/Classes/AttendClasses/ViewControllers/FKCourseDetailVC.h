//
//  FKCourseDetailVC.h
//  lbexam
//
//  Created by frankay on 17/1/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMListViewController.h"

@interface FKCourseDetailVC : HMListViewController
@property(nonatomic,strong) NSString *cmid;
@end
