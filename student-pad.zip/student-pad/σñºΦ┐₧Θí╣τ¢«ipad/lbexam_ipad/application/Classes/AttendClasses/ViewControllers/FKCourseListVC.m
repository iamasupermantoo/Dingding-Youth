//
//  FKCourseListVC.m
//  lbexam
//
//  Created by frankay on 17/1/13.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCourseListVC.h"
#import "FKCourseViewCell.h"

#import "FKCourseDetailVC.h"
#import "FKLessionListVC.h"

#import "FKCourseListRequestTask.h"
#import "HMPlaceholderCellItem.h"
#import "FKCourseItem.h"
@interface FKCourseListVC ()<FKCourseViewCellDelegate>
@property(nonatomic,assign) BOOL isOnlyRow;
@end

@implementation FKCourseListVC


- (BOOL)hasHeadRefresh{
    return YES;
}


- (void)viewDidLoad {
    self.view.frame = CGRectMake(0, 0, IPAD_SCREENWIDTH, SCREENHEIGHT-64);
    [super viewDidLoad];
    self.title = HMLocal(@"课程");
    self.listRequestTask = [[FKCourseListRequestTask alloc] init];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

- (Class)cellItemClass{

    return [FKCourseViewCellItem class];
}


-(void)datasourceWillAddCellItems:(NSMutableArray<HMTableViewCellItem *> *)cellItems requestTask:(HMListRequestTask *)requestTask{
  
    if (!requestTask.isLoadingMore) {
        if (cellItems.count<=0) {
            
        }else{
            // 只有一行的时候
            if (cellItems.count==1) {
                self.isOnlyRow = YES;
            }
            HMPlaceholderCellItem *placeholderCellItem1 = [HMPlaceholderCellItem cellItemWithCellHeight:36];
            [cellItems insertObject:placeholderCellItem1 atIndex:0];
            
        }
    }

      [super datasourceWillAddCellItems:cellItems requestTask:requestTask];
   

}


- (void)getCourseListData{
    FKCourseListRequestTask *task = [[FKCourseListRequestTask alloc] init];
    [task loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            NSArray *listarr = response[@"data"][@"courses"][@"list"];
            NSMutableArray *cellItems = [NSMutableArray array];
            for (NSDictionary *dict in listarr) {
                FKCourseItem *item = [FKCourseItem itemWithDictionary:dict];
                FKCourseViewCellItem *cellItem = [[FKCourseViewCellItem alloc] init];
                cellItem.rawObject = item;
                [cellItems addObject:cellItem];
            }
            
            
            if (listarr.count==0) {
                // 没有数据
                
            }else if(listarr.count==1){
                // 全部显示
//                FKCourseViewCellItem *cellItem = cellItems.firstObject;
//                FKCourseItem *item = cellItem.rawObject;
//                FKLessionListVC *vc = [[FKLessionListVC alloc] init];
//                vc.courseItem = item;
//
//                [self.view addSubview:vc.view];
//                [self addChildViewController:vc];
                // 显示courselist
                HMPlaceholderCellItem *placeholderCellItem1 = [HMPlaceholderCellItem cellItemWithCellHeight:36];
                [self.dataSource insertCellItem:placeholderCellItem1 adIndex:0];
                [self.dataSource addCellItems:cellItems];
                [self reloadTableView];
                
            }else{
                // 显示courselist
                HMPlaceholderCellItem *placeholderCellItem1 = [HMPlaceholderCellItem cellItemWithCellHeight:36];
                [self.dataSource insertCellItem:placeholderCellItem1 adIndex:0];
                [self.dataSource addCellItems:cellItems];
                [self reloadTableView];
            }
        }
        
    }];
}

- (UIBarButtonItem *)leftBarButtonItem{
    return nil;
}


// 点击cell
- (void)hmTableView:(UITableView *)tableView didSelectCellItem:(HMTableViewCellItem *)cellItem{
//    FKCourseItem *item = cellItem.rawObject;
//    
//    FKCourseDetailVC *detailVC = [[FKCourseDetailVC alloc] init];
//    detailVC.cmid = item.cmId;
//    [self.navigationController pushViewController:detailVC animated:YES];
    
}

#pragma mark -FKCourseViewCellDelegate
- (void)ClickLessonButton:(NSDictionary *)info{
    FKCourseViewCellItem *cellItem = info[HMTableViewCell_Action_Key_CellItem];
    FKCourseItem *courseItem = cellItem.rawObject;

    FKLessionListVC *lesson = [[FKLessionListVC alloc] init];
    lesson.cid = courseItem.cid;
    [self.navigationController pushViewController:lesson animated:YES];
 
}


-(void)emptyViewWhenTableViewEmpty{
    [self.tableView emptyWithImage:nil title:@"您还没有购买课程"];
}



@end
