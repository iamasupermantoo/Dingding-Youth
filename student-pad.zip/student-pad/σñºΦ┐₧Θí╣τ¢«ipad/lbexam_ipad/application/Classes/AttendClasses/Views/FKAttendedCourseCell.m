//
//  FKAttendedCourseCell.m
//  lbexam
//
//  Created by frankay on 17/1/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKAttendedCourseCell.h"
#import "FKCourseItem.h"
#import "HMYellowButton.h"
@interface FKAttendedCourseCell ()
@property (weak, nonatomic) IBOutlet UIImageView *CimageView;
@property (weak, nonatomic) IBOutlet FKinitLabel *Cname;
@property (weak, nonatomic) IBOutlet FKinitLabel *CtotalTime;
@property (weak, nonatomic) IBOutlet FKinitLabel *Cteacher;
@property (weak, nonatomic) IBOutlet FKinitLabel *Ctime;
@property (weak, nonatomic) IBOutlet HMYellowButton *commentBtn;
@property (weak, nonatomic) IBOutlet UIImageView *arrowImageView;

@end

@implementation FKAttendedCourseCell


- (void)initSettings{
    [super initSettings];
    self.commentBtn.userInteractionEnabled = NO;

}

- (void)updateWithCellItem:(FKAttendedCourseCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    FKCourseItem *courseItem = cellItem.rawObject;

//    if (cellItem.btnstatus == 0) {
//        // 显示箭头
//        self.commentBtn.hidden = YES;
//    }
//    if (cellItem.btnstatus == 1) {
//        // 去评价
//        self.arrowImageView.hidden = YES;
//        [self.commentBtn setTitle:@"去评价" forState:UIControlStateNormal];
//        self.commentBtn.enabled = YES;
//    }
//    if (cellItem.btnstatus == 2) {
//        // 已评价
//        self.arrowImageView.hidden = YES;
//        [self.commentBtn setTitle:@"已评价" forState:UIControlStateNormal];
//        self.commentBtn.enabled = NO;
//    }
    
    if (courseItem.status==0) {
        
        self.arrowImageView.hidden = YES;
        [self.commentBtn setTitle:@"未上课" forState:UIControlStateNormal];
        [self.commentBtn setBackgroundImage:IMG_NAME(@"curriculum_lessons_normal") forState:UIControlStateNormal];
        [self.commentBtn setTitleColor:[UIColor hmTextBlackColor] forState:UIControlStateNormal];
    } else if(courseItem.status==1){
        self.arrowImageView.hidden = YES;
        [self.commentBtn setTitle:@"正在上课" forState:UIControlStateNormal];
        [self.commentBtn setBackgroundImage:IMG_NAME(@"curriculum_lessons_normal") forState:UIControlStateNormal];
        [self.commentBtn setTitleColor:[UIColor hmTextBlackColor] forState:UIControlStateNormal];
    
    }else if (courseItem.status==2){
        // 已上课
        self.arrowImageView.hidden = YES;
        [self.commentBtn setTitle:@"已上课" forState:UIControlStateNormal];
        [self.commentBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.commentBtn setBackgroundImage:IMG_NAME(@"curriculum_lessons_normalgray") forState:UIControlStateNormal];
    }
    
    [self.CimageView hmLoadImageURL:[courseItem.imageItem imageUrlWithWidth:88 height:115] placeholderImage:IMG_NAME(@"icon.jpg") local:YES];
    self.Cname.text = [NSString stringWithFormat:@"课程：%@",courseItem.course];
    self.CtotalTime.text = [NSString stringWithFormat:@"课次：第%@节课",courseItem.cnt];
    self.Cteacher.text = [NSString stringWithFormat:@"老师：%@",courseItem.teacher];
    self.Ctime.text = [NSString stringWithFormat:@"时间：%@",courseItem.time];
}


-(void)showImagesWithCellItem:(HMTableViewCellItem *)cellItem{
    [super showImagesWithCellItem:cellItem];
    FKCourseItem *courseItem = cellItem.rawObject;
    [self.CimageView hmLoadImageURL:[courseItem.imageItem imageUrlWithWidth:88 height:115] placeholderImage:IMG_NAME(@"icon.jpg") local:NO];
}

- (IBAction)commentBtnAction:(HMYellowButton *)sender {
    [self.deleagte hmTableViewCell:self sender:sender selector:@selector(fk_GoToFeedbackWith:) userInfo:nil];
}

@end



@implementation FKAttendedCourseCellItem
- (void)initSettings{
    [super initSettings];
    self.canSelect = YES;
    self.separatorInset = kIpadNoGapSeperateInsets;
    self.cellHeight = 147;
}

@end
