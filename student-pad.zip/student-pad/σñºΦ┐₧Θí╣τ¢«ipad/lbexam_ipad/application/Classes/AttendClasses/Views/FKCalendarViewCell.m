//
//  FKCalendarViewCell.m
//  lbexam
//
//  Created by frankay on 17/1/17.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCalendarViewCell.h"
#import "FSCalendar.h"
#define kLineHeight     50
#define kCommon_SeparateLineHeight      (0.5)

#define kCalendarHeight     kLineHeight*6+44

#import "FKCalendarreminddotTask.h"
@interface FKCalendarViewCell ()<FSCalendarDataSource,FSCalendarDelegate,FSCalendarDelegateAppearance>
@property (weak, nonatomic) IBOutlet UILabel *curentDateTitle;
@property (weak, nonatomic) IBOutlet UIView *calendarContent;
@property(nonatomic,strong) FSCalendar *calendar;
@property(nonatomic,strong) NSArray *datesWithEvent;
@property (nonatomic, copy) NSString *currentDay;
@property (nonatomic, copy) NSString *currentMonth;
@property (nonatomic, copy) NSString *currentMonthTitle;
@property (nonatomic, strong) UIView *lastLineView;

@property (nonatomic, strong) NSMutableDictionary *pointDict;
@property (nonatomic, strong) NSMutableDictionary *countDict;

@property(nonatomic,strong) FKCalendarreminddotTask *dotremindTask;

@property(nonatomic,assign) CGFloat preCalHeight;
@property(nonatomic,assign) BOOL isfirst;

@property (weak, nonatomic) IBOutlet UIView *line1;
@property (weak, nonatomic) IBOutlet UIView *line2;

@end


@implementation FKCalendarViewCell

- (FKCalendarreminddotTask *)dotremindTask{
    if (!_dotremindTask) {
        _dotremindTask = [[FKCalendarreminddotTask alloc] init];
    }
    return _dotremindTask;
}
- (NSMutableDictionary *)pointDict {
    if (_pointDict == nil) {
        _pointDict = [NSMutableDictionary dictionary];
    }
    return _pointDict;
}


- (NSMutableDictionary *)countDict {
    if (_countDict == nil) {
        _countDict = [NSMutableDictionary dictionary];
    }
    return _countDict;
}


- (void)initSettings{
    [super initSettings];
    
    self.line1.backgroundColor = [UIColor hmBorderColor];
    self.line2.backgroundColor = [UIColor hmBorderColor];
    
    self.curentDateTitle.textColor = [UIColor hmTextBlackColor];
    [self setupCalendarView];
//    [self setupLineViews];
    self.calendar.clipsToBounds = YES;
    
    self.currentMonth = [NSString dateStringWithDate:[NSDate date] formatter:@"yyyy-MM"];
    self.currentMonthTitle = [NSString dateStringWithDate:[NSDate date] formatter:@"yyyy-MM月"];
    self.currentDay = [NSString dateStringWithDate:[NSDate date] formatter:@"yyyy-MM-dd"];
    self.curentDateTitle.text = self.currentMonthTitle;
    self.isfirst = YES;
    
}


- (void)updateWithCellItem:(FKCalendarViewCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    if (!self.cid) {
        self.cid = cellItem.cid;
    }
}


- (void)getdotData:(NSString *)cid{
    
    if (cid) {
        self.dotremindTask.cid = cid;
    }
    self.dotremindTask.month = self.currentMonth;
    
    [self.dotremindTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            NSMutableArray *dayArray = [NSMutableArray array];

            NSArray *dayArr = response[@"data"][@"days"];
            [dayArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                NSNumber *number = obj;
                if ([number isKindOfClass:[NSNumber class]]) {
                    NSString *day = [number stringValue];
                    if (day.length == 1) {
                        day = [NSString stringWithFormat:@"0%@", day];
                    }
                    day = [NSString stringWithFormat:@"%@-%@", self.currentMonth, day];
                    [dayArray addObject:day];
                }
            }];
            
            [self.pointDict setObject:dayArray forKey:self.currentMonth];
            
            self.datesWithEvent = [self.pointDict objectForKey:self.currentMonth];
            [self.calendar reloadData];

        }
        
    }];


}


// click left or right arrow
- (IBAction)ClickLeftBtn:(id)sender {
    [self preAction];
}
- (IBAction)ClickRightBtn:(id)sender {
    [self nextAction];
}

#pragma mark Actions

- (void)preAction {
    
    [self.calendar setCurrentPage:[self preDatePage] animated:YES];
}

- (void)nextAction {
    
    [self.calendar setCurrentPage:[self nextDatePage] animated:YES];
}


- (NSDate *)preDatePage {

    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *comps = nil;
    comps = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:self.calendar.currentPage];
    NSDateComponents *adcomps = [[NSDateComponents alloc] init];
    
    [adcomps setYear:0];
    [adcomps setMonth:-1];
    [adcomps setDay:0];
    NSDate *newdate = [calendar dateByAddingComponents:adcomps toDate:self.calendar.currentPage options:0];
    
//    NSLog(@"newdate %@",[self.calendar stringFromDate:newdate format:@"yyyy-MM-dd,HH:mm:ss"]);
    
    return newdate;
    //    NSDateFormatter *formatter1 = [[NSDateFormatter alloc] init];
    //    [formatter1 setDateFormat:@"yyyy-MM-dd,HH:mm:ss"];
    //    NSString *str = @"2016-07-01 00:00:00";
    //    NSDate *date = [formatter1 dateFromString:str];
    //    return date;
}

- (NSDate *)nextDatePage {

    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *comps = nil;
    comps = [calendar components:NSCalendarUnitDay|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:self.calendar.currentPage];
    NSDateComponents *adcomps = [[NSDateComponents alloc] init];
    
    [adcomps setYear:0];
    [adcomps setMonth:1];
    [adcomps setDay:0];
    NSDate *newdate = [calendar dateByAddingComponents:adcomps toDate:self.calendar.currentPage options:0];
    
//    NSLog(@"newdate %@",[self.calendar stringFromDate:newdate format:@"yyyy-MM-dd,HH:mm:ss"]);
    
    return newdate;
    //    NSDateFormatter *formatter1 = [[NSDateFormatter alloc] init];
    //    [formatter1 setDateFormat:@"yyyy-MM-dd,HH:mm:ss"];
    //    NSString *str = @"2016-07-01 00:00:00";
    //    NSDate *date = [formatter1 dateFromString:str];
    //    return date;
}


- (void)setupCalendarView{
     FSCalendar *calendar = [[FSCalendar alloc] initWithFrame:CGRectMake(0, 0, IPAD_SCREENWIDTH, kCalendarHeight)];
    calendar.dataSource = self;
    calendar.delegate = self;
    calendar.backgroundColor = [UIColor whiteColor];
    calendar.appearance.caseOptions = FSCalendarCaseOptionsHeaderUsesUpperCase|FSCalendarCaseOptionsWeekdayUsesSingleUpperCase;
    [self.calendarContent addSubview:calendar];
    //    [calendar selectDate:[calendar dateWithYear:2015 month:10 day:3]];
    [calendar selectDate:[NSDate date]];
    calendar.firstWeekday = 1;
    calendar.placeholderType = FSCalendarPlaceholderTypeNone;
    self.calendar = calendar;
    self.calendar.clipsToBounds = YES;
    _calendar.scrollDirection = FSCalendarScrollDirectionHorizontal;
    
    _calendar.appearance.weekdayTextColor = [UIColor colorWithRed:0.58 green:0.58 blue:0.58 alpha:1.00];
    _calendar.appearance.headerTitleColor = [UIColor colorWithRed:0.58 green:0.58 blue:0.58 alpha:1.00];
   _calendar.appearance.eventSelectionColor = [UIColor colorWithRed:1.00 green:0.55 blue:0.18 alpha:1.00];
    _calendar.appearance.eventDefaultColor = [UIColor hmBorderColor];
    
    _calendar.appearance.headerDateFormat = @"MMMM yyyy";
    _calendar.appearance.todayColor = [UIColor hmBorderColor];
    _calendar.appearance.separators = FSCalendarSeparatorInterRows;

    _calendar.swipeToChooseGesture.enabled = YES;

    _calendar.appearance.headerMinimumDissolvedAlpha = 0.2;

    _calendar.headerHeight = 0;
    _calendar.weekdayHeight = 44;
    _calendar.allowsMultipleSelection = NO;
    _calendar.clipsToBounds = YES;
    
    _datesWithEvent = @[];

}



- (void)setupLineViews {
    
    CGFloat headerHeight = _calendar.weekdayHeight;
    CGFloat lineHeight = kLineHeight;
    
    UIView *lineView = nil;
    
    lineView = [UIView new];
    lineView.backgroundColor = [UIColor hmBorderColor];
    [self.calendar addSubview:lineView];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.height.mas_equalTo(kCommon_SeparateLineHeight);
        make.top.mas_equalTo(headerHeight);
    }];
    
    
    for (int i = 0; i < 5; i ++) {
        lineView = [UIView new];
        lineView.backgroundColor = [UIColor hmBorderColor];
        [self.calendar addSubview:lineView];
        [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(0);
            make.right.mas_equalTo(0);
            make.height.mas_equalTo(kCommon_SeparateLineHeight);
            make.top.mas_equalTo(headerHeight + (kCommon_SeparateLineHeight +lineHeight) * (i+1));
        }];
        if (i == 4) {
            self.lastLineView = lineView;
        }
    }
    
    lineView = [UIView new];
    lineView.backgroundColor = [UIColor hmBorderColor];
    [self.calendar addSubview:lineView];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.height.mas_equalTo(kCommon_SeparateLineHeight);
        make.bottom.mas_equalTo(0);
    }];
}

#pragma mark - FSCalendarDataSource

- (NSString *)calendar:(FSCalendar *)calendar titleForDate:(NSDate *)date {
    return nil;
    //    return [calendar isDateInToday:date] ? @"今天" : nil;
}

- (NSString *)calendar:(FSCalendar *)calendar subtitleForDate:(NSDate *)date {
    return nil;
}

- (NSInteger)calendar:(FSCalendar *)calendar numberOfEventsForDate:(NSDate *)date {
    if ([_datesWithEvent containsObject:[NSString dateStringWithDate:date formatter:@"yyyy-MM-dd"]]) {
        return 1;
    }else{
        return 0;
    }
    
//    return [_datesWithEvent containsObject:[calendar stringFromDate:date format:@"yyyy-MM-dd"]];
}

- (NSDate *)minimumDateForCalendar:(FSCalendar *)calendar
{
    return [NSString dateWithString:@"2016-12-01" andFormatterStr:@"yyyy-MM-dd"];
}

- (NSDate *)maximumDateForCalendar:(FSCalendar *)calendar
{
    return [NSString dateWithString:@"2020-12-01" andFormatterStr:@"yyyy-MM-dd"];
}



- (UIColor *)calendar:(FSCalendar *)calendar appearance:(nonnull FSCalendarAppearance *)appearance fillSelectionColorForDate:(nonnull NSDate *)date{
    return [UIColor fkfe8d25Color];
}


#pragma mark - FSCalendarDelegate

- (BOOL)calendar:(FSCalendar *)calendar shouldSelectDate:(NSDate *)date {
    return YES;
}


//select date
- (void)calendar:(FSCalendar *)calendar didSelectDate:(NSDate *)date {
  
    
    self.currentDay = [NSString dateStringWithDate:date formatter:@"yyyy-MM-dd"];
    // 通知vc
    // 当有提醒事件的时候调用
    NSArray *evendays = [self.pointDict objectForKey:self.currentMonth];
    if ([evendays containsObject:self.currentDay]) {
        // 有提醒时间
      [self.deleagte hmTableViewCell:self sender:nil selector:@selector(getRemindData:) userInfo:self.currentDay];
    }else{
        // 没提醒事件
        [self.deleagte hmTableViewCell:self sender:nil selector:@selector(getEmptyData:) userInfo:nil];
    
    }
    
}



// tell delegate change current page
- (void)calendarCurrentPageDidChange:(FSCalendar *)calendar {
    
    self.currentMonth = [NSString dateStringWithDate:calendar.currentPage formatter:@"yyyy-MM"];
    self.currentMonthTitle = [NSString dateStringWithDate:calendar.currentPage formatter:@"yyyy-MM月"];

    self.curentDateTitle.text = self.currentMonthTitle;
    
    
    // 防止有新的课程  刷新课程刷不出来
    [self getdotData:self.cid];
    
    //
//    if (![self.pointDict objectForKey:self.currentMonth]) {
//        [self getdotData:self.cid];
//    }else{
//        self.datesWithEvent = [self.pointDict objectForKey:self.currentMonth];
//        [self.calendar reloadData];
//    }
//    

    
}
- (CGPoint)calendar:(FSCalendar *)calendar appearance:(FSCalendarAppearance *)appearance titleOffsetForDate:(NSDate *)date{
    // title偏移
    return CGPointMake(0, 4);
}
//- (CGFloat)calendar:(FSCalendar *)calendar appearance:(FSCalendarAppearance *)appearance borderRadiusForDate:(NSDate *)date{
//    return 0.8;
//}
- (void)calendarCurrentScopeWillChange:(FSCalendar *)calendar animated:(BOOL)animated {
    
}

// change rect
- (void)calendar:(FSCalendar *)calendar boundingRectWillChange:(CGRect)bounds animated:(BOOL)animated {
    if (self.isfirst) {
        [self getdotData:self.cid];
        // 当有提醒事件的时候调用
        self.isfirst = NO;
    }
    
    
    dispatch_async(dispatch_get_main_queue(), ^{
        // 刷新cell的高度
        [self.deleagte hmTableViewCell:self sender:nil selector:@selector(reloadCellHeight:) userInfo:@(bounds.size.height)];
    });
  
}

@end


@implementation FKCalendarViewCellItem
- (void)initSettings{
    [super initSettings];
    self.separatorInset = kIpadNoGapSeperateInsets;
    self.cellHeight =  kCalendarHeight + 44;
    self.canSelect = NO;
}

- (void)setRawObject:(id)rawObject{
    if (rawObject == nil) {
        return;
    }
    
    self.cellHeight = [rawObject integerValue] +44-6 ;

}
@end
