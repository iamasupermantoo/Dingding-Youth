//
//  FKCourseViewCell.h
//  lbexam
//
//  Created by frankay on 17/1/13.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"
#import "HMTableViewCellItem.h"

@protocol FKCourseViewCellDelegate <NSObject>

- (void)ClickLessonButton:(NSDictionary *)info;
@end

@interface FKCourseViewCell : HMTableViewCell

@end



@interface FKCourseViewCellItem : HMTableViewCellItem
@property(nonatomic,strong) NSString *btnTitle;
@end
