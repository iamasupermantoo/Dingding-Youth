//
//  FKAttendedCourseCell.h
//  lbexam
//
//  Created by frankay on 17/1/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"


@protocol FKAttendedCourseCellDelegate <NSObject>

- (void)fk_GoToFeedbackWith:(NSDictionary *)info;

@end

@interface FKAttendedCourseCell : HMTableViewCell

@end


@interface FKAttendedCourseCellItem : HMTableViewCellItem
@property(nonatomic,assign) NSInteger btnstatus;
@end
