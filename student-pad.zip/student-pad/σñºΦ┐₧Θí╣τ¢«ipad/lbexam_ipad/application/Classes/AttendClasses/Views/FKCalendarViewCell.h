//
//  FKCalendarViewCell.h
//  lbexam
//
//  Created by frankay on 17/1/17.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"

@protocol FKCalendarViewCellDelegate <NSObject>

- (void)reloadCellHeight:(NSDictionary *)info;
- (void)getRemindData:(NSDictionary *)info;
- (void)getEmptyData:(NSDictionary *)info;
@end

@interface FKCalendarViewCell : HMTableViewCell
@property(nonatomic,strong) NSString *cid;
@end

@interface FKCalendarViewCellItem : HMTableViewCellItem

@property(nonatomic,strong) NSString *cid;
@end
