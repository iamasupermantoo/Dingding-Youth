//
//  FKCourseDetailBriefCell.m
//  lbexam
//
//  Created by frankay on 17/1/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCourseDetailBriefCell.h"
#import "FKCourseItem.h"
@interface FKCourseDetailBriefCell ()
@property (weak, nonatomic) IBOutlet UIImageView *CimageView;
@property (weak, nonatomic) IBOutlet FKinitLabel *Cname;
@property (weak, nonatomic) IBOutlet FKinitLabel *Ctime;
@property (weak, nonatomic) IBOutlet FKinitLabel *Cteacher;

@property (weak, nonatomic) IBOutlet FKinitLabel *Clevel;
@property (weak, nonatomic) IBOutlet FKinitLabel *Cfee;

@end
@implementation FKCourseDetailBriefCell


- (IBAction)clickAttendClassBtn:(UIButton *)sender {
    // 点击约课
    [self.deleagte hmTableViewCell:self sender:sender selector:@selector(CheckCourse:) userInfo:nil];
}



-(void)updateWithCellItem:(HMTableViewCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    FKCourseItem *courseItem = cellItem.rawObject;
    [self.CimageView hmLoadImageURL:[courseItem.imageItem imageUrlWithSide:75] placeholderImage:IMG_NAME(@"icon.jpg") local:YES];
    self.Cname.text = [NSString stringWithFormat:@"课程：%@",courseItem.name];
    self.Ctime.text = [NSString stringWithFormat:@"课次：%@节课",courseItem.totalCnt];
    self.Cteacher.text = [NSString stringWithFormat:@"老师：%@",courseItem.teacher];
    self.Clevel.text = [NSString stringWithFormat:@"level：%ld",(long)courseItem.level];
    self.Cfee.text = [NSString stringWithFormat:@"费用：%@/期",courseItem.teacher];
}


- (void)showImagesWithCellItem:(HMTableViewCellItem *)cellItem{
    [super showImagesWithCellItem:cellItem];
    FKCourseItem *courseItem = cellItem.rawObject;
    [self.CimageView hmLoadImageURL:[courseItem.imageItem imageUrlWithSide:75] placeholderImage:IMG_NAME(@"icon.jpg") local:NO];
}
@end

@implementation FKCourseDetailBriefCellItem

- (void)initSettings{
    [super initSettings];
    self.cellHeight = 185;
    self.separatorInset = kIpadNoGapSeperateInsets;
}

@end

