//
//  FKCourseViewCell.m
//  lbexam
//
//  Created by frankay on 17/1/13.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCourseViewCell.h"
#import "FKCourseItem.h"
#import "HMYellowButton.h"
@interface FKCourseViewCell ()
@property (weak, nonatomic) IBOutlet UIImageView *CimageView;
@property (weak, nonatomic) IBOutlet FKinitLabel *Cname;
@property (weak, nonatomic) IBOutlet FKinitLabel *CtotalTiem;
@property (weak, nonatomic) IBOutlet FKinitLabel *Cteacher;
@property (weak, nonatomic) IBOutlet UIButton *lessonBtn;

@property (weak, nonatomic) IBOutlet UIView *line1;

@property (weak, nonatomic) IBOutlet UIView *line2;

@end
@implementation FKCourseViewCell

- (void)initSettings{
    [super initSettings];
    self.Cteacher.hidden = YES;
    
    self.line1.backgroundColor = [UIColor hmBorderColor];
    self.line2.backgroundColor = [UIColor hmBorderColor];
    
}


- (void)updateWithCellItem:(FKCourseViewCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    FKCourseItem *courseItem = cellItem.rawObject;
    [self.CimageView hmLoadImageURL:[courseItem.imageItem imageUrlWithWidth:88 height:115] local:YES];
    
    self.Cname.text = [NSString stringWithFormat:@"课    程：%@",courseItem.name];
    self.CtotalTiem.text = [NSString stringWithFormat:@"总课次：%@节课",courseItem.totalCnt];
    self.Cteacher.text = [NSString stringWithFormat:@"时    间：%@",courseItem.time];
    if (cellItem.btnTitle) {
        [self.lessonBtn setTitle:@"返回" forState:UIControlStateNormal];
    }

}

- (void)showImagesWithCellItem:(FKCourseViewCellItem *)cellItem{
    
    [super showImagesWithCellItem:cellItem];
    FKCourseItem *courseItem = cellItem.rawObject;
    [self.CimageView hmLoadImageURL:[courseItem.imageItem imageUrlWithWidth:88 height:115] local:NO];
}


- (IBAction)Lessons:(id)sender {
    [self.deleagte hmTableViewCell:self sender:sender selector:@selector(ClickLessonButton:) userInfo:nil];
}

@end


@implementation FKCourseViewCellItem

- (void)initSettings{
    [super initSettings];
    self.cellHeight = 147;
    self.separatorInset = kIpadNoGapSeperateInsets;
}
@end
