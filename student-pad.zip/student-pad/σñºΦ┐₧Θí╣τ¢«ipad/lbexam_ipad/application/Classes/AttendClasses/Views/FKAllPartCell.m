//
//  FKAllPartCell.m
//  lbexam
//
//  Created by frankay on 17/1/16.
//  Copyright © 2017年 frankay. All rights reserved.
//


#import "FKAllPartCell.h"

@interface FKAllPartCell ()
@property (weak, nonatomic) IBOutlet UIView *lineView;
@property (weak, nonatomic) IBOutlet FKinitLabel *Lname;
@property (weak, nonatomic) IBOutlet FKinitLabel *Ldate;
@property (weak, nonatomic) IBOutlet FKinitLabel *Ltime;
@property (weak, nonatomic) IBOutlet FKinitLabel *Lstate;
@property (weak, nonatomic) IBOutlet HMYellowButton *replayBtn;
@property (weak, nonatomic) IBOutlet HMYellowButton *commentBtn;
@property (weak, nonatomic) IBOutlet HMYellowButton *feedBackBtn;
@property (weak, nonatomic) IBOutlet HMYellowButton *homeworkBtn;
@property (weak, nonatomic) IBOutlet UIView *BgContentView;

@end
@implementation FKAllPartCell

- (void)initSettings{
    [super initSettings];
    self.lineView.backgroundColor = [UIColor hmBorderColor];
    self.backgroundColor = [UIColor clearColor];
    self.Lstate.textColor = [UIColor hmTextGrayColor];
    
    self.BgContentView.layer.borderWidth = 0.5;
    self.BgContentView.layer.borderColor = [UIColor hmBorderColor].CGColor;
}

- (void)updateWithCellItem:(FKAllPartCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    FKCourseLessonItem *lessonItem = cellItem.rawObject;
    self.Lname.text = lessonItem.label;
    self.Ldate.text = lessonItem.date;
    self.Ltime.text = lessonItem.time;
    if (lessonItem.status == 0) {
        self.Lstate.text = @"未上课";
        self.Lstate.textColor = [UIColor fkfe8d25Color];
        self.replayBtn.enabled = NO;
        self.commentBtn.enabled = NO;
        self.homeworkBtn.enabled = NO;
        self.feedBackBtn.enabled = NO;
    }else{
        
        self.Lstate.text = @"已上课";
        self.Lstate.textColor = [UIColor hmTextGrayColor];
        self.replayBtn.enabled = YES;
        self.commentBtn.enabled = YES;
        [self.commentBtn setBackgroundImage:[UIImage ddImageWithColor:[UIColor fkfe8d25Color]] forState:UIControlStateNormal];
        self.homeworkBtn.enabled = YES;
    }
    
    if (lessonItem.studentReactionStatus == 0) {
        [self.commentBtn setTitle:@"评价" forState:UIControlStateNormal];
        self.commentBtn.tag = 1001;
    }else{
        [self.commentBtn setTitle:@"查看评价" forState:UIControlStateNormal];
        self.commentBtn.tag = 1002;
    }
    
    if (lessonItem.teacherReactionStatus==1) {
        self.feedBackBtn.enabled = YES;
        
    }else{
        self.feedBackBtn.enabled = NO;
    }
    
    if (lessonItem.homeworkStatus==0 || lessonItem.homeworkStatus==1) {
        // 未批改
        [self.homeworkBtn setTitle:HMLocal(@"提交作业") forState:UIControlStateNormal];
        
    }else{
        [self.homeworkBtn setTitle:HMLocal(@"查看批改") forState:UIControlStateNormal];
    }

}

// click action 回放
- (IBAction)ClickLreplay:(id)sender {
    [self.deleagte hmTableViewCell:self sender:sender selector:@selector(PartReplay:) userInfo:nil];
}

// 评论 或者查看评论
- (IBAction)ClickLappraize:(id)sender {
    [self.deleagte hmTableViewCell:self sender:sender selector:@selector(PartComment:) userInfo:nil];
}

// 反馈或者查看反馈
- (IBAction)ClickfeedBack:(id)sender {
    [self.deleagte hmTableViewCell:self sender:sender selector:@selector(PartFeedBack:) userInfo:nil];
}

// 作业
- (IBAction)HomeworkBtnAction:(id)sender {
     [self.deleagte hmTableViewCell:self sender:sender selector:@selector(PartHomework:) userInfo:nil];
}

@end


@implementation FKAllPartCellItem

- (void)initSettings{
    [super initSettings];
    self.cellHeight = 129;
//    self.hidenSeparator = YES;
    
}

@end



