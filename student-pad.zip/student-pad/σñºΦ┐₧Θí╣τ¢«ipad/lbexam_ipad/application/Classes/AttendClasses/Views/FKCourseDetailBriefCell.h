//
//  FKCourseDetailBriefCell.h
//  lbexam
//
//  Created by frankay on 17/1/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"

@protocol FKCourseDetailBriefCellDelegate <NSObject>

- (void)CheckCourse:(NSDictionary *)info;
@end

@interface FKCourseDetailBriefCell : HMTableViewCell

@end


@interface FKCourseDetailBriefCellItem : HMTableViewCellItem

@end
