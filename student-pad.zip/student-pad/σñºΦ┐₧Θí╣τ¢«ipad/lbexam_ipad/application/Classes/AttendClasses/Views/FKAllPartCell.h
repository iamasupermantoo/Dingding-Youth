//
//  FKAllPartCell.h
//  lbexam
//
//  Created by frankay on 17/1/16.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"
#import "FKCourseLessonItem.h"


@protocol FKAllPartCellDelegate <NSObject>

- (void)PartReplay:(NSDictionary *)info;
- (void)PartFeedBack:(NSDictionary *)info;
- (void)PartHomework:(NSDictionary *)info;
- (void)PartComment:(NSDictionary *)info;
@end

@interface FKAllPartCell : HMTableViewCell

@end


@interface FKAllPartCellItem : HMTableViewCellItem

@end
