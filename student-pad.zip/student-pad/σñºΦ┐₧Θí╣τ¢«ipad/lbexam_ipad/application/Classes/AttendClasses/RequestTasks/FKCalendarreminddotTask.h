//
//  FKCalendarreminddotTask.h
//  lbexam
//
//  Created by frankay on 17/1/18.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface FKCalendarreminddotTask : HMBaseRequestTask
@property(nonatomic,strong) NSString *cid;
@property(nonatomic,strong) NSString *month;
@end
