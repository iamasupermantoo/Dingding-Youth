//
//  FKCourseDetailRequestTask.m
//  lbexam
//
//  Created by frankay on 17/1/17.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCourseDetailRequestTask.h"

@implementation FKCourseDetailRequestTask
- (NSString *)apiName{
    return @"course/meta/details";
}


- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.cmid && [self.cmid ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"cmid"];
        
    }
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:self.cmid forKey:@"cmid"];
}
@end
