//
//  FKCalendarreminddotTask.m
//  lbexam
//
//  Created by frankay on 17/1/18.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCalendarreminddotTask.h"

@implementation FKCalendarreminddotTask

- (NSString *)apiName{
    return @"calendar/points";
}


- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.month && [self.month ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"cmid"];
    }
    
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    if (self.cid) {
        [self.parameterDictionary setObject:self.cid forKey:@"cid"];
    }
 
    [self.parameterDictionary setObject:self.month forKey:@"month"];
}

@end
