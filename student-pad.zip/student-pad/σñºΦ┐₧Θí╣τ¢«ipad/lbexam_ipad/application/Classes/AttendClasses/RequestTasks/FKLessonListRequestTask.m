//
//  FKLessonListRequestTask.m
//  lbexam
//
//  Created by frankay on 17/1/17.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKLessonListRequestTask.h"
#import "FKCourseLessonItem.h"
@implementation FKLessonListRequestTask


+ (BOOL)needLogin{
    return YES;
}


- (instancetype)init{
    self = [super init];
    if (self) {
        self.resultItemsKeyword = @"lessons";
    }
    return self;
}

- (Class)itemClass{
    return [FKCourseLessonItem class];
}


- (NSString *)apiName{
    return @"lesson/list";
}


- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.cid && [self.cid ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"cid"];

    }
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:self.cid forKey:@"cid"];
  }



@end
