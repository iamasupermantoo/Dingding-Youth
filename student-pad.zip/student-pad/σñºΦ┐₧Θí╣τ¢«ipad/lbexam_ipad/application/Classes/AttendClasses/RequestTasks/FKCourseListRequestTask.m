//
//  FKCourseListRequestTask.m
//  lbexam
//
//  Created by frankay on 17/1/17.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCourseListRequestTask.h"
#import "FKCourseItem.h"
@implementation FKCourseListRequestTask

+ (BOOL)needLogin{
    return YES;
}



- (NSString *)apiName{
    return @"course/list";
}



- (instancetype)init{
    self = [super init];
    if (self) {
        self.resultItemsKeyword = @"courses";
    }
    return self;
}

- (Class)itemClass{
    return [FKCourseItem class];
}


@end
