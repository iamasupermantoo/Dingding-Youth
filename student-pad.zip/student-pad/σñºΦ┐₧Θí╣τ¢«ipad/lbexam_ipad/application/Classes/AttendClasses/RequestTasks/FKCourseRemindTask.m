//
//  FKCourseRemindTask.m
//  lbexam
//
//  Created by frankay on 17/1/18.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCourseRemindTask.h"

@implementation FKCourseRemindTask
- (NSString *)apiName{
    return @"calendar/reminders";
}


- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.day && [self.day ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"day"];
    }
    
    return nil;
}


- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    if (self.cid) {
        [self.parameterDictionary setObject:self.cid forKey:@"cid"];
    }
    
    [self.parameterDictionary setObject:self.day forKey:@"day"];
}
@end
