//
//  FKGetUserInfoRequestTask.m
//  lbexam
//
//  Created by frankay on 17/2/25.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKGetUserInfoRequestTask.h"

@implementation FKGetUserInfoRequestTask
- (NSString *)apiName{
    return @"/mine/info";
}

+(BOOL)needLogin{
    return YES;
}

-(NSError *)responseHanlderWithDataInfo:(NSDictionary *)info{
    if (info[@"info"]) {
        
        [HMUserHandler sharedInstance].userItem = [HMUserItem itemWithDictionary:info[@"info"]];
        [[HMUserHandler sharedInstance] saveToLocal];
    }
    
    return [super responseHanlderWithDataInfo:info];
}
@end
