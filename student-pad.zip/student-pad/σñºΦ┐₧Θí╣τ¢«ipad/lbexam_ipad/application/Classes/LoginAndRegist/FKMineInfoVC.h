//
//  FKMineInfoVC.h
//  lbexam_ipad
//
//  Created by frankay on 17/5/28.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseViewController.h"


typedef NS_ENUM(NSUInteger, HMEditProfileTextType) {
    //    HMEditProfileTextTypeName, // 姓名
    HMEditProfileTextTypeGrade, // 年级
    HMEditProfileTextTypeHomeTown, // 家乡
    HMEditProfileTextTypeGender, // 性别
    HMEditProfileTextTypeSignature, // 签名
    
};
@interface FKMineInfoVC : HMBaseViewController

@end
