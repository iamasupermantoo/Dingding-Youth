//
//  HMRegisterViewController.m
//  UDan
//
//  Created by lilingang on 16/9/26.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMRegisterViewController.h"
//#import "HMPerfectProfileInfoViewController.h"
#import "HMYellowButton.h"
#import "HMCursorOffsetTextField.h"
#import "HMRegisterRequestTask.h"
#import "UIButton+UDanCountDown.h"
#import "NSString+UDan.h"

@interface HMRegisterViewController ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet HMCursorOffsetTextField *phoneTextField;
@property (weak, nonatomic) IBOutlet HMYellowButton *captchaButton;
@property (weak, nonatomic) IBOutlet HMCursorOffsetTextField *captchaTextField;
@property (weak, nonatomic) IBOutlet HMCursorOffsetTextField *passwordTextField;
@property (weak, nonatomic) IBOutlet UIButton *confirmButton;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *pswHeightConstraint;
@property(nonatomic,assign) BOOL isRegisted;

@property(nonatomic,strong) HMRegisterVerifyCodeRequestTask *registerVerifyCode;
@property(nonatomic,strong) HMForgetVerifyCodeRequestTask *forgetVerifyCode;
@property(nonatomic,strong) HMNotBindButRegistedRequestTask *notBindButRegistedTask;
@end

@implementation HMRegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = HMLocal(@"注册");
    [self.phoneTextField addTarget:self action:@selector(textFieldTextDidChange:) forControlEvents:UIControlEventAllEditingEvents];
    [self.captchaTextField addTarget:self action:@selector(textFieldTextDidChange:) forControlEvents:UIControlEventAllEditingEvents];
    [self.passwordTextField addTarget:self action:@selector(textFieldTextDidChange:) forControlEvents:UIControlEventAllEditingEvents];
    if (self.jumpType == FKJumpRegistVCTypeWxQq2Bind) {
        self.pswHeightConstraint.constant = 0.0;
        [self.confirmButton setTitle:@"绑定" forState:UIControlStateNormal];
        self.title = HMLocal(@"绑定");
        
    }else if (self.jumpType == FKJumpRegistVCTypeForget){
        self.title = HMLocal(@"找回密码");
    }
    self.phoneTextField.text = self.phoneNumber;
    self.captchaButton.countDownFormat = HMLocal(@"(%d)秒");
    self.captchaButton.finishedString = HMLocal(@"重发");
    
    [self initSetting];
}

- (void)initSetting{
    
    self.captchaTextField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:self.captchaTextField.placeholder attributes:@{NSForegroundColorAttributeName:[UIColor fkColorWithString:@"#767676"]}];

    self.passwordTextField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:self.passwordTextField.placeholder attributes:@{NSForegroundColorAttributeName:[UIColor fkColorWithString:@"#767676"]}];
    self.phoneTextField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:self.phoneTextField.placeholder attributes:@{NSForegroundColorAttributeName:[UIColor fkColorWithString:@"#767676"]}];
    
    self.captchaTextField.layer.borderWidth = 0.5;
    self.captchaTextField.layer.borderColor = [UIColor fkColorWithString:@"#c7c7c7"].CGColor;
    
    self.phoneTextField.layer.borderWidth = 0.5;
    self.phoneTextField.layer.borderColor = [UIColor fkColorWithString:@"#c7c7c7"].CGColor;
    
    self.passwordTextField.layer.borderWidth = 0.5;
    self.passwordTextField.layer.borderColor = [UIColor fkColorWithString:@"#c7c7c7"].CGColor;

}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if (self.phoneNumber && ![self.phoneNumber ddIsEmpty]) {
        self.captchaButton.enabled = YES;
    } else {
        self.captchaButton.enabled = NO;
    }
    
    if (self.jumpType != FKJumpRegistVCTypeWxQq2Bind) {
//        [self.phoneTextField becomeFirstResponder];

    }
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self.phoneTextField becomeFirstResponder];
    
}


- (void)resignTextFieldFirstResponder{
    if ([self.phoneTextField isFirstResponder]) {
        [self.phoneTextField resignFirstResponder];
    }
    if ([self.captchaTextField isFirstResponder]) {
        [self.captchaTextField resignFirstResponder];
    }
    if ([self.passwordTextField isFirstResponder]) {
        [self.passwordTextField resignFirstResponder];
    }
}

#pragma mark - Button Action

// get Verify code
- (IBAction)captchaButtonAction:(id)sender {
    [self.phoneTextField resignFirstResponder];
    if (![self.phoneTextField.text isPhoneNumber]) {
        [DDProgressHUD showErrorWithStatus:@"手机号有误"];
        return;
    }
    [self.captchaButton countDownWithTimeInterval:60];
    [DDProgressHUD showHUDWithStatus:@"获取验证码..."];
    
    HMBaseRegisterRequestTask *getCodeRequestTask;
    
    if (self.jumpType == FKJumpRegistVCTypeMobile) {
        // mobile
        getCodeRequestTask = [[HMRegisterGetCodeRequestTask alloc] init];
    }else if (self.jumpType == FKJumpRegistVCTypeForget){
        // forget password
        getCodeRequestTask = [[HMForgetGetCodeRequestTask alloc] init];
        
    }else if (self.jumpType == FKJumpRegistVCTypeWxQq2Bind){
        // bind
        getCodeRequestTask = [[HMBindGetCodeRequestTask alloc] init];
        if (_accountType == HMAccountTypeQQ) {
            // qq
            getCodeRequestTask.type = 1;
        }
        
        if (_accountType == HMAccountTypeWechat) {
            // wechat
            getCodeRequestTask.type = 2;
        }
    }
    
    getCodeRequestTask.mobile = self.phoneTextField.text;
    
    [getCodeRequestTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            [DDProgressHUD showSucessWithStatus:@"发送成功"];
            [self.captchaTextField becomeFirstResponder];
            
            if (self.jumpType == FKJumpRegistVCTypeWxQq2Bind) {
                // not regist  by code to update view
                if ([response[@"meta"][@"code"] integerValue]==1) {
                    
                    self.isRegisted = NO;
                    if (self.pswHeightConstraint.constant==0) {
                        self.pswHeightConstraint.constant = 45;
                    }
                    
                }else{
                    // regist
                    self.isRegisted = YES;
                    self.pswHeightConstraint.constant = 0;
                }
                
            }
        } else {
            [self.captchaButton stopCountDown];
        }
    }];

}

- (IBAction)confirmButtonAction:(id)sender {
//    [self pushToUserBasicInfoViewController];
    if (self.jumpType !=FKJumpRegistVCTypeWxQq2Bind) {
        NSString *password = self.passwordTextField.text;
        if ([password length] > 20 || [password length] < 6) {
            [DDProgressHUD showWithStatus:@"密码长度必须在6-20之间"];
            return;
        }
    }
    
    NSString *code = self.captchaTextField.text;
    if ([code length] > 8 || [code length] <= 0) {
        [DDProgressHUD showWithStatus:@"验证码格式错误"];
        return;
    }
    [self resignTextFieldFirstResponder];
    [DDProgressHUD showWithStatus:@"校验验证码..."];
    
    if (self.jumpType == FKJumpRegistVCTypeMobile) {
        // mobile
        [self VerifyCodetaskLoad:self.registerVerifyCode];
    }else if (self.jumpType == FKJumpRegistVCTypeForget){
        // forget password
        [self VerifyCodetaskLoad:self.forgetVerifyCode];
        
    }else if (self.jumpType == FKJumpRegistVCTypeWxQq2Bind){
        // bind
        if (!self.isRegisted) {
            [self VerifyCodetaskLoad:self.registerVerifyCode];
        }else{
            // regist
            [self VerifyCodetaskLoad:self.notBindButRegistedTask];
        }
    }
}

// verify code


- (void)VerifyCodetaskLoad:(id)task{
    
    [task loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            if (self.jumpType == FKJumpRegistVCTypeForget) {
                // forget password to login
                [DDProgressHUD showSucessWithStatus:@"修改成功,请重新登录"];
                [self.navigationController popViewControllerAnimated:YES];
            }
            
            if (self.jumpType == FKJumpRegistVCTypeMobile) {
                [DDProgressHUD showErrorWithStatus:@"iPad端还没有注册功能!"];

            }
            
            if (self.jumpType == FKJumpRegistVCTypeWxQq2Bind) {
                // if don't bind and mobile not regist to basic vc  if regist to mainvc
                if (self.isRegisted) {
                    // regist to mainvc
                    
                    // 如果在登陆状态就回到原界面  否则进入主页
                    if ([HMUserHandler sharedInstance].hasLogin) {
                        // 登陆状态
                        [DDProgressHUD showSucessWithStatus:@"绑定成功,进去首页"];
                        [HMRouterHandler revertToMainController];
                    }
                    
                }else{
                    // not regist to basicvc
                    [DDProgressHUD showErrorWithStatus:@"您还没有注册,请去手机端注册！"];
                }
            }
        }
    }];
}




#pragma mark - UITextFieldDelegate
- (void)textFieldTextDidChange:(UITextField *)textField{
    if (textField == self.phoneTextField) {
        if (![self.phoneTextField.text ddIsEmpty] && self.captchaButton.leaveTime == 0) {
            self.captchaButton.enabled = YES;
        } else {
            self.captchaButton.enabled = NO;
        }
    }
    
    if (![self.phoneTextField.text ddIsEmpty] && ![self.captchaTextField.text ddIsEmpty] && self.pswHeightConstraint.constant==0) {
        if (![self.passwordTextField.text ddIsEmpty]) {
            self.confirmButton.enabled = NO;

        }else{
            self.confirmButton.enabled = YES;
        }
        
    } else {
        if ([self.passwordTextField.text ddIsEmpty]) {
            self.confirmButton.enabled = NO;
            
        }else{
            self.confirmButton.enabled = YES;
        }
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if (textField == self.captchaTextField) {
        [self.passwordTextField becomeFirstResponder];
        return NO;
    }
    return YES;
}


// get
-(HMRegisterVerifyCodeRequestTask *)registerVerifyCode{
    if (!_registerVerifyCode) {
        _registerVerifyCode = [[HMRegisterVerifyCodeRequestTask alloc] init];
       
    }
    _registerVerifyCode.code = self.captchaTextField.text;
    _registerVerifyCode.mobile = self.phoneTextField.text;
    return _registerVerifyCode;
}

-(HMForgetVerifyCodeRequestTask *)forgetVerifyCode{
    if (!_forgetVerifyCode) {
        _forgetVerifyCode = [[HMForgetVerifyCodeRequestTask alloc] init];
      
    }
    _forgetVerifyCode.code = self.captchaTextField.text;
    _forgetVerifyCode.newpassword = self.passwordTextField.text;
    _forgetVerifyCode.mobile = self.phoneTextField.text;
    return _forgetVerifyCode;
}

- (HMNotBindButRegistedRequestTask *)notBindButRegistedTask{
    if (!_notBindButRegistedTask) {
        _notBindButRegistedTask = [[HMNotBindButRegistedRequestTask alloc] init];
     
    }
    _notBindButRegistedTask.mobile = self.phoneTextField.text;
    _notBindButRegistedTask.code = self.captchaTextField.text;
    _notBindButRegistedTask.type = self.accountType;
    _notBindButRegistedTask.externalUserId = self.externalUserId;
    _notBindButRegistedTask.accessToken = self.accessToken;
    _notBindButRegistedTask.nickname = self.nickname;
    
    _notBindButRegistedTask.refreshToken = self.refreshToken;

    return _notBindButRegistedTask;

}
@end
