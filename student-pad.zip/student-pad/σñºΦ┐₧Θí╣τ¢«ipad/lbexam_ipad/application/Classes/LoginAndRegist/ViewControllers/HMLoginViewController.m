//
//  HMLoginViewController.m
//  UDan
//
//  Created by lilingang on 16/9/26.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMLoginViewController.h"
#import "HMRegisterViewController.h"

#import "HMYellowButton.h"
#import "HMCursorOffsetTextField.h"
#import "HMLoginRequestTask.h"
#import "HMConfigRequestTask.h"


#import "HMRouterHandler.h"
#import "HMPushHandler.h"
#import "DDSocialShareHandler.h"

#import "UIAlertController+FKAlertController.h"
@interface HMLoginViewController ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet HMCursorOffsetTextField *phoneTextField;
@property (weak, nonatomic) IBOutlet HMCursorOffsetTextField *passwordTextField;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
@property (weak, nonatomic) IBOutlet UIButton *forgetPasswordButton;
@property (weak, nonatomic) IBOutlet UIButton *serviceButton;
@property (weak, nonatomic) IBOutlet UIButton *wechatLoginButton;
@property (weak, nonatomic) IBOutlet UIButton *qqLoginButton;
@property (weak, nonatomic) IBOutlet UIImageView *logoImageView;
@property (weak, nonatomic) IBOutlet UIView *line1;
@property (weak, nonatomic) IBOutlet UIView *line2;
@property (weak, nonatomic) IBOutlet UIButton *cuserviceBtn;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *LogoBottomConstraint;

@property (weak, nonatomic) IBOutlet UIView *loginBgView;

@property (weak, nonatomic) IBOutlet UIView *tapView;
@end

@implementation HMLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.title = HMLocal(@"登录");
    self.line1.backgroundColor = [UIColor clearColor];
    self.line2.backgroundColor = [UIColor hmTextGrayColor];
    [self.cuserviceBtn setTitleColor:[UIColor hmTextGrayColor] forState:UIControlStateNormal];
    self.LogoBottomConstraint.constant = (SCREENHEIGHT-490)/2;
    [self.phoneTextField addTarget:self action:@selector(textFieldTextDidChange:) forControlEvents:UIControlEventAllEditingEvents];
    [self.passwordTextField addTarget:self action:@selector(textFieldTextDidChange:) forControlEvents:UIControlEventAllEditingEvents];
    
    [self initSetting];
}




- (void)initSetting{
    
    self.passwordTextField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:self.passwordTextField.placeholder attributes:@{NSForegroundColorAttributeName:[UIColor fkColorWithString:@"#767676"]}];
     self.phoneTextField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:self.phoneTextField.placeholder attributes:@{NSForegroundColorAttributeName:[UIColor fkColorWithString:@"#767676"]}];
    //
    self.phoneTextField.layer.borderWidth = 0.5;
    self.phoneTextField.layer.borderColor = [UIColor fkColorWithString:@"#c7c7c7"].CGColor;
    
    self.passwordTextField.layer.borderColor = [UIColor fkColorWithString:@"#c7c7c7"].CGColor;
    self.passwordTextField.layer.borderWidth = 0.5;
    
    self.loginBgView.layer.borderWidth = 0.5;
    self.loginBgView.layer.borderColor = [UIColor hmYellowColor].CGColor;
    
    [self.wechatLoginButton setTitleEdgeInsets:UIEdgeInsetsMake(108, -53, 0, 0)];
    [self.wechatLoginButton setImageEdgeInsets:UIEdgeInsetsMake(0, 35, 0, 0)];
    
    [self.qqLoginButton setTitleEdgeInsets:UIEdgeInsetsMake(108, -53, 0, 0)];
    [self.qqLoginButton setImageEdgeInsets:UIEdgeInsetsMake(0, 35, 0, 0)];
    
    
    UITapGestureRecognizer *serverChangeTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(serverChangeTap)];
    serverChangeTap.numberOfTapsRequired = 10;
    [self.tapView addGestureRecognizer:serverChangeTap];

}

- (void)serverChangeTap{
    
    [UIAlertController formalServerAction:^{
        if ([[NSUserDefaults standardUserDefaults] objectForKey:@"FKDEBUG"]) {
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"FKDEBUG"];
            
            [[NSUserDefaults standardUserDefaults] synchronize];
            [DDProgressHUD showWithStatus:@"切换到正式服务器，请重新登录"];
            [HMRouterHandler revertToLoginController];
        }
    } andTestServerAction:^{
        
        [[NSUserDefaults standardUserDefaults] setObject:@"http://api.z.ziduan.com" forKey:@"FKDEBUG"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [DDProgressHUD showWithStatus:@"切换到测试服务器，请重新登录"];
        [HMRouterHandler revertToLoginController];
        
    } andLocalserverAction:^{
        
    } InController:self];
    
    
}


- (UIBarButtonItem *)leftBarButtonItem{
    return nil;
}


#pragma mark - Button Action

- (IBAction)loginButtonAction {
    NSString *phoneNumber = self.phoneTextField.text;
    NSString *password = self.passwordTextField.text;
    if (![phoneNumber isPhoneNumber]) {
        [DDProgressHUD showErrorWithStatus:@"手机号码有误"];
        return;
    }
    if ([password length] < 6 || [password length]> 20) {
        [DDProgressHUD showErrorWithStatus:@"密码长度必须限制在6-20个字符之间"];
        return;
    }
    
    [self loginReqeustWithAccountType:HMAccountTypeMobile phoneNumber:phoneNumber password:password externalUserId:nil];
}

// forget password
- (IBAction)forgetPasswordButtonAction {
    HMRegisterViewController *viewController = [[HMRegisterViewController alloc] init];
    viewController.jumpType = FKJumpRegistVCTypeForget;
    [self.navigationController pushViewController:viewController animated:YES];
    
}

// customer service
- (IBAction)serviceBtnAction:(UIButton *)sender {
    
    
}


// weixin login
- (IBAction)wechatLoginButtonAction:(id)sender {
    [self authrizeWithPlatformWith:DDSSPlatformWeChat];
}

// qq login
- (IBAction)qqLoginButtonAction:(id)sender {
//    [self loginWithPlatform:SSDKPlatformTypeQQ];
    [self authrizeWithPlatformWith:DDSSPlatformQQ];
}




#pragma mark - Private Method

- (void)authrizeWithPlatformWith:(DDSSPlatform)platform{
    
    [[DDSocialShareHandler sharedInstance] authWithPlatform:platform authMode:DDSSAuthModeCode controller:self handler:^(DDSSPlatform platform, DDSSAuthState state, DDAuthItem *authItem, NSError *error) {
        switch (state) {
            case DDSSAuthStateBegan: {
                NSLog(@"开始授权");
                break;
            }
            case DDSSAuthStateSuccess: {
                NSLog(@"授权成功：%@",authItem);
                HMAccountType accountType = HMAccountTypeQQ;
                if (platform == DDSSPlatformWeChat) {
                    accountType = HMAccountTypeWechat;
                    // it is wechat
                    [self getAccessTokenWithPara:authItem success:^(id ResponseObj) {
                        DDAuthItem *authItem = [[DDAuthItem alloc] initWithDic:ResponseObj];
                        
                        [[DDSocialShareHandler sharedInstance] getUserInfoWithPlatform:DDSSPlatformWeChat authItem:authItem handler:^(DDUserInfoItem *userInfoItem, NSError *error) {
                            
                            authItem.userInfo = userInfoItem;
                            [self handleJumpAsbindedcaseWith:authItem andtype:accountType];
                        }];
                        
                    } failure:^(NSError *error) {
                        [DDProgressHUD showWithStatus:@"授权失败,请重试"];
                    }];
                }
                
                if(platform == DDSSPlatformQQ){
                    // QQ
                    [[DDSocialShareHandler sharedInstance] getUserInfoWithPlatform:DDSSPlatformQQ authItem:authItem handler:^(DDUserInfoItem *userInfoItem, NSError *error) {
                        authItem.userInfo = userInfoItem;
                        [self handleJumpAsbindedcaseWith:authItem andtype:accountType];
                    }];
                }
                
                break;
            }
            case DDSSAuthStateFail: {
                NSLog(@"授权失败Error：%@",error);
                break;
            }
            case DDSSAuthStateCancel: {
                NSLog(@"授权取消");
                break;
            }
        }
    }];
    
}


// wechat getAccess_token
- (void)getAccessTokenWithPara:(DDAuthItem *)authItem success:(void (^)(id ResponseObj))success failure:(void (^)(NSError *))failure{
    NSString *url = [NSString stringWithFormat:@"https://api.weixin.qq.com/sns/oauth2/access_token?appid=%@&secret=%@&code=%@&grant_type=%@",@"wxeedfa061ec4d68c0",@"40536ac2f1972ec8fc74857e545189a3",authItem.thirdToken,@"authorization_code"];
    AFHTTPSessionManager *sessionManager = [AFHTTPSessionManager manager];
    sessionManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/html",@"text/json",@"text/javascript", @"text/plain", nil];
    [sessionManager GET:url parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        if (success) {
            success(responseObject);
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
    }];
}

// after getting access_token
- (void)handleJumpAsbindedcaseWith:(DDAuthItem *)authItem andtype:(HMAccountType)accountType{
    [DDProgressHUD showHUDWithStatus:@"登录..."];
    HMLoginConnectedBindRequestTask *bindRequestTask = [[HMLoginConnectedBindRequestTask alloc] init];
    bindRequestTask.accountType = accountType;
    bindRequestTask.externalUserId = authItem.thirdId;
    bindRequestTask.nickname = authItem.userInfo.nickName;
    [bindRequestTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            BOOL isBind = [response[@"meta"][@"code"] integerValue]== 1?YES:NO;
            [DDProgressHUD dismiss];
            
            if (isBind) {
                // bind to mainvc
                [DDProgressHUD showWithStatus:@"账号已经绑定，登陆到首页"];
                [HMRouterHandler revertToMainController];
                
            } else {
                // not bind to bindVC
                [UIAlertController showWithTitle:@"您还没绑定手机号哦~" WithAction1Title:@"取消" WithAction2Title:@"去绑定" andconfirmBlock:^{
                    HMRegisterViewController *viewController = [[HMRegisterViewController alloc] init];
                    viewController.jumpType = FKJumpRegistVCTypeWxQq2Bind;
                    viewController.accountType = accountType;
                    viewController.externalUserId = authItem.thirdId;
                    viewController.accessToken = authItem.thirdToken;
                    viewController.refreshToken = authItem.refresh_token;
                    viewController.nickname = authItem.userInfo.nickName;
                    [self.navigationController pushViewController:viewController animated:YES];
                } andcancelBlock:nil Incontroller:self];
                
                
                //
            }

        }
   }];
    
}

- (void)loginReqeustWithAccountType:(HMAccountType)type phoneNumber:(NSString *)phone password:(NSString *)password externalUserId:(NSString *)uid{
    [DDProgressHUD showHUDWithStatus:@"登录中..."];
    HMLoginMobileRequestTask *loginMobileRequestTask = [[HMLoginMobileRequestTask alloc] init];
    loginMobileRequestTask.accountType = type;
    loginMobileRequestTask.mobile = phone;
    loginMobileRequestTask.password = password;
    loginMobileRequestTask.externalUserId = uid;
    [loginMobileRequestTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {

        if (!error) {
            [DDProgressHUD showSucessWithStatus:@"登陆成功！"];
            [HMRouterHandler revertToMainController];

        }
        
        }
    ];
  
}

#pragma mark - UITextFieldDelegate
- (void)textFieldTextDidChange:(UITextField *)textField{
    if ([self.phoneTextField.text length] > 0 && [self.passwordTextField.text length] > 0) {
        self.loginButton.enabled = YES;
    } else {
        self.loginButton.enabled = NO;
    }
}



@end
