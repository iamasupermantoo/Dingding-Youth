//
//  HMRegisterViewController.h
//  UDan
//
//  Created by lilingang on 16/9/26.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseViewController.h"

@interface HMRegisterViewController : HMBaseViewController

@property (nonatomic, assign) HMAccountType accountType;

@property (nonatomic, copy) NSString *phoneNumber;

@property (nonatomic, copy) NSString *externalUserId;
@property (nonatomic, copy) NSString *accessToken;
@property (nonatomic, copy) NSString *refreshToken;
@property(nonatomic,strong) NSString *nickname;

@property(nonatomic,assign) FKJumpRegistVCType jumpType;
@end
