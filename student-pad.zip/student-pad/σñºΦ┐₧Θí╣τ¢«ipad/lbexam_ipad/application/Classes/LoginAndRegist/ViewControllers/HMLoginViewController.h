//
//  HMLoginViewController.h
//  UDan
//
//  Created by lilingang on 16/9/26.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMBaseViewController.h"

@interface HMLoginViewController : HMBaseViewController

@end
