//
//  FKMineInfoVC.m
//  lbexam_ipad
//
//  Created by frankay on 17/5/28.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKMineInfoVC.h"
#import "HMLogoutRequestTask.h"
#import "HMLoginHandler.h"
#import "FKGetUserInfoRequestTask.h"
#import "FKModifyUserInfoRequestTask.h"
#import "HMSinglePickerView.h"
#import "HMCityPickerView.h"
#import <YYWebImage/YYImageCache.h>
#import <YYCache/YYCache.h>
#import "WSRequestCache.h"
@interface FKMineInfoVC ()<HMSinglePickerViewDelegate,HMSinglePickerViewDataSource,HMCityPickerViewDelegate>
@property (weak, nonatomic) IBOutlet UIView *nameVIew;
@property (weak, nonatomic) IBOutlet UIView *sexView;
@property (weak, nonatomic) IBOutlet UIView *eduView;
@property (weak, nonatomic) IBOutlet UIView *hometownView;
@property (weak, nonatomic) IBOutlet UIView *signView;


@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UIImageView *nameArrow;

@property (weak, nonatomic) IBOutlet UILabel *sexLabel;
@property (weak, nonatomic) IBOutlet UIImageView *sexArrow;
@property (weak, nonatomic) IBOutlet UITextField *eduLabel;
@property (weak, nonatomic) IBOutlet UIImageView *eduArrow;
@property (weak, nonatomic) IBOutlet UILabel *homeTownTextField;
@property (weak, nonatomic) IBOutlet UIImageView *homeTownArrow;

@property (weak, nonatomic) IBOutlet UITextField *signTextField;
@property (weak, nonatomic) IBOutlet UIImageView *signArrow;

@property (weak, nonatomic) IBOutlet UIButton *editBtn;

@property(nonatomic,copy) HMUserItem *changedUserItem;

@property(nonatomic,strong) FKModifyUserInfoRequestTask *modifyTask;

@property(nonatomic,strong) NSArray *academicArr; // 学历
@property(nonatomic,strong) NSArray *genderArr; // 性别

@end

@implementation FKMineInfoVC


-(FKModifyUserInfoRequestTask *)modifyTask{
    if (!_modifyTask) {
        _modifyTask = [[FKModifyUserInfoRequestTask alloc] init];
    }
    return _modifyTask;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = HMLocal(@"个人资料");
    [self arrowHiden:YES];
    [self.sexView ddAddTarget:self tapAction:@selector(sexViewAction:)];
    self.eduLabel.placeholder = @"";
    self.nameTextField.placeholder = @"";
    self.signTextField.placeholder = @"";
//    [self.eduView ddAddTarget:self tapAction:@selector(eduViewAction:)];
    [self.hometownView ddAddTarget:self tapAction:@selector(homeTownViewAction:)];
    // Do any additional setup after loading the view from its nib.
    self.academicArr = @[@(HMUserTypeSenior),@(HMUserTypeUniversity)];
    self.genderArr = @[@(HMGenderTypeMale),@(HMGenderTypeFemale)];
    
 

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self getInfo];

}

-(void)getInfo{

    FKGetUserInfoRequestTask *getinfoTask = [[FKGetUserInfoRequestTask alloc] init];
    [getinfoTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            // 获取信息之后
            self.changedUserItem = [HMUserHandler sharedInstance].userItem;
            self.nameTextField.text = self.changedUserItem.name;
            self.sexLabel.text = [NSString stringWithGenderType:self.changedUserItem.gender];
            
            self.eduLabel.text = self.changedUserItem.grade;
            self.homeTownTextField.text = (self.changedUserItem.province==nil||self.changedUserItem.region==nil)?@"": [NSString stringWithFormat:@"%@ %@",self.changedUserItem.province,self.changedUserItem.region];
            self.signTextField.text = self.changedUserItem.signature;
            
        }
        
    }];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.editBtn.selected = NO;
    [self arrowHiden:YES];
    
    UIView *view = [self.view viewWithTag:10001];
    
    if (view==nil) {
        return;
    }
    if ([view isKindOfClass:[HMSinglePickerView class]]) {
        // 是单个
        HMSinglePickerView *singleView = (HMSinglePickerView *)view;
        [singleView dismissWithAnimated:YES completion:nil];
    }
    
    
    if ([view isKindOfClass:[HMCityPickerView class]]) {
        // 是单个
        HMCityPickerView *cityView = (HMCityPickerView *)view;
        [cityView dismissWithAnimated:YES completion:nil];
    }
}


-(UIBarButtonItem *)leftBarButtonItem{
    return nil;
}

- (IBAction)editBtnAction:(UIButton *)sender {
    if (!sender.selected) {
        // 变为选中状态
        sender.selected = YES;
        self.eduLabel.placeholder = @"请输入年级";
        self.nameTextField.placeholder = @"请输入姓名";
        self.signTextField.placeholder = @"请输入签名";
        [self arrowHiden:NO];
        
    }else{
     
        if ([self.nameTextField.text ddIsEmpty] || [self.eduLabel.text ddIsEmpty] ||self.changedUserItem.gender==-1 ||[self.changedUserItem.province ddIsEmpty] || [self.changedUserItem.region ddIsEmpty]) {
            [DDProgressHUD showErrorWithStatus:@"请完善资料!"];
            return;
        }
        sender.selected = NO;
        [self arrowHiden:YES];
        self.eduLabel.placeholder = @"";
        self.nameTextField.placeholder = @"";
        self.signTextField.placeholder = @"";
        self.modifyTask.name = self.nameTextField.text;
        self.modifyTask.grade = self.eduLabel.text;
        self.modifyTask.province = self.changedUserItem.province;
        self.modifyTask.region = self.changedUserItem.region;
        self.modifyTask.signature = self.changedUserItem.signature;
        self.modifyTask.gender = self.changedUserItem.gender;
        self.modifyTask.headImg = self.changedUserItem.headImage.udid;
        [DDProgressHUD showHUDWithStatus:@"正在修改资料..."];
        [self.modifyTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
            if (!error) {
                
                self.changedUserItem.name = self.nameTextField.text;
                self.changedUserItem.grade = self.eduLabel.text;
                [HMUserHandler sharedInstance].userItem = self.changedUserItem;
                [[HMUserHandler sharedInstance] saveToLocal];
                [DDProgressHUD showSucessWithStatus:@"修改资料成功！"];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"modifyName" object:nil];
            }
        }];
    }
    
}


- (void)arrowHiden:(BOOL)isHiden{
    if (isHiden) {
        self.nameTextField.enabled = NO;
        self.signTextField.enabled = NO;
        self.eduLabel.enabled = NO;
    }else{
        self.nameTextField.enabled = YES;
        self.signTextField.enabled = YES;
        self.eduLabel.enabled = YES;
    }
    
    self.nameArrow.hidden = isHiden;
    self.sexArrow.hidden = isHiden;
    self.eduArrow.hidden = isHiden;
    self.homeTownArrow.hidden = isHiden;
    self.signArrow.hidden = isHiden;

}

#pragma mark - label action
- (void)sexViewAction:(UIGestureRecognizer *)tap{
    if (self.editBtn.selected) {
        // edit
        HMSinglePickerView *singlePickerView = [[HMSinglePickerView alloc] init];
        singlePickerView.delegate = self;
        singlePickerView.dataSource = self;
        singlePickerView.identify = @(HMEditProfileTextTypeGender);
        [singlePickerView.pickerView selectRow:self.changedUserItem.gender inComponent:0 animated:NO];
        singlePickerView.tag = 10001;
        [self.view addSubview:singlePickerView];
        [singlePickerView showAnimated:YES completion:nil];
    }
    
}

- (void)eduViewAction:(UIGestureRecognizer *)tap{
    if (self.editBtn.selected) {
        // edit
        HMSinglePickerView *singlePickerView = [[HMSinglePickerView alloc] init];
        singlePickerView.delegate = self;
        singlePickerView.dataSource = self;
        singlePickerView.identify = @(HMEditProfileTextTypeGrade);
        singlePickerView.tag = 10001;
        [singlePickerView.pickerView selectRow:0 inComponent:0 animated:NO];
        [self.view addSubview:singlePickerView];
        
        [singlePickerView showAnimated:YES completion:nil];
    }
    
}


- (void)homeTownViewAction:(UIGestureRecognizer *)tap{
    if (self.editBtn.selected) {
        // edit
        HMCityPickerView *cityPicker = [[HMCityPickerView alloc] init];
        cityPicker.tag=10001;
        cityPicker.delegate = self;
        
        [cityPicker selectedProvince:self.changedUserItem.province city:self.changedUserItem.region animated:NO];
        [self.view addSubview:cityPicker];
        [cityPicker showAnimated:YES completion:nil];
    }
}

#pragma mark - HMSinglePickerViewDataSource
- (NSInteger)hmNumberOfRowsInSinglePickerView:(HMSinglePickerView *)pickerView{
    HMEditProfileTextType textType = [pickerView.identify integerValue];
    if (textType == HMEditProfileTextTypeGrade) {
        // 年级
        return self.academicArr.count;
    }else if(textType == HMEditProfileTextTypeGender){
        return self.genderArr.count;
    }
    return 0;
}

- (NSString *)hmSinglePickerView:(HMSinglePickerView *)pickerView titleOfRow:(NSInteger)row{
    HMEditProfileTextType textType = [pickerView.identify integerValue];
    if (textType == HMEditProfileTextTypeGrade) {
        return [NSString stringWithUserType:[self.academicArr[row] integerValue]];
    }else if (textType == HMEditProfileTextTypeGender){
        
        return [NSString stringWithGenderType:[self.genderArr[row] integerValue]];
    }
    return nil;
}

#pragma mark - HMSinglePickerViewDelegate

- (void)hmSinglePickerView:(HMSinglePickerView *)pickerView didIndex:(NSInteger)index{
//    HMUserItem *userItem = self.changedUserItem;
    HMEditProfileTextType textType = [pickerView.identify integerValue];
    if (textType == HMEditProfileTextTypeGrade) {
        self.eduLabel.text =[NSString stringWithUserType:[self.academicArr[index] integerValue]];
        self.changedUserItem.grade = [NSString stringWithUserType:[self.academicArr[index] integerValue]];
    }
    
    if (textType == HMEditProfileTextTypeGender) {
        self.sexLabel.text = [NSString stringWithGenderType:[self.genderArr[index] integerValue]];
        self.changedUserItem.gender = [self.genderArr[index] integerValue];
    }
    
}



#pragma mark - HMCityPickerViewDelegate

- (void)hmCityPickerViewDidSelectedProvince:(HMCityItem *)provinceItem cityItem:(HMCityItem *)cityItem{
    HMUserItem *userItem = self.changedUserItem;
    userItem.province = provinceItem.name;
    userItem.region = cityItem.name;
    self.homeTownTextField.text = [NSString stringWithFormat:@"%@ %@",provinceItem.name,cityItem.name];
    
    
}


- (IBAction)logoutBtnAction:(UIButton *)sender {
    [DDProgressHUD showHUDWithStatus:@"退出登录..."];
    HMLogoutRequestTask *logoutRequestTask = [[HMLogoutRequestTask alloc] init];
    [logoutRequestTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            
            // 清除缓存
            [[WSRequestCache shareInstance] clearAllCacheCompleteHandler:^(NSError *error) {
            }];
            
            [[YYImageCache sharedCache].memoryCache removeAllObjects];
            
            [[YYImageCache sharedCache].diskCache removeAllObjectsWithBlock:^{
            }];
            
            [DDProgressHUD dismiss];
            [[HMLoginHandler sharedInstance] logout];
        } else {
            
        }
    }];
    
}


@end
