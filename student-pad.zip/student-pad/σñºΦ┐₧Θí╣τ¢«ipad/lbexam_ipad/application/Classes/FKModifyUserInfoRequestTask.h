//
//  FKModifyUserInfoRequestTask.h
//  lbexam
//
//  Created by frankay on 17/2/25.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface FKModifyUserInfoRequestTask : HMBaseRequestTask
@property(nonatomic,strong) NSString *name;
@property(nonatomic,strong) NSString *grade;
@property(nonatomic,strong) NSString *province;
@property(nonatomic,strong) NSString *region;
@property(nonatomic,assign) HMGenderType gender;
@property(nonatomic,strong) NSString *signature;
@property(nonatomic,strong) NSString *headImg;

@end
