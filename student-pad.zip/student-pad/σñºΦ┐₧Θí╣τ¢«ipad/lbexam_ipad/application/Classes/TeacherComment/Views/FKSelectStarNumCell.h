//
//  FKSelectStarNumCell.h
//  lbexam_ipad
//
//  Created by frankay on 17/2/24.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"


@protocol FKSelectStarNumCellDelegate <NSObject>

- (void)fk_selectStarWith:(NSDictionary *)info;
- (void)fk_commitBtnActionWith:(NSDictionary *)info;
@end
@interface FKSelectStarNumCell : HMTableViewCell

@end

@class HMImageItem;
@interface FKSelectStarNumCellItem : HMTableViewCellItem
@property(nonatomic,assign) NSInteger starselNum;
@property(nonatomic,strong) NSString *teacher;
@property(nonatomic,strong) NSString *markForTeacher;
@property(nonatomic,strong) HMImageItem *ImageItem;
@end
