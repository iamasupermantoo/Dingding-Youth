//
//  FKCommentLessonCell.m
//  lbexam_ipad
//
//  Created by frankay on 17/5/28.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCommentLessonCell.h"
#import "FKCourseItem.h"
@interface FKCommentLessonCell ()
@property (weak, nonatomic) IBOutlet UIImageView *courseImageView;
@property (weak, nonatomic) IBOutlet UILabel *lessonName;
@property (weak, nonatomic) IBOutlet FKinitLabel *courseName;
@property (weak, nonatomic) IBOutlet FKinitLabel *time;

@property (weak, nonatomic) IBOutlet FKinitLabel *teacherName;

@property (weak, nonatomic) IBOutlet UIButton *goCommentBtn;

@end

@implementation FKCommentLessonCell



- (void)updateWithCellItem:(FKCommentLessonCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    FKCourseItem *item = cellItem.rawObject;
    [self.courseImageView hmLoadImageURL:[item.imageItem imageUrlWithWidth:88 height:115] local:YES];
    self.lessonName.text = [NSString stringWithFormat:@"第%@节课",item.cnt];
    self.courseName.text = item.course;
    self.teacherName.text = [NSString stringWithFormat:@"老师：%@",item.teacher];
    self.time.text = [NSString stringWithFormat:@"时间：%@",item.date];
    
    if (cellItem.type==1) {
        [self.goCommentBtn setTitle:@"查看评价" forState:UIControlStateNormal];
    }
    
    
}


- (void)showImagesWithCellItem:(HMTableViewCellItem *)cellItem{
    [super showImagesWithCellItem:cellItem];
    self.courseImageView.image = nil;
    
    FKCourseItem *item = cellItem.rawObject;
    [self.courseImageView hmLoadImageURL:[item.imageItem imageUrlWithWidth:88 height:115] local:NO];
}


- (IBAction)goCommentAction:(UIButton *)sender {
    
    [self.deleagte hmTableViewCell:self sender:sender selector:@selector(fk_goCommentAction:) userInfo:nil];
}

@end



@implementation FKCommentLessonCellItem

- (void)initSettings{
    [super initSettings];
    self.cellHeight = 155;
    self.separatorInset = kIpadNoGapSeperateInsets;
    
}

@end
