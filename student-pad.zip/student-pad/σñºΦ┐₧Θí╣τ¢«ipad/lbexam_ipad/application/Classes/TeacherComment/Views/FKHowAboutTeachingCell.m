//
//  FKHowAboutTeachingCell.m
//  lbexam_ipad
//
//  Created by frankay on 17/2/23.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKHowAboutTeachingCell.h"

@interface FKHowAboutTeachingCell ()
@property (weak, nonatomic) IBOutlet UIView *firstbgView;
@property (weak, nonatomic) IBOutlet UIView *secondbgView;
@property (weak, nonatomic) IBOutlet UIView *thirdbgView;
@property (weak, nonatomic) IBOutlet UIView *fourthbgView;


@property (weak, nonatomic) IBOutlet UIImageView *firstAnswer;
@property (weak, nonatomic) IBOutlet UIImageView *secondAnswer;
@property (weak, nonatomic) IBOutlet UIImageView *thirdAnswer;
@property (weak, nonatomic) IBOutlet UIImageView *fourAnswer;

@end
@implementation FKHowAboutTeachingCell

-(void)initSettings{
    [super initSettings];
    self.firstbgView.tag = 1004;
    [self.firstbgView ddAddTarget:self tapAction:@selector(selectAnswerAction:)];
    self.secondbgView.tag = 1003;
    [self.secondbgView ddAddTarget:self tapAction:@selector(selectAnswerAction:)];
    self.thirdbgView.tag = 1002;
    [self.thirdbgView ddAddTarget:self tapAction:@selector(selectAnswerAction:)];
    self.fourthbgView.tag = 1001;
    [self.fourthbgView ddAddTarget:self tapAction:@selector(selectAnswerAction:)];
    
}


- (void)selectAnswerAction:(UIGestureRecognizer *)tap{
    UIView *view = tap.view;
    [self.deleagte hmTableViewCell:self sender:tap selector:@selector(HowAboutTeachingSelectAnswerWith:) userInfo:@{@"tag":@(view.tag-1000)}];
}

-(void)updateWithCellItem:(FKHowAboutTeachingCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    if (cellItem.selectAnswer==4) {
        self.firstAnswer.image = IMG_NAME(@"fb_circlesel");
        self.secondAnswer.image = IMG_NAME(@"fb_circle");
        self.thirdAnswer.image = IMG_NAME(@"fb_circle");
        self.fourAnswer.image = IMG_NAME(@"fb_circle");
    }
    if (cellItem.selectAnswer==3) {
        self.firstAnswer.image = IMG_NAME(@"fb_circle");
        self.secondAnswer.image = IMG_NAME(@"fb_circlesel");
        self.thirdAnswer.image = IMG_NAME(@"fb_circle");
        self.fourAnswer.image = IMG_NAME(@"fb_circle");
    }
    if (cellItem.selectAnswer==2) {
        self.firstAnswer.image = IMG_NAME(@"fb_circle");
        self.secondAnswer.image = IMG_NAME(@"fb_circle");
        self.thirdAnswer.image = IMG_NAME(@"fb_circlesel");
        self.fourAnswer.image = IMG_NAME(@"fb_circle");
    }
    
    if (cellItem.selectAnswer==1) {
        self.firstAnswer.image = IMG_NAME(@"fb_circle");
        self.secondAnswer.image = IMG_NAME(@"fb_circle");
        self.thirdAnswer.image = IMG_NAME(@"fb_circle");
        self.fourAnswer.image = IMG_NAME(@"fb_circlesel");
    }
    
}

@end



@implementation FKHowAboutTeachingCellItem

- (void)initSettings{
    [super initSettings];
    self.canSelect = NO;
    self.separatorInset = kIpadNoGapSeperateInsets;
    self.cellHeight = 177.5;
}

@end
