//
//  FKCommentContentCell.h
//  lbexam
//
//  Created by frankay on 17/2/25.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"


@interface FKCommentContentCell : HMTableViewCell

@end


@interface FKCommentContentCellItem : HMTableViewCellItem
@property(nonatomic,strong) NSString *titlestr;
@property(nonatomic,strong) NSAttributedString *attr;
@end
