//
//  FKHowAboutTeachingCell.h
//  lbexam_ipad
//
//  Created by frankay on 17/2/23.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"

@protocol FKHowAboutTeachingCellDelegate <NSObject>

- (void)HowAboutTeachingSelectAnswerWith:(NSDictionary *)info;

@end

@interface FKHowAboutTeachingCell : HMTableViewCell

@end

@interface FKHowAboutTeachingCellItem : HMTableViewCellItem
@property(nonatomic,assign)NSInteger selectAnswer;
@end
