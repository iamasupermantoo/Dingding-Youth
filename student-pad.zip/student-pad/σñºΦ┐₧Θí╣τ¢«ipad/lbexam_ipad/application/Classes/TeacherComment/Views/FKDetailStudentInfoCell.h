//
//  FKDetailStudentInfoCell.h
//  lbexam
//
//  Created by frankay on 17/2/27.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"

@interface FKDetailStudentInfoCell : HMTableViewCell

@end


@interface FKDetailStudentInfoCellItem : HMTableViewCellItem

@end
