//
//  FKLearnLevelCell.h
//  lbexam_ipad
//
//  Created by frankay on 17/2/23.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"

@protocol FKLearnLevelCellDelegate <NSObject>

- (void)fk_LearnLevelCellSelectAnswerWith:(NSDictionary *)info;

@end

@interface FKLearnLevelCell : HMTableViewCell

@end


@interface FKLearnLevelCellItem : HMTableViewCellItem
@property(nonatomic,assign)NSInteger selectAnswer;

@end
