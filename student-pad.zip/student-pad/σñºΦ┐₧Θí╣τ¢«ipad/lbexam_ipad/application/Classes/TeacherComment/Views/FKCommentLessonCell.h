//
//  FKCommentLessonCell.h
//  lbexam_ipad
//
//  Created by frankay on 17/5/28.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"


@protocol FKCommentLessonCellDelegate <NSObject>

- (void)fk_goCommentAction:(NSDictionary *)info;

@end

@interface FKCommentLessonCell : HMTableViewCell

@end


@interface FKCommentLessonCellItem : HMTableViewCellItem
@property(nonatomic,assign) NSInteger type; //
@end
