//
//  FKRemarkinfoCell.h
//  lbexam_ipad
//
//  Created by frankay on 17/2/23.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"


@protocol FKRemarkinfoCellDelegate <NSObject>

- (void)fk_fillinTextViewWithText:(NSDictionary *)info;

@end

@interface FKRemarkinfoCell : HMTableViewCell

@end

@interface FKRemarkinfoCellItem : HMTableViewCellItem
@property(nonatomic,assign) BOOL isInactive;
@end
