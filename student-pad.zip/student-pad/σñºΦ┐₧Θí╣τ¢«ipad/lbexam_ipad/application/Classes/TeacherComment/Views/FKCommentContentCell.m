//
//  FKCommentContentCell.m
//  lbexam
//
//  Created by frankay on 17/2/25.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCommentContentCell.h"


@interface FKCommentContentCell ()
@property (weak, nonatomic) IBOutlet UIView *lineView;
@property (weak, nonatomic) IBOutlet FKinitLabel *title;
@property (weak, nonatomic) IBOutlet FKinitLabel *content;

@end
@implementation FKCommentContentCell

- (void)initSettings{
    [super initSettings];
    self.content.textColor = [UIColor fk666Color];
}

-(void)updateWithCellItem:(FKCommentContentCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    
    self.title.text = cellItem.titlestr;
    if (cellItem.attr) {
        self.content.attributedText = cellItem.attr;
    }else{
        self.content.text = cellItem.rawObject;
    }
}

@end

@implementation FKCommentContentCellItem
- (void)initSettings{
    [super initSettings];
    self.separatorInset = kIpadNoGapSeperateInsets;
    self.canSelect = NO;
    self.cellHeight = 72;
}

- (void)setRawObject:(id)rawObject{

    [super setRawObject:rawObject];
    if (rawObject==nil) {
        return;
    }
    NSString *content = rawObject;
    UIFont *font = [UIFont systemFontOfSize:15];
    CGFloat textHeight = [content HeightWithFont:font maxSize:SCREENWIDTH-40];
    if (textHeight>ceil(font.lineHeight)) {
        self.attr = [content attributedStringWithTextFont:font];
    }
    
    if ([self.titlestr isEqualToString:@"本次备注"]) {
        self.cellHeight = 71+textHeight;
    }else
    self.cellHeight = 51+textHeight;
}

@end
