//
//  FKRemarkinfoCell.m
//  lbexam_ipad
//
//  Created by frankay on 17/2/23.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKRemarkinfoCell.h"
#import "UITextView+Placeholder.h"

@interface FKRemarkinfoCell ()<UITextViewDelegate>

@property (weak, nonatomic) IBOutlet UITextView *textView;

@end
@implementation FKRemarkinfoCell
- (void)initSettings{
    [super initSettings];
    
    self.textView.delegate = self;
    self.textView.attributedPlaceholder = [[NSAttributedString alloc] initWithString:HMLocal(@"请输入备注内容") attributes:@{NSFontAttributeName:self.textView.font,
                                                                                                                    NSForegroundColorAttributeName:[UIColor hmBorderColor]}];
}

//-(void)updateWithCellItem:(FKRemarkinfoCellItem *)cellItem{
//    [super updateWithCellItem:cellItem];
//    self.textView.text = cellItem.rawObject;
//    if (cellItem.isInactive) {
//        self.textView.userInteractionEnabled = NO;
//    }
//}


- (void)textViewDidEndEditing:(UITextView *)textView{
    [textView resignFirstResponder];
    [self.deleagte hmTableViewCell:self sender:textView selector:@selector(fk_fillinTextViewWithText:) userInfo:@{@"text":textView.text}];
}
@end


@implementation FKRemarkinfoCellItem

- (void)initSettings{
    [super initSettings];
    self.canSelect = NO;
    self.separatorInset = kIpadNoGapSeperateInsets;
    self.cellHeight = 131;
}

@end
