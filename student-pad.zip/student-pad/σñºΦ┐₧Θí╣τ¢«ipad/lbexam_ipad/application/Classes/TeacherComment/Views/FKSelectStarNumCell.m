//
//  FKSelectStarNumCell.m
//  lbexam_ipad
//
//  Created by frankay on 17/2/24.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKSelectStarNumCell.h"
#import "HMYellowButton.h"
#import "HMImageItem.h"
@interface FKSelectStarNumCell ()
@property (weak, nonatomic) IBOutlet UIImageView *t_icon;
@property (weak, nonatomic) IBOutlet FKinitLabel *t_name;
@property (weak, nonatomic) IBOutlet UILabel *markForTeacher;
@property (weak, nonatomic) IBOutlet UIView *line1;
@property (weak, nonatomic) IBOutlet UIView *line2;
@property (weak, nonatomic) IBOutlet UIView *starBgView;
@property (weak, nonatomic) IBOutlet UIImageView *star1;
@property (weak, nonatomic) IBOutlet UIImageView *star2;
@property (weak, nonatomic) IBOutlet UIImageView *star3;
@property (weak, nonatomic) IBOutlet UIImageView *star4;
@property (weak, nonatomic) IBOutlet UIImageView *star5;
@property (weak, nonatomic) IBOutlet UIView *bgView;

@end

@implementation FKSelectStarNumCell

- (void)initSettings{
    [super initSettings];
    self.markForTeacher.textColor = [UIColor hmTextGrayColor];
    self.line1.backgroundColor = [UIColor hmTextGrayColor];
    self.line2.backgroundColor = [UIColor hmTextGrayColor];
    self.bgView.backgroundColor = [UIColor hmMainBgColor];
    [self.star1 ddAddTarget:self tapAction:@selector(selectStar:)];
    self.star1.tag = 1001;
    [self.star2 ddAddTarget:self tapAction:@selector(selectStar:)];
     self.star2.tag = 1002;
    [self.star3 ddAddTarget:self tapAction:@selector(selectStar:)];
     self.star3.tag = 1003;
    [self.star4 ddAddTarget:self tapAction:@selector(selectStar:)];
     self.star4.tag = 1004;
    [self.star5 ddAddTarget:self tapAction:@selector(selectStar:)];
    self.star5.tag = 1005;
    
}

- (void)updateWithCellItem:(FKSelectStarNumCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    self.t_name.text = cellItem.teacher;
    self.markForTeacher.text = cellItem.markForTeacher;
    [self.t_icon hmLoadImageURL:[cellItem.ImageItem avatatImageURL40] placeholderImage:IMG_NAME(@"placeImage") local:NO];
    if (cellItem.starselNum==1) {
        self.star1.image = IMG_NAME(@"cstarsel");
        self.star2.image = IMG_NAME(@"cstar");
        self.star3.image = IMG_NAME(@"cstar");
        self.star4.image = IMG_NAME(@"cstar");
        self.star5.image = IMG_NAME(@"cstar");
    }
    
    if (cellItem.starselNum==2) {
        self.star1.image = IMG_NAME(@"cstarsel");
        self.star2.image = IMG_NAME(@"cstarsel");
        self.star3.image = IMG_NAME(@"cstar");
        self.star4.image = IMG_NAME(@"cstar");
        self.star5.image = IMG_NAME(@"cstar");
    }
    if (cellItem.starselNum==3) {
        self.star1.image = IMG_NAME(@"cstarsel");
        self.star2.image = IMG_NAME(@"cstarsel");
        self.star3.image = IMG_NAME(@"cstarsel");
        self.star4.image = IMG_NAME(@"cstar");
        self.star5.image = IMG_NAME(@"cstar");
    }
    if (cellItem.starselNum==4) {
        self.star1.image = IMG_NAME(@"cstarsel");
        self.star2.image = IMG_NAME(@"cstarsel");
        self.star3.image = IMG_NAME(@"cstarsel");
        self.star4.image = IMG_NAME(@"cstarsel");
        self.star5.image = IMG_NAME(@"cstar");
    }
    if (cellItem.starselNum==5) {
        self.star1.image = IMG_NAME(@"cstarsel");
        self.star2.image = IMG_NAME(@"cstarsel");
        self.star3.image = IMG_NAME(@"cstarsel");
        self.star4.image = IMG_NAME(@"cstarsel");
        self.star5.image = IMG_NAME(@"cstarsel");
    }

    
}

- (void)selectStar:(UIGestureRecognizer *)tap{
    NSInteger tag = tap.view.tag-1000;
    
    [self.deleagte hmTableViewCell:self sender:tap selector:@selector(fk_selectStarWith:) userInfo:@{@"starNum":@(tag)}];
    
}


- (IBAction)commitBtnAction:(HMYellowButton *)sender {
    
    [self.deleagte hmTableViewCell:self sender:sender selector:@selector(fk_commitBtnActionWith:) userInfo:nil];
}

@end



@implementation FKSelectStarNumCellItem

- (void)initSettings{
    [super initSettings];
    self.canSelect = NO;
    self.hidenSeparator = YES;
    self.cellHeight = 320;
}

@end
