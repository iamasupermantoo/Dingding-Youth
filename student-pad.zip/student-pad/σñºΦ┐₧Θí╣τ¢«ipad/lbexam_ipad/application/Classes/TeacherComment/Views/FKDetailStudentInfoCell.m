//
//  FKDetailStudentInfoCell.m
//  lbexam
//
//  Created by frankay on 17/2/27.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKDetailStudentInfoCell.h"


@interface FKDetailStudentInfoCell ()
@property (weak, nonatomic) IBOutlet FKinitLabel *fb_date;
@property (weak, nonatomic) IBOutlet FKinitLabel *fb_time;
@property (weak, nonatomic) IBOutlet FKinitLabel *fb_courseName;
@property (weak, nonatomic) IBOutlet FKinitLabel *fb_classAddr;
@property (weak, nonatomic) IBOutlet FKinitLabel *fb_stuName;

@end

@implementation FKDetailStudentInfoCell
- (void)updateWithCellItem:(HMTableViewCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    NSDictionary *reaction = cellItem.rawObject;
    self.fb_courseName.text = reaction[@"course"];
    self.fb_date.text = reaction[@"date"];
    self.fb_time.text = reaction[@"time"];
    self.fb_stuName.text = reaction[@"teacher"];
}
@end


@implementation FKDetailStudentInfoCellItem

- (void)initSettings{
    [super initSettings];
    self.canSelect = NO;
    self.separatorInset = kIpadNoGapSeperateInsets;
    self.cellHeight = 133;
}

@end
