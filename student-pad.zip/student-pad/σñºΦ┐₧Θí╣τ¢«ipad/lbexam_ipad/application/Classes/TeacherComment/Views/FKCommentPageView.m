//
//  FKCommentPageView.m
//  UDan
//
//  Created by frankay on 17/2/23.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCommentPageView.h"
#import "HMYellowButton.h"
@interface FKCommentPageView ()
@property (strong, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet UIView *scrollbgView;
@property (weak, nonatomic) IBOutlet UIButton *hottest;
@property (weak, nonatomic) IBOutlet UIButton *newest;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *scrollbgLeading;
@property (weak, nonatomic) IBOutlet UIView *bgView;

@end

@implementation FKCommentPageView

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        self.contentView.frame = CGRectMake(0, 0, CGRectGetWidth(self.bounds), CGRectGetHeight(self.bounds));
        [self addSubview:self.contentView];
        [self initsetting];
    }
    return self;
}

- (void)initsetting{
    [self.hottest setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.newest setTitleColor:[UIColor fkBlueColor] forState:UIControlStateNormal];

    self.scrollbgView.backgroundColor = [UIColor fkBlueColor];
    self.contentView.backgroundColor = [UIColor hmMainBgColor];
    // 设置圆角
    self.bgView.layer.borderWidth = 1;
    self.bgView.layer.borderColor = [UIColor fkBlueColor].CGColor;
    self.bgView.layer.cornerRadius = 15;
    self.scrollbgView.layer.cornerRadius = 15;
    
}


- (IBAction)clickhottestBtn:(UIButton *)sender {
    [self.hottest setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.newest setTitleColor:[UIColor fkBlueColor] forState:UIControlStateNormal];
    self.scrollbgLeading.constant = 0;
    [self.scrollbgView layoutIfNeeded];
    if (self.delegate && [self.delegate respondsToSelector:@selector(FKQuestionPageViewClickHottestBtn:)]) {
        [self.delegate FKQuestionPageViewClickHottestBtn:sender];
    }
}

- (IBAction)clickNewestBtn:(UIButton *)sender {
    [self.hottest setTitleColor:[UIColor fkBlueColor] forState:UIControlStateNormal];
    [self.newest setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.scrollbgLeading.constant = 60;
    [self.scrollbgView layoutIfNeeded];
    if (self.delegate && [self.delegate respondsToSelector:@selector(FKQuestionPageViewClickNewtestBtn:)]) {
        [self.delegate FKQuestionPageViewClickNewtestBtn:sender];
    }
}


@end
