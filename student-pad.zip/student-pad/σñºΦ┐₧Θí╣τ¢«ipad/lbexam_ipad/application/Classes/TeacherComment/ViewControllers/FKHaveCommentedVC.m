//
//  FKHaveCommentedVC.m
//  lbexam_ipad
//
//  Created by frankay on 17/2/23.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKHaveCommentedVC.h"
#import "FKFeedBackDetailVC.h"

#import "FKCommentLessonCell.h"
#import "FKCommentRequestTask.h"
#import "FKCourseItem.h"

#import "HMPlaceholderCellItem.h"

@interface FKHaveCommentedVC ()<FKCommentLessonCellDelegate>
@property(nonatomic,strong) FKCommentRequestTask *commentTask;

@end

@implementation FKHaveCommentedVC


-(FKCommentRequestTask *)commentTask{
    if (!_commentTask) {
        _commentTask = [[FKCommentRequestTask alloc] init];
        _commentTask.status = 1;
    }
    return _commentTask;
}

- (UIBarButtonItem *)leftBarButtonItem{
    return nil;
}

- (BOOL)hasHeadRefresh{
    
    return YES;
    
}

- (void)viewDidLoad {
    self.automaticallyAdjustsScrollViewInsets = NO;
     self.view.frame = CGRectMake(0, 0, IPAD_SCREENWIDTH, SCREENHEIGHT-64-89);
    [super viewDidLoad];
  
    self.title = @"评价";
    self.listRequestTask = self.commentTask;


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    
    self.viewDidAppear = NO;

    [super viewWillAppear:animated];
    
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    self.viewDidAppear = NO;
}

-(Class)cellItemClass{
    return [FKCommentLessonCellItem class];
}

-(void)datasourceWillAddCellItems:(NSMutableArray<HMTableViewCellItem *> *)cellItems requestTask:(HMListRequestTask *)requestTask{
    
    [cellItems enumerateObjectsUsingBlock:^(HMTableViewCellItem * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        FKCommentLessonCellItem *cellItem =(FKCommentLessonCellItem *)obj;
        cellItem.canSelect = NO;
        cellItem.type =1;
        
    }];
    
    [super datasourceWillAddCellItems:cellItems requestTask:requestTask];
    
    if (!requestTask.isLoadingMore && cellItems.count>0) {
        HMPlaceholderCellItem *placeholderCellItem1 = [HMPlaceholderCellItem cellItemWithCellHeight:20];
        [self.dataSource insertCellItem:placeholderCellItem1 adIndex:0];
    }
    
}


#pragma mark - FKCommentLessonCellDelegate
- (void)fk_goCommentAction:(NSDictionary *)info{
    FKCommentLessonCellItem *cellItem = info[HMTableViewCell_Action_Key_CellItem];
    FKCourseItem *item = cellItem.rawObject;
    FKFeedBackDetailVC *feedbackVC = [[FKFeedBackDetailVC alloc] init];
    feedbackVC.cid = item.cid;
    feedbackVC.lid = item.lid;
    feedbackVC.type = 0;
    [self.navigationController pushViewController:feedbackVC animated:YES];
}


-(void)emptyViewWhenTableViewEmpty{
    [self.tableView emptyWithImage:nil title:@"还没有已评价的信息"];
}
@end
