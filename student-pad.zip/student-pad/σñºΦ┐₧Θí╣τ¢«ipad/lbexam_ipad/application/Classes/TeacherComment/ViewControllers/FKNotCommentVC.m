//
//  FKNotCommentVC.m
//  lbexam_ipad
//
//  Created by frankay on 17/2/23.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKNotCommentVC.h"
#import "FKCommentLessonCell.h"
#import "HMPlaceholderCellItem.h"
#import "FKCommentRequestTask.h"
#import "FKFeedBackToTeacherVC.h"
#import "FKCourseItem.h"
@interface FKNotCommentVC ()<FKCommentLessonCellDelegate>
@property(nonatomic,strong) FKCommentRequestTask *commentTask;

@end

@implementation FKNotCommentVC


-(FKCommentRequestTask *)commentTask{
    if (!_commentTask) {
        _commentTask = [[FKCommentRequestTask alloc] init];
        _commentTask.status = 0;
    }
    return _commentTask;
}

- (UIBarButtonItem *)leftBarButtonItem{
    return nil;
}


- (BOOL)hasHeadRefresh{
    return YES;
}
- (void)viewDidLoad {
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.view.frame = CGRectMake(0, 0, IPAD_SCREENWIDTH, SCREENHEIGHT-64-89);

    [super viewDidLoad];
   
    self.title = @"评价";
    self.listRequestTask = self.commentTask;


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    
    self.viewDidAppear = NO;
    [super viewWillAppear:animated];
    
}



-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];

}

- (Class)cellItemClass{
    return [FKCommentLessonCellItem class];
}


-(void)requestDidFinished:(WSRequestTask *)request headers:(NSDictionary *)headers response:(NSDictionary *)response localResult:(BOOL)localResult{

    [super requestDidFinished:request headers:headers response:response localResult:YES];
    
    
}

-(void)datasourceWillAddCellItems:(NSMutableArray<HMTableViewCellItem *> *)cellItems requestTask:(HMListRequestTask *)requestTask{
    
    [super datasourceWillAddCellItems:cellItems requestTask:requestTask];
    if (!requestTask.isLoadingMore && cellItems.count>0) {
        HMPlaceholderCellItem *placeholderCellItem1 = [HMPlaceholderCellItem cellItemWithCellHeight:20];
        [self.dataSource insertCellItem:placeholderCellItem1 adIndex:0];
    }
}

#pragma mark -FKCommentLessonCellDelegate

-(void)fk_goCommentAction:(NSDictionary *)info{
    
    // 跳到填写反馈页面
    self.viewDidAppear = NO;
    
    FKCommentLessonCellItem *cellItem = info[HMTableViewCell_Action_Key_CellItem];
    FKCourseItem *item = cellItem.rawObject;
    FKFeedBackToTeacherVC *feedbackVC = [[FKFeedBackToTeacherVC alloc] init];
    feedbackVC.cid = item.cid;
    feedbackVC.lid = item.lid;
//    feedbackVC.teacherName = item.teacher;
    [self.navigationController pushViewController:feedbackVC animated:YES];
    
}

-(void)emptyViewWhenTableViewEmpty{
    [self.tableView emptyWithImage:nil title:@"还没有未评价的信息"];
}

@end
