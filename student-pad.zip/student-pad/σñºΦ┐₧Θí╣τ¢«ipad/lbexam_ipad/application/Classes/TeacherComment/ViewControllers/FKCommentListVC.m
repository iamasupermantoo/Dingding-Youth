//
//  FKCommentListVC.m
//  lbexam_ipad
//
//  Created by frankay on 17/2/23.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCommentListVC.h"
#import "FKNotCommentVC.h"
#import "FKHaveCommentedVC.h"

#import "FKTopSelectionView.h"
@interface FKCommentListVC ()<FKTopSelectionViewDelegate>


@property(nonatomic,strong) FKTopSelectionView *topView;

@end

@implementation FKCommentListVC

- (instancetype)init{
    self = [super init];
    if (self) {
        // 不能进行view的初始化 不然会跳到viewdidload
        _containerEdgeInset = UIEdgeInsetsMake(89, 0, 0, 0);
        _scrollEnable = YES;
        FKNotCommentVC *viewcontroller1 = [[FKNotCommentVC alloc] init];
        
        FKHaveCommentedVC *viewcontroller2 = [[FKHaveCommentedVC alloc] init];
        _viewControllers = @[viewcontroller1,viewcontroller2];
        
    }
    
    return self;
}




- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.topView];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


-(FKTopSelectionView *)topView{
    if (!_topView) {
        _topView = [[FKTopSelectionView alloc] initWithFrame:CGRectMake(0, 36, IPAD_SCREENWIDTH, 53) WithType:1];
        _topView.delegate = self;
    }
    
    return _topView;
    
}


#pragma mark - FKTopSelectionViewDelegate

- (void)fk_OneTitleTapAction{
    [self switchToIndex:0 animated:YES];
    
}


- (void)fk_TwoTitleTapAction{
    [self switchToIndex:1 animated:YES];
}



@end
