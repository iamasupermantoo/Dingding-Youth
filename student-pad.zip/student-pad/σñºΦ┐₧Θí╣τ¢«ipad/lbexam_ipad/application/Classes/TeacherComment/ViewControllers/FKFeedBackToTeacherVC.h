//
//  FKFeedBackToTeacherVC.h
//  lbexam_ipad
//
//  Created by frankay on 17/2/23.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewController.h"

@interface FKFeedBackToTeacherVC : HMTableViewController
@property(nonatomic,strong) NSString *cid;
@property(nonatomic,strong) NSString *lid;

@property(nonatomic,copy) HMBlock statusBlock;

@end
