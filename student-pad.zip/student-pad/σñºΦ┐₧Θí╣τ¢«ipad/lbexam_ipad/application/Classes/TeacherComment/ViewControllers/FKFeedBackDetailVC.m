//
//  FKFeedBackDetailVC.m
//  lbexam_ipad
//
//  Created by frankay on 17/2/24.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKFeedBackDetailVC.h"
#import "FKHeaderView3Cell.h"
#import "FKDetailStudentInfoCell.h"
#import "FKSelectStarNumCell.h"
#import "HMPlaceholderCellItem.h"
#import "FKCommentContentCell.h"


#import "FKFeedbackDetailRequestTask.h"
#import "FKCommitFeedbackTask.h"

#import "HMImageItem.h"
@interface FKFeedBackDetailVC ()
@property(nonatomic,strong) FKFeedbackDetailRequestTask *detailTask;

@end

@implementation FKFeedBackDetailVC

- (FKFeedbackDetailRequestTask *)detailTask{
    if (!_detailTask) {
        _detailTask = [[FKFeedbackDetailRequestTask alloc] init];
        _detailTask.cid = self.cid;
        _detailTask.lid = self.lid;
        _detailTask.type = self.type;
    }
    return _detailTask;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.type == 1) {
        self.title = HMLocal(@"老师反馈");
    }else{
         self.title = @"评价详情";
    }
   
    self.tableView.frame = CGRectMake(40,0, SCREENWIDTH-80, SCREENHEIGHT-64);
    [self initCellItems];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)initCellItems{
    
    [self.detailTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (error==nil) {
          
            NSDictionary *dict = response[@"data"][@"reaction"];
            FKHeaderView3CellItem *header0 = [[FKHeaderView3CellItem alloc] init];
            header0.rawObject = @"上课信息";
            header0.cellHeight = 45;
            [self.dataSource insertCellItem:header0 adIndex:0];
            FKDetailStudentInfoCellItem *feedback = [[FKDetailStudentInfoCellItem alloc] init];
            feedback.rawObject = dict;
            [self.dataSource insertCellItem:feedback adIndex:1];
            FKHeaderView3CellItem *header1 = [[FKHeaderView3CellItem alloc] init];
            header1.rawObject = @"评价";
            [self.dataSource insertCellItem:header1 adIndex:2];
         
            FKCommentContentCellItem *cellItem1 = [[FKCommentContentCellItem alloc] init];
            if (self.type == 1) {
                cellItem1.titlestr = HMLocal(@"课堂表现");
                cellItem1.rawObject = [NSString stringWithStudentBehaviorType:[dict[@"behavior"] integerValue]];
            }else{
                cellItem1.titlestr = HMLocal(@"老师讲课怎么样");
                cellItem1.rawObject = [NSString stringWithTeachQualityType:[dict[@"quality"] integerValue]];
                
            }
         
            [self.dataSource addCellItem:cellItem1];
            
            FKCommentContentCellItem *cellItem2 = [[FKCommentContentCellItem alloc] init];
            if (self.type == 1) {
                cellItem2.titlestr = HMLocal(@"教学理念");
                cellItem2.rawObject = [NSString stringWithLearnDegreeType:[dict[@"idea"] integerValue]];
            }else{
                cellItem2.titlestr = HMLocal(@"本次课学会程度");
                cellItem2.rawObject = [NSString stringWithLearnDegreeType:[dict[@"acceptance"] integerValue]];
            }
            
           
            [self.dataSource addCellItem:cellItem2];
            
            FKCommentContentCellItem *cellItem3 = [[FKCommentContentCellItem alloc] init];
            cellItem3.titlestr = HMLocal(@"本次备注");
            cellItem3.rawObject = dict[@"remark"];
            [self.dataSource addCellItem:cellItem3];
            
            FKHeaderView3CellItem *header4 = [[FKHeaderView3CellItem alloc] init];
            if (self.type==1) {
                header4.rawObject = @"学生得分";
            }else{
                header4.rawObject = @"老师得分";

            }
            [self.dataSource addCellItem:header4];
            
            FKSelectStarNumCellItem *star = [[FKSelectStarNumCellItem alloc] init];
            star.cellHeight = 150;
            
            if (self.type == 1) {
                star.teacher = dict[@"student"];
                star.markForTeacher = [NSString stringWithFormat:@"%@同学获得%ld分",dict[@"student"],[dict[@"star"] integerValue]*20];
                star.ImageItem = [HMImageItem yy_modelWithDictionary:dict[@"studentHeadImg"]];
                star.starselNum = [dict[@"star"] integerValue];
            }else{
                star.teacher = dict[@"teacher"];
                star.markForTeacher = [NSString stringWithFormat:@"%@老师获得%ld分",dict[@"teacher"],[dict[@"star"] integerValue]*20];
                star.ImageItem = [HMImageItem yy_modelWithDictionary:dict[@"teacherHeadImg"]];
                star.starselNum = [dict[@"star"] integerValue];
            
            }
       
            [self.dataSource addCellItem:star];
            
            [self.tableView reloadData];
        }
    }];
    
}


@end
