//
//  FKFeedBackToTeacherVC.m
//  lbexam_ipad
//
//  Created by frankay on 17/2/23.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKFeedBackToTeacherVC.h"
#import "FKHeaderView3Cell.h"
#import "FKHowAboutTeachingCell.h"
#import "FKLearnLevelCell.h"
#import "FKFeedBackClassInfoCell.h"
#import "FKRemarkinfoCell.h"
#import "FKSelectStarNumCell.h"
#import "HMPlaceholderCellItem.h"

#import "FKFeedbackDetailRequestTask.h"
#import "FKCommitFeedbackTask.h"

#import "HMImageItem.h"
@interface FKFeedBackToTeacherVC ()<FKHowAboutTeachingCellDelegate,FKLearnLevelCellDelegate,FKRemarkinfoCellDelegate,FKSelectStarNumCellDelegate>

@property(nonatomic,strong) FKFeedbackDetailRequestTask *detailTask;
@property(nonatomic,strong) FKCommitFeedbackTask *commitTask;


@end

@implementation FKFeedBackToTeacherVC{
    
    NSInteger _quality;
    NSInteger _acceptance;
    NSInteger _star;
    NSString  *_remark;
}

- (FKFeedbackDetailRequestTask *)detailTask{
    if (!_detailTask) {
        _detailTask = [[FKFeedbackDetailRequestTask alloc] init];
        _detailTask.cid = self.cid;
        _detailTask.lid = self.lid;
    }
    return _detailTask;
}

- (FKCommitFeedbackTask *)commitTask{
    if (!_commitTask) {
        _commitTask = [[FKCommitFeedbackTask alloc] init];
        _commitTask.cid = self.cid;
        _commitTask.lid = self.lid;
    }
    return _commitTask;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = HMLocal(@"给老师评价");
    self.tableView.frame = CGRectMake(40, 0, SCREENWIDTH-80, SCREENHEIGHT-64);
  
    [self.detailTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            [self initCellItems];
            
            NSDictionary *dict = response[@"data"][@"reaction"];
            FKFeedBackClassInfoCellItem *feedback = [[FKFeedBackClassInfoCellItem alloc] init];
            feedback.rawObject = dict;
            [self.dataSource insertCellItem:feedback adIndex:1];
            
            FKSelectStarNumCellItem *star = [[FKSelectStarNumCellItem alloc] init];
            star.teacher = dict[@"teacher"];
            star.markForTeacher = [NSString stringWithFormat:@"请为%@老师打分",dict[@"teacher"]];
            star.ImageItem = [HMImageItem yy_modelWithDictionary:dict[@"teacherHeadImg"]];
            [self.dataSource addCellItem:star];
            
        }
        
        
        
//        [DDProgressHUD dismiss];
        [self.tableView reloadData];

    
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

-(void)leftButtonAction:(id)sender{
    // 返回是提示是否放弃评价
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"是否放弃评价" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"是的" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [alert dismissViewControllerAnimated:YES completion:nil];

        [self.navigationController popViewControllerAnimated:YES];
    }];
    
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [alert dismissViewControllerAnimated:YES completion:nil];
    }];
    
   
    [alert addAction:cancel];
    [alert addAction:ok];
    [self presentViewController:alert animated:YES completion:nil];

}

- (void)initCellItems{
    HMPlaceholderCellItem *placeCellItem = [HMPlaceholderCellItem cellItemWithCellHeight:20];
    [self.dataSource insertCellItem:placeCellItem adIndex:0];
    
    FKHeaderView3CellItem *header = [[FKHeaderView3CellItem alloc] init];
    header.rawObject = @"老师讲课怎么样:";
    [self.dataSource addCellItem:header];
    FKHowAboutTeachingCellItem *howabout = [[FKHowAboutTeachingCellItem alloc] init];
   
    [self.dataSource addCellItem:howabout];
    
    FKHeaderView3CellItem *header2 = [[FKHeaderView3CellItem alloc] init];
    header2.rawObject = @"本次课学会程度:";
    [self.dataSource addCellItem:header2];
    
    FKLearnLevelCellItem *learnLevel = [[FKLearnLevelCellItem alloc] init];
    
    [self.dataSource addCellItem:learnLevel];
    
    FKHeaderView3CellItem *header3 = [[FKHeaderView3CellItem alloc] init];
    header3.rawObject = @"本次备注:";
    [self.dataSource addCellItem:header3];
    
    FKRemarkinfoCellItem *remarkinfo = [[FKRemarkinfoCellItem alloc] init];
    [self.dataSource addCellItem:remarkinfo];
    
    FKHeaderView3CellItem *header4 = [[FKHeaderView3CellItem alloc] init];
    header4.rawObject = @"给老师打分:";
    [self.dataSource addCellItem:header4];
    
}

#pragma mark - FKHowAboutTeachingCellDelegate

- (void)HowAboutTeachingSelectAnswerWith:(NSDictionary *)info{
    
    NSDictionary *userinfo = info[HMTableViewCell_Action_Key_UserInfo];
    NSInteger answer = [userinfo[@"tag"] integerValue];
    _quality = answer;
    FKHowAboutTeachingCellItem *cellItem = info[HMTableViewCell_Action_Key_CellItem];
    NSIndexPath *path = info[HMTableViewCell_Action_Key_IndexPath];
    cellItem.selectAnswer = answer;
    [self.tableView reloadRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationNone];
}

#pragma mark - FKLearnLevelCellDelegate
-(void)fk_LearnLevelCellSelectAnswerWith:(NSDictionary *)info{
    NSDictionary *userinfo = info[HMTableViewCell_Action_Key_UserInfo];
    NSInteger answer = [userinfo[@"tag"] integerValue];
    _acceptance = answer;
    FKLearnLevelCellItem *cellItem = info[HMTableViewCell_Action_Key_CellItem];
    NSIndexPath *path = info[HMTableViewCell_Action_Key_IndexPath];
    cellItem.selectAnswer = answer;
    [self.tableView reloadRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationNone];
    
}

#pragma mark - FKRemarkinfoCellDelegate

-(void)fk_fillinTextViewWithText:(NSDictionary *)info{
    NSDictionary *userinfo = info[HMTableViewCell_Action_Key_UserInfo];
    _remark = userinfo[@"text"];
    
}

#pragma mark - FKSelectStarNumCellDelegate
-(void)fk_selectStarWith:(NSDictionary *)info{
    
    NSDictionary *userinfo = info[HMTableViewCell_Action_Key_UserInfo];
    NSInteger star = [userinfo[@"starNum"] integerValue];
    _star = star;
    FKSelectStarNumCellItem *cellItem = info[HMTableViewCell_Action_Key_CellItem];
    NSIndexPath *path = info[HMTableViewCell_Action_Key_IndexPath];
    cellItem.starselNum = star;
    
    [self.tableView reloadRowsAtIndexPaths:@[path] withRowAnimation:UITableViewRowAnimationNone];
}

- (void)fk_commitBtnActionWith:(NSDictionary *)info{
    
    [DDProgressHUD showHUDWithStatus:@"正在提交..."];
    self.commitTask.quality = _quality;
    self.commitTask.acceptance = _acceptance;
    self.commitTask.star = _star;
    self.commitTask.remark = _remark;
    
//    WEAKSELF;
    [self.commitTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            [DDProgressHUD showSucessWithStatus:@"提交评价成功！"];
            if (self.statusBlock) {
                self.statusBlock(nil);

            }
            [self.navigationController popViewControllerAnimated:YES];
        }
    }];
}
@end
