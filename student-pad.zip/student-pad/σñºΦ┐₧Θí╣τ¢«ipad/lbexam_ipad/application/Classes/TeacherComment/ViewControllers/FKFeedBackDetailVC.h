//
//  FKFeedBackDetailVC.h
//  lbexam_ipad
//
//  Created by frankay on 17/2/24.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewController.h"

@interface FKFeedBackDetailVC : HMTableViewController
@property(nonatomic,strong) NSString *cid;
@property(nonatomic,strong) NSString *lid;
@property(nonatomic,assign) NSInteger type;
@end
