//
//  FKFeedbackDetailRequestTask.m
//  lbexam_ipad
//
//  Created by frankay on 17/2/24.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKFeedbackDetailRequestTask.h"

@implementation FKFeedbackDetailRequestTask
- (NSString *)apiName{
    if (self.type == 1) {
        return @"/reaction/details/byteacher";
    }
    return @"/reaction/details";
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.cid || [self.cid ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"cid"];
    }
    if (!self.lid || [self.lid ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"lid"];
    }
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
  
    [self.parameterDictionary setObject:self.cid forKey:@"cid"];
    [self.parameterDictionary setObject:self.lid forKey:@"lid"];
    
}

@end
