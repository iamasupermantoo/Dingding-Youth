//
//  FKCommitFeedbackTask.h
//  lbexam_ipad
//
//  Created by frankay on 17/2/24.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface FKCommitFeedbackTask : HMBaseRequestTask

@property(nonatomic,assign) NSInteger quality;
@property(nonatomic,assign) NSInteger acceptance;
@property(nonatomic,strong) NSString *remark;
@property(nonatomic,assign) NSInteger star;
@property(nonatomic,strong) NSString *cid;
@property(nonatomic,strong) NSString *lid;
@end
