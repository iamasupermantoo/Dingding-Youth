//
//  FKFeedbackDetailRequestTask.h
//  lbexam_ipad
//
//  Created by frankay on 17/2/24.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface FKFeedbackDetailRequestTask : HMBaseRequestTask
@property(nonatomic,strong) NSString *cid;
@property(nonatomic,strong) NSString *lid;

@property(nonatomic,assign) NSInteger type; // 0 学生的反馈详情， 1是老师对学生的反馈详情。
@end
