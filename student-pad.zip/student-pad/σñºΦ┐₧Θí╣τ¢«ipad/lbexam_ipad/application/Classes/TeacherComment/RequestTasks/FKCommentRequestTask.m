//
//  FKCommentRequestTask.m
//  lbexam_ipad
//
//  Created by frankay on 17/2/24.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCommentRequestTask.h"
#import "FKCourseItem.h"
@implementation FKCommentRequestTask

+ (BOOL)needLogin{
    return YES;
}

- (instancetype)init{
    self = [super init];
    if (self) {
        self.resultItemsKeyword = @"reactions";
    }
    return self;
}


- (Class)itemClass{
    return [FKCourseItem class];
}


- (NSString *)apiName{
    return @"/reaction/list";
}


- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:@(self.status) forKey:@"status"];
}


@end
