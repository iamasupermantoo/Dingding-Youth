//
//  FKCommitFeedbackTask.m
//  lbexam_ipad
//
//  Created by frankay on 17/2/24.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKCommitFeedbackTask.h"

@implementation FKCommitFeedbackTask

-(NSString *)apiName{
    return @"/reaction/commit";
}

- (WSHTTPMethod)requestMethod{
    return WSHTTPMethodPOST;
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (self.quality==0 || self.quality>4) {
        return [NSError wsLocalParamErrorKey:@"请为老师讲课质量评价"];
    }
    if (self.acceptance==0 || self.quality>4) {
        return [NSError wsLocalParamErrorKey:@"请选择本次学会程度"];
    }
   
    
    if (!self.remark || [self.remark ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"备注内容不能为空"];
    }
    if (self.star==0 || self.star>5) {
        return [NSError wsLocalParamErrorKey:@"请为老师评级"];
        
    }
    if (!self.cid || [self.cid ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"cid"];
    }
    if (!self.lid || [self.lid ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"lid"];
    }
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:@(self.quality) forKey:@"quality"];
    [self.parameterDictionary setObject:@(self.acceptance) forKey:@"acceptance"];
    [self.parameterDictionary setObject:@(self.star) forKey:@"star"];
    [self.parameterDictionary setObject:self.remark forKey:@"remark"];
    [self.parameterDictionary setObject:self.cid forKey:@"cid"];
    [self.parameterDictionary setObject:self.lid forKey:@"lid"];
    
}

@end
