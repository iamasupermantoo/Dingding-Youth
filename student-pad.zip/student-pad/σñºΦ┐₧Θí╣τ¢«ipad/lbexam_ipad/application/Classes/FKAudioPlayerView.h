//
//  FKAudioPlayerView.h
//  lbexam_ipad
//
//  Created by frankay on 17/2/20.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FKAudioPlayerView : UIView


- (void)play;
- (void)pause;
- (void)close;
- (void)changeSlideValueWith:(CGFloat)value;
- (void)createPlayerWithUrl:(NSString *)url;

@end
