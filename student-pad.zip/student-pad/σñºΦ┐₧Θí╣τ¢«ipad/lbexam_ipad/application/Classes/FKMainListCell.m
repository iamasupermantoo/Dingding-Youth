//
//  FKMainListCell.m
//  lbexam_ipad
//
//  Created by frankay on 17/2/20.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKMainListCell.h"


@interface FKMainListCell ()
@property (weak, nonatomic) IBOutlet UIImageView *tipImageView;

@property (weak, nonatomic) IBOutlet UILabel *tittle;

@property(nonatomic,strong) UIView *selectedbgView;
@end
@implementation FKMainListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.tittle.textColor = [UIColor whiteColor];
    self.separatorInset = kIpadNoGapSeperateInsets;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    if (self.selected) {
//        // 选中的状态
//        self.selectedBackgroundView = self.selectedbgView;
    }else{
        

    }
    // Configure the view for the selected state
}


-(void)UpdatecellWithDictionary:(NSDictionary *)dict{
    
    self.tipImageView.image = IMG_NAME(dict[@"image"]);
    self.tittle.text = dict[@"title"];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    for (UIView *subview in self.contentView.superview.subviews) {
        if ([NSStringFromClass(subview.class) hasSuffix:@"SeparatorView"]) {
            subview.hidden = NO;
            CGRect frame = subview.frame;
            frame.origin.x += self.separatorInset.left;
            frame.size.width -= self.separatorInset.right;
            subview.frame =frame;
        }
    }
}

- (UIView *)selectedbgView{
    if (!_selectedbgView) {
        _selectedbgView = [[UIView alloc] initWithFrame:self.bounds];
        _selectedbgView.backgroundColor = [UIColor fkColorWithString:@"#08b1ed"];
    }
    return _selectedbgView;

}

@end
