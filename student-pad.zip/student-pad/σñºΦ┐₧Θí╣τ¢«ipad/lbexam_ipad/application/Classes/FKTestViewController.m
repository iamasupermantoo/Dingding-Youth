//
//  FKTestViewController.m
//  lbexam
//
//  Created by frankay on 17/1/13.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKTestViewController.h"
#import "FKAudioPlayerView.h"
@interface FKTestViewController ()
@property(nonatomic,strong) FKAudioPlayerView *playerView;
@end

@implementation FKTestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor hmTextBlueColor];
//    self.playerView = [[FKAudioPlayerView alloc] initWithFrame:CGRectMake(0, 100, 300, 200)];
//    [self.view addSubview:self.playerView];
//    [self.playerView createPlayerWithUrl:@"http://res.webftp.bbs.hnol.net/lovegege/NANA/2014/07/01.nan/12.mp3"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
