//
//  FKTeacherItem.h
//  lbexam
//
//  Created by frankay on 17/1/16.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseItem.h"
#import "HMImageItem.h"
@interface FKTeacherItem : HMBaseItem

@property(nonatomic,strong) NSString *tid;   // 教师id
@property(nonatomic,strong) NSString *name;  // 教师姓名
@property(nonatomic,assign) NSInteger gender; // 教师性别 0男1女
@property(nonatomic,strong) NSString *hours;   //已上课时
@property(nonatomic,strong) NSString *desc;   // 教师描述

@property(nonatomic,strong) HMImageItem *imageItem; // 头像
@end
