//
//  FKestalishCourseItem.m
//  lbexam
//
//  Created by frankay on 17/1/17.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKestalishCourseItem.h"

@implementation FKestalishCourseItem
+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"imageItem"  : @"image"};
}
@end
