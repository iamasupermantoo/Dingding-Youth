//
//  FKTeacherItem.m
//  lbexam
//
//  Created by frankay on 17/1/16.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKTeacherItem.h"

@implementation FKTeacherItem
+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{
             @"imageItem":@"headImg"
             };
}
@end
