//
//  FKestalishCourseItem.h
//  lbexam
//
//  Created by frankay on 17/1/17.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseItem.h"
#import "HMImageItem.h"
@interface FKestalishCourseItem : HMBaseItem
@property(nonatomic,strong) NSString *cmid; // 课程id
@property(nonatomic,strong) HMImageItem *imageItem; // 展示图片
@property(nonatomic,strong) NSString *brief; // 课程简介

@property(nonatomic,assign) BOOL issingleLine;
@end

