//
//  FKTeacherinfoAboutCourceCell.h
//  lbexam
//
//  Created by frankay on 17/1/13.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"
#import "HMTableViewCellItem.h"
@interface FKTeacherinfoAboutCourceCell : HMTableViewCell

@end


@interface FKTeacherinfoAboutCourceCellItem : HMTableViewCellItem

@end
