//
//  FKSomethingBriefCell.h
//  lbexam
//
//  Created by frankay on 17/1/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMTableViewCell.h"
#import "HMTableViewCellItem.h"
@interface FKSomethingBriefCell : HMTableViewCell

@end


@interface FKSomethingBriefCellItem : HMTableViewCellItem

@property(nonatomic,strong) NSString *Btitle;
@property(nonatomic,strong) NSAttributedString *attributestring;
@end
