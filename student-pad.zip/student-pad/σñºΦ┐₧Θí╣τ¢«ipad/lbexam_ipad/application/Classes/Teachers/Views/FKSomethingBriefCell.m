//
//  FKSomethingBriefCell.m
//  lbexam
//
//  Created by frankay on 17/1/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKSomethingBriefCell.h"
#import "FKTeacherItem.h"

@interface FKSomethingBriefCell ()
@property (weak, nonatomic) IBOutlet FKinitLabel *Btitle;
@property (weak, nonatomic) IBOutlet FKinitLabel *Bcontent;

@end
@implementation FKSomethingBriefCell

- (void)initSettings{
    [super initSettings];
    self.Bcontent.textColor = [UIColor fk666Color];

}
- (void)updateWithCellItem:(FKSomethingBriefCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    self.Btitle.text = cellItem.Btitle;
  
    NSString *desc = cellItem.rawObject;
    if (cellItem.attributestring) {
        self.Bcontent.attributedText = cellItem.attributestring;
    }else{
        self.Bcontent.text = desc;
    }
}
@end




@implementation FKSomethingBriefCellItem

- (void)initSettings{
    [super initSettings];
    self.cellHeight = 100;
    self.separatorInset = kIpadNoGapSeperateInsets;
}


- (void)setRawObject:(id)rawObject{
    if (rawObject==nil) {
        return;
    }
    
    NSString *desc = rawObject;
    CGFloat maxWidth = SCREENWIDTH-30;
    UIFont *font = [UIFont systemFontOfSize:15];
    CGFloat labelHeight = [desc HeightWithFont:font maxSize:maxWidth];
    // 如果高度大于一行
 
    self.attributestring = [desc attributedStringWithTextFont:font];
    
    
    self.cellHeight = labelHeight + 60;
}

@end
