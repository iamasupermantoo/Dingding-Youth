//
//  FKTeacherinfoAboutCourceCell.m
//  lbexam
//
//  Created by frankay on 17/1/13.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKTeacherinfoAboutCourceCell.h"
#import "FKTeacherItem.h"
@interface FKTeacherinfoAboutCourceCell ()
@property (weak, nonatomic) IBOutlet UIImageView *Ticon;
@property (weak, nonatomic) IBOutlet FKinitLabel *Tname;
@property (weak, nonatomic) IBOutlet FKinitLabel *Tgender;
@property (weak, nonatomic) IBOutlet FKinitLabel *Tclasstime;

@end
@implementation FKTeacherinfoAboutCourceCell

- (void)updateWithCellItem:(HMTableViewCellItem *)cellItem{
    [super updateWithCellItem:cellItem];
    FKTeacherItem *teacherItem = cellItem.rawObject;
    
    [self.Ticon hmLoadImageURL:[teacherItem.imageItem imageUrlWithSide:75] placeholderImage:IMG_NAME(@"icon.jpg") local:YES];
    self.Tname.text = [NSString stringWithFormat:@"姓        名：%@",teacherItem.name];
   ;
    self.Tgender.text =[NSString stringWithFormat:@"性        别：%@", [NSString stringWithGenderType:teacherItem.gender]];
    
    self.Tclasstime.text = [NSString stringWithFormat:@"已上课时：%@小时",teacherItem.hours];
}

@end

@implementation FKTeacherinfoAboutCourceCellItem
- (void)initSettings{
    [super initSettings];
    self.separatorInset = kIpadNoGapSeperateInsets;
    self.cellHeight = 105;
}

@end
