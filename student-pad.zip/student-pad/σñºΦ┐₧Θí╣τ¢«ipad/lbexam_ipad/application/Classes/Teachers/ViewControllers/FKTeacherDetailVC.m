//
//  FKTeacherDetailVC.m
//  lbexam
//
//  Created by frankay on 17/1/16.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKTeacherDetailVC.h"
#import "FKTeacherinfoAboutCourceCell.h"
#import "FKSomethingBriefCell.h"
#import "FKTwoLineCell.h"
#import "FKHeaderView1Cell.h"
#import "HMPlaceholderCellItem.h"
#import "HMEmptyCell.h"

#import "FKTeacherDetailRequestTask.h"
#import "FKTeacherItem.h"
#import "FKestalishCourseItem.h"
@interface FKTeacherDetailVC ()
@property(nonatomic,strong) FKTeacherDetailRequestTask *teacherTask;
@end

@implementation FKTeacherDetailVC

- (BOOL)hasLoadMore{
    return NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self getdata];
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)getdata{
    
    [self.teacherTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            HMPlaceholderCellItem *holderCellItem = [HMPlaceholderCellItem placeholderCellItem];
            // 转换为教师item
            NSDictionary *teacherDic = response[@"data"][@"teacher"];
            FKTeacherItem *teacherItem = [FKTeacherItem yy_modelWithDictionary:teacherDic];
            FKTeacherinfoAboutCourceCellItem *CellItem1 = [[FKTeacherinfoAboutCourceCellItem alloc] init];
            CellItem1.rawObject = teacherItem;
            [self.dataSource addCellItem:CellItem1];
            [self.dataSource addCellItem:holderCellItem];
            
            FKSomethingBriefCellItem *somebriefCellItem = [[FKSomethingBriefCellItem alloc] init];
            NSString *str = teacherItem.desc;
            somebriefCellItem.rawObject = str;
            somebriefCellItem.Btitle = @"教师简介";
            [self.dataSource addCellItem:somebriefCellItem];
            [self.dataSource addCellItem:holderCellItem];
            
            // 添加已开课程头标题
            FKHeaderView1CellItem *cellItem3 = [[FKHeaderView1CellItem alloc] init];
            cellItem3.rawObject = @"已开课程";
            cellItem3.hidenSeparator = NO;
            cellItem3.Bottomconstant = 10;
            [self.dataSource addCellItem:cellItem3];
            
            // 已开课程
            NSArray *courseMetas = response[@"data"][@"courseMetas"];
            if (courseMetas.count == 0) {
                // 已开课程为空
                HMEmptyCellItem *emptyCellItem = [[HMEmptyCellItem alloc] init];
                [self.dataSource addCellItem:emptyCellItem];
            }else{
                NSMutableArray *ImageCellItems = [NSMutableArray arrayWithCapacity:2];
                for (NSDictionary *dict in courseMetas) {
                     FKestalishCourseItem *estalishItem = [FKestalishCourseItem yy_modelWithDictionary:dict];
                    
                    
                    if (ImageCellItems.count<2) {
                        [ImageCellItems addObject:estalishItem];
                        if ([courseMetas.lastObject isEqualToDictionary:dict]) {
                            // 最后一个数据
                            FKTwoLineCellItem *twoLineCellItem = [[FKTwoLineCellItem alloc] init];
                            twoLineCellItem.rawObject = ImageCellItems;
                            [self.dataSource addCellItem:twoLineCellItem];
                            ImageCellItems = [NSMutableArray arrayWithCapacity:2];
                        }
                    }else{
                        // 先创建cellItem 再清空数组
                        FKTwoLineCellItem *twoLineCellItem = [[FKTwoLineCellItem alloc] init];
                        twoLineCellItem.rawObject = ImageCellItems;
                        [self.dataSource addCellItem:twoLineCellItem];
                        ImageCellItems = [NSMutableArray arrayWithCapacity:2];
                    }
                 
                    
                }
            
            }
            
            [self.tableView reloadData];
        }
    }];

}


- (FKTeacherDetailRequestTask *)teacherTask{
    if (!_teacherTask) {
        _teacherTask = [[FKTeacherDetailRequestTask alloc] init];
        _teacherTask.tid = @"T001";
    }
    return _teacherTask;
}

@end
