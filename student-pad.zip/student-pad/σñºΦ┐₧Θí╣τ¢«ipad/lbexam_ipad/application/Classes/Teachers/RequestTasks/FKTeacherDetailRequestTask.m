//
//  FKTeacherDetailRequestTask.m
//  lbexam
//
//  Created by frankay on 17/1/17.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKTeacherDetailRequestTask.h"

@implementation FKTeacherDetailRequestTask

- (NSString *)apiName{
    return @"teacher/details";
}


- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.tid && [self.tid ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"tid"];
        
    }
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    [self.parameterDictionary setObject:self.tid forKey:@"tid"];
}



@end
