//
//  FKMainViewController.m
//  lbexam
//
//  Created by frankay on 17/1/13.
//  Copyright © 2017年 frankay. All rights reserved.
//


#import "FKMainViewController.h"
#import "FKMainListCell.h"
#import "FKHomeWorkListContentView.h"
#import "FKCourseTableVC.h"
#import "FKCommentListVC.h"
#import "FKCourseListVC.h"
#import "HMLoginHandler.h"
#import "FKMineInfoVC.h"
#import "DDTabBar.h"
#import "DDTabBarItem.h"


@interface FKMainViewController ()<DDTabBarDelegate>
@property(nonatomic,strong) DDTabBar *tabBar;
@property(nonatomic,strong) UIImageView *iconImageView;
@property(nonatomic,strong) UILabel *nameLabel;
@end

@implementation FKMainViewController{
    
    CGFloat leftViewWidth;
}


-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


- (instancetype)init{
    self = [super init];
    if (self) {
        // 不能进行view的初始化 不然会跳到viewdidload
        _containerEdgeInset = UIEdgeInsetsMake(0,IPAD_HALFSCREEN_X, 0, IPAD_HALFSCREEN_X-191);
        
        FKCourseTableVC *viewcontroller1 = [[FKCourseTableVC alloc] init];
      
        FKCourseListVC *viewcontroller2 = [[FKCourseListVC alloc] init];
       
        FKHomeWorkListContentView *viewcontroller3 = [[FKHomeWorkListContentView alloc] init];
        
        FKCommentListVC *viewcontroller4 = [[FKCommentListVC alloc] init];
        FKMineInfoVC *viewcontrooler5 = [[FKMineInfoVC alloc] init];
        _viewControllers = @[viewcontroller1,viewcontroller2,viewcontroller3,viewcontroller4,viewcontrooler5];
    
    }
    
    return self;
}

- (void)setLeftView{

    // 背景色
    UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, leftViewWidth, SCREENHEIGHT-64)];
    UIImageView *bgImageView = [[UIImageView alloc] init];
    bgImageView.frame = leftView.bounds;
    bgImageView.image = IMG_NAME(@"Schedule_background_normal");
    [leftView addSubview:bgImageView];
    // 头像
    UIView *iconBgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, leftViewWidth, 140)];
    
    UIImageView *iconBgImageView = [[UIImageView alloc] init];
    iconBgImageView.frame = iconBgView.bounds;
    iconBgImageView.image = IMG_NAME(@"personal-data_Avatar-background_normal");
    [iconBgView addSubview:iconBgImageView];
    [leftView addSubview:iconBgView];
    UIImageView *icon = [[UIImageView alloc] initWithFrame:CGRectMake(59, 19, 73, 73)];
    icon.layer.cornerRadius = icon.frame.size.width/2.0;
    icon.clipsToBounds = YES;
    [icon hmLoadImageURL:[[HMUserHandler sharedInstance].userItem.headImage imageURLWithCornerRadius:70 border:3 borderColor:@"ffffff" alpha:1.0] local:NO];
    [icon ddAddTarget:self tapAction:@selector(iconTapAction:)];
    
    [iconBgView addSubview:icon];
    
    UILabel *name = [[UILabel alloc] initWithFrame:CGRectMake(0, 103, leftViewWidth, 20)];
    name.font = [UIFont systemFontOfSize:15];
    name.textColor = [UIColor whiteColor];
    name.textAlignment = NSTextAlignmentCenter;
    name.text = [HMUserHandler sharedInstance].userItem.name;
    self.nameLabel = name;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeName) name:@"modifyName" object:nil];
    [iconBgView addSubview:name];

    
    DDTabBarItem *barItem1 = [[DDTabBarItem alloc] initWithTitle:nil imageNormalName:@"Schedule_Schedule_normal" imageSelectedName:@"Schedule_Schedule_seletced"];
    barItem1.edgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
  
    DDTabBarItem *barItem2 = [[DDTabBarItem alloc] initWithTitle:nil imageNormalName:@"Schedule_curriculum_normal" imageSelectedName:@"Schedule_curriculum_selected"];
   
     barItem2.edgeInsets = barItem1.edgeInsets;
    
    DDTabBarItem *barItem3 = [[DDTabBarItem alloc] initWithTitle:nil imageNormalName:@"Schedule_task_normal" imageSelectedName:@"Schedule_task_selected"];
    
    barItem3.edgeInsets = barItem1.edgeInsets;
    
    DDTabBarItem *barItem4 = [[DDTabBarItem alloc] initWithTitle:nil imageNormalName:@"Schedule_evaluate_normal" imageSelectedName:@"Schedule_evaluate_selected"];
    
    barItem4.edgeInsets = barItem1.edgeInsets;
    
    self.tabBar = [[DDTabBar alloc] initWithFrame:CGRectMake(0, 140, leftViewWidth, SCREENHEIGHT-140-64)tabBarItems:@[barItem1,barItem2,barItem3,barItem4]];
    self.tabBar.delegate = self;
    [leftView addSubview:self.tabBar];
    [self.view addSubview:leftView];
    
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor hmMainBgColor];
    leftViewWidth = 191.0;
    [self setLeftView];
}

- (void)changeName{

     self.nameLabel.text = [HMUserHandler sharedInstance].userItem.name;
}

- (void)iconTapAction:(UIGestureRecognizer *)tap{
    // 点击头像跳转
    [self.tabBar cleanAllSelectedState];
    [self switchToIndex:4 animated:NO];
}

- (void)logout:(UIGestureRecognizer *)tap{
    [[HMLoginHandler sharedInstance] logout];

}
- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
  
}


#pragma mark - DDTabBarDelegate

- (void)tabBar:(DDTabBar *)caller didPressedOtherTab:(NSUInteger)tag{
    
    [self switchToIndex:tag animated:NO];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
