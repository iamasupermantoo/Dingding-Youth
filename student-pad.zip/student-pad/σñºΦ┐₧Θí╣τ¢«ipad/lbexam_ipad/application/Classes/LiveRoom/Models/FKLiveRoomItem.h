//
//  FKLiveRoomItem.h
//  lbexam_ipad
//
//  Created by frankay on 17/3/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseItem.h"

@interface FKLiveRoomItem : HMBaseItem

@property(nonatomic,assign) NSUInteger account;
@property(nonatomic,assign) NSUInteger studentAccount;
@property(nonatomic,assign) NSUInteger teacherAccount;
@property(nonatomic,strong) NSString *channelKey; // 频道加密key
@property(nonatomic,strong) NSString *channelName; //
@property(nonatomic,assign) NSInteger role;
@property(nonatomic,strong) NSString *signalingKey;

@end
