//
//  FKPageItem.h
//  lbexam_ipad
//
//  Created by frankay on 17/3/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseItem.h"

@class HMImageItem;
@interface FKPageItem : HMBaseItem
@property(nonatomic,assign) NSInteger idx; // page 第一个索引
@property(nonatomic,strong) HMImageItem *image;
@property(nonatomic,assign) NSInteger type; // 0 是图片 1是MP3 2是MP4
@property(nonatomic,strong) NSString *audio; // mp3

@property(nonatomic,strong) NSString *video; // mp4
@end
