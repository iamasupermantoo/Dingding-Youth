//
//  FKDetailPageItem.m
//  lbexam_ipad
//
//  Created by frankay on 17/3/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKDetailPageItem.h"

@implementation FKDetailPageItem


+(nullable NSDictionary<NSString *, id> *)modelContainerPropertyGenericClass{
    return @{
             
                @"children": [FKPageItem class]
             
             };
}
@end
