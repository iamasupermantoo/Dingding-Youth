//
//  FKDetailPageItem.h
//  lbexam_ipad
//
//  Created by frankay on 17/3/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKPageItem.h"

@interface FKDetailPageItem : FKPageItem

@property(nonatomic,strong) NSArray *children; //Array<FKPageItem>

@end
