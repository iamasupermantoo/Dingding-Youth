//
//  FKGiftView.h
//  testAnimationView
//
//  Created by frankay on 17/7/1.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FKGiftView : UIView

- (void)receiveGiftAnimationWithGiftTotalCount:(NSInteger)count;

@end
