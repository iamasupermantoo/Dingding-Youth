//
//  FKGiftView.m
//  testAnimationView
//
//  Created by frankay on 17/7/1.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKGiftView.h"

@interface FKGiftView ()<CAAnimationDelegate>
@property (strong, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIView *bgView;
@property (weak, nonatomic) IBOutlet UILabel *giftCount;
@property (weak, nonatomic) IBOutlet UILabel *giftName;

@end

@implementation FKGiftView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        self.contentView.frame = self.bounds;
        self.contentView.backgroundColor = [UIColor clearColor];
        [self addSubview:self.contentView];
        [self initSetting];
    }
    return self;
}


- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super initWithCoder:aDecoder]) {
        [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
        self.contentView.frame = self.bounds;
        self.contentView.backgroundColor = [UIColor clearColor];
        [self addSubview:self.contentView];
        [self initSetting];

    }
    
    return self;
}


- (void)layoutSubviews{
    [super layoutSubviews];
    self.contentView.frame = self.bounds;
}


- (void)initSetting{
    
//    self.backgroundColor = [UIColor clearColor];
    self.bgView.layer.borderWidth = 0.5;
    self.bgView.layer.borderColor = [UIColor whiteColor].CGColor;
    self.giftName.textColor = [UIColor whiteColor];
    self.giftCount.textColor = [UIColor fkNavBackGroundColor];
    self.giftCount.text = @"";
    if (self.tag==1001) {
        self.giftName.text = @"星星";
        self.imageView.image = IMG_NAME(@"giftstar");
    }else if (self.tag==1002){
        self.giftName.text = @"鼓掌";
        self.imageView.image = IMG_NAME(@"applaud");

    }else if (self.tag==1003){
        self.giftName.text = @"气球";
        self.imageView.image = IMG_NAME(@"balloon");

    }else if (self.tag==1004){
        self.giftName.text = @"小熊";
        self.imageView.image = IMG_NAME(@"littlebear");
    }
    
}


- (void)receiveGiftAnimationWithGiftTotalCount:(NSInteger)count{
    self.giftCount.text = [NSString stringWithFormat:@"+%ld",count];
    [self updateHightImageWithGiftCount:count];
    
    CABasicAnimation *basicScale = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    basicScale.beginTime = 0.0;
    basicScale.fromValue = @(0.3);
    basicScale.toValue = @(1.0);
    basicScale.duration = 0.5;
    basicScale.repeatCount = 1;
    basicScale.autoreverses = NO;
//    basicScale.delegate = self;
    [self.imageView.layer addAnimation:basicScale forKey:@"scale"];
    self.giftCount.text = [NSString stringWithFormat:@"+%ld",count];
}


- (void)updateHightImageWithGiftCount:(NSInteger)count{
    
    if (count<1) {
        return;
    }
    
    if (self.tag==1001) {
        self.imageView.image = IMG_NAME(@"giftstarsel");
    }else if (self.tag==1002){
        self.imageView.image = IMG_NAME(@"applaudsel");
        
    }else if (self.tag==1003){
        self.imageView.image = IMG_NAME(@"balloonsel");
        
    }else if (self.tag==1004){
        self.imageView.image = IMG_NAME(@"littlebearsel");
    }
}
@end
