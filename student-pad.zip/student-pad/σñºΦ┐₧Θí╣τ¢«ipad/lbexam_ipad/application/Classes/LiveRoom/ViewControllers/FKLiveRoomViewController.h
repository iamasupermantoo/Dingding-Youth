//
//  FKLiveRoomViewController.h
//  AgoraLiveTest
//
//  Created by frankay on 17/2/16.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FKAgoraSignalHandle.h"
#import "FKAgoraLiveHandle.h"
#import "HMBaseViewController.h"
@interface FKLiveRoomViewController :HMBaseViewController

@property(nonatomic,assign) AgoraRtcVideoProfile videoProfile;

@property(nonatomic,strong) NSString *cid;
@property(nonatomic,strong) NSString *lid;

@property(nonatomic,strong) NSString *titleName;
@end
