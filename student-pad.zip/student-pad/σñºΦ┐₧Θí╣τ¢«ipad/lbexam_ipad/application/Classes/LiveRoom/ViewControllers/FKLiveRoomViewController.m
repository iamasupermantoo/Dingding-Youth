//
//  FKLiveRoomViewController.m
//  AgoraLiveTest
//
//  Created by frankay on 17/2/16.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKLiveRoomViewController.h"
#import "FKChatBaseView.h"
#import "HMDetailToolBar.h"
#import "FKBaseChatItem.h"
#import "AppDelegate.h"
#import "IMView.h"
#import "IMLine.h"
#import "FKGiftView.h"
#import "FKimageHandle.h"
#import "FKAudioPlayerView.h"
#import "FKAudioPlayerHandle.h"
#import "ZFPlayerView.h"
#import "FKContolView.h"
#import "ZFPlayerModel.h"

#import "Masonry.h"
#import "FKEnterLiveRoomRequestTask.h"
#import "FKLeaveLiveRoomTask.h"
#import "FKDetailPageItem.h"
#import "FKLiveRoomItem.h"
#import "UIAlertController+FKAlertController.h"
#import "AVAudioSession+FKAgoraAudioSession.h"
#import "OLImageView.h"
#import "OLImage.h"
#import "FKSoundEffectPlayerHandle.h"
@interface FKLiveRoomViewController ()<FKAgoraLiveHandleDelegate,FKAgoraSignalHandleDelegate,FKChatBaseViewDelegate,IMViewDelegate,FKimageHandleDelegate,CAAnimationDelegate>
@property (weak, nonatomic) IBOutlet UIView *MetarialView;
@property (weak, nonatomic) IBOutlet UIView *chatRoomView;
@property (weak, nonatomic) IBOutlet UIView *TeacherView;
@property (weak, nonatomic) IBOutlet UIView *studentView;
@property (weak, nonatomic) IBOutlet UIImageView *pageImageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

/**画线*/
@property(nonatomic,strong) IMView *imView;
@property(nonatomic,strong) IMLine *line;
@property(nonatomic,strong) NSMutableArray *items;
@property(nonatomic,strong) NSMutableArray *lines; // 存储线
@property (weak, nonatomic) IBOutlet UIButton *paintbrushBtn; // 画笔
@property (weak, nonatomic) IBOutlet UIButton *eraserBtn;

@property(nonatomic,strong) FKSoundEffectPlayerHandle *handle;

// 聊天室
@property(nonatomic,strong) FKChatBaseView *chatView;

// 直播信令handle
@property(nonatomic,strong) FKAgoraLiveHandle *liveHandle;
@property(nonatomic,strong) FKAgoraSignalHandle *signalHandle;
@property(nonatomic,strong) FKimageHandle *imageHandle;

// 音视频
@property(nonatomic,strong) FKAudioPlayerView *audioPlayer;
@property(nonatomic,strong) ZFPlayerView *playerView;
@property(nonatomic,strong) ZFPlayerModel *playerModel;
@property(nonatomic,strong) UIView *zfFatherView;

@property(nonatomic,strong) FKLiveRoomItem *roomItem;
@property(nonatomic,strong) FKDetailPageItem *CurrentpageItem;
@property(nonatomic,strong) NSMutableArray *pageItems;
@property(nonatomic,strong) NSMutableArray *ImagesArray;
@property(nonatomic,assign) BOOL isoffLine;
@property(nonatomic,assign) NSUInteger failCount;
@property(nonatomic,strong) NSString *Currentpagestr;

@property(nonatomic,strong) UIView *zfplayerCoverView;

@property(nonatomic,strong) FKEnterLiveRoomRequestTask *task;
@property (weak, nonatomic) IBOutlet FKGiftView *starView;
@property (weak, nonatomic) IBOutlet FKGiftView *applaudView;

@property (weak, nonatomic) IBOutlet FKGiftView *ballonView;

@property (weak, nonatomic) IBOutlet FKGiftView *littleBearView;

@property(nonatomic,strong) OLImageView *giftImageView;

@property(nonatomic,assign) FKGiftType giftType;



@end

@implementation FKLiveRoomViewController{
    NSInteger typeCount;
    NSInteger starCount;
    NSInteger applauseCount;
    NSInteger ballonCount;
    NSInteger bearCount;
}
// 改变状态栏的前背景
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (instancetype)init{
    self = [super init];
    if (self) {
        self.failCount = 0;
        self.isoffLine = NO;
//        self.shouldHidenNavigationBar = YES;
    }
    return self;
}


-(FKEnterLiveRoomRequestTask *)task{
    if (!_task) {
        _task = [[FKEnterLiveRoomRequestTask alloc] init];
        _task.cid = self.cid;
        _task.lid = self.lid;
    }
    return _task;
    
}

- (NSMutableArray *)pageItems{
    if (!_pageItems) {
        _pageItems = [NSMutableArray array];
    }
    return _pageItems;
}

- (NSMutableArray *)ImagesArray{
    if (!_ImagesArray) {
        _ImagesArray =[NSMutableArray array];
    }
    return _ImagesArray;
}


- (FKAudioPlayerView *)audioPlayer{
    if (!_audioPlayer) {
        _audioPlayer = [[FKAudioPlayerView alloc] initWithFrame:CGRectMake(93, CGRectGetHeight(self.MetarialView.frame)/2.0-30,self.MetarialView.frame.size.width-186, 60)];
    }
    return _audioPlayer;
}

- (UIView *)zfplayerCoverView{
    if (!_zfplayerCoverView) {
        _zfplayerCoverView = [[UIView alloc] init];
        _zfplayerCoverView.userInteractionEnabled = YES;
        _zfplayerCoverView.backgroundColor = [UIColor clearColor];
    }
    return _zfplayerCoverView;

}

- (ZFPlayerModel *)playerModel
{
    if (!_playerModel) {
        _playerModel                  = [[ZFPlayerModel alloc] init];
        _playerModel.title            = @"这里设置视频标题";
    
        _playerModel.placeholderImage = [UIImage imageNamed:@"loading_bgView1"];
        _playerModel.fatherView       = self.zfFatherView;
    }
    return _playerModel;
}


- (UIView *)zfFatherView{
    if (!_zfFatherView) {
        _zfFatherView = [[UIView alloc] init];
        [self.MetarialView addSubview:_zfFatherView];
        [_zfFatherView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(_MetarialView);
            make.leading.mas_equalTo(93);
            make.trailing.mas_equalTo(-93);
            // 这里宽高比16：9,可自定义宽高比
            make.height.mas_equalTo(_zfFatherView.mas_width).multipliedBy(9.0f/16.0f);
        }];
        
            [self.MetarialView addSubview:self.zfplayerCoverView];
            [_zfplayerCoverView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.center.equalTo(_MetarialView);
                make.leading.mas_equalTo(93);
                make.trailing.mas_equalTo(-93);
                // 这里宽高比16：9,可自定义宽高比
                make.height.mas_equalTo(_zfplayerCoverView.mas_width).multipliedBy(9.0f/16.0f);
            }];
    }
    return _zfFatherView;
    
}


- (FKAgoraLiveHandle *)liveHandle{
    if (!_liveHandle) {
        _liveHandle = [[FKAgoraLiveHandle alloc] init];
        
        _liveHandle.appId = @"81d04aa3482a4261a1ccf9b7367eb312";
        _liveHandle.channelKey = self.roomItem.channelKey;
        _liveHandle.uid = self.roomItem.account;
        _liveHandle.Roletype = self.roomItem.role;
        _liveHandle.roomNum = self.roomItem.channelName;
        _liveHandle.videoProfile = self.videoProfile;
        _liveHandle.delegate = self;
    }
    return _liveHandle;
}


- (FKAgoraSignalHandle *)signalHandle{
    if (!_signalHandle) {
        _signalHandle = [[FKAgoraSignalHandle alloc] init];
        _signalHandle.delegate = self;
    }
    return _signalHandle;
}



-(FKimageHandle *)imageHandle{
    if (!_imageHandle) {
        _imageHandle = [[FKimageHandle alloc] init];
        _imageHandle.delegate = self;
    }
    return _imageHandle;
}


- (FKChatBaseView *)chatView{
    if (!_chatView) {
        _chatView = [[FKChatBaseView alloc] initWithSuperViewFrame:self.chatRoomView.frame];
        _chatView.delegate = self;
        _chatView.superView = self.chatRoomView;
        _chatView.NavBarHeight = 64;
        _chatView.bottomHeight = 0;
    }
    return _chatView;
}

- (IMLine *)line{
    if (!_line) {
        _line = [[IMLine alloc] init];
    }
    return _line;
}

- (IMView *)imView{
    if (!_imView) {
        
        _imView = [[IMView alloc] init];
        _imView.frame = self.MetarialView.bounds;
        _imView.backgroundColor = [UIColor clearColor];
        _imView.delegate = self;
        _imView.sliderValue = 0.5;
        _imView.color = [UIColor fkColorWithString:@"#25aa1f"];
        _imView.selfLineColor = [UIColor fkColorWithString:@"#217aff"];
        _imView.userInteractionEnabled = NO;
    }
    return _imView;
}


- (NSMutableArray *)lines{
    if (!_lines) {
        _lines = [NSMutableArray array];
    }
    return _lines;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor fkColorWithString:@"#40508f"];
    self.chatRoomView.backgroundColor = [UIColor fkColorWithString:@"#353152"];
    self.chatRoomView.layer.cornerRadius = 25;
    self.MetarialView.layer.cornerRadius = 25;
    self.studentView.layer.cornerRadius = 25;
    self.TeacherView.layer.cornerRadius = 25;
    self.MetarialView.clipsToBounds = YES;
    self.studentView.clipsToBounds = YES;
    self.TeacherView.clipsToBounds = YES;
//    self.automaticallyAdjustsScrollViewInsets = NO;
//    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.items = [NSMutableArray array];
    
    self.title = HMLocal(self.titleName);
    
    // 获取数据
    [self getLiveRoomInfo];
    
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
}


- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];

//    UIView *view = [[UIView alloc] initWithFrame:self.chatRoomView.bounds];
//    [self.chatRoomView addSubview:view];
//    [view addSubview:self.chatView];
    
    [self.MetarialView insertSubview:self.imView aboveSubview:self.pageImageView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    
}

- (IBAction)leftButtonAction:(id)sender{
    // 离开直播间 需要退出
   
    if (!_liveHandle) {
        // 进来后没有初始化sdk的情况下（一般无网络）
        [super leftButtonAction:sender];
      
    }else{
        
        [self.liveHandle leaveChannel];
        [self.signalHandle logout];
        [self.imageHandle cleanChace];
        [self.imView clearAll];
        
        if (_zfFatherView) {
            [_playerView pause];
            [_zfFatherView removeFromSuperview];
            _zfFatherView = nil;
            _playerView = nil;
            _playerModel = nil;
            [_zfplayerCoverView removeFromSuperview];
            _zfplayerCoverView = nil;
        }
        
        if (_audioPlayer) {
            [_audioPlayer close];
            [_audioPlayer removeFromSuperview];
            _audioPlayer = nil;
        }
        [DDProgressHUD showHUDWithStatus:@"离开房间..."];
    }
}


// 资料加载成功
-(void)downLoadSuccessWithImagechaces:(NSDictionary *)dict{
    dispatch_async(dispatch_get_main_queue(), ^{
        // 主线程中更新ui
        [DDProgressHUD showSucessWithStatus:@"资料加载成功"];
        //
        UIImage *image = [self.imageHandle getImageWithUrl:self.ImagesArray[self.CurrentpageItem.idx] withType:1];
        self.pageImageView.image = image;
        [self.liveHandle initagoraKit];
        
        [self.signalHandle loginAgoraWebWithAccount:[@(self.roomItem.account) stringValue] withToken:self.roomItem.signalingKey];
    });
    
}


#pragma mark -FKChatBaseViewDelegate

-(void)sendText:(NSString *)text{
    
    if ([text isEqualToString:@""]) {
        // 为空
        [DDProgressHUD showErrorWithStatus:@"发送内容不能为空!"];
        return;
    }
    
    // 发送消息
    NSData *data = [text dataUsingEncoding:NSUTF8StringEncoding];
    [self.signalHandle sendChannelMsgInChannelName:self.roomItem.channelName WithMsg:[self SignalMsgWithType:1 withData:[data base64EncodedStringWithOptions:0]]];
}

#pragma mark - FKAgoraLiveHandleDelegate
-(void)fkFirstLocalVideoWithView:(UIView *)view{
    if (self.roomItem.role == FKStatusTypeStudent) {
        // 学生
        view.frame = self.studentView.bounds;
        [self.studentView addSubview:view];
        
    }else if(self.roomItem.role == FKStatusTypeTeacher){
        view.frame = self.TeacherView.bounds;
        [self.TeacherView addSubview:view];
    }
}


-(void)fkFirstRemoteVideoWithView:(UIView *)view withUid:(NSUInteger)uid{
    if (self.roomItem.studentAccount== uid) {
        // 学生的流
        view.frame = self.studentView.bounds;
        [self.studentView addSubview:view];
        
    }else if(self.roomItem.teacherAccount == uid){
        // 老师的流
        view.frame = self.TeacherView.bounds;
        [self.TeacherView addSubview:view];
        // 如果学生重连 获取老师的第一帧视频的时候才开始获取ppt当前的位置
        // 重连就找到当前的
        if (self.Currentpagestr) {
            [self findDataSourceWithType:FKSignalMsgTypePage withData:self.Currentpagestr AndInfo:nil];
            self.Currentpagestr = nil;
        }
    }
}

-(void)fkCheckLocalVideoStatus:(AgoraRtcLocalVideoStats *)stats{
    // 如果掉线之后   重连后 判断在不在线 不在重新登陆信令加入频道
    if (![self.signalHandle isOnline]) {
         [self.signalHandle loginAgoraWebWithAccount:[@(self.roomItem.account) stringValue] withToken:self.roomItem.signalingKey];
    }
}


// 用户离线
- (void)fkOtherUserOffLineWithUserId:(NSUInteger)uid{
    if (_audioPlayer) {
        [_audioPlayer close];
        [_audioPlayer removeFromSuperview];
        _audioPlayer = nil;
    }
    
    if (uid == self.roomItem.teacherAccount) {
        [DDProgressHUD showWithStatus:@"老师离开了房间"];
    }
    
    if (uid == self.roomItem.studentAccount) {
        [DDProgressHUD showWithStatus:@"学生离开了房间"];
    }

}

// 用户加入房间
- (void)fkRemoteUserJoinRoomWithUserId:(NSUInteger)uid{
    
    if (uid == self.roomItem.teacherAccount) {
        [DDProgressHUD showWithStatus:@"老师加入了房间"];
    }
    
    if (uid == self.roomItem.studentAccount) {
        [DDProgressHUD showWithStatus:@"学生加入了房间"];
    }
}


// 离开成功后
- (void)fkLeaveSuccess{
    
    // 引擎销毁之后
    self.liveHandle = nil;
    self.signalHandle = nil;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [DDProgressHUD dismiss];
        // 告诉服务器 我离开了
        FKLeaveLiveRoomTask *task = [[FKLeaveLiveRoomTask alloc] init];
        task.lid = self.lid;
        task.cid = self.cid;
        [task loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
            if (!error) {
                 [self.navigationController popViewControllerAnimated:YES];
             

            }
        }];
      
    });
}



- (void)getLiveRoomInfo{
    
    [self.task loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            NSArray *pages =response[@"data"][@"liveInfo"][@"framesInfo"][@"frames"];
            self.roomItem = [FKLiveRoomItem itemWithDictionary:response[@"data"][@"liveInfo"][@"roomInfo"]];
            if (pages.count>0) {
                [pages enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    FKDetailPageItem *pageItem = [FKDetailPageItem itemWithDictionary:obj];
                    [self.pageItems addObject:pageItem];
                    NSString *url = [pageItem.image imageUrlWithWidth:CGRectGetWidth(self.MetarialView.frame) height:CGRectGetHeight(self.MetarialView.frame)];
                    // page的图片添加到数组中
                    if (url) {
                        [self.ImagesArray addObject:url];
                    }
                    
                }];
                
                if (self.ImagesArray.count!=self.pageItems.count) {
                    [DDProgressHUD showErrorWithStatus:@"服务器出错，请联系客服人员，谢谢配合！"];
                    return ;
                }
                
                self.Currentpagestr = [NSString stringWithFormat:@"%@,%@",response[@"data"][@"liveInfo"][@"rejoinInfo"][@"currentFrameX"],response[@"data"][@"liveInfo"][@"rejoinInfo"][@"currentFrameY"]];
                self.CurrentpageItem = self.pageItems[[response[@"data"][@"liveInfo"][@"rejoinInfo"][@"currentFrameX"] integerValue]];
                // 开始下载图片到本地缓存
                //            self.roomItem.channelName = @"8000";
                
                [DDProgressHUD showHUDWithStatus:@"加载资料中..."];
                [self.imageHandle downloadImageWith:self.ImagesArray];
                self.imageHandle.Urlcount = self.ImagesArray.count;
            }
            }
           }];
    
}



#pragma mark -FKAgoraSignalHandleDelegate

- (void)fkAgoraSignalLoginSuccessWithUid:(NSUInteger)uid{
    // 登陆成功后再加入频道
    
    [self.signalHandle joinChannelWithChannelName:self.roomItem.channelName];
}


- (void)fkAgoraSignalLoginFailedWithEcode:(AgoraEcode)ecode{
    
     self.failCount++;
    
    if (self.failCount<5) {
        
        //登录失败继续重新登录  三次之后提示网络异常 并退出此页面
        [self.signalHandle loginAgoraWebWithAccount:[@(self.roomItem.account) stringValue] withToken:self.roomItem.signalingKey];
        
    }else
   
    // 登陆失败
     {
        if (self.roomItem.role == 2) {
            [DDProgressHUD dismiss];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                [UIAlertController showWithTitle:@"网络异常，请检查您的网络~" WithAction1Title:@""
                    WithAction2Title:@"确定并退出直播间"
                    andconfirmBlock:^{
                    [self.navigationController popViewControllerAnimated:YES];
                } andcancelBlock:nil Incontroller:self];
                
            });
           
        }else{
           [DDProgressHUD showErrorWithStatus:@"网络异常，请检查您的网络~"];
        }
        self.failCount = 0;
    }
        
}


-(void)fkAgoraSignalLogoutWithEcode:(AgoraEcode)ecode{
    // 退出成功
//    [DDProgressHUD showWithStatus:[NSString stringWithFormat: @"%lu退出信令成功",ecode]];
}

- (void)fkAgoraSignalReceiveChannelMsg:(NSDictionary *)info{
    // 接收频道消息
    
    NSString *msg = info[@"msg"];
    
    // 解析msg的data
    NSDictionary *msgdict = [NSString convertDicWithjsonstr:msg];
    /*
        type:1
        data:@""
     */
    // 查找对应的资源 然后操作
    
    [self findDataSourceWithType:[msgdict[@"type"] integerValue] withData:msgdict[@"data"] AndInfo:info];
    
}

- (void)fkAgoraSignalJoinChannelWithName:(NSString *)name{
    NSLog(@"加入频道成功");
      [DDProgressHUD showWithStatus:@"加入频道成功"];
    if (self.isoffLine) {
        [self getPageWhenRejoin];
        self.isoffLine = NO;
    }
}


-(void)fkAgoraSignalJoinChannelFailedWithName:(NSString *)name andEcode:(AgoraEcode)ecode{
    // 加入频道失败
   
    [DDProgressHUD showWithStatus:[NSString stringWithFormat: @"加入频道失败%lu",(unsigned long)ecode]];
    if (ecode==300) {
        // 频道引擎加载失败
        [UIAlertController showWithTitle:@"引擎加载失败\n请重新进入房间" WithAction1Title:@"" WithAction2Title:@"确定" andconfirmBlock:^{
            [self.liveHandle leaveChannel];
            [self.signalHandle logout];
            [self.imageHandle cleanChace];
            [self.imView clear];
            
            if (_zfFatherView) {
                [_playerView pause];
                [_zfFatherView removeFromSuperview];
                _zfFatherView = nil;
                _playerView = nil;
                _playerModel = nil;
                
                [_zfplayerCoverView removeFromSuperview];
                _zfplayerCoverView = nil;
            }
            
            if (_audioPlayer) {
                [_audioPlayer close];
                [_audioPlayer removeFromSuperview];
                _audioPlayer = nil;
            }
            [DDProgressHUD showHUDWithStatus:@"离开房间..."];
            
        } andcancelBlock:nil Incontroller:self];
        
    }
}


- (void)fkAgoraSignalOtherJoinChannelWithName:(NSString *)name AndUid:(NSUInteger)uid{
    // 他人加入频道
//    if (uid == self.roomItem.teacherAccount) {
//     
//        [DDProgressHUD showWithStatus:@"老师加入了房间"];
//    }
    
}


- (void)fkAgoraSignalOtherLeaveChannelWithName:(NSString *)name AndUid:(NSUInteger)uid{
    // 他人离开频道
//     [DDProgressHUD showWithStatus:@"老师离开了房间"];
}

- (void)fkAgoraSignalLoseConnecting:(NSUInteger)nretry{

    //
    if (nretry==1) {
        [DDProgressHUD showHUDWithStatus:@"网络不好,正在加载..."];
       
    }
    if (nretry==10) {
         self.isoffLine = YES;
    }
    
    if (nretry == 25) {
        // 退出信令  弹出提示框
        [self.signalHandle logout];
        
        // 重新登录信令
        [self.signalHandle loginAgoraWebWithAccount:[@(self.roomItem.account) stringValue] withToken:self.roomItem.signalingKey];
    }
}


- (void)fkAgoraSignalReConnectingSuccess{
    [DDProgressHUD showWithStatus:@"重连成功!"];
    // 请求服务器的joininfo 如果和之前相同不做任何操作
    if (self.isoffLine) {
        [self getPageWhenRejoin];
    }
}


#pragma mark -  signal operation（指令操作）

// 播放一个视频
- (void)playAVideoWithUrl:(NSString *)url{
    [self.imView clearAll];

    
    if (_audioPlayer) {
        [_audioPlayer close];
        [_audioPlayer removeFromSuperview];
        _audioPlayer = nil;
    }
    
    self.playerModel.videoURL = [NSURL URLWithString:url];
    self.playerView = [[ZFPlayerView alloc] init];
    FKContolView *controlView = [[FKContolView alloc] init];
    [self.playerView playerControlView:controlView playerModel:self.playerModel];
//    

    // 设置代理
//    self.playerView.delegate = self;
    // 打开预览图
    self.playerView.hasPreviewView = YES;
    // 是否自动播放，默认不自动播放
    [self.playerView autoPlayTheVideo];
    
}


// 播放音频
- (void)playAnAudioWithUrl:(NSString *)url{
    
    [self.imView clearAll];
    if (self.playerView) {
        [_zfFatherView removeFromSuperview];
        _zfFatherView = nil;
        _playerView = nil;
        _playerModel = nil;
        [_zfplayerCoverView removeFromSuperview];
        _zfplayerCoverView = nil;
    }
    [self.MetarialView addSubview:self.audioPlayer];
    [self.audioPlayer createPlayerWithUrl:url];
}

// 显示一张图片

- (void)showPictureWithUrl:(NSString *)url{
    [self.imView clearAll];
    if (self.playerView) {
        [_zfFatherView removeFromSuperview];
        _zfFatherView = nil;
        _playerView = nil;
        _playerModel = nil;
        [_zfplayerCoverView removeFromSuperview];
        _zfplayerCoverView = nil;
    }
    
    if (_audioPlayer) {
        [_audioPlayer close];
        [_audioPlayer removeFromSuperview];
        _audioPlayer = nil;
    }
    
    
    UIImage *image = [self.imageHandle getImageWithUrl:url withType:1];
    self.pageImageView.image = image;
    
}


// 接收文本消息指令
- (void)recieveMsg:(NSString *)msg from:(NSString *)uid{
    
    //1.将base64编码后的字符串『解码』为二进制数据
    NSData *data = [[NSData alloc]initWithBase64EncodedString:msg options:0];
    
    //2.把二进制数据转换为字符串返回
   NSString *message = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    NSString *iconUrl = @"";
    NSInteger who;
    if ([uid isEqualToString:[@(self.roomItem.account) stringValue]] ) {
        // 自己的消息
        who = 0;
        dispatch_async(dispatch_get_main_queue(), ^{
            // 主线程中更新ui
            [self.chatView.toolBar clear];
        });
    }else{
        who = 1;
    }
    
    NSDictionary *dict = @{@"iconUrl":iconUrl,@"Content":message,@"who":@(who)};
    FKBaseChatItem *Item = [FKBaseChatItem itemWithDictionary:dict];
    
    [self.items addObject:Item];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        // 主线程中更新ui

        [self.chatView updateItems:self.items];
    });
    
}

// 解析左右控制指令
- (void)analysisSignalWithPagestr:(NSString *)signalstr{
    NSArray *signalArr = [signalstr componentsSeparatedByString:@","];
    NSInteger page = [signalArr[0] integerValue];
    NSInteger subPage = [signalArr[1] integerValue];
    self.CurrentpageItem = self.pageItems[page];
    dispatch_async(dispatch_get_main_queue(), ^{
        // 主线程中更新ui page一定要存在的
        
//         [self showPictureWithUrl:self.ImagesArray[self.CurrentpageItem.idx]];
        if (subPage == -1) {
             [self showPictureWithUrl:self.ImagesArray[self.CurrentpageItem.idx]];
        }else{
            
            if (self.CurrentpageItem.children!=nil) {
                [self.CurrentpageItem.children enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    
                    FKPageItem *item = obj;
                    if (subPage == item.idx) {
                        if (item.type == 1) {
                            // mp3
                            [self playAnAudioWithUrl:item.audio];
                        }
                        
                        if (item.type == 2) {
                            // mp4
                            [self playAVideoWithUrl:item.video];
                            
                        }
                        
                        *stop = YES;
                    }
                    
                }];
            }

        }
     
    });
    
}

// mp3播放器的控制
- (void)mp3ControlWithSignal:(NSString *)signal{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        // 主线程中更新ui
        if ([signal isEqualToString:@"1"]) {
            // 播放
            [self.audioPlayer play];
        }
        if ([signal isEqualToString:@"2"]) {
            // 暂停
            [self.audioPlayer pause];
        }
        if ([signal isEqualToString:@"3"]) {
            // 关闭
            [_audioPlayer close];
            [_audioPlayer removeFromSuperview];
            _audioPlayer = nil;
        }

    });

}

// MP4播放器控制
- (void)mp4ControlWithSignal:(NSString *)signal{
    dispatch_async(dispatch_get_main_queue(), ^{
        if ([signal isEqualToString:@"1"]) {
            // 播放
            [self.playerView play];
        }
        if ([signal isEqualToString:@"2"]) {
            // 暂停
            [self.playerView pause];
        }
        if ([signal isEqualToString:@"3"]) {
            // 关闭
            [self.playerView pause];
            _playerView = nil;
            _playerModel = nil;
            [_zfFatherView removeFromSuperview];
            _zfFatherView = nil;
          
            [_zfplayerCoverView removeFromSuperview];
            _zfplayerCoverView = nil;
        }
    });
}


// 画线指令
- (void)DrawLineControlWithSignal:(NSString *)signal withAccount:(NSString *)account{
    
    if ([account isEqualToString:[@(self.roomItem.account) stringValue]]) {
        // 自己发的消息
        
        return;
    }
    
    if ([signal isEqualToString:@"-1"]) {
        //  清除
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.imView clear];
        });
    }else{
        
        NSMutableArray *points = [NSMutableArray array];
        
        NSArray *arr = [signal componentsSeparatedByString:@","];
        [arr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSArray *pointarr = [obj componentsSeparatedByString:@"-"];
            CGPoint point = CGPointMake([pointarr[0] floatValue]*CGRectGetWidth(self.imView.bounds), [pointarr[1] floatValue]*CGRectGetHeight(self.imView.bounds));
            NSValue *value = [NSValue valueWithCGPoint:point];
            [points addObject:value];
        }];
        
        IMLine *line = [[IMLine alloc] init];
        line.points = points;
        NSLog(@"hahhaahha------%@",line.points);
//        [self.lines addObject:self.line];
        [self.imView.lines addObject:line];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            // 主线程中更新ui
            [self.imView setNeedsDisplay];
        });
    }
}






#pragma mark - 画笔 和  笔擦

- (IBAction)paintbrushAction:(UIButton *)sender {
   
//    typeCount++;
//    [self receiveGiftWithType:typeCount];
//    
//    if (typeCount==4) {
//        typeCount = 0;
//    }
    if (!sender.selected) {
        // 如果选中
        self.imView.userInteractionEnabled = YES;
        sender.selected = YES;
    }else{
        self.imView.userInteractionEnabled = NO;
        sender.selected = NO;
    }
    
}


- (IBAction)eraserBtnAction:(UIButton *)sender {
    // 清除自己的画线
    [self.imView clearSelfLines];
    
    // 发送指令到教师端
    [self.signalHandle sendChannelMsgInChannelName:self.roomItem.channelName WithMsg:[self SignalMsgWithType:5 withData:@"-1"]];
}

#pragma mark - IMViewDelegate
// 画完一条线

- (void)touchEndWithLines:(IMLine *)line{
    
    
//     画完一条线就发送一个指令
    NSMutableArray *all = [NSMutableArray array];
    
    [line.points enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        CGPoint point = [obj CGPointValue];
        NSString *str = [NSString stringWithFormat:@"%f-%f",point.x/CGRectGetWidth(self.imView.bounds),point.y/CGRectGetHeight(self.imView.bounds)];
        [all addObject:str];
    }];
    
    NSString *msg =[all componentsJoinedByString:@","];
    [self.signalHandle sendChannelMsgInChannelName:self.roomItem.channelName WithMsg:[self SignalMsgWithType:5 withData:msg]];
}

// 接收礼物指令
// 收到一个礼物 播放相应的动画
- (void)receiveGiftWithType:(FKGiftType)type{
    if (!self.giftImageView) {
        self.giftType = type;
        
        self.giftImageView = [[OLImageView alloc] initWithImage:[OLImage imageNamed:[NSString stringWithGiftType:type]]];
        [self.giftImageView setFrame:CGRectMake(0, 0, 200, 167.5)];
        self.giftImageView.center = self.MetarialView.center;
        [self.giftImageView setUserInteractionEnabled:YES];
        [self.MetarialView addSubview:self.giftImageView];
        
        UIView *maskBgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 210, 177)];
        maskBgView.center = self.MetarialView.center;
        maskBgView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
        maskBgView.layer.cornerRadius = 10;
        
        [self.MetarialView insertSubview:maskBgView belowSubview:self.giftImageView];
        
        [self playSoundeffectWithType:type];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.handle stop];
            
            // 延时2秒关闭动画
            if ([self.giftImageView isAnimating]) {
                
                CGPoint startPoint = [self.MetarialView convertPoint:self.giftImageView.center toView:self.view];
                // 暂停
                [self.giftImageView stopAnimating];
                [maskBgView removeFromSuperview];
                [self.giftImageView removeFromSuperview];
                self.giftImageView.center = startPoint;
                [self.view addSubview:self.giftImageView];
                [self.giftImageView stopAnimating];

                // 起始坐标
                CGPoint endPoint;
                
                if (type == FKGiftTypeStarAnimation) {
                    endPoint = [self.chatRoomView convertPoint:self.starView.center toView:self.view];
                }else if (type == FKGiftTypeApplaudAnimation){
                    endPoint = [self.chatRoomView convertPoint:self.applaudView.center toView:self.view];
                }else if (type == FKGiftTypeBallonAnimation){
                    endPoint = [self.chatRoomView convertPoint:self.ballonView.center toView:self.view];
                }else {
                    endPoint = [self.chatRoomView convertPoint:self.littleBearView.center toView:self.view];
                }
               
                CABasicAnimation *basicMove = [CABasicAnimation animationWithKeyPath:@"position"];
                basicMove.delegate = self;
                basicMove.beginTime = 0.0;
                basicMove.fromValue =[NSValue valueWithCGPoint:startPoint];
                basicMove.toValue = [NSValue valueWithCGPoint:endPoint];
                basicMove.duration = 0.5;
                basicMove.repeatCount = 1;
                basicMove.autoreverses = NO;
                // 消除动画结束后 回到原始位置闪烁
                basicMove.removedOnCompletion = NO;
                basicMove.fillMode = kCAFillModeForwards;
                [self.giftImageView.layer addAnimation:basicMove forKey:@"position"];
//
                CABasicAnimation *basicScale = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
                
                basicScale.beginTime = 0.0;
                basicScale.fromValue = @(1.0);
                basicScale.toValue = @(0.3);
                basicScale.duration = 0.5;
                basicScale.repeatCount = 1;
                basicScale.autoreverses = NO;
                basicScale.removedOnCompletion = NO;
                basicScale.fillMode = kCAFillModeForwards;
                [self.giftImageView.layer addAnimation:basicScale forKey:@"scale"];
            }
        });
    }

}


////============ 播放音效=================
- (void)playSoundeffectWithType:(FKGiftType)type{
    
    NSString *source;
    if (type==FKGiftTypeApplaudAnimation) {
        source = @"great";
    }else if (type == FKGiftTypeStarAnimation){
        source = @"good";
    }else if (type == FKGiftTypeBallonAnimation){
        source = @"wonderful";
    }else{
        source = @"excellent";
        
    }
    
    FKSoundEffectPlayerHandle *handle = [[FKSoundEffectPlayerHandle alloc] init];
    self.handle = handle;
    NSString *url = [[NSBundle mainBundle] pathForResource:source ofType:@"mp3"];
    [handle createAudioPlayerWithUrl:url];
    
}

#pragma mark - animationDelegate
- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag{
    if (flag) {
        
        [self.giftImageView removeFromSuperview];
        [self.giftImageView.layer removeAllAnimations];
        self.giftImageView = nil;
        if (self.giftType == FKGiftTypeStarAnimation) {
            starCount++;
            [self.starView receiveGiftAnimationWithGiftTotalCount:starCount];
        }else if (self.giftType  == FKGiftTypeApplaudAnimation){
            applauseCount++;
            [self.applaudView receiveGiftAnimationWithGiftTotalCount:applauseCount];
        }else if (self.giftType  == FKGiftTypeBallonAnimation){
            ballonCount++;
             [self.ballonView receiveGiftAnimationWithGiftTotalCount:ballonCount];
        }else if (self.giftType  == FKGiftTypeLittleBearAnimation){
            bearCount++;
            [self.littleBearView receiveGiftAnimationWithGiftTotalCount:bearCount];
        }
    }
}

#pragma mark - find datasource

- (void)findDataSourceWithType:(FKSignalMsgType)type withData:(NSString *)str  AndInfo:(NSDictionary *)info {
    if (type == FKSignalMsgTypeText) {
        [self recieveMsg:str from:info[@"account"]];
    }else
    
    if (type==FKSignalMsgTypePage) {
        [self analysisSignalWithPagestr:str];
    }else
    
    if (type==FKSignalMsgTypeMp3) {
        [self mp3ControlWithSignal:str];
    }else
    
    if (type == FKSignalMsgTypeMp4) {
        [self mp4ControlWithSignal:str];
    }else
    
    if (type==FKSignalMsgTypeLine) {
        [self DrawLineControlWithSignal:str withAccount:info[@"account"]];
    }else
        
    if (type == FKSignalMsgTypeGift) {
        
        
        dispatch_async(dispatch_get_main_queue(), ^{
            // 主线程中更新ui
            [self receiveGiftWithType:[str integerValue]];

        });
    }
    
}

// 构造类型信息
- (NSString *)SignalMsgWithType:(NSInteger)type withData:(NSString *)str{
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    [dict setObject:@(type) forKey:@"type"];
//    NSString *utf8str = [str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    [dict setObject:str forKey:@"data"];
    // 转成json
    return [NSString convertJsonStrWith:dict];
    
}

#pragma  mark - rejoin getdata

- (void)getPageWhenRejoin{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.task loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
            if (!error) {
                NSInteger idx = [response[@"data"][@"liveInfo"][@"rejoinInfo"][@"currentFrameX"] integerValue];
                if (self.CurrentpageItem.idx != idx) {
                    self.Currentpagestr = [NSString stringWithFormat:@"%@,%@",response[@"data"][@"liveInfo"][@"rejoinInfo"][@"currentFrameX"],response[@"data"][@"liveInfo"][@"rejoinInfo"][@"currentFrameY"]];
                    self.CurrentpageItem = self.pageItems[[response[@"data"][@"liveInfo"][@"rejoinInfo"][@"currentFrameX"] integerValue]];
                    UIImage *image = [self.imageHandle getImageWithUrl:self.ImagesArray[self.CurrentpageItem.idx] withType:1];
                    self.pageImageView.image = image;
                    
                    [self findDataSourceWithType:FKSignalMsgTypePage withData:self.Currentpagestr AndInfo:nil];
                }
            }
        }];
    });
    
}



//- (BOOL)shouldAutorotate{
//    return YES;
//}
//
//
//
//- (UIInterfaceOrientationMask)supportedInterfaceOrientations{
//
//    return UIInterfaceOrientationMaskLandscape;
//}




- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
