//
//  FKReplayVC.h
//  lbexam
//
//  Created by frankay on 17/6/26.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseViewController.h"

@interface FKReplayVC : HMBaseViewController

@property(nonatomic,strong) NSString *videoURL;
@property(nonatomic,strong) NSString *videoTitle;
@end
