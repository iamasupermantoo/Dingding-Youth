//
//  FKEnterLiveRoomRequestTask.h
//  lbexam_ipad
//
//  Created by frankay on 17/3/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface FKEnterLiveRoomRequestTask : HMBaseRequestTask
@property(nonatomic,strong) NSString *cid;
@property(nonatomic,strong) NSString *lid;
@end
