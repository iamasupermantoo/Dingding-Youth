//
//  FKEnterLiveRoomRequestTask.m
//  lbexam_ipad
//
//  Created by frankay on 17/3/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKEnterLiveRoomRequestTask.h"

@implementation FKEnterLiveRoomRequestTask

+ (BOOL)needLogin{
    return YES;
}


- (NSString *)apiName{
    return @"/live/info";
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.cid || [self.cid ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"cid"];
    }
    if (!self.lid || [self.lid ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"lid"];
    }
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    
    [self.parameterDictionary setObject:self.cid forKey:@"cid"];
    [self.parameterDictionary setObject:self.lid forKey:@"lid"];
}

@end
