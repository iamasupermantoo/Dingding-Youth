//
//  FKLeaveLiveRoomTask.m
//  lbexam_ipad
//
//  Created by frankay on 17/7/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKLeaveLiveRoomTask.h"

@implementation FKLeaveLiveRoomTask

- (NSString *)apiName{
    
    return @"/live/leave";
    
}

- (WSHTTPMethod)requestMethod{
    return WSHTTPMethodPOST;
}

- (NSError *)requestLocalCheckParameterValidity{
    NSError *error = [super requestLocalCheckParameterValidity];
    if (error) {
        return error;
    }
    if (!self.cid || [self.cid ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"cid"];
    }
    if (!self.lid || [self.lid ddIsEmpty]) {
        return [NSError wsLocalParamErrorKey:@"lid"];
    }
    return nil;
}

- (void)requestParameterConfiguration{
    [super requestParameterConfiguration];
    
    [self.parameterDictionary setObject:self.cid forKey:@"cid"];
    [self.parameterDictionary setObject:self.lid forKey:@"lid"];
}
@end
