//
//  FKLeaveLiveRoomTask.h
//  lbexam_ipad
//
//  Created by frankay on 17/7/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "HMBaseRequestTask.h"

@interface FKLeaveLiveRoomTask : HMBaseRequestTask
@property(nonatomic,strong) NSString *lid;
@property(nonatomic,strong) NSString *cid;
@end
