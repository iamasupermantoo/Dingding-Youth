//
//  HMTypeDefine.h
//  UDan
//
//  Created by frankay on 17/1/3.
//  Copyright © 2017年 frankay. All rights reserved.
//

#ifndef HMTypeDefine_h
#define HMTypeDefine_h

typedef void (^HMBlock)(id userInfo);

typedef NS_ENUM(NSInteger, HMBOOL) {
    HMBOOLUnkown = -1, /**默认值初始值*/
    HMBOOLFalse  = 0,  /**BOOL值的NO or bool值得false*/
    HMBOOLTrue   = 1,  /**BOOL值的YES or bool值得true*/
};

typedef NS_ENUM(NSInteger, HMAccountType) {
    HMAccountTypeMobile = 0,      /**手机号*/
    HMAccountTypeQQ = 1,         /**QQ*/
    HMAccountTypeWechat = 2,     /**微信*/
};

typedef NS_ENUM(NSInteger, HMUserType) {
    HMUserTypeUnkown = -1,      /**默认值*/
    HMUserTypeSenior  = 0,      /**高中生*/
    HMUserTypeUniversity = 1,  /**大学生*/
};

typedef NS_ENUM(NSInteger, HMAcademicDegreeType) {
    HMAcademicDegreeTypeUnkown = -1,            /**未知*/
    HMAcademicDegreeTypeUndergraduate = 0,      /**本科*/
    HMAcademicDegreeTypejunioruniversity = 1,   /**专科*/
    HMAcademicDegreeTypePostGraduate = 2,       /**研究生*/
    HMAcademicDegreeTypeDoctor = 3,             /**博士生*/
    HMAcademicDegreeTypePostDoctorate = 4,      /**博士后*/
};

typedef NS_ENUM(NSInteger, FKJumpRegistVCType) {
    FKJumpRegistVCTypeUnkown = -1,      /**未知*/
    FKJumpRegistVCTypeMobile = 0,       /**手机号注册*/
    FKJumpRegistVCTypeForget = 1,       /**忘记密码*/
    FKJumpRegistVCTypeWxQq2Bind = 2,         /**微信，QQ登陆绑定*/
};

typedef NS_ENUM(NSInteger, HMGenderType) {
    HMGenderTypeUnkown = -1,   /**未知*/
    HMGenderTypeMale = 0,      /**男生*/
    HMGenderTypeFemale = 1,    /**女生*/
};

typedef NS_ENUM(NSInteger, HMFeedType) {
    HMFeedTypeArticle = 0,      /**文章Feed*/
    HMFeedTypeImage = 1,        /**图片Feed*/
    HMFeedTypeUnkown,           /**未知*/
};

typedef NS_ENUM(NSInteger, HMRelationStatus) {
    HMRelationStatusUnKown = -1, /**未知状态*/
    HMRelationStatusUnFollow = 0,   /**没关联*/
    HMRelationStatusFollowing = 1,  /**只是关注别人*/
    HMRelationStatusFollowed = 2,   /**只是被别人关注*/
    HMRelationStatusFollowBoth = 3, /**相互关注*/
};

typedef NS_ENUM(NSInteger, FKLearnDegreeType) {
    FKLearnDegreeTypeLowest = 1, // 最低20%-40%
    FKLearnDegreeTypeLow = 2, // 低40%-60%
    FKLearnDegreeTypeHeight = 3, // 60%-80%
    FKLearnDegreeTypeHeightest = 4 // 80%-100%
};

typedef NS_ENUM(NSInteger, FKTeachQualityType) {
    FKTeachQualityTypeLowest = 1, // 最低
    FKTeachQualityTypeLow = 2, // 低
    FKTeachQualityTypeHeight = 3, // 高
    FKTeachQualityTypeHeightest = 4 // 最高
};

typedef NS_ENUM(NSInteger, FKPublishType){
    FKPublishTypeArtical = 0,            /**发布文章*/
    FKPublishTypeAnwser  = 1,            /**发布问答回答*/
    FKPublishTypeQuestion = 2,           /**发布问题*/
};

typedef NS_ENUM(NSInteger, FKSignalMsgType){
    FKSignalMsgTypeText = 1,        /**文本内容*/
    FKSignalMsgTypePage = 2,        /**page指令*/
    FKSignalMsgTypeMp3 = 3,         /**mp3操作指令*/
    FKSignalMsgTypeMp4 = 4,         /**mp4操作指令*/
    FKSignalMsgTypeLine = 5,        /**画线操作指令*/
    FKSignalMsgTypeGift = 6         /**接收礼物*/
};

typedef NS_ENUM(NSInteger, FKGiftType){
    FKGiftTypeStarAnimation = 1,        /**星星✨*/
    FKGiftTypeApplaudAnimation = 2,        /**鼓掌👏*/
    FKGiftTypeBallonAnimation = 3,         /**气球🎈*/
    FKGiftTypeLittleBearAnimation = 4,         /**小熊*/
};

typedef NS_ENUM(NSInteger, FKHomeWorkState){
    FKHomeWorkStateWaitingCommit = 0,        /**等待提交作业*/
    FKHomeWorkStateWaitingMark  = 1,        /**等待评分*/
    FKHomeWorkStateMarked = 2,             /**已评分*/
};

typedef NS_ENUM(NSInteger, FKSessionFileType){
    FKSessionFileTypeText = 0,              /**文本类型*/
    FKSessionFileTypePicture = 1,           /**图片类型*/
    FKSessionFileTypeVideo = 2,             /**语音类型*/
    FKSessionFileTypeAudio = 3,             /**视频类型*/
};

#endif /* HMTypeDefine_h */
