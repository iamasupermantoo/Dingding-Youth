//
//  HMMacroDefine.h
//  UDan
//
//  Created by lilingang on 16/9/29.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#ifndef HMMacroDefine_h
#define HMMacroDefine_h

#define SCREENWIDTH   (CGRectGetWidth([UIScreen mainScreen].bounds))
#define SCREENHEIGHT  (CGRectGetHeight([UIScreen mainScreen].bounds))
#define IPAD_SCREENWIDTH    SCREENWIDTH-191.0-80
#define IPAD_FULLSCREEN_X   (SCREENWIDTH-IPAD_SCREENWIDTH)/2.0

#define IPAD_HALFSCREEN_X   191.0+40.0

#define MAINWINDOW    [[[UIApplication sharedApplication] delegate] window]
#define WEAKSELF __weak typeof(self) me = self;

#define kNoGapWithSepLine UIEdgeInsetsMake(0, -8.0, 0, -8.0)

#define kIpadNoGapSeperateInsets UIEdgeInsetsMake(0, -1000.0, 0, -1000.0)

#define IMGNAME(s)    [[UIImage imageNamed:s] resizableImageWithCapInsets:UIEdgeInsetsMake(30, 15, 6, 15)]

#define IMG_NAME(s) [UIImage imageNamed:s]
#define USER_DEFAULTS [NSUserDefaults standardUserDefaults]


#define kNotParaPush(classStr) [HMRouterHandler NotHaveParameterPushWith:classStr]; 
//**国际化*/
#ifndef HMLocal
#define HMLocal(s)\
[[NSBundle mainBundle] localizedStringForKey:s value:s table:@""]

#endif

#ifdef DEBUG

#define PRINT_RETAIN_COUNT(obj)   NSLog(@"\n======%@的引用计数：%ld======",NSStringFromClass([obj class]),CFGetRetainCount((__bridge CFTypeRef)(obj)));
//#undef RETAIN
//do sth.
#else
//do sth.
#endif
//**单例*/
#ifndef HMSYNTHESIZE_SINGLETON_FOR_CLASS
#define HMSYNTHESIZE_SINGLETON_FOR_CLASS(classname) \
+ (classname *)shareInstance \
{\
\
static dispatch_once_t pred; \
\
static classname *instance = nil; \
\
dispatch_once(&pred, ^{ \
\
instance = [[self alloc] init]; \
\
} \
\
);\
return instance; \
}
#endif

#endif /* HMMacroDefine_h */
