//
//  HMGrowingTextView.h
//  UDan
//
//  Created by lilingang on 16/10/30.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <HPGrowingTextView/HPGrowingTextView.h>

@interface HMGrowingTextView : HPGrowingTextView

@end
