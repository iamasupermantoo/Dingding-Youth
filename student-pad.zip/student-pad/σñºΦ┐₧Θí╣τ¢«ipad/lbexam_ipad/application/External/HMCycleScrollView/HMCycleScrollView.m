//
//  HMCycleScrollView.m
//  UIComponentsDemo
//
//  Created by lilingang on 16/10/10.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMCycleScrollView.h"

NSUInteger const HMReuseTitleViewCount = 3;

typedef NS_ENUM(NSInteger, HMCycleScrollViewScrollDirection) {
    HMCycleScrollViewScrollDirectionNone,
    HMCycleScrollViewScrollDirectionLeft,
    HMCycleScrollViewScrollDirectionRight,
};

@interface HMCycleScrollView ()<UIScrollViewDelegate>

@property (nonatomic, strong) UIScrollView *scrollView;

@property (nonatomic, strong) NSArray *titleViewArray;

@property (nonatomic, assign) NSUInteger currentIndex;

@property (nonatomic, assign) NSUInteger expandCurrentIndex;

@property (nonatomic, strong) NSTimer *animationTimer;

@property (nonatomic, assign) CGPoint lastContentOffset;

@end

@implementation HMCycleScrollView

- (void)dealloc{
    self.scrollView.delegate = nil;
}

#pragma mark - init
- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initSettings];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initSettings];
    }
    return self;
}

- (void)initSettings{
    self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectZero];
    self.scrollView.delegate = self;
    self.scrollView.pagingEnabled = YES;
    self.scrollView.showsVerticalScrollIndicator = NO;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    [self addSubview:self.scrollView];
    
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapHandler:)];
    [self.scrollView addGestureRecognizer:tapGestureRecognizer];
}

- (void)layoutSubviews{
    [super layoutSubviews];
    self.scrollView.frame = CGRectInset(self.bounds, 0, 0);
    self.scrollView.contentSize = CGSizeMake([self viewWidth]*HMReuseTitleViewCount, [self viewHeight]);
    self.lastContentOffset = CGPointMake([self viewWidth]*(HMReuseTitleViewCount/2), 0);
    [self.scrollView setContentOffset:self.lastContentOffset animated:NO];
    for (NSInteger i = 0; i < HMReuseTitleViewCount; i ++) {
        UIView *view = self.titleViewArray[i];
        view.frame = CGRectMake([self viewWidth]*i, 0,[self viewWidth], [self viewHeight]);
    }
}

#pragma mark - Public Methods

- (void)reloadData{
    self.scrollView.scrollEnabled = self.totalItemsCount > 1;
    if (!self.titleViewArray || ![self.titleViewArray count]) {
        NSAssert([self.delegate respondsToSelector:@selector(hmTitleViewForCycleScrollView:)], @"must implementation @selector(hmTitleViewForCycleScrollView:)");
        NSMutableArray *viewArray = [NSMutableArray arrayWithCapacity:HMReuseTitleViewCount];
        for (NSInteger i = 0; i < HMReuseTitleViewCount; i ++) {
            UIView *view = [self.delegate hmTitleViewForCycleScrollView:self];
            [self.scrollView addSubview:view];
            [viewArray addObject:view];
        }
        self.titleViewArray = viewArray;
    }
    self.expandCurrentIndex = self.totalItemsCount * HMReuseTitleViewCount + self.currentIndex;
    if (self.expandCurrentIndex <= 0) {
        return;
    }
    NSUInteger prepreIndex = self.expandCurrentIndex - floor(HMReuseTitleViewCount/2.0);
    if ([self.delegate respondsToSelector:@selector(hmCycleScrollView:configureTileView:forIndex:)]) {
        for (NSInteger i = 0; i < HMReuseTitleViewCount; i ++) {
            UIView *view = self.titleViewArray[i];
            [self.delegate hmCycleScrollView:self configureTileView:view forIndex:(prepreIndex+i)%self.totalItemsCount];
        }
    }
    [self.scrollView setContentOffset:self.lastContentOffset animated:NO];
}

#pragma mark - Private Methods

- (HMCycleScrollViewScrollDirection)scrollDirectionWithHorizontalOffset:(CGPoint)offset {
    HMCycleScrollViewScrollDirection scrollDirection = HMCycleScrollViewScrollDirectionNone;
    if (offset.x <= self.lastContentOffset.x - [self viewWidth]/2.0) {
        scrollDirection = HMCycleScrollViewScrollDirectionLeft;
    } else if (offset.x >= self.lastContentOffset.x + [self viewWidth]/2.0){
        scrollDirection = HMCycleScrollViewScrollDirectionRight;
    }
    return scrollDirection;
}

- (void)tapHandler:(UITapGestureRecognizer *)tapGestureRecognizer{
    if (self.delegate && [self.delegate respondsToSelector:@selector(hmCycledScrollView:didSelectedIndex:)]) {
        [self.delegate hmCycledScrollView:self didSelectedIndex:self.currentIndex];
    }
}

#pragma mark - Timer

- (void)destroyTimer{
    if (self.animationTimer) {
        [self.animationTimer invalidate];
        self.animationTimer = nil;
    }
}

- (void)startTimer{
    [self destroyTimer];
    if (_animationTimeInterval <= 0.5) {
        return;
    }
    if (self.totalItemsCount <= 1) {
        return;
    }
    self.animationTimer = [NSTimer scheduledTimerWithTimeInterval:_animationTimeInterval
                                                           target:self
                                                         selector:@selector(animationTimerDidFired:)
                                                         userInfo:nil
                                                          repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.animationTimer forMode:NSRunLoopCommonModes];
}

- (void)animationTimerDidFired:(NSTimer *)timer{
    if (!self.delegate) {
        [self destroyTimer];
        return;
    }
    [self.scrollView setContentOffset:CGPointMake(self.scrollView.contentOffset.x + [self viewWidth], 0) animated:YES];
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self destroyTimer];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    [self startTimer];
}

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView{
    [self scrollViewDidEndDecelerating:scrollView];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    HMCycleScrollViewScrollDirection scrollDirection = [self scrollDirectionWithHorizontalOffset:scrollView.contentOffset];
    if (scrollDirection == HMCycleScrollViewScrollDirectionLeft) {
        self.expandCurrentIndex --;
    } else if (scrollDirection == HMCycleScrollViewScrollDirectionRight){
        self.expandCurrentIndex ++;
    }
    if (scrollDirection != HMCycleScrollViewScrollDirectionNone) {
        self.currentIndex = self.expandCurrentIndex % self.totalItemsCount;
        [self reloadData];
        if (self.delegate && [self.delegate respondsToSelector:@selector(hmCycledScrollView:didScrollToIndex:)]) {
            [self.delegate hmCycledScrollView:self didScrollToIndex:self.currentIndex];
        }
    }
}

#pragma mark - Getter and Setter

- (CGFloat)viewWidth{
    return CGRectGetWidth(self.frame);
}

- (CGFloat)viewHeight{
    return CGRectGetHeight(self.frame);
}

- (void)setTotalItemsCount:(NSUInteger)totalItemsCount{
    if (_totalItemsCount != totalItemsCount) {
        [self reloadData];
    }
    _totalItemsCount = totalItemsCount;
}

- (void)setAnimationTimeInterval:(NSTimeInterval)animationTimeInterval{
    _animationTimeInterval = animationTimeInterval;
    [self startTimer];
}
@end
