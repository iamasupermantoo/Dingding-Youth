//
//  HMCycleScrollView.h
//  UIComponentsDemo
//
//  Created by lilingang on 16/10/10.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HMCycleScrollView;

@protocol HMCycleScrollViewDelegate <NSObject>
@required
/**
 返回每页的UI容器

 @param scrollView HMCycleScrollView

 @return 继承于UIView
 */
- (UIView *)hmTitleViewForCycleScrollView:(HMCycleScrollView *)scrollView;

/**
 配置每页展示的UI

 @param scrollView HMCycleScrollView
 @param view       当前要更新的UI
 @param index      当前显示的数据源在整个数据源中的位置
 */
- (void)hmCycleScrollView:(HMCycleScrollView *)scrollView configureTileView:(UIView *)view forIndex:(NSUInteger)index;

@optional

/**
 已经滚动到下一个页面

 @param cycleScrollView HMCycleScrollView
 @param index           下一个数据源在整个数据源中的位置
 */
- (void)hmCycledScrollView:(HMCycleScrollView *)cycleScrollView didScrollToIndex:(NSInteger)index;

/**
 当前选中的元素

 @param cycleScrollView HMCycleScrollView
 @param index           当前选中的数据源在整个数据源中的位置
 */
- (void)hmCycledScrollView:(HMCycleScrollView *)cycleScrollView didSelectedIndex:(NSInteger)index;

@end

@interface HMCycleScrollView : UIView


/**
 遵循HMCycleScrollViewDelegate协议的指针
 */
@property (nonatomic, weak) id<HMCycleScrollViewDelegate> delegate;

/**
 总的数据源个数
 */
@property (nonatomic, assign) NSUInteger totalItemsCount;

/**
 定时器动画时间间隔,0 -取消自动滚动 >0 -自动滚动,不需要自动滚动的时候需要手动设置为0
 */
@property (nonatomic, assign) NSTimeInterval animationTimeInterval;

/**
 更新数据源
 */
- (void)reloadData;

@end
