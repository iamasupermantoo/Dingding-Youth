//
//  YLEmailTextFieldListener.m
//  Youlun
//
//  Created by Chin on 15/5/26.
//  Copyright (c) 2015年 Chin. All rights reserved.
//

#import "YLEmailTextFieldListener.h"
#import "NSString+UDan.h"

@implementation YLEmailTextFieldListener
- (void)afterView{
    [self.view setKeyboardType:UIKeyboardTypeEmailAddress];
}
- (BOOL)isValidInput{
    return [self.view.text isEmail];
}
@end
