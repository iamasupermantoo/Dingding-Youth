//
//  UITextField+Listener.m
//  Youlun
//
//  Created by Chin on 15/5/26.
//  Copyright (c) 2015年 Chin. All rights reserved.
//

#import "UITextField+Listener.h"
#import "YLPhoneTextFieldListener.h"
#import "YLEmailTextFieldListener.h"
#import "YLNumberTextFieldListener.h"
#import "YLASCIIListener.h"
#import <objc/runtime.h>


NSString *kTextFieldListenerKey = @"kTextFieldListenerKey";
NSString *kTextFieldValiedFinishedKey = @"kTextFieldValiedFinishedKey";
NSString *kTextFieldTextShouldBeginKey = @"kTextFieldTextShouldBeginKey";
NSString *kTextFieldTextDidBeginKey = @"kTextFieldTextDidBeginKey";
NSString *kTextFieldTextDidChangeKey = @"kTextFieldTextDidChangeKey";
NSString *kTextFieldTextShouldReturnKey = @"kTextFieldTextShouldReturnKey";
NSString *kTextFieldTextEndEditingKey = @"kTextFieldTextEndEditingKey";

@implementation UITextField (Listener)
- (BOOL)isValidInput{
    return [[self listener] isValidInput];
}
- (YLTextFieldListener *)listener{
    return objc_getAssociatedObject(self, &kTextFieldListenerKey);
}
- (void)setListener:(YLTextFieldListener *)listener{
    if (listener == nil) {
        return;
    }
    objc_setAssociatedObject(self, &kTextFieldListenerKey, listener, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self setDelegate:listener];
    [listener setView:self];
}
- (void)setValidFinished:(void(^)(BOOL))finished{
    objc_setAssociatedObject(self, &kTextFieldValiedFinishedKey, finished, OBJC_ASSOCIATION_COPY);
}
- (void(^)(BOOL))validFinished{
    return objc_getAssociatedObject(self, &kTextFieldValiedFinishedKey);
}
- (void)textShouldBegin:(BOOL(^)(UITextField *))finished{
    objc_setAssociatedObject(self, &kTextFieldTextShouldBeginKey, finished, OBJC_ASSOCIATION_COPY);
}
- (BOOL(^)(UITextField *))textShouldBegin{
    return objc_getAssociatedObject(self, &kTextFieldTextShouldBeginKey);
}
- (void)textDidBegin:(void(^)(UITextField *))finished{
    objc_setAssociatedObject(self, &kTextFieldTextDidBeginKey, finished, OBJC_ASSOCIATION_COPY);
}
- (void(^)(UITextField *))textDidBegin{
    return objc_getAssociatedObject(self, &kTextFieldTextDidBeginKey);
}
- (void)textDidChange:(void(^)(UITextField *))finished{
    objc_setAssociatedObject(self, &kTextFieldTextDidChangeKey, finished, OBJC_ASSOCIATION_COPY);
}
- (void(^)(UITextField *))textDidChange{
    return objc_getAssociatedObject(self, &kTextFieldTextDidChangeKey);
}
- (void)textDidEndEditing:(void(^)(UITextField *))finished{
    objc_setAssociatedObject(self, &kTextFieldTextEndEditingKey, finished, OBJC_ASSOCIATION_COPY);
}

- (void(^)(UITextField *))textDidEndEditing{
    return objc_getAssociatedObject(self, &kTextFieldTextEndEditingKey);
}
- (void)textShouldReturn:(BOOL(^)(UITextField *))finished{
    objc_setAssociatedObject(self, &kTextFieldTextShouldReturnKey, finished, OBJC_ASSOCIATION_COPY);

}
- (BOOL(^)(UITextField *))textShouldReturn{
    return objc_getAssociatedObject(self, &kTextFieldTextShouldReturnKey);
}

- (void)setInputType:(UITextFieldInputType)type{
    YLTextFieldListener  *listener = nil;
    if (type == UITextFieldInputTypePhone) {
       listener = [[YLPhoneTextFieldListener alloc] init];
    }
    if (type == UITextFieldInputTypeEmail) {
        listener = [[YLEmailTextFieldListener alloc] init];
    }
    if (type == UITextFieldInputTypeNone) {
        listener = [[YLTextFieldListener alloc] init];
    }
    if (type == UITextFieldInputTypeNumber) {
        listener = [[YLNumberTextFieldListener alloc] init];
    }
    if (type == UITextFieldInputTypeASCII) {
        listener = [[YLASCIIListener alloc] init];
    }
    [self setListener:listener];
}
@end
