//
//  UITextField+Listener.h
//  Youlun
//
//  Created by Chin on 15/5/26.
//  Copyright (c) 2015年 Chin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YLTextFieldListener.h"

typedef NS_ENUM(NSInteger, UITextFieldInputType){
    UITextFieldInputTypeNone,
    UITextFieldInputTypePhone,
    UITextFieldInputTypeEmail,
    UITextFieldInputTypeNumber,
    UITextFieldInputTypeASCII,
};

@interface UITextField (Listener)
- (BOOL)isValidInput;
- (void)setListener:(YLTextFieldListener *)Listener;
- (void)setInputType:(UITextFieldInputType)type;

- (void)setValidFinished:(void(^)(BOOL))finished;
- (void(^)(BOOL))validFinished;

- (void)textShouldBegin:(BOOL(^)(UITextField *))finished;
- (BOOL(^)(UITextField *))textShouldBegin;

- (void)textDidBegin:(void(^)(UITextField *))finished;
- (void(^)(UITextField *))textDidBegin;

- (void)textDidChange:(void(^)(UITextField *))finished;
- (void(^)(UITextField *))textDidChange;

- (void)textShouldReturn:(BOOL(^)(UITextField *))finished;
- (BOOL(^)(UITextField *))textShouldReturn;

- (void)textDidEndEditing:(void(^)(UITextField *))finished;
- (void(^)(UITextField *))textDidEndEditing;
@end
