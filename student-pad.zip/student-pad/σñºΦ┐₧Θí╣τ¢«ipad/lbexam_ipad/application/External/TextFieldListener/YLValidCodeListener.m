//
//  YLValidCodeListener.m
//  ck
//
//  Created by 范文青 on 15/12/14.
//  Copyright © 2015年 chin. All rights reserved.
//

#import "YLValidCodeListener.h"
//#import "UIToolbar+Builder.h"
#import "NSString+UDan.h"

@implementation YLValidCodeListener
- (void)afterView{
    [self.view setKeyboardType:UIKeyboardTypeNumberPad];
  //  [self.view setInputAccessoryView:[UIToolbar inputAccessoryView:self.view sel:@selector(resignFirstResponder)]];
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (string.length == 0) {
        return YES;
    }
    if (textField.text.length >= 6) {
        return NO;
    }
    if([string isNumber]){
        return YES;
    }
    return NO;
}
@end
