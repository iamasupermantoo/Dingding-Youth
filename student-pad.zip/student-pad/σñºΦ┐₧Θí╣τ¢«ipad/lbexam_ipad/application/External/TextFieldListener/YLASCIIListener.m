//
//  YLASCIIListener.m
//  ck
//
//  Created by 范文青 on 15/12/10.
//  Copyright © 2015年 chin. All rights reserved.
//

#import "YLASCIIListener.h"
#import "NSString+UDan.h"

@implementation YLASCIIListener
- (void)afterView{
    [self.view setKeyboardType:UIKeyboardTypeASCIICapable];
}

@end
