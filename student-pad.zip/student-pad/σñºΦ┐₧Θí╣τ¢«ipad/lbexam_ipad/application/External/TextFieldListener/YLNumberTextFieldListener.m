//
//  YLNumberTextFieldListener.m
//  ck
//
//  Created by 范文青 on 15/11/24.
//  Copyright © 2015年 chin. All rights reserved.
//

#import "YLNumberTextFieldListener.h"
#import "NSString+UDan.h"

@implementation YLNumberTextFieldListener
- (void)afterView{
    [self.view setKeyboardType:UIKeyboardTypeNumberPad];
  //  [self.view setInputAccessoryView:[UIToolbar inputAccessoryView:self sel:@selector(clearKeyboard)]];
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (string.length == 0) {
        return YES;
    }
    if([string isNumber]){
        return YES;
    }
    return NO;
}
- (void)clearKeyboard{
  //  [MAIN_WINDOW endEditing:YES];
}
@end
