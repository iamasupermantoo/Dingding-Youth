//
//  YLEmailTextFieldListener.h
//  Youlun
//
//  Created by Chin on 15/5/26.
//  Copyright (c) 2015年 Chin. All rights reserved.
//

#import "YLTextFieldListener.h"

@interface YLEmailTextFieldListener : YLTextFieldListener

@end
