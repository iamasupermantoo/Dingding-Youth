//
//  YLASCIIListener.h
//  ck
//
//  Created by 范文青 on 15/12/10.
//  Copyright © 2015年 chin. All rights reserved.
//

#import "YLTextFieldListener.h"

@interface YLASCIIListener : YLTextFieldListener

@end
