//
//  YLTextFieldListener.h
//  Youlun
//
//  Created by Chin on 15/5/26.
//  Copyright (c) 2015年 Chin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YLTextFieldListener : NSObject<UITextFieldDelegate>
@property (nonatomic,weak)UITextField *view;


- (BOOL)isValidInput;
@end
