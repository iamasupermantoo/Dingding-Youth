//
//  YLPhoneTextFieldListener.m
//  Youlun
//
//  Created by Chin on 15/5/26.
//  Copyright (c) 2015年 Chin. All rights reserved.
//

#import "YLPhoneTextFieldListener.h"
#import "NSString+UDan.h"
//#import "UIToolbar+Builder.h"

@implementation YLPhoneTextFieldListener
- (void)afterView{
    [self.view setKeyboardType:UIKeyboardTypeNumberPad];
  //  [self.view setInputAccessoryView:[UIToolbar inputAccessoryView:self.view sel:@selector(resignFirstResponder)]];
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (string.length == 0) {
        return YES;
    }
    if(![string isNumber]){
        return NO;
    }
    if (textField.text.length >= 11) {
        return NO;
    }
    
    if (textField.text.length == 0) {
        if (![string isEqualToString:@"1"]) {
            return NO;
        }
    }
    if (textField.text.length == 1) {
        if (![string isEqualToString:@"3"] && ![string isEqualToString:@"4"] && ![string isEqualToString:@"5"] && ![string isEqualToString:@"7"] && ![string isEqualToString:@"8"]) {
            return NO;
        }
    }
    
    return YES;
}
- (BOOL)isValidInput{
    return [self.view.text isPhoneNumber];
}
@end
