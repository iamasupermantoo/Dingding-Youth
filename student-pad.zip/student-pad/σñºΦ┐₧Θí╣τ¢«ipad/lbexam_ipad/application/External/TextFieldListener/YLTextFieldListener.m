//
//  YLTextFieldListener.m
//  Youlun
//
//  Created by Chin on 15/5/26.
//  Copyright (c) 2015年 Chin. All rights reserved.
//

#import "YLTextFieldListener.h"
#import "UITextField+Listener.h"

@implementation YLTextFieldListener
- (void)setView:(UITextField *)view{
    _view = view;
    [self.view addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    [self afterView];
}
- (void)afterView{
    
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if (self.view.textShouldBegin) {
       return  self.view.textShouldBegin(textField);
    }
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (self.view.textDidBegin) {
        self.view.textDidBegin(textField);
    }
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField{
    if (self.view.textDidEndEditing) {
        self.view.textDidEndEditing(textField);
    }
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField{
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if (_view.textShouldReturn) {
       return _view.textShouldReturn(textField);
    }
    [[[UIApplication sharedApplication].delegate window] endEditing:YES];
    return YES;
}

- (BOOL)isValidInput{
    return YES;
}
-(void)textFieldDidChange :(UITextField *)textField{
    if ([self.view validFinished]) {
        self.view.validFinished([self isValidInput]);
    }
    if ([self.view textDidChange]) {
        self.view.textDidChange(textField);
    }
}
@end
