//
//  YLNumberTextFieldListener.h
//  ck
//
//  Created by 范文青 on 15/11/24.
//  Copyright © 2015年 chin. All rights reserved.
//

#import "YLTextFieldListener.h"

@interface YLNumberTextFieldListener : YLTextFieldListener

@end
