//
//  FKContolView.h
//  Player
//
//  Created by frankay on 17/2/18.
//  Copyright © 2017年 任子丰. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASValueTrackingSlider.h"
#import "ZFPlayer.h"

typedef void(^ChangeResolutionBlock)(UIButton *button);
typedef void(^SliderTapBlock)(CGFloat value);
@interface FKContolView : UIView



/*
    关闭视频
 **/
- (void)control_close;

/*
    播放
 **/

- (void)control_play;

///*
//    暂停
// **/
//
//- (void)control_pause;
//
///*
//    向前拖动
// **/
//
//- (void)control_forward;
//
///*
//   向后拖动
// **/
//
//- (void)control_backwards;

/*
    拖动结束
 **/
- (void)control_slideEndWith:(CGFloat)value;


@end
