//
//  FKContolView.m
//  Player
//
//  Created by frankay on 17/2/18.
//  Copyright © 2017年 任子丰. All rights reserved.
//

#import "FKContolView.h"

#import <AVFoundation/AVFoundation.h>
#import <MediaPlayer/MediaPlayer.h>
#import "UIView+CustomControlView.h"
#import "MMMaterialDesignSpinner.h"
#import "FKValueTrackingSlider.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored"-Wdeprecated-declarations"

@interface FKContolView ()
/** 当前播放时长label */
@property (nonatomic, strong) UILabel                 *currentTimeLabel;
/** 视频总时长label */
@property (nonatomic, strong) UILabel                 *totalTimeLabel;
/** 缓冲进度条 */
@property (nonatomic, strong) UIProgressView          *progressView;
/** 滑杆 */
@property (nonatomic, strong) FKValueTrackingSlider   *videoSlider;

@property (nonatomic, strong) MMMaterialDesignSpinner *activity;

/** bottomView*/
@property (nonatomic, strong) UIImageView             *bottomImageView;
/** 占位图 */
@property (nonatomic, strong) UIImageView             *placeholderImageView;

/** 播放模型 */
@property (nonatomic, strong) ZFPlayerModel           *playerModel;

/** 是否拖拽slider控制播放进度 */
@property (nonatomic, assign, getter=isDragged) BOOL  dragged;
/** 是否播放结束 */
@property (nonatomic, assign, getter=isPlayEnd) BOOL  playeEnd;
/** 是否全屏播放 */
@property (nonatomic, assign,getter=isFullScreen)BOOL fullScreen;
@end
@implementation FKContolView

- (instancetype)init
{
    self = [super init];
    
    if (self) {
        
        [self addSubview:self.placeholderImageView];
        [self addSubview:self.bottomImageView];
        [self.bottomImageView addSubview:self.currentTimeLabel];
        [self.bottomImageView addSubview:self.videoSlider];
        self.videoSlider.userInteractionEnabled = NO;
        // 添加子控件的约束
        [self makeSubViewsConstraints];
        
        // 初始化时重置controlView
        [self zf_playerResetControlView];
//        // app退到后台
//        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidEnterBackground) name:UIApplicationWillResignActiveNotification object:nil];
//        // app进入前台
//        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidEnterPlayground) name:UIApplicationDidBecomeActiveNotification object:nil];
        
    }
    return self;
}
/** 重置ControlView */
- (void)zf_playerResetControlView
{
    self.videoSlider.value           = 0.0;
    self.progressView.progress       = 0;
    self.currentTimeLabel.text       = @"00:00";
    self.placeholderImageView.alpha  = 1;
}

- (void)makeSubViewsConstraints
{
    [self.placeholderImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsZero);
    }];
    
    
    [self.bottomImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.bottom.equalTo(self);
        make.height.mas_equalTo(30);
    }];
    

    [self.currentTimeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.trailing.equalTo(self.bottomImageView.mas_trailing).offset(-15);
        make.centerY.equalTo(self.bottomImageView.mas_centerY);
        make.width.mas_equalTo(40);
    }];
    
    [self.videoSlider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.bottomImageView.mas_leading).offset(15);
        make.trailing.equalTo(self.currentTimeLabel.mas_leading).offset(-15);
        make.centerY.equalTo(self.bottomImageView.mas_centerY).offset(0);
        make.height.mas_equalTo(8);
    }];
    
}

- (MMMaterialDesignSpinner *)activity
{
    if (!_activity) {
        _activity = [[MMMaterialDesignSpinner alloc] init];
        _activity.lineWidth = 1;
        _activity.duration  = 1;
        _activity.tintColor = [[UIColor whiteColor] colorWithAlphaComponent:0.9];
    }
    return _activity;
}
/**
 slider滑块的bounds
 */
- (CGRect)thumbRect
{
    return [self.videoSlider thumbRectForBounds:self.videoSlider.bounds
                                      trackRect:[self.videoSlider trackRectForBounds:self.videoSlider.bounds]
                                          value:self.videoSlider.value];
}
#pragma mark - getter

- (UIImageView *)bottomImageView
{
    if (!_bottomImageView) {
        _bottomImageView                        = [[UIImageView alloc] init];
        _bottomImageView.userInteractionEnabled = NO;
        _bottomImageView.image                  = [UIImage imageNamed:@"bottomImage"];
        self.bottomImageView.backgroundColor = [UIColor redColor];
    }
    return _bottomImageView;
}

- (UILabel *)currentTimeLabel
{
    if (!_currentTimeLabel) {
        _currentTimeLabel               = [[UILabel alloc] init];
        _currentTimeLabel.textColor     = [UIColor whiteColor];
        _currentTimeLabel.font          = [UIFont systemFontOfSize:12.0f];
        _currentTimeLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _currentTimeLabel;
}



- (FKValueTrackingSlider *)videoSlider
{
    if (!_videoSlider) {
        _videoSlider                       = [[FKValueTrackingSlider alloc] init];
        _videoSlider.popUpViewCornerRadius = 0.0;
        _videoSlider.popUpViewColor = RGBA(19, 19, 9, 1);
        _videoSlider.popUpViewArrowLength = 8;
        
        [_videoSlider setThumbImage:[self OriginImage:[UIImage imageNamed:@"slide"] scaleToSize:CGSizeMake(16, 12)] forState:UIControlStateNormal];
        _videoSlider.maximumValue          = 1;
        _videoSlider.minimumTrackTintColor = [UIColor blueColor];
        _videoSlider.maximumTrackTintColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:1];
    }
    return _videoSlider;
}

- (UILabel *)totalTimeLabel
{
    if (!_totalTimeLabel) {
        _totalTimeLabel               = [[UILabel alloc] init];
        _totalTimeLabel.textColor     = [UIColor whiteColor];
        _totalTimeLabel.font          = [UIFont systemFontOfSize:12.0f];
        _totalTimeLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _totalTimeLabel;
}

- (UIImageView *)placeholderImageView
{
    if (!_placeholderImageView) {
        _placeholderImageView = [[UIImageView alloc] init];
        _placeholderImageView.userInteractionEnabled = NO;
    }
    return _placeholderImageView;
}


- (void)zf_playerCurrentTime:(NSInteger)currentTime totalTime:(NSInteger)totalTime sliderValue:(CGFloat)value
{
//    // 当前时长进度progress
//    NSInteger proMin = currentTime / 60;//当前秒
//    NSInteger proSec = currentTime % 60;//当前分钟
//    // duration 总时长
//    NSInteger durMin = totalTime / 60;//总秒
//    NSInteger durSec = totalTime % 60;//总分钟
    
    // 剩余时间
    NSInteger leftMin = (totalTime-currentTime) / 60;//总秒
    NSInteger leftSec = (totalTime-currentTime) % 60;//总分钟
    if (!self.isDragged) {
        // 更新slider
        self.videoSlider.value           = value;
        // 更新当前播放时间
        self.currentTimeLabel.text       = [NSString stringWithFormat:@"%02zd:%02zd", leftMin, leftSec];
    }
    // 更新总时间
//    self.totalTimeLabel.text = [NSString stringWithFormat:@"%02zd:%02zd", durMin, durSec];
}

#pragma mark - public

-(void)control_close{
    if ([self.delegate respondsToSelector:@selector(zf_controlView:closeAction:)]) {
        [self.delegate zf_controlView:self closeAction:nil];
    }
}

- (void)control_play{
    if ([self.delegate respondsToSelector:@selector(zf_controlView:playAction:)]) {
        [self.delegate zf_controlView:self playAction:nil];
    }
}

- (void)control_slideEndWith:(CGFloat)value{
    self.videoSlider.value = value;
    if ([self.delegate respondsToSelector:@selector(zf_controlView:progressSliderTouchEnded:)]) {
        [self.delegate zf_controlView:self progressSliderTouchEnded:self.videoSlider];
    }
}

/** 加载的菊花 */
- (void)zf_playerActivity:(BOOL)animated
{
    if (animated) {
        [self.activity startAnimating];
    } else {
        [self.activity stopAnimating];
    }
}

/** 播放完了 */
- (void)zf_playerPlayEnd
{
    self.playeEnd         = YES;
    self.placeholderImageView.hidden = NO;
    self.placeholderImageView.image = [self ImageWithVideoURL:self.playerModel.videoURL];
    
}


-(UIImage *)OriginImage:(UIImage*)image scaleToSize:(CGSize)size
{
    UIGraphicsBeginImageContext(size);//size为CGSize类型，即你所需要的图片尺寸
    [image drawInRect:CGRectMake(0,0, size.width, size.height)];
    UIImage* scaledImage =UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}


-(UIImage *)ImageWithVideoURL:(NSURL *)url
{
    // 根据视频的url 创建AVURLAseset对象
    AVURLAsset *asset = [AVURLAsset URLAssetWithURL:url options:nil];
    // 根据AVURLAseset 创建AVAssetImageGenerator对象（获取缩略图的对象）
    AVAssetImageGenerator *gen = [[AVAssetImageGenerator alloc] initWithAsset:asset];
    // 定义0帧处的截图
    CMTime  time = asset.duration ;
    NSError *error = nil;
    CMTime actualTime; //实际截取的时间
    CGImageRef image = [gen copyCGImageAtTime:time actualTime:&actualTime error:&error];
    UIImage *needImage = (__bridge UIImage *)(image);
    CGImageRelease(image); // 释放CG对象
    return needImage;
}
@end
