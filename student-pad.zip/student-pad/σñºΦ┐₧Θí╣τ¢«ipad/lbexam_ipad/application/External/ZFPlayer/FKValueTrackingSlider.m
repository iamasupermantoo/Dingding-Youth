//
//  FKValueTrackingSlider.m
//  lbexam
//
//  Created by frankay on 17/6/26.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKValueTrackingSlider.h"

@implementation FKValueTrackingSlider

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


- (CGRect)trackRectForBounds:(CGRect)bounds{

    return CGRectMake(0, 0, bounds.size.width, 8);

}
@end
