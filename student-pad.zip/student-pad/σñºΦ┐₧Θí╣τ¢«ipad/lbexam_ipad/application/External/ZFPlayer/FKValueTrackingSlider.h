//
//  FKValueTrackingSlider.h
//  lbexam
//
//  Created by frankay on 17/6/26.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "ASValueTrackingSlider.h"

@interface FKValueTrackingSlider : ASValueTrackingSlider

@end
