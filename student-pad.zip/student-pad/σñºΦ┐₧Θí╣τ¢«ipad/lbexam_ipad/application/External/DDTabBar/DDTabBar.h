//
//  DDTabBar.h
//  DDPagerControllerDemo
//
//  Created by lilingang on 15/11/16.
//  Copyright © 2015年 LiLingang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DDTabBarItem.h"
@class DDTabBar;

@protocol DDTabBarDelegate <NSObject>

@required
- (void)tabBar:(DDTabBar *)caller didPressedOtherTab:(NSUInteger)tag;

@optional
- (void)tabBar:(DDTabBar *)caller didPressedSameTab:(NSUInteger)tag;
- (void)tabBar:(DDTabBar *)caller didLongPressedTag:(NSUInteger)tag;

@end


@interface DDTabBar : UIView

@property (nonatomic, weak) id<DDTabBarDelegate> delegate;
/**@brief  设置背景图*/
@property (nonatomic, strong) UIImage *backGroundImage;
/**@brief 设置顶部的阴影线*/
@property (nonatomic, strong) UIImage *topShadowImage;

- (instancetype)initWithFrame:(CGRect)frame
                  tabBarItems:(NSArray *)tabBarItems;

- (void)setCurrentIndex:(NSInteger)currentIndex animated:(BOOL)animated;

- (void)cleanAllSelectedState;
@end
