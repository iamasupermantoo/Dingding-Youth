//
//  DDTabBar.m
//  DDPagerControllerDemo
//
//  Created by lilingang on 15/11/16.
//  Copyright © 2015年 LiLingang. All rights reserved.
//

#import "DDTabBar.h"
#import "DDTabBarButton.h"

@interface DDTabBar ()

@property (nonatomic, strong) UIImageView *backgroundImageView;
@property (nonatomic, strong) UIImageView *topShadowImageView;
@property (nonatomic, strong) UIView *contentView;

@property (nonatomic, assign) NSInteger currentIndex;

@property (nonatomic, strong) NSArray *tabBarItems;

@end

@implementation DDTabBar

#pragma mark Life cycle
- (instancetype)initWithFrame:(CGRect)frame tabBarItems:(NSArray *)tabBarItems{
    self = [super initWithFrame:frame];
    if (self) {
        self.contentView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(frame), CGRectGetHeight(frame))];
        [self addSubview:self.contentView];
        self.currentIndex = -1;
        [self reloadWithTabBarItems:tabBarItems];
        [self setCurrentIndex:0 animated:NO];
    }
    return self;
}


- (void)reloadWithTabBarItems:(NSArray *)tabBarItems{
    if ([tabBarItems count] == 0) {
        return;
    }
    if (self.tabBarItems != tabBarItems) {
        self.tabBarItems = tabBarItems;
    }
    //clear UI
    for (UIView *view in self.contentView.subviews) {
        if ([view isKindOfClass:[DDTabBarButton class]]) {
            [view removeFromSuperview];
        }
    }
    CGFloat width = CGRectGetWidth(self.contentView.frame);
    CGFloat height = CGRectGetHeight(self.contentView.frame);
    //create  BarButtons
    CGFloat x = 0;
    CGFloat y = 0;
    CGFloat w = width;
    CGFloat h = roundf(height / [tabBarItems count]);
    
    DDTabBarButton *tabBarButton = nil;
    int index = 0;
    for (DDTabBarItem *tabBarItem in tabBarItems) {
        tabBarButton = [[DDTabBarButton alloc] initWithFrame:CGRectMake(x, y, w, h) tabBarItem:tabBarItem];
        tabBarButton.tag = index;
        [tabBarButton addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchDown];
        
        if (tabBarItem.shouldLongPressEvent) {
            UILongPressGestureRecognizer *longPressGestureRecognizer = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(buttonLongPressed:)];
            [tabBarButton addGestureRecognizer:longPressGestureRecognizer];
        }
        y += h;
        [self.contentView addSubview:tabBarButton];
        index++;
    }
}

#pragma mark Logic

- (DDTabBarButton *)tabBarButtonForIndex:(NSInteger)index {
    DDTabBarItem *item = [self tabBarItemForIndex:index];
    if (!item) {
        return nil;
    }
    DDTabBarButton *tabBarButton = nil;
    for (DDTabBarButton *button in self.contentView.subviews) {
        if ([button isKindOfClass:[DDTabBarButton class]] && button.tabBarItem == item) {
            tabBarButton = button;
            break;
        }
    }
    return tabBarButton;
}

- (DDTabBarItem *)tabBarItemForIndex:(NSInteger)index{
    if (index < 0 || index >= [self.tabBarItems count]) {
        return nil;
    }
    return [self.tabBarItems objectAtIndex:index];
}

#pragma mark Buttons

- (void)buttonPressed:(DDTabBarButton *)button{
    if (self.currentIndex == button.tag) {
        if ([self.delegate respondsToSelector:@selector(tabBar:didPressedSameTab:)]) {
            [self.delegate tabBar:self didPressedSameTab:button.tag];
        }
    } else {
        DDTabBarItem *barItem = self.tabBarItems[button.tag];
        if (barItem.shouldChangeOtherTabState) {
            [self setCurrentIndex:button.tag animated:YES];
        }
        if ([self.delegate respondsToSelector:@selector(tabBar:didPressedOtherTab:)]) {
            [self.delegate tabBar:self didPressedOtherTab:button.tag];
        }
    }
}

- (void)buttonLongPressed:(UILongPressGestureRecognizer *)gesture{
    if (gesture.state == UIGestureRecognizerStateBegan && [self.delegate respondsToSelector:@selector(tabBar:didLongPressedTag:)]) {
        UIView *button = gesture.view;
        [self.delegate tabBar:self didLongPressedTag:button.tag];
    }
}


#pragma mark - Getter and Setter

- (void)setCurrentIndex:(NSInteger)currentIndex animated:(BOOL)animated{
    
    
    if (_currentIndex != currentIndex) {
        DDTabBarButton *oldTabBarButton = [self tabBarButtonForIndex:self.currentIndex];
        oldTabBarButton.selected = NO;
        DDTabBarButton *newTabBarButton = [self tabBarButtonForIndex:currentIndex];
        newTabBarButton.selected = YES;
        _currentIndex = currentIndex;
    }
}

- (void)setBackGroundImage:(UIImage *)backGroundImage{
    _backGroundImage = backGroundImage;
    if (!self.backgroundImageView) {
        self.backgroundImageView = [[UIImageView alloc] initWithFrame:self.bounds];
        [self addSubview:self.backgroundImageView];
        [self.backgroundImageView sendSubviewToBack:self.contentView];
    }
    self.backgroundImageView.image = backGroundImage;
}

- (void)setTopShadowImage:(UIImage *)topShadowImage{
    _topShadowImage = topShadowImage;
    if (!self.topShadowImageView) {
        self.topShadowImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), 4)];
        [self addSubview:self.topShadowImageView];
    }
    self.topShadowImageView.image = topShadowImage;
}

-(void)cleanAllSelectedState{
    for (DDTabBarButton *button in self.contentView.subviews) {
        if ([button isKindOfClass:[DDTabBarButton class]]) {
            
            button.selected = NO;
        }
    }
    self.currentIndex = -1;

}

@end
