//
//  DDTabBarButton.m
//  DDPagerControllerDemo
//
//  Created by lilingang on 15/11/16.
//  Copyright © 2015年 LiLingang. All rights reserved.
//

#import "DDTabBarButton.h"
#import "DDTabBarItem.h"

@interface DDTabBarButton ()

@property (nonatomic, strong) DDTabBarItem *tabBarItem;

@end

@implementation DDTabBarButton

- (id)initWithFrame:(CGRect)frame tabBarItem:(DDTabBarItem *)tabBarItem{
    self = [super initWithFrame:frame];
    if (self) {
        self.tabBarItem = tabBarItem;
        self.adjustsImageWhenHighlighted = NO;
        self.imageView.contentMode = UIViewContentModeCenter;
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.font = self.tabBarItem.font;
        [self setTitle:self.tabBarItem.title forState:UIControlStateNormal];
        self.selected = NO;
    }
    return self;
}

- (void)setSelected:(BOOL)selected{
    [super setSelected:selected];
    if (selected) {
        if (self.tabBarItem.backgroundSelectedColor) {
            self.backgroundColor = self.tabBarItem.backgroundSelectedColor;
        }
        if (self.tabBarItem.backgroundSelectedImage) {
            [self setBackgroundImage:self.tabBarItem.backgroundSelectedImage forState:UIControlStateNormal];
        }
        if (self.tabBarItem.imageSelectedName) {
            [self setImage:[UIImage imageNamed:self.tabBarItem.imageSelectedName] forState:UIControlStateNormal];
        }
        if (self.tabBarItem.titleSelectedColor) {
            [self setTitleColor:self.tabBarItem.titleSelectedColor forState:UIControlStateNormal];
        }
    } else {
        if (self.tabBarItem.backgroundNormalColor) {
            self.backgroundColor = self.tabBarItem.backgroundNormalColor;
        }
        if (self.tabBarItem.backgroundNormalImage) {
            [self setBackgroundImage:self.tabBarItem.backgroundNormalImage forState:UIControlStateNormal];
        }
        if (self.tabBarItem.imageNormalName) {
            [self setImage:[UIImage imageNamed:self.tabBarItem.imageNormalName] forState:UIControlStateNormal];
        }
        if (self.tabBarItem.titleNormalColor) {
            [self setTitleColor:self.tabBarItem.titleNormalColor forState:UIControlStateNormal];
        }
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat topEdge = self.tabBarItem.edgeInsets.top;
    CGFloat bottomEdge = self.tabBarItem.edgeInsets.bottom;
    CGFloat leftEdge = self.tabBarItem.edgeInsets.left;
    CGFloat rightEdge = self.tabBarItem.edgeInsets.right;
    
    CGFloat width = CGRectGetWidth(self.frame);
    CGFloat height = CGRectGetHeight(self.frame);
    
    if ([self.tabBarItem.title length] > 0 && [self.tabBarItem.imageNormalName length] > 0) {
        CGSize sizeToFit = [self.tabBarItem.title boundingRectWithSize:CGSizeMake(width, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName : self.tabBarItem.font} context:nil].size;
        CGFloat textHeight = ceil(sizeToFit.height);
        
        UIImage *image = [UIImage imageNamed:self.tabBarItem.imageNormalName];
        CGRect frame = CGRectMake(leftEdge, topEdge, width - leftEdge - rightEdge, image.size.height);
        self.imageView.frame = frame;
        
        frame = CGRectMake(leftEdge, height - textHeight - bottomEdge, width - leftEdge - rightEdge, textHeight);
        self.titleLabel.frame = frame;
        
    } else if([self.tabBarItem.title length] > 0){
        
        self.imageView.hidden = YES;
        CGRect frame = CGRectMake(leftEdge, topEdge, width, height);
        self.titleLabel.frame = frame;
        
    } else {
        self.titleLabel.hidden = YES;
        CGRect frame = CGRectMake(leftEdge, topEdge, width, height);
        self.imageView.frame = frame;
    }
}

@end
