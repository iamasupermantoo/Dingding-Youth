//
//  DDPageViewController.h
//  DDPagerControllerDemo
//
//  Created by lilingang on 15/11/17.
//  Copyright (c) 2015年 LeeLingang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DDPageViewController : UIPageViewController

@property (nonatomic, assign) BOOL bounces;

@end
