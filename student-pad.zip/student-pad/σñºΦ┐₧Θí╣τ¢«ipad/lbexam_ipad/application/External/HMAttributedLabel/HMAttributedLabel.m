//
//  HMAttributedLabel.m
//  UDan
//
//  Created by lilingang on 16/10/26.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMAttributedLabel.h"

@implementation HMAttributedLabel

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initSettings];
    }
    return self;
}

- (void)awakeFromNib{
    [super awakeFromNib];
    [self initSettings];
}

- (void)initSettings{
    self.linkAttributes = [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:NO] forKey:(NSString *)kCTUnderlineStyleAttributeName];
    self.activeLinkAttributes = [NSDictionary dictionaryWithObject:(__bridge id)[[UIColor hmTextBlueColor] CGColor] forKey:(__bridge NSString *)kCTForegroundColorAttributeName];
}

@end
