//
//  HMAttributedLabel.h
//  UDan
//
//  Created by lilingang on 16/10/26.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <TTTAttributedLabel/TTTAttributedLabel.h>

@interface HMAttributedLabel : TTTAttributedLabel

@end
