//
//  HMPageControl.m
//  UDan
//
//  Created by lilingang on 16/10/8.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMPageControl.h"


@implementation HMPageControl
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initSettings];
    }
    return self;
}

- (void)awakeFromNib{
    [super awakeFromNib];
    [self initSettings];
}

- (void)initSettings{
    self.pageIndicatorTintColor = [UIColor grayColor];
    self.currentPageIndicatorTintColor = [UIColor whiteColor];
}

@end
