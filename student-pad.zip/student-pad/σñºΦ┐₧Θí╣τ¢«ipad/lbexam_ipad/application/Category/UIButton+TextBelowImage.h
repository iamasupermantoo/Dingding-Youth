//
//  UIButton+TextBelowImage.h
//  Youlun
//
//  Created by Chin on 15/6/17.
//  Copyright (c) 2015年 Chin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (TextBelowImage)
- (void)aliginTextAndImage;
- (void)aliginTextAndImage:(float)spacing;
//居中左到右，中间加个spacing
- (void)centerButtonAndImageWithSpacing:(CGFloat)spacing;
@end
