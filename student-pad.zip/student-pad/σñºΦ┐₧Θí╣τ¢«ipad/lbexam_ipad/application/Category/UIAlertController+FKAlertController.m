//
//  UIAlertController+FKAlertController.m
//  lbexam
//
//  Created by frankay on 17/2/27.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "UIAlertController+FKAlertController.h"

@implementation UIAlertController (FKAlertController)

+ (void)showWithTitle:(NSString *)title WithAction1Title:(NSString *)title1 WithAction2Title:(NSString *)title2 andconfirmBlock:(confirmBtnAciton)actionBlock andcancelBlock:(cancelBtnAciton)cancelBlock Incontroller:(UIViewController *)controller{
    // 返回是提示是否放弃评价
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:title preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:title2 style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [alert dismissViewControllerAnimated:YES completion:nil];
        if (actionBlock) {
            actionBlock();
        }
    }];
    
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:title1 style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [alert dismissViewControllerAnimated:YES completion:nil];
        if (cancelBlock) {
            cancelBlock();
        }
    }];
    
    if (![cancel.title isEqualToString:@""]) {
         [alert addAction:cancel];
    }
  
    [alert addAction:ok];
    [controller presentViewController:alert animated:YES completion:nil];
    
    
}

+ (void)formalServerAction:(confirmBtnAciton)formalBlock andTestServerAction:(confirmBtnAciton)testBlock andLocalserverAction:(confirmBtnAciton)localBlock InController:(UIViewController *)controller{
    // 返回是提示是否放弃评价
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"选择切换的服务器" message:nil preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *formal = [UIAlertAction actionWithTitle:@"切换到正式服务器" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [alert dismissViewControllerAnimated:YES completion:nil];
        if (formalBlock) {
            formalBlock();
        }
    }];
    
    UIAlertAction *test = [UIAlertAction actionWithTitle:@"切换到测试服务器" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
         [alert dismissViewControllerAnimated:YES completion:nil];
        if (testBlock) {
            testBlock();
        }
    }];
    
    UIAlertAction *local = [UIAlertAction actionWithTitle:@"切换到本地服务器" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [alert dismissViewControllerAnimated:YES completion:nil];
        if (localBlock) {
            localBlock();
        }
    }];

    
    [alert addAction:formal];
    [alert addAction:test];
    [alert addAction:local];
    [controller presentViewController:alert animated:YES completion:nil];
    



}
@end
