//
//  NSString+UDan.h
//  UDan
//
//  Created by lilingang on 16/10/7.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#define Email_Check_Format  @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
#define Phone_Check_Format  @"^1[34578][0-9]{9}$"
#define Password_Check_Format  @"^[a-zA-Z0-9]{6,30}$"
#define Name_Check_Format  @"^[a-zA-Z0-9]{2,20}$"
#define Identity_Check_Format  @"(^\\d{15}$)|(^\\d{17}([0-9]|X|x)$)"
#define Number_Check_Format  @"^[0-9]\\d*$"
#define Letter_Check_Format  @"^[a-zA-Z]*$"
#define Int_Number_Check_Format  @"^[1-9]\\d*$"
#define Decimal_Number_Check_Format  @"^((0\\.[0-9]{1,2})|([1-9]+[0-9]*\\.[0-9]{1,2})|([1-9]+[0-9]*))$"
#define ZipCode_Check_Format  @"^[1-9][0-9]{5}$"


#import <Foundation/Foundation.h>

//@class HMPersonItem;

@interface NSString (UDan)

- (BOOL)isMobileNumber;


-(NSString *) stringByReplacingRegexPattern:(NSString *)regex withString:(NSString *) replacement;
-(NSString *) stringByReplacingRegexPattern:(NSString *)regex withString:(NSString *) replacement caseInsensitive:(BOOL) ignoreCase;
-(NSString *) stringByReplacingRegexPattern:(NSString *)regex withString:(NSString *) replacement caseInsensitive:(BOOL) ignoreCase treatAsOneLine:(BOOL) assumeMultiLine;
-(NSArray *) stringsByExtractingGroupsUsingRegexPattern:(NSString *)regex;
-(NSArray *) stringsByExtractingGroupsUsingRegexPattern:(NSString *)regex caseInsensitive:(BOOL) ignoreCase treatAsOneLine:(BOOL) assumeMultiLine;
-(BOOL) matchesPatternRegexPattern:(NSString *)regex;
-(BOOL) matchesPatternRegexPattern:(NSString *)regex caseInsensitive:(BOOL) ignoreCase treatAsOneLine:(BOOL) assumeMultiLine;

- (BOOL)isEmail;
- (BOOL)isPhoneNumber;
- (BOOL)isNumber;
- (BOOL)isUrl;
- (BOOL)isPassword;
- (BOOL)isSingleLineWithMaxWidth:(CGFloat)width textFont:(UIFont *)font;

- (NSAttributedString *)attributedStringWithTextFont:(UIFont *)font;

- (NSAttributedString *)attributedStringWithTextFont:(UIFont *)font lineSpace:(CGFloat)lineSpace;

- (NSAttributedString *)attributedStringWithTextFont:(UIFont *)font lineSpace:(CGFloat)lineSpace firstLineHeadIndent:(CGFloat)firstLineHeadIndent;

- (CGFloat)HeightWithFont:(UIFont *)font maxSize:(CGFloat)maxSize WithAttributedString:(NSAttributedString *)AttributedString lineSpace:(CGFloat)lineSpace HeadIndent:(CGFloat)firstLineHeadIndent;
- (CGFloat)HeightWithFont:(UIFont *)font maxSize:(CGFloat)maxSize lineSpace:(CGFloat)lineSpace HeadIndent:(CGFloat)firstLineHeadIndent;
- (CGFloat)HeightWithFont:(UIFont *)font maxSize:(CGFloat)maxSize;

- (CGSize)sizeWithFont:(UIFont *)font;
- (CGSize)sizeWithFont:(UIFont *)font constrainedToSize:(CGSize)size;
- (CGSize)sizeWithMaxWidth:(CGFloat)width textFont:(UIFont *)font;

- (CGSize)sizeWithMaxWidth:(CGFloat)width textFont:(UIFont *)font lineSpace:(CGFloat)lineSpace firstLineHeadIndent:(CGFloat)firstLineHeadIndent;

+ (NSString *)dateStringWithTimeInterval:(NSTimeInterval)timeInterval;

//+ (NSString *)mineRegionInfoWithPersonItem:(HMPersonItem *)item font:(UIFont *)font;
//+ (NSString *)schoolInfoWithPersonItem:(HMPersonItem *)item font:(UIFont *)font;
//+ (NSString *)regionInfoWithPersonItem:(HMPersonItem *)item font:(UIFont *)font;
//
//+ (NSAttributedString *)profileSchoolInfoWithPersonItem:(HMPersonItem *)item font:(UIFont *)font;
//+ (NSAttributedString *)profileSeniorInfoWithPersonItem:(HMPersonItem *)item font:(UIFont *)font;

+ (NSString *)stringWithCount:(NSInteger)count;

+ (NSString *)stringWithUserType:(HMUserType)type;
+ (NSString *)stringWithGenderType:(HMGenderType)type;
+ (NSString *)stringWithAcademicDegreeType:(HMAcademicDegreeType)type;
+ (NSString *)stringWithLearnDegreeType:(FKLearnDegreeType)type;
+ (NSString *)stringWithTeachQualityType:(FKTeachQualityType)type;

+ (NSString *)stringWithStudentBehaviorType:(FKTeachQualityType)type;

+ (NSString *)stringWithGiftType:(FKGiftType)type;
//+ (NSString *)stringWithSubCourseType:(HMSubCourseType)type;

+ (NSString *)dateStringWithDate:(NSDate *)date formatter:(NSString *)dateformat;
+ (NSDate *)dateWithString:(NSString *)string andFormatterStr:(NSString *)formatterStr;

+ (NSString *)platformString;

+ (BOOL)resolutionisEqualPoint;
// 字典-> json
+(NSString *)convertJsonStrWith:(NSDictionary *)dict;

// josn -> 字典
+(NSMutableDictionary *)convertDicWithjsonstr:(NSString *)jsonstr;


// 字典转data
+ (NSData *)convertDataWithDic:(NSDictionary *)dict;

// data转字典

+ (NSDictionary *)convertDicWithData:(NSData *)data;


+ (NSData *)encodeWithNSObject:(id)obj;

+ (id)undecodeWithData:(NSData *)data;



@end
