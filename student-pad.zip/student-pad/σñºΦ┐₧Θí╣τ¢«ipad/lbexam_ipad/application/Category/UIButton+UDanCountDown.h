//
//  UIButton+UDanCountDown.h
//  UDan
//
//  Created by lilingang on 16/10/7.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (UDanCountDown)

@property (nonatomic, copy) NSString *countDownFormat;

@property (nonatomic, copy) NSString *finishedString;

@property (nonatomic, assign, readonly) NSTimeInterval leaveTime;

- (void)countDownWithTimeInterval:(NSTimeInterval) duration;

- (void)stopCountDown;

@end
