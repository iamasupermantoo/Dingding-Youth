//
//  UIFont+FKFont.m
//  lbexam
//
//  Created by frankay on 17/1/4.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "UIFont+FKFont.h"

@implementation UIFont (FKFont)
+ (UIFont *)FKFontWithType:(FontsizeType)sizeType isBold:(BOOL)bold{
    UIFont *font;
    if ([UIScreen mainScreen].bounds.size.width<414) {
        if (bold) {
            font = [UIFont boldSystemFontOfSize:sizeType];
        }else{
            font= [UIFont systemFontOfSize:sizeType];
        }
    }else{
        // plus size+1
        if (bold) {
            font = [UIFont boldSystemFontOfSize:sizeType+1.0];
        }else{
            font = [UIFont systemFontOfSize:sizeType+1.0];
        }
    }
    return font;
}


+(UIFont *)fk_FontWithPixel:(CGFloat)pixel{
    
    if ([NSString resolutionisEqualPoint]) {
        // 分辨率和点一样的
        return [UIFont systemFontOfSize:pixel];
    }else{
        return [UIFont systemFontOfSize:pixel/2.0];
    }
}


+(UIFont *)fk_FontSize14{
    return [UIFont fk_FontWithPixel:28];
}

+ (UIFont *)fk_FontSize15{
    return [UIFont fk_FontWithPixel:30];
}

+(UIFont *)fk_FontSize16{
    return [UIFont fk_FontWithPixel:32];
}

+(UIFont *)fk_FontSize17{
    return [UIFont fk_FontWithPixel:34];
}

+(UIFont *)fk_FontSize18{
    return [UIFont fk_FontWithPixel:36];
}

+ (UIFont *)fk_FontSize19{
    return [UIFont fk_FontWithPixel:38];
}
@end
