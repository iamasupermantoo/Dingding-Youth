//
//  UIImage+RerectImageSize.h
//  UDan
//
//  Created by frankay on 16/12/12.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (RerectImageSize)
+ (UIImage *)RectWithImage:(UIImage *)originImage rectSize:(CGRect)rect;
+ (UIImage *)squareImageFromImage:(UIImage *)image scaledToSize:(CGFloat)newSize;
@end
