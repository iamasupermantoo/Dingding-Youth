//
//  UIView+Line.h
//  UDan
//
//  Created by 范文青 on 16/10/11.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIView (Line)
- (UIView *)addBottomLine;
- (UIView *)addTopLine;
@end
