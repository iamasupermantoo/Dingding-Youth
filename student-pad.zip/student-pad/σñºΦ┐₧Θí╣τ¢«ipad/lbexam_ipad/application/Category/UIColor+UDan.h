//
//  UIColor+UDan.h
//  UDan
//
//  Created by lilingang on 16/9/30.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (UDan)

+ (UIColor *)hmTextBlackColor;
+ (UIColor *)hmMainBgColor;
+ (UIColor *)hmBorderColor;
+ (UIColor *)hmTextGrayColor;
+ (UIColor *)hmTextBlueColor;
+ (UIColor *)hmYellowColor;
+ (UIColor *)hmBackGrayColor;
+ (UIColor *)fk666Color;
+ (UIColor *)fkBlueColor;
+ (UIColor *)fkfe8d25Color;
+ (UIColor *)fkde0303redColor;
+ (UIColor *)fkcccColor;
+ (UIColor *)fkColorWithString:(NSString *)hex;
+ (UIColor *)fkNavBackGroundColor;
@end
