//
//  AVAudioSession+FKAgoraAudioSession.m
//  lbexam_ipad
//
//  Created by frankay on 17/3/22.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "AVAudioSession+FKAgoraAudioSession.h"


@implementation AVAudioSession (FKAgoraAudioSession)


#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wobjc-protocol-method-implementation"

- (BOOL)setActive:(BOOL)active error:(NSError **)outError{
//    
//    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:AVAudioSessionCategoryOptionMixWithOthers error:nil];
    NSLog(@"----------------->%@",self.category);
    return YES;
}


#pragma clang diagnostic pop


@end
