//
//  CreateDocumentFile.h
//  dd
//
//  Created by frankay on 15/12/31.
//  Copyright © 2015年 frankay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CreateDocumentFile : NSObject
+ (NSString *)DocumentFile:(NSString *)filename;
+ (BOOL)isexistWithTheFileName:(NSString *)filename;
+ (void)deleteFile:(NSString *)filename;
@end
