//
//  UIView+Line.m
//  UDan
//
//  Created by 范文青 on 16/10/11.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "UIView+Line.h"

@implementation UIView(Line)
- (UIView *)addBottomLine{
    float one_px = 1.0/[UIScreen mainScreen].scale;
    UIView  *view = [[UIView alloc] initWithFrame:CGRectMake(0, self.ddHeight - one_px, self.ddWidth, one_px)];
    [view setBackgroundColor:[UIColor hmBorderColor]];
    [self addSubview:view];
    return view;
}
- (UIView *)addTopLine{
    float one_px = 1.0/[UIScreen mainScreen].scale;
    UIView  *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.ddWidth, one_px)];
    [view setBackgroundColor:[UIColor hmBorderColor]];
    [self addSubview:view];
    return view;
}

@end
