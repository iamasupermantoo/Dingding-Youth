//
//  UIAlertController+FKAlertController.h
//  lbexam
//
//  Created by frankay on 17/2/27.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^confirmBtnAciton)();
typedef void (^cancelBtnAciton)();

@interface UIAlertController (FKAlertController)

+ (void)showWithTitle:(NSString *)title WithAction1Title:(NSString *)title1 WithAction2Title:(NSString *)title2 andconfirmBlock:(confirmBtnAciton)actionBlock andcancelBlock:(cancelBtnAciton)cancelBlock Incontroller:(UIViewController *)controller;

+ (void)formalServerAction:(confirmBtnAciton)formalBlock andTestServerAction:(confirmBtnAciton)testBlock andLocalserverAction:(confirmBtnAciton)localBlock InController:(UIViewController *)controller;
@end
