//
//  UIColor+UDan.m
//  UDan
//
//  Created by lilingang on 16/9/30.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "UIColor+UDan.h"

@implementation UIColor (UDan)

+ (UIColor *)hmTextBlackColor{
    return RGBHexCOLOR(@"#333333");
}
+ (UIColor *)hmMainBgColor{
    return RGBHexCOLOR(@"#eeeeee");
}
+ (UIColor *)hmBorderColor{
    return RGBHexCOLOR(@"#cccccc");
}
+ (UIColor *)hmTextGrayColor{
    return RGBHexCOLOR(@"#999999");
}
+ (UIColor *)hmTextBlueColor{
    return RGBHexCOLOR(@"#2c8ec7");
}

+ (UIColor *)hmYellowColor{
    return RGBHexCOLOR(@"#f8d50d");
}

+ (UIColor *)hmBackGrayColor{
    return RGBHexCOLOR(@"#E0E0E0");
}

+ (UIColor *)fk666Color{
    return RGBHexCOLOR(@"#666666");
}

+ (UIColor *)fkBlueColor{
    return RGBHexCOLOR(@"#08b0ee");

}

+ (UIColor *)fkfe8d25Color{
    return RGBHexCOLOR(@"#fe8d25");
}


+ (UIColor *)fkNavBackGroundColor{
    
    return RGBHexCOLOR(@"#f8d50d");
}

+ (UIColor *)fkde0303redColor{
    
    return RGBHexCOLOR(@"#de0303");
}

+  (UIColor *)fkcccColor{
    return RGBHexCOLOR(@"#cccccc");
}

+ (UIColor *)fkColorWithString:(NSString *)hex{
    return RGBHexCOLOR(hex);
}
@end
