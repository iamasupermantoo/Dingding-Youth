//
//  UIImageView+UDan.h
//  UDan
//
//  Created by lilingang on 16/10/8.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (UDan)

- (NSString *)hmURLString;

- (void)hmLoadImageURL:(NSString *)urlString
                 local:(BOOL)local;

- (void)hmLoadImageURL:(NSString *)urlString
      placeholderImage:(UIImage *)placeholderImage
                 local:(BOOL)local;

- (void)imageViewAnimationWithArray:(NSArray *)arr;

@end
