//
//  NSString+UDan.m
//  UDan
//
//  Created by lilingang on 16/10/7.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "NSString+UDan.h"
//#import "HMPersonItem.h"
#import <sys/sysctl.h>
@implementation NSString (UDan)

- (BOOL)isMobileNumber{
    //    电信号段:133/153/180/181/189/177
    //    联通号段:130/131/132/155/156/185/186/145/176
    //    移动号段:134/135/136/137/138/139/150/151/152/157/158/159/182/183/184/187/188/147/178
    //    虚拟运营商:170
    NSString *MOBILE = @"^1(3[0-9]|4[57]|5[0-35-9]|8[0-9]|7[06-8])\\d{8}$";
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", MOBILE];
    return [regextestmobile evaluateWithObject:self];
}



-(NSString *) stringByReplacingRegexPattern:(NSString *)regex withString:(NSString *) replacement caseInsensitive:(BOOL)ignoreCase {
    return [self stringByReplacingRegexPattern:regex withString:replacement caseInsensitive:ignoreCase treatAsOneLine:NO];
}

-(NSString *) stringByReplacingRegexPattern:(NSString *)regex withString:(NSString *) replacement caseInsensitive:(BOOL) ignoreCase treatAsOneLine:(BOOL) assumeMultiLine {
    
    NSUInteger options=0;
    if (ignoreCase) {
        options = options | NSRegularExpressionCaseInsensitive;
    }
    if (assumeMultiLine) {
        options = options | NSRegularExpressionDotMatchesLineSeparators;
    }
    
    NSError *error=nil;
    NSRegularExpression *pattern = [NSRegularExpression regularExpressionWithPattern:regex options:options error:&error];
    if (error) {
        NSLog(@"Error creating Regex: %@",[error description]);
        return nil;
    }
    
    NSString *retVal= [pattern stringByReplacingMatchesInString:self options:0 range:NSMakeRange(0, [self length]) withTemplate:replacement];
    return retVal;
}

-(NSString *) stringByReplacingRegexPattern:(NSString *)regex withString:(NSString *) replacement {
    return [self stringByReplacingRegexPattern:regex withString:replacement caseInsensitive:NO treatAsOneLine:NO];
}

-(NSArray *) stringsByExtractingGroupsUsingRegexPattern:(NSString *)regex caseInsensitive:(BOOL) ignoreCase treatAsOneLine:(BOOL) assumeMultiLine {
    NSUInteger options=0;
    if (ignoreCase) {
        options = options | NSRegularExpressionCaseInsensitive;
    }
    if (assumeMultiLine) {
        options = options | NSRegularExpressionDotMatchesLineSeparators;
    }
    
    NSError *error=nil;
    NSRegularExpression *pattern = [NSRegularExpression regularExpressionWithPattern:regex options:options error:&error];
    if (error) {
        NSLog(@"Error creating Regex: %@",[error description]);
        return nil;
    }
    
    __block NSMutableArray *retVal = [NSMutableArray array];
    [pattern enumerateMatchesInString:self options:0 range:NSMakeRange(0, [self length]) usingBlock:^(NSTextCheckingResult *result, NSMatchingFlags flags, BOOL *stop) {
        //Note, we only want to return the things in parens, so we're skipping index 0 intentionally
        for (int i=1; i<[result numberOfRanges]; i++) {
            NSString *matchedString=[self substringWithRange:[result rangeAtIndex:i]];
            [retVal addObject:matchedString];
        }
    }];
    return retVal;
}

-(NSArray *) stringsByExtractingGroupsUsingRegexPattern:(NSString *)regex {
    return [self stringsByExtractingGroupsUsingRegexPattern:regex caseInsensitive:NO treatAsOneLine:NO];
}

-(BOOL) matchesPatternRegexPattern:(NSString *)regex caseInsensitive:(BOOL) ignoreCase treatAsOneLine:(BOOL) assumeMultiLine {
    NSUInteger options=0;
    if (ignoreCase) {
        options = options | NSRegularExpressionCaseInsensitive;
    }
    if (assumeMultiLine) {
        options = options | NSRegularExpressionDotMatchesLineSeparators;
    }
    
    NSError *error=nil;
    NSRegularExpression *pattern = [NSRegularExpression regularExpressionWithPattern:regex options:options error:&error];
    if (error) {
        NSLog(@"Error creating Regex: %@",[error description]);
        return NO;  //Can't possibly match an invalid Regex
    }
    
    return ([pattern numberOfMatchesInString:self options:0 range:NSMakeRange(0, [self length])] > 0);
}

-(BOOL) matchesPatternRegexPattern:(NSString *)regex {
    return [self matchesPatternRegexPattern:regex caseInsensitive:NO treatAsOneLine:NO];
}
- (BOOL)isEmail{
    return [self matchesPatternRegexPattern:Email_Check_Format];
}
- (BOOL)isPhoneNumber{
    return [self matchesPatternRegexPattern:Phone_Check_Format];
}
- (BOOL)isNumber{
    return [self matchesPatternRegexPattern:Number_Check_Format];
}
- (BOOL)isPassword{
    return [self matchesPatternRegexPattern:Password_Check_Format];
}
- (BOOL)isUrl{
    if (self.length < 5) {
        return NO;
    }
    if ([self hasPrefix:@"http"]) {
        return YES;
    }
    if ([self hasPrefix:@"https"]) {
        return YES;
    }
    if ([self hasPrefix:@"www"]) {
        return YES;
    }
    return NO;
}

- (BOOL)isSingleLineWithMaxWidth:(CGFloat)width textFont:(UIFont *)font{
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 0;
    paragraphStyle.maximumLineHeight = font.lineHeight;
    paragraphStyle.minimumLineHeight = font.lineHeight;
    paragraphStyle.alignment = NSTextAlignmentLeft;
    NSDictionary *attributes = @{
                                 NSFontAttributeName:font,
                                 NSParagraphStyleAttributeName:paragraphStyle
                                 };
    
    CGSize constraintSize = CGSizeMake(width, CGFLOAT_MAX);
    CGRect stringRect = [self boundingRectWithSize:constraintSize
                                             options:
                         NSStringDrawingUsesFontLeading|
                         NSStringDrawingTruncatesLastVisibleLine|
                         NSStringDrawingUsesLineFragmentOrigin
                                          attributes:attributes
                                             context:NULL];
    return stringRect.size.height - font.lineHeight <= 2.0;
}

- (NSAttributedString *)attributedStringWithTextFont:(UIFont *)font{
    return [self attributedStringWithTextFont:font lineSpace:7.0];
}

- (NSAttributedString *)attributedStringWithTextFont:(UIFont *)font lineSpace:(CGFloat)lineSpace{
    return [self attributedStringWithTextFont:font lineSpace:lineSpace firstLineHeadIndent:0];
}

- (NSAttributedString *)attributedStringWithTextFont:(UIFont *)font lineSpace:(CGFloat)lineSpace firstLineHeadIndent:(CGFloat)firstLineHeadIndent{
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = NSLineBreakByTruncatingTail;
    paragraphStyle.lineSpacing = lineSpace;
    paragraphStyle.paragraphSpacing = 0;
    paragraphStyle.firstLineHeadIndent = firstLineHeadIndent;
    paragraphStyle.maximumLineHeight = font.lineHeight;
    paragraphStyle.minimumLineHeight = font.lineHeight;
    paragraphStyle.alignment = NSTextAlignmentLeft;
    NSDictionary *attributes = @{
                                 NSFontAttributeName:font,
                                 NSParagraphStyleAttributeName:paragraphStyle
                                 };
    return [[NSAttributedString alloc] initWithString:self attributes:attributes];
}

- (CGFloat)HeightWithFont:(UIFont *)font maxSize:(CGFloat)maxSize WithAttributedString:(NSAttributedString *)AttributedString lineSpace:(CGFloat)lineSpace HeadIndent:(CGFloat)firstLineHeadIndent{
    BOOL isSingleDetail = [self isSingleLineWithMaxWidth:maxSize textFont:font];
    if (!isSingleDetail) {
        CGSize textSize = [self sizeWithMaxWidth:maxSize textFont:font lineSpace:lineSpace firstLineHeadIndent:firstLineHeadIndent];
        AttributedString = [self attributedStringWithTextFont:font lineSpace:lineSpace];
        return textSize.height;
    }
    return ceil(font.lineHeight);
}

- (CGFloat)HeightWithFont:(UIFont *)font maxSize:(CGFloat)maxSize lineSpace:(CGFloat)lineSpace HeadIndent:(CGFloat)firstLineHeadIndent{
    BOOL isSingleDetail = [self isSingleLineWithMaxWidth:maxSize textFont:font];
    if (!isSingleDetail) {
        CGSize textSize = [self sizeWithMaxWidth:maxSize textFont:font lineSpace:lineSpace firstLineHeadIndent:firstLineHeadIndent];
       
        return textSize.height;
    }
    return ceil(font.lineHeight);
}

- (CGFloat)HeightWithFont:(UIFont *)font maxSize:(CGFloat)maxSize{
    BOOL isSingleDetail = [self isSingleLineWithMaxWidth:maxSize textFont:font];
    if (!isSingleDetail) {
        CGSize textSize = [self sizeWithMaxWidth:maxSize textFont:font];
        return textSize.height;
    }
    return ceil(font.lineHeight);
}

- (CGSize)sizeWithMaxWidth:(CGFloat)width textFont:(UIFont *)font{
    return [self sizeWithMaxWidth:width textFont:font lineSpace:7.0f firstLineHeadIndent:0];
}

- (CGSize)sizeWithFont:(UIFont *)font{
    CGSize size = [self sizeWithAttributes:
                   @{NSFontAttributeName: font}];
    
    // Values are fractional -- you should take the ceilf to get equivalent values
    CGSize adjustedSize = CGSizeMake(ceilf(size.width), ceilf(size.height));
    return adjustedSize;
}

- (CGSize)sizeWithFont:(UIFont *)font constrainedToSize:(CGSize)size{
    NSAttributedString *attributedText =
    [[NSAttributedString alloc]
     initWithString:self
     attributes:@
     {
     NSFontAttributeName: font
     }];
    CGRect rect = [attributedText boundingRectWithSize:size
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                               context:nil];
    return rect.size;
}

- (CGSize)sizeWithMaxWidth:(CGFloat)width textFont:(UIFont *)font lineSpace:(CGFloat)lineSpace firstLineHeadIndent:(CGFloat)firstLineHeadIndent{
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = lineSpace;
    paragraphStyle.firstLineHeadIndent = firstLineHeadIndent;
    paragraphStyle.maximumLineHeight = ceil(font.lineHeight);
    paragraphStyle.minimumLineHeight = ceil(font.lineHeight);
    paragraphStyle.alignment = NSTextAlignmentLeft;
    NSDictionary *attributes = @{
                                 NSFontAttributeName:font,
                                 NSParagraphStyleAttributeName:paragraphStyle
                                 };
    
    CGSize constraintSize = CGSizeMake(width, CGFLOAT_MAX);
    CGRect stringRect = [self boundingRectWithSize:constraintSize
                                           options:
                         NSStringDrawingUsesFontLeading|
                         NSStringDrawingTruncatesLastVisibleLine|
                         NSStringDrawingUsesLineFragmentOrigin
                                        attributes:attributes
                                           context:NULL];
    return stringRect.size;
}

+ (NSString *)dateStringWithTimeInterval:(NSTimeInterval)time {
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:time];
    NSTimeInterval timeInterval = [[NSDate date] timeIntervalSinceDate:date];
    timeInterval = MAX(0, timeInterval);
    NSString *resString = nil;
    if (timeInterval <= 0) {
        resString = [NSString stringWithFormat:@"1%@", HMLocal(@"秒前")];;
    } else if (timeInterval < 60) {
        resString = [NSString stringWithFormat:@"%.0f%@", timeInterval, HMLocal(@"秒前")];
    } else if (timeInterval < 60 * 60){
        resString = [NSString stringWithFormat:@"%.0f%@", timeInterval / 60, HMLocal(@"分钟前")];
    } else if (timeInterval < 60 * 60 * 24) {
        resString = [NSString stringWithFormat:@"%.0f%@", timeInterval / (60 * 60), HMLocal(@"小时前")];
    } else if (timeInterval < 60 * 60 * 24 * 30) {
        resString = [NSString stringWithFormat:@"%.0f%@", timeInterval / (60 * 60 * 24), HMLocal(@"天前")];
    } else if (timeInterval < 60 * 60 * 24 * 30 * 12) {
        resString = [NSString stringWithFormat:@"%.0f%@", timeInterval / (60 * 60 * 24 * 30), HMLocal(@"个月前")];
    } else {
        resString = [NSString stringWithFormat:@"%.0f%@", timeInterval / (60 * 60 * 24 * 30 * 12), HMLocal(@"年前")];
    }
    return resString;
}
+ (NSString *)dateStringWithDate:(NSDate *)date formatter:(NSString *)dateformat{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = dateformat;
    return  [formatter stringFromDate:date];
}

+ (NSDate *)dateWithString:(NSString *)string andFormatterStr:(NSString *)formatterStr{
    NSDateFormatter *dateformatter = [[NSDateFormatter alloc] init];
    dateformatter.dateFormat = formatterStr;
    return [dateformatter dateFromString:string];
}
//+ (NSString *)mineRegionInfoWithPersonItem:(HMPersonItem *)item font:(UIFont *)font{
//    NSString *addressString = @"";
//    if (item.userItem.province && ![item.userItem.province ddIsEmpty]) {
//        addressString = [addressString stringByAppendingFormat:@"%@%@",[addressString length] > 0 ? @"/":@"",item.userItem.province];
//    }
//    if (item.userItem.region && ![item.userItem.region ddIsEmpty]) {
//        addressString = [addressString stringByAppendingFormat:@"%@%@",[addressString length] > 0 ? @"/":@"",item.userItem.region];
//    }
//    if (item.seniorSchool && ![item.seniorSchool ddIsEmpty]) {
//        addressString = [addressString stringByAppendingFormat:@"%@%@",[addressString length] > 0 ? @"/":@"",item.seniorSchool];
//    }
//    return addressString;
//}
//
//+ (NSString *)schoolInfoWithPersonItem:(HMPersonItem *)item font:(UIFont *)font{
//    NSString *universityString = @"";
//    if (item.school && ![item.school ddIsEmpty]) {
//        universityString = [universityString stringByAppendingFormat:@"%@%@",[universityString length] > 0 ? @"/":@"",item.school];
//    }
//    if (item.academy && ![item.academy ddIsEmpty]) {
//        universityString = [universityString stringByAppendingFormat:@"%@%@",[universityString length] > 0 ? @"/":@"",item.academy];
//    }
//    return universityString;
//}
//
//+ (NSString *)regionInfoWithPersonItem:(HMPersonItem *)item font:(UIFont *)font{
//    NSString *addressString = @"";
//    if (item.userItem.province && ![item.userItem.province ddIsEmpty]) {
//        addressString = [addressString stringByAppendingFormat:@"%@%@",[addressString length] > 0 ? @"/":@"",item.userItem.province];
//    }
//    if (item.seniorSchool && ![item.seniorSchool ddIsEmpty]) {
//        addressString = [addressString stringByAppendingFormat:@"%@%@",[addressString length] > 0 ? @"/":@"",item.seniorSchool];
//    }
//    if (item.seniorYear && ![item.seniorYear ddIsEmpty]) {
//        addressString = [addressString stringByAppendingFormat:@"%@%@",[addressString length] > 0 ? @"/":@"",item.seniorYear];
//    }
//    return addressString;
//}
//
//+ (NSAttributedString *)profileSchoolInfoWithPersonItem:(HMPersonItem *)item font:(UIFont *)font{
//    NSString *universityString = @"";
//    if (item.school && ![item.school ddIsEmpty]) {
//        universityString = [universityString stringByAppendingFormat:@"%@%@",[universityString length] > 0 ? @"/":@"",item.school];
//    }
//    if (item.academy && ![item.academy ddIsEmpty]) {
//        universityString = [universityString stringByAppendingFormat:@"%@%@",[universityString length] > 0 ? @"/":@"",item.academy];
//    }
//    if (item.year && ![item.year ddIsEmpty]) {
//        universityString = [universityString stringByAppendingFormat:@"%@%@",[universityString length] > 0 ? @"/":@"",item.year];
//    }
//    if ([universityString length]) {
//        return [universityString attributedStringWithTextFont:font lineSpace:0];
//    } else {
//        return nil;
//    }
//}
//
//+ (NSAttributedString *)profileSeniorInfoWithPersonItem:(HMPersonItem *)item font:(UIFont *)font{
//    NSString *addressString = @"";
//    if (item.seniorSchool && ![item.seniorSchool ddIsEmpty]) {
//        addressString = [addressString stringByAppendingFormat:@"%@%@",[addressString length] > 0 ? @"/":@"",item.seniorSchool];
//    }
//    if (item.seniorYear && ![item.seniorYear ddIsEmpty]) {
//        addressString = [addressString stringByAppendingFormat:@"%@%@",[addressString length] > 0 ? @"/":@"",item.seniorYear];
//    }
//    if ([addressString length]) {
//        return [addressString attributedStringWithTextFont:font lineSpace:0];
//    } else {
//        return nil;
//    }
//}


+ (NSString *)stringWithCount:(NSInteger)count{
    return [NSString stringWithFormat:@"%ld",MAX(count, 0)];
}

+ (NSString *)stringWithUserType:(HMUserType)type{
    if (type == HMUserTypeUniversity) {
        return HMLocal(@"大学生");
    } else {
        return HMLocal(@"高中生");
    }
}

+ (NSString *)stringWithGenderType:(HMGenderType)type{
    if (type == HMGenderTypeMale) {
        return HMLocal(@"男");
    } else if (type == HMGenderTypeFemale){
        return HMLocal(@"女");
    } else {
        return HMLocal(@"");
    }
}

+ (NSString *)stringWithAcademicDegreeType:(HMAcademicDegreeType)type{
    if (type == HMAcademicDegreeTypePostDoctorate) {
        return HMLocal(@"博士后");
    } else if (type == HMAcademicDegreeTypeDoctor){
        return HMLocal(@"博士生");
    } else if (type == HMAcademicDegreeTypePostGraduate){
        return HMLocal(@"研究生");
    } else if (type == HMAcademicDegreeTypejunioruniversity){
        return HMLocal(@"专科");
    } else if (type == HMAcademicDegreeTypeUndergraduate){
        return HMLocal(@"本科生");
    } else {
        return @"";
    }
}

+ (NSString *)stringWithLearnDegreeType:(FKLearnDegreeType)type{
    if (type == FKLearnDegreeTypeLowest) {
        return HMLocal(@"听进去20%-40%");
    }else
        
        if (type == FKLearnDegreeTypeLow) {
            return HMLocal(@"听进去40%-60%");
        }else
            if (type == FKLearnDegreeTypeHeight) {
                return HMLocal(@"听进去60%-80%");
            }else
                if (type == FKLearnDegreeTypeHeightest) {
                    return HMLocal(@"听进去80%-100%");
                }else return @"";
}

+ (NSString *)stringWithTeachQualityType:(FKTeachQualityType)type{
    
    if (type == FKTeachQualityTypeLowest) {
        return HMLocal(@"上课非常无趣，作业布置太多");
    }else
        
        if (type == FKTeachQualityTypeLow) {
            return HMLocal(@"讲的太深奥，有时听不懂，有点枯燥");
        }else
            if (type == FKTeachQualityTypeHeight) {
                return HMLocal(@"语言生动严谨，准确流畅，一丝不苟");
            }else
                if (type == FKTeachQualityTypeHeightest) {
                    return HMLocal(@"知识结构合理、重点突出、条理清晰");
                }else return @"";
}



+ (NSString *)stringWithStudentBehaviorType:(FKTeachQualityType)type{
    if (type == FKTeachQualityTypeLowest) {
        return HMLocal(@"上课容易分心，东瞅西望");
    }else
        if (type == FKTeachQualityTypeLow) {
            return HMLocal(@"偶尔没有认真学习");
        }else
            if (type == FKTeachQualityTypeHeight) {
                return HMLocal(@"学习能力强，课后按时完成作业");
            }else
                if (type == FKTeachQualityTypeHeightest) {
                    return HMLocal(@"上课认真，紧随老师教课任务");
                }else return @"";
}


+ (NSString *)stringWithGiftType:(FKGiftType)type{
    NSString *animationName;
    if (type == FKGiftTypeStarAnimation) {
        animationName = @"starAnimation.gif";
    }else if (type == FKGiftTypeApplaudAnimation){
        animationName = @"applaudAnimation.gif";
    }else if (type==FKGiftTypeBallonAnimation){
        animationName = @"ballonAnimation.gif";
    }else if (type == FKGiftTypeLittleBearAnimation){
    
        animationName = @"littleBearAnimation.gif";
    }
    
    return animationName;
}


// pragma mark 判断设备的型号
+ (NSString *)platformString {
    
    // Gets a string with the device model
    size_t size;
    int nR = sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char *machine = (char *)malloc(size);
    nR = sysctlbyname("hw.machine", machine, &size, NULL, 0);
    NSString *platform = [NSString stringWithCString:machine encoding:NSUTF8StringEncoding];
    free(machine);
    
    // iPhone======
    
    if ([platform isEqualToString:@"iPhone1,1"]) return @"iPhone 1";
    
    if ([platform isEqualToString:@"iPhone1,2"]) return @"iPhone 3";
    
    if ([platform isEqualToString:@"iPhone2,1"]) return @"iPhone 3GS";
    
    if ([platform isEqualToString:@"iPhone3,1"]) return @"iPhone 4";
    
    if ([platform isEqualToString:@"iPhone3,2"]) return @"iPhone 4";
    
    if ([platform isEqualToString:@"iPhone3,3"]) return @"iPhone 4";
    
    if ([platform isEqualToString:@"iPhone4,1"]) return @"iPhone 4s";
    
    if ([platform isEqualToString:@"iPhone5,1"]) return @"iPhone 5";
    
    if ([platform isEqualToString:@"iPhone5,2"]) return @"iPhone 5";
    
    if ([platform isEqualToString:@"iPhone5,3"]) return @"iPhone 5C";
    
    if ([platform isEqualToString:@"iPhone5,4"]) return @"iPhone 5C";
    
    if ([platform isEqualToString:@"iPhone6,1"]) return @"iPhone 5S";
    
    if ([platform isEqualToString:@"iPhone6,2"]) return @"iPhone 5S";
    
    if ([platform isEqualToString:@"iPhone7,1"]) return @"iPhone 6";
    
    if ([platform isEqualToString:@"iPhone7,2"]) return @"iPhone 6 Plus";
    
    if ([platform isEqualToString:@"iPhone8,1"]) return @"iPhone 6s";
    
    if ([platform isEqualToString:@"iPhone8,2"]) return @"iPhone 6s Plus";
    
    if ([platform isEqualToString:@"iPhone8,4"]) return @"iPhone SE";
    
    // iPot Touch======
    
    if ([platform isEqualToString:@"iPod1,1"]) return @"iPod Touch";
    
    if ([platform isEqualToString:@"iPod2,1"]) return @"iPod Touch 2";
    
    if ([platform isEqualToString:@"iPod3,1"]) return @"iPod Touch 3";
    
    if ([platform isEqualToString:@"iPod4,1"]) return @"iPod Touch 4";
    
    if ([platform isEqualToString:@"iPod5,1"]) return @"iPod Touch 5";
    
    // iPad======
    
    if ([platform isEqualToString:@"iPad1,1"]) return @"iPad";
    
    if ([platform isEqualToString:@"iPad2,1"]) return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,2"]) return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,3"]) return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,4"]) return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,5"]) return @"iPad Mini 1";
    
    if ([platform isEqualToString:@"iPad2,6"]) return @"iPad Mini 1";
    
    if ([platform isEqualToString:@"iPad2,7"]) return @"iPad Mini 1";
    
    if ([platform isEqualToString:@"iPad3,1"]) return @"iPad 3";
    
    if ([platform isEqualToString:@"iPad3,2"]) return @"iPad 3";
    
    if ([platform isEqualToString:@"iPad3,3"]) return @"iPad 3";
    
    if ([platform isEqualToString:@"iPad3,4"]) return @"iPad 4";
    
    if ([platform isEqualToString:@"iPad3,5"]) return @"iPad 4";
    
    if ([platform isEqualToString:@"iPad3,6"]) return @"iPad 4";
    
    if ([platform isEqualToString:@"iPad4,1"]) return @"iPad air";
    
    if ([platform isEqualToString:@"iPad4,2"]) return @"iPad air";
    
    if ([platform isEqualToString:@"iPad4,3"]) return @"iPad air";
    
    if ([platform isEqualToString:@"iPad4,4"]) return @"iPad mini 2";
    
    if ([platform isEqualToString:@"iPad4,5"]) return @"iPad mini 2";
    
    if ([platform isEqualToString:@"iPad4,6"]) return @"iPad mini 2";
    
    if ([platform isEqualToString:@"iPad4,7"]) return @"iPad mini 3";
    
    if ([platform isEqualToString:@"iPad4,8"]) return @"iPad mini 3";
    
    if ([platform isEqualToString:@"iPad4,9"]) return @"iPad mini 3";
    
    if ([platform isEqualToString:@"iPad5,3"]) return @"iPad air 2";
    
    if ([platform isEqualToString:@"iPad5,4"]) return @"iPad air 2";
    
    // 模拟器======
    
    if ([platform isEqualToString:@"iPhone Simulator"] || [platform isEqualToString:@"x86_64"]) return @"iPhone Simulator";
    return @"型号未知";
}

+ (BOOL)resolutionisEqualPoint{
    if ([[NSString platformString] isEqualToString:@"iPad"] || [[NSString platformString] isEqualToString:@"iPad 2"] || [[NSString platformString] isEqualToString:@"iPad Mini 1"]) {
        return YES;
        
    }else{
        
        return NO;
    }
}


// 字典转json
+(NSString *)convertJsonStrWith:(NSDictionary *)dict{
    if (dict==nil) {
        return nil;
    }
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&parseError];
    if(parseError) {
        NSLog(@"json解析失败：%@",parseError);
        return nil;
    }
    NSString *jsonstr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    // 对字符串进行替换
 
    return jsonstr;
}

// josn ->字典
+(NSMutableDictionary *)convertDicWithjsonstr:(NSString *)jsonstr{
    if (jsonstr == nil) {
        return nil;
    }
    
    NSData *jsonData = [jsonstr dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&err]];
    if(err) {
        NSLog(@"字典解析失败：%@",err);
        return nil;
    }
    return dic;
    
}
// dic -> data
+ (NSData *)convertDataWithDic:(NSDictionary *)dict{
   
    NSData  *data = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:nil];
    
    return data;
}

// data -> dic

+ (NSDictionary *)convertDicWithData:(NSData *)data{
    NSError *parseError;
//    NSLog(@"%d",[NSJSONSerialization isValidJSONObject:data]);
   
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments  error:&parseError];
    return dic;
}

// 归档obj
+ (NSData *)encodeWithNSObject:(id)obj{
    NSMutableData *data = [NSMutableData data];
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
    [archiver encodeObject:obj forKey:@"obj"];
    [archiver finishEncoding];
    return data;
}

// 解档obj
+ (id)undecodeWithData:(NSData *)data{
    NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
    id obj = [unarchiver decodeObjectForKey:@"obj"];
    return obj;
}
@end
