//
//  UIImageView+UDan.m
//  UDan
//
//  Created by lilingang on 16/10/8.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "UIImageView+UDan.h"
#import <YYWebImage/YYWebImage.h>

@implementation UIImageView (UDan)

- (NSString *)hmURLString{
    return [self.yy_imageURL absoluteString];
}

- (void)hmLoadImageURL:(NSString *)urlString
                 local:(BOOL)local{
    [self hmLoadImageURL:urlString
        placeholderImage:nil
            cornerRadius:0
             borderWidth:0
             borderColor:nil
                   local:local];
}

- (void)hmLoadImageURL:(NSString *)urlString
      placeholderImage:(UIImage *)placeholderImage
                 local:(BOOL)local{
    [self hmLoadImageURL:urlString
        placeholderImage:placeholderImage
            cornerRadius:0
             borderWidth:0
             borderColor:nil
                   local:local];
}


#pragma mark - Private Methods
- (void)hmLoadImageURL:(NSString *)urlString
      placeholderImage:(UIImage *)placeholderImage
          cornerRadius:(CGFloat)cornerRadius
           borderWidth:(CGFloat)borderWidth
           borderColor:(UIColor *)borderColor
                 local:(BOOL)local {
    if (![urlString isEqualToString:self.hmURLString] && self.hmURLString) {
        self.image = nil;
    }
    //for bugfix avatar can not load
    NSMutableDictionary *header = [YYWebImageManager sharedManager].headers.mutableCopy;
    header[@"User-Agent"] = @"iPhone"; // for example
    header[@"Accept"] = @"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";
    [YYWebImageManager sharedManager].headers = header;
 
    NSURL *imageURL = [NSURL URLWithString:urlString];
    NSString *key = [[YYWebImageManager sharedManager] cacheKeyForURL:imageURL];
    if ([[YYWebImageManager sharedManager].cache containsImageForKey:key withType:YYImageCacheTypeAll] || local) {
        UIImage *image = [[YYWebImageManager sharedManager].cache getImageForKey:key withType:YYImageCacheTypeAll];
        if (image) {
            self.image = image;
        }
    } else {
        [self yy_setImageWithURL:imageURL
                     placeholder:placeholderImage
                         options:YYWebImageOptionIgnoreImageDecoding | YYWebImageOptionIgnoreAnimatedImage | YYWebImageOptionSetImageWithFadeAnimation
                        progress:nil
                       transform:^UIImage * _Nullable(UIImage * _Nonnull image, NSURL * _Nonnull url) {
                           NSString *query = imageURL.query;
                           if ([query length] > 0) {
                               CGFloat cornerRadius = 0;
                               CGFloat borderWidth = 0;
                               UIColor *borderColor = 0;
                               CGFloat alpha = 1.0;
                               NSArray *paramArray = [query componentsSeparatedByString:@"&"];
                               for (NSString *paramString in paramArray) {
                                   NSArray *array = [paramString componentsSeparatedByString:@"="];
                                   NSString *key = [array firstObject];
                                   if ([key isEqualToString:@"corner"]) {
                                       cornerRadius = [[array lastObject] floatValue];
                                   }
                                   if ([key isEqualToString:@"border"]) {
                                       borderWidth = [[array lastObject] floatValue];
                                   }
                                   if ([key isEqualToString:@"color"]) {
                                       borderColor = RGBHexCOLOR([@"#"stringByAppendingString:[array lastObject]]);
                                   }
                                   
                                   if ([key isEqualToString:@"alpha"]) {
                                       alpha = [[array lastObject] floatValue];
                                   }
                               }
                               return [self image:image cornerRadius:cornerRadius borderWidth:borderWidth borderColor:borderColor alpha:alpha];
                           } else {
                               return image;
                           }
                       }
                      completion:^(UIImage * _Nullable image, NSURL * _Nonnull url, YYWebImageFromType from, YYWebImageStage stage, NSError * _Nullable error) {
                          if (!error) {
                              if ([[url absoluteString] isEqualToString:self.hmURLString]) {
                                  self.image = image;
                              } else {
                                  self.image = nil;
                              }
                          } else {
                              NSLog(@"load image:%@ error:%@",[imageURL absoluteString],error);
                          }
                      }];
    }
    
}

- (UIImage *)image:(UIImage *)image
      cornerRadius:(CGFloat)radius
       borderWidth:(CGFloat)borderWidth
       borderColor:(UIColor *)borderColor alpha:(CGFloat)borderalpha{
    CGFloat width = MAX(image.ddWidth, image.ddHeight);
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(width, width), NO, image.scale);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGRect rect = CGRectMake(0, 0, width, width);
    CGContextScaleCTM(context, 1, -1);
    CGContextTranslateCTM(context, 0, -rect.size.height);
    
    if (borderWidth < width / 2) {
        UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectInset(rect, borderWidth, borderWidth) byRoundingCorners:UIRectCornerAllCorners cornerRadii:CGSizeMake(radius, borderWidth)];
        [path closePath];
        path.lineWidth = borderWidth;
        path.lineJoinStyle = kCGLineJoinRound;
        [[borderColor colorWithAlphaComponent:borderalpha] setStroke];
        [path stroke];
        CGContextSaveGState(context);
        [path addClip];
        CGContextDrawImage(context, rect, image.CGImage);
        CGContextRestoreGState(context);
    }
    
    
    UIImage *cornerimage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return cornerimage;
}

- (void)imageViewAnimationWithArray:(NSArray *)arr{
    //imageView的动画图片是数组images
    self.animationImages = arr;
    //按照原始比例缩放图片，保持纵横比
    self.contentMode = UIViewContentModeScaleAspectFit;
    //切换动作的时间3秒，来控制图像显示的速度有多快，
    self.animationDuration = 1;
    //动画的重复次数，想让它无限循环就赋成0
    self.animationRepeatCount = 0;
    [self startAnimating];
}
@end
