//
//  UIFont+FKFont.h
//  lbexam
//
//  Created by frankay on 17/1/4.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSInteger,FontsizeType){
    FontsizeType12 = 12,   // 字体12pt
    FontsizeType13 = 13,
    FontsizeType14 = 14,
    FontsizeType15 = 15,
    FontsizeType16 = 16,
    FontsizeType18 = 18,
    FontsizeType19 = 19
};

@interface UIFont (FKFont)

+ (UIFont *)FKFontWithType:(FontsizeType)sizeType isBold:(BOOL)bold;

+ (UIFont *)fk_FontWithPixel:(CGFloat)pixel;

+ (UIFont *)fk_FontSize14;
+ (UIFont *)fk_FontSize15;
+ (UIFont *)fk_FontSize16;
+ (UIFont *)fk_FontSize17;
+ (UIFont *)fk_FontSize18;
+ (UIFont *)fk_FontSize19;

@end
