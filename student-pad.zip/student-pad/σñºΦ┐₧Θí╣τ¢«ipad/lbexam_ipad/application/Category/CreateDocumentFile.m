//
//  CreateDocumentFile.m
//  dd
//
//  Created by frankay on 15/12/31.
//  Copyright © 2015年 frankay. All rights reserved.
//

#import "CreateDocumentFile.h"

@implementation CreateDocumentFile
+ (NSString *)DocumentFile:(NSString *)filename{
    NSString *docupath = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:filename];
    return docupath;
}


+ (BOOL)isexistWithTheFileName:(NSString *)filename{
    NSFileManager *manager = [NSFileManager defaultManager];
    if ([manager fileExistsAtPath:[CreateDocumentFile DocumentFile:filename]]) {
        return YES;
    }else{
        return NO;
    }
}

+(void)deleteFile:(NSString *)filename{
    NSFileManager *manager = [NSFileManager defaultManager];
    if ([manager fileExistsAtPath:[CreateDocumentFile DocumentFile:filename]]) {
        [manager removeItemAtPath:[CreateDocumentFile DocumentFile:filename] error:nil];
    }
}
@end
