//
//  UIImage+RerectImageSize.m
//  UDan
//
//  Created by frankay on 16/12/12.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "UIImage+RerectImageSize.h"

@implementation UIImage (RerectImageSize)

+ (UIImage *)RectWithImage:(UIImage *)originImage rectSize:(CGRect)rect{
    CGImageRef imageRef = CGImageCreateWithImageInRect([originImage CGImage],rect);
    UIImage *newImage = [UIImage imageWithCGImage:imageRef];
    CGImageRelease(imageRef);
    return newImage;
}


+ (UIImage *)squareImageFromImage:(UIImage *)image scaledToSize:(CGFloat)newSize {
    CGFloat y = (newSize-image.size.height)/2.0;
    UIGraphicsBeginImageContext(CGSizeMake(newSize, newSize));
    [[UIColor blackColor] set];
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [UIColor blackColor].CGColor);
    CGContextFillRect(context, CGRectMake(0, 0, newSize, newSize));
    [image drawInRect:CGRectMake(0, y, newSize, image.size.height)];
    UIImage *resultImg = UIGraphicsGetImageFromCurrentImageContext();//从当前上下文中获得最终图片
    UIGraphicsEndImageContext();//关闭上下文
    
    return resultImg;
}

@end
