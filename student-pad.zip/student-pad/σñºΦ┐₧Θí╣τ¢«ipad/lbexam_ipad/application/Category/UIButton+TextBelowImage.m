//
//  UIButton+TextBelowImage.m
//  Youlun
//
//  Created by Chin on 15/6/17.
//  Copyright (c) 2015年 Chin. All rights reserved.
//

#import "UIButton+TextBelowImage.h"

@implementation UIButton (TextBelowImage)
- (void)aliginTextAndImage:(float)spacing
{
    // get the size of the elements here for readability
    CGSize imageSize = self.imageView.frame.size;
    CGSize titleSize = self.titleLabel.frame.size;
    
    // get the height they will take up as a unit
    CGFloat totalHeight = (imageSize.height + titleSize.height + spacing);
    
    // raise the image and push it right to center it
    self.imageEdgeInsets = UIEdgeInsetsMake(- (totalHeight - imageSize.height), 0.0, 0.0, - titleSize.width);
    
    // lower the text and push it left to center it
    self.titleEdgeInsets = UIEdgeInsetsMake(0.0, - imageSize.width, - (totalHeight - titleSize.height),0.0);
}

- (void)aliginTextAndImage
{
    [self aliginTextAndImage:5];
}

//居中左到右，中间加个spacing
- (void)centerButtonAndImageWithSpacing:(CGFloat)spacing {
    CGFloat inset = spacing / 2.0;
    self.imageEdgeInsets = UIEdgeInsetsMake(0, -inset, 0, inset);
    self.titleEdgeInsets = UIEdgeInsetsMake(0, inset, 0, -inset);
    self.contentEdgeInsets = UIEdgeInsetsMake(0, inset, 0, inset);
}


@end
