//
//  UIButton+UDanCountDown.m
//  UDan
//
//  Created by lilingang on 16/10/7.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "UIButton+UDanCountDown.h"
#import <objc/runtime.h>


static NSString *HMDisplayLinkKey;
static NSString *HMLaveTimeKey;
static NSString *HMCountDownFormatKey;
static NSString *HMFinishedStringKey;

@interface UIButton ()

@property (nonatomic, strong) CADisplayLink *displayLink;

@property (nonatomic, assign, readwrite) NSTimeInterval leaveTime;

@end

@implementation UIButton (UDanCountDown)

#pragma mark - Public Methods

-(void)countDownWithTimeInterval:(NSTimeInterval) duration{
    [self setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.leaveTime = duration;
    self.enabled=NO;
    self.displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(countDown)];
    self.displayLink.frameInterval=60;
    [self.displayLink  addToRunLoop: [NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
}

- (void)stopCountDown{
    self.leaveTime = 0;
    self.displayLink.paused = YES;
    [self.displayLink removeFromRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
    [self.displayLink invalidate];
    self.displayLink = nil;
    self.enabled = YES;
    [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
}

#pragma mark - Private Methods

- (void)countDown{
    self.leaveTime--;
    if (!self.countDownFormat) {
        self.countDownFormat=@"(%d)秒";
    }
    [self setTitle:[NSString stringWithFormat:self.countDownFormat,(int)self.leaveTime] forState:UIControlStateDisabled];
    if (self.leaveTime == 0) {
        [self stopCountDown];
        if (self.finishedString) {
            [self setTitle:self.finishedString forState:UIControlStateNormal];
        } else {
            [self setTitle:@"重发" forState:UIControlStateNormal];
        }
    }
}

#pragma mark - Getter And Setter

- (void)setDisplayLink:(CADisplayLink *)displayLink{
    objc_setAssociatedObject(self, &HMDisplayLinkKey, displayLink, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
- (CADisplayLink *)displayLink{
    return  objc_getAssociatedObject(self, &HMDisplayLinkKey);
}



- (void)setLeaveTime:(NSTimeInterval)leaveTime{
    objc_setAssociatedObject(self, &HMLaveTimeKey, @(leaveTime), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
- (NSTimeInterval)leaveTime{
    return  [objc_getAssociatedObject(self, &HMLaveTimeKey) doubleValue];
}



- (void)setCountDownFormat:(NSString *)countDownFormat{
    objc_setAssociatedObject(self, &HMCountDownFormatKey, countDownFormat, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
- (NSString *)countDownFormat{
    return objc_getAssociatedObject(self, &HMCountDownFormatKey);
}


- (void)setFinishedString:(NSString *)finishedString{
    objc_setAssociatedObject(self, &HMFinishedStringKey, finishedString, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
- (NSString *)finishedString{
    return objc_getAssociatedObject(self, &HMFinishedStringKey);
}
@end
