//
//  HMStat.h
//  UDan
//
//  Created by lilingang on 16/10/29.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, HMStatChannel) {
    HMStatChannelAppStore,
    HMStatChannelFirIm,
};

@interface HMStat : NSObject

+ (void)startStatWIthChannel:(HMStatChannel)channel;

+ (void)beginLogPageView:(NSString *)pageName;

+ (void)endLogPageView:(NSString *)pageName;

@end
