//
//  FKSoundEffectPlayerHandle.m
//  lbexam_ipad
//
//  Created by frankay on 17/7/4.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKSoundEffectPlayerHandle.h"
#import <AVFoundation/AVFoundation.h>

@interface FKSoundEffectPlayerHandle ()<AVAudioPlayerDelegate>
@property(nonatomic,strong) AVAudioPlayer *audioPlayer;
@end

@implementation FKSoundEffectPlayerHandle


- (instancetype)init{
    if (self = [super init]) {

        NSError *err;
        AVAudioSession *session = [AVAudioSession sharedInstance];
        [session setCategory:AVAudioSessionCategoryPlayAndRecord error:&err];
    }
    
    return self;
}

- (void)createAudioPlayerWithUrl:(NSString *)url{
    
    if (self.audioPlayer) {
        // 存在
        [self.audioPlayer stop];
        self.audioPlayer = nil;
    }
    
    
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:url] error:nil];
    self.audioPlayer.delegate = self;
    [self.audioPlayer prepareToPlay];
    [self.audioPlayer play];
}

- (void)play{
    [self.audioPlayer play];
}

- (void)pause{
    [self.audioPlayer pause];
}

- (void)stop{
    
    [self.audioPlayer stop];
    self.audioPlayer = nil;
}

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag{
    if (flag) {
        if (self.finishPlayBlock) {
            self.finishPlayBlock(nil);

        }
    }

}

@end
