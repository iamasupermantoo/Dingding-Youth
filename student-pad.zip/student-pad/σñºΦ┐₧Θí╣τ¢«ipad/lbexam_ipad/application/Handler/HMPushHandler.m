//
//  HMPushHandler.m
//  UDan
//
//  Created by lilingang on 16/11/5.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMPushHandler.h"
#import "HMPushRequestTask.h"

#import "HMGotoPageItem.h"
#import "HMRouterHandler.h"
#import "HMUserHandler.h"
#import "WSRequestCache.h"
#import <YYWebImage/YYWebImage.h>

typedef NS_ENUM(NSUInteger, HMPushActionType) {
    HMPushActionTypeGotoPage = 0,  //进入gotoPage
    HMPushActionTypeNone = 1,       //什么都不做
    HMPushActionTypeClearCache = 2, //清楚缓存
    HMPushActionTypeUploadLog = 3,  //上传日志
};

@implementation HMPushHandler

+ (HMPushHandler *)shareInstance {
    static HMPushHandler *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}


// 设置push
- (void)requestAPNSService {
    if (![[HMUserHandler sharedInstance] hasLogin]) {
        return;
    }
    [self cleanBadge];
    UIUserNotificationSettings *mySettings;
    if ([HMUserHandler sharedInstance].pushSwitch) {
        mySettings = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeBadge|UIUserNotificationTypeSound|UIUserNotificationTypeAlert categories:nil];
    } else {
        mySettings = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeNone categories:nil];
    }
    [[UIApplication sharedApplication] registerUserNotificationSettings:mySettings];
    [[UIApplication sharedApplication] registerForRemoteNotifications];
}

- (void)cleanBadge {
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
}



+ (void)applicationDidRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    if (![HMUserHandler sharedInstance].pushSwitch) {
        return;
    }
    [HMUserHandler sharedInstance].pushToken = deviceToken;
    NSString *token=[NSString stringWithFormat:@"%@",deviceToken];
    token=[token substringWithRange:NSMakeRange(1, [token length]-2)];
    token = [token stringByReplacingOccurrencesOfString:@" " withString:@""];
    HMPushRequestTask *pushRequestTask = [[HMPushRequestTask alloc] init];
    pushRequestTask.token = token;
    [pushRequestTask loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            NSLog(@"Push bind Success");
        }
    }];
}

+ (void)application:(UIApplication *)application DidReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult result))completionHandler{
    [[self class] application:(UIApplication *)application DidReceiveRemoteNotification:userInfo shouldRevertViewControllers:YES];
    if (completionHandler) {
        completionHandler(UIBackgroundFetchResultNoData);
    }
}

+ (void)application:(UIApplication *)application DidReceiveRemoteNotification:(NSDictionary *)userInfo shouldRevertViewControllers:(BOOL)revert{
    if (![[HMUserHandler sharedInstance] hasLogin]) {
        return;
    }
    HMPushActionType actionType = [userInfo[@"action"] integerValue];
//    NSDictionary *extra = userInfo[@"extra"];不可预知的参数
    if (actionType == HMPushActionTypeGotoPage) {
        if (application.applicationState == UIApplicationStateInactive) {
            // app在后台运行时
//            HMGotoPageItem *gotoPageItem = [HMGotoPageItem itemWithDictionary:userInfo[@"gotoPage"]];
//            [HMRouterHandler gotoViewControllerWithItem:gotoPageItem animated:NO shouldRevertToRoot:YES];
        }
    } else if (actionType == HMPushActionTypeClearCache){
        [[WSRequestCache shareInstance] clearAllCacheCompleteHandler:^(NSError *error) {
        }];
        [[YYImageCache sharedCache].memoryCache removeAllObjects];
        [[YYImageCache sharedCache].diskCache removeAllObjectsWithBlock:^{
        }];
    } else if (actionType == HMPushActionTypeUploadLog){
        
    }
}

@end
