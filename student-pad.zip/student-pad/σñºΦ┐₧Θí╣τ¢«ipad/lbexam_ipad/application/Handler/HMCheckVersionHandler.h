//
//  HMCheckVersionHandler.h
//  UDan
//
//  Created by lilingang on 16/11/17.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMCheckVersionHandler : NSObject

+ (HMCheckVersionHandler *)sharedInstance;

- (void)checkAppUpdate;

@end
