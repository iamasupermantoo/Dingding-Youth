//
//  FKimageHandle.m
//  lbexam_ipad
//
//  Created by frankay on 17/2/22.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKimageHandle.h"
#import "CreateDocumentFile.h"

#define kPicPlist @"pic.plist"
@interface FKimageHandle ()
// 下载的task的数组
@property(nonatomic,strong) NSMutableDictionary *operations;
// 操作队列
@property(nonatomic,strong) NSOperationQueue *operationQueue;
// 缓存数组
@property(nonatomic,strong) NSMutableDictionary *imagechaces;


@end

@implementation FKimageHandle{
    int count;
}


- (void)downloadImageWith:(NSArray *)urls{
    count = 0;

    self.imagechaces = [NSMutableDictionary dictionaryWithContentsOfFile:[CreateDocumentFile DocumentFile:kPicPlist]];
    if (self.imagechaces) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(downLoadSuccessWithImagechaces:)]) {
            [self.delegate downLoadSuccessWithImagechaces:self.imagechaces];
        }
        return;
    }
    
    for (NSString *url in urls) {
        NSBlockOperation *operation = nil;
        if (operation==nil) {
            // 操作不存在
            operation = [NSBlockOperation blockOperationWithBlock:^{
                // type 0 下载 type 1 是获取image
                [self getImageWithUrl:url withType:0];
            }];
            
            [self.operationQueue addOperation:operation];
        }
    }
}


- (UIImage *)getImageWithUrl:(NSString *)url withType:(NSInteger)type{
    
    // 从缓存中取
    if (self.imagechaces[url]==nil) {
        // 从plist文件中获取
        
        [self loadImageWithUrl:url withType:type];
        
    }
    
    if (type==0) {
        count++;
        if (count==_Urlcount) {
            // 下载成功把
            [CreateDocumentFile deleteFile:kPicPlist];
            
            if (![CreateDocumentFile isexistWithTheFileName:kPicPlist]) {
                // 存入本地
                NSString *picPath= [CreateDocumentFile DocumentFile:kPicPlist];
                [self.imagechaces writeToFile:picPath atomically:YES];
            }
            
            if (self.delegate && [self.delegate respondsToSelector:@selector(downLoadSuccessWithImagechaces:)]) {
                [self.delegate downLoadSuccessWithImagechaces:self.imagechaces];
            }
        }

    }
    NSData *_decodedImageData = [[NSData alloc]initWithBase64EncodedString:self.imagechaces[url] options:NSDataBase64DecodingIgnoreUnknownCharacters];
    UIImage *_decodedImage = [UIImage imageWithData:_decodedImageData];
    return _decodedImage;
    
}

-(void)cleanChace{
    
    if (self.imagechaces) {
        [self.imagechaces removeAllObjects];
         self.imagechaces = nil;
    }
    self.operationQueue = nil;
}


- (void)loadImageWithUrl:(NSString *)url withType:(NSInteger)type{
    
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:url]];
    
    // 数据加载失败
    if (data==nil) {
        if (type==1) {
            [DDProgressHUD showErrorWithStatus:@"抱歉，图片加载失败"];
        }
        return;
    }
    UIImage *image = [UIImage imageWithData:data];
    NSData *_data = UIImageJPEGRepresentation(image, 0.5f);
    //将图片的data转化为字符串
    NSString *strimage64 = [_data base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    
    // 把下载的图片保存在内存中
    [self.imagechaces setObject:strimage64 forKey:url];
    if (type==1) {
       
        //  把新增的图片添加到文件中
        NSString *picPath= [CreateDocumentFile DocumentFile:kPicPlist];
        [self.imagechaces writeToFile:picPath atomically:YES];
    
    }
    
}

- (NSMutableDictionary *)operations{
    if (!_operations) {
        _operations = [NSMutableDictionary dictionary];
    }
    return _operations;
}

- (NSMutableDictionary *)imagechaces{
    if (!_imagechaces) {
        _imagechaces = [NSMutableDictionary dictionary];
    }
    return _imagechaces;
}

- (NSOperationQueue *)operationQueue{
    if (!_operationQueue) {
        _operationQueue = [[NSOperationQueue alloc] init];
        _operationQueue.maxConcurrentOperationCount = 5;
    }
    return _operationQueue;
}
@end
