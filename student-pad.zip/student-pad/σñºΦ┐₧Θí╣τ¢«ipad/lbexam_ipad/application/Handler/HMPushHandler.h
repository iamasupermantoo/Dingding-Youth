//
//  HMPushHandler.h
//  UDan
//
//  Created by lilingang on 16/11/5.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMPushHandler : NSObject

+ (HMPushHandler *)shareInstance;

- (void)requestAPNSService;

- (void)cleanBadge;

+ (void)applicationDidRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken;

+ (void)application:(UIApplication *)application
   DidReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult result))completionHandler;

+ (void)application:(UIApplication *)application DidReceiveRemoteNotification:(NSDictionary *)userInfo shouldRevertViewControllers:(BOOL)revert;

@end
