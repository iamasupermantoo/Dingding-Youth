//
//  NewsHandle.h
//  UDan
//
//  Created by frankay on 16/12/23.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsHandle : NSObject
/**创建信息的存储地方*/
+ (void)createFile:(id)obj withKey:(NSString *)key;

/**删除文件*/
+ (void)deleteFilewithKey:(NSString *)key;

/**写文件*/
+ (void)writeInFileWithObj:(id)obj withKey:(NSString *)key;

/**读文件*/
+ (id)readFromFilewithKey:(NSString *)key;
@end
