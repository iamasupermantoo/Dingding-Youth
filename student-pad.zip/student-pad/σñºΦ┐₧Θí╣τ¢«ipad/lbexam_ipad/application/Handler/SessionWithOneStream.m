//
//  SessionWithOneStream.m
//  AgoraLiveTest
//
//  Created by frankay on 17/1/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "SessionWithOneStream.h"
#import <AgoraRtcEngineKit/AgoraRtcEngineKit.h>
@implementation SessionWithOneStream

- (instancetype)initWithUid:(NSUInteger)uid {
    if (self = [super init]) {
        self.uid = uid;
        self.hostingView = [[UIView alloc] init];
        self.hostingView.translatesAutoresizingMaskIntoConstraints = NO;
        self.canvas = [[AgoraRtcVideoCanvas alloc] init];
        self.canvas.uid = uid;
        self.canvas.view = self.hostingView;
        self.canvas.renderMode = AgoraRtc_Render_Hidden;
    }
    return self;
}

@end
