//
//  FKAudioPlayerHandle.h
//  newUdan_ipad
//
//  Created by frankay on 17/2/20.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import "DOUAudioStreamer.h"


@interface FKNowPlayerModel : NSObject
@property(nonatomic,strong) NSString *mp_Title;
@property(nonatomic,strong) NSString *mp_Artist;
@property(nonatomic,strong) NSString *mp_AlbumTitle;
@property(nonatomic,strong) UIImage  *mp_ArtworkImage;
@end


@protocol FKAudioPlayerHandleDelegate <NSObject>


@optional
- (void)updateSlideValue:(CGFloat)value andTime:(NSString *)leftTime;

- (void)streamerWithStatus:(DOUAudioStreamerStatus)status;

@end

@interface FKAudioPlayerHandle : NSObject
@property(nonatomic,weak)id<FKAudioPlayerHandleDelegate>delegate;

@property(nonatomic,strong) NSString *identify; // 播放音频的标识
@property(nonatomic,assign) BOOL isPlaying;

@property(nonatomic,strong) UIView *floatView; // 播放器的悬浮view
@property(nonatomic,strong) FKNowPlayerModel *mp_Model;

@property(nonatomic,assign) BOOL canPlayinGround; // 设置锁频时候是否能播放

+ (FKAudioPlayerHandle *)sharedManager;
- (void)createStreamWithUrl:(NSString *)url;
- (void)fk_play;
- (void)fk_pause;
- (void)fk_close;
- (void)fk_chageSlideToValue:(CGFloat)value;

- (DOUAudioStreamerStatus)streamStatus;


@end



