//
//  HMCheckVersionHandler.m
//  UDan
//
//  Created by lilingang on 16/11/17.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMCheckVersionHandler.h"
#import "HMCheckVersionRequestTask.h"

@implementation HMCheckVersionHandler

+ (HMCheckVersionHandler *)sharedInstance {
    static HMCheckVersionHandler *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
    
}


- (void)checkAppUpdate{
    
    HMCheckVersionRequestTask *task = [[HMCheckVersionRequestTask alloc] init];
    [task loadWithComplateHandle:^(WSRequestTask *request, NSDictionary *headers, NSDictionary *response, BOOL localResult, NSError *error) {
        if (!error) {
            HMCheckVersionRequestTask *tmpTask = (HMCheckVersionRequestTask *)request;
            if (tmpTask.isUpdate) {
                [self checkNewAppVersion:tmpTask.force title:tmpTask.title des:tmpTask.descriptionString url:tmpTask.downloadUrl];
            }
          
        }
    }];
}

- (void)checkNewAppVersion:(BOOL)force title:(NSString *)title des:(NSString *)description url:(NSString *)url{
    
    PSTAlertController *alertController = [PSTAlertController alertWithTitle:title message:description];
    PSTAlertAction *cancel = [PSTAlertAction actionWithTitle:@"取消" handler:nil];
    PSTAlertAction *update = [PSTAlertAction actionWithTitle:@"更新" style:PSTAlertActionStyleDefault handler:^(PSTAlertAction * _Nonnull action) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
        }];
        if (!force) {
            // 强制
            [alertController addAction:cancel];

        }
        [alertController addAction:update];
        [alertController showWithSender:nil controller:[UIApplication sharedApplication].keyWindow.rootViewController animated:YES completion:nil];
    
}

@end
