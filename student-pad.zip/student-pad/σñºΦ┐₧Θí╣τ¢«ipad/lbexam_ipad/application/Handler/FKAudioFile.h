//
//  FKAudioFile.h
//  lbexam_ipad
//
//  Created by frankay on 17/2/22.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DOUAudioFile.h"
@interface FKAudioFile : NSObject<DOUAudioFile>
@property(nonatomic,strong) NSString *url;
@property (nonatomic, strong) NSURL *audioFileURL;
@end
