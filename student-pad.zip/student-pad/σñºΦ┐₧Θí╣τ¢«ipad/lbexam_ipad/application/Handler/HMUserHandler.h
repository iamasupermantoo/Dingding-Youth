//
//  HMUserHandler.h
//  UDan
//
//  Created by lilingang on 16/10/14.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "HMUserItem.h"

@interface HMUserHandler : NSObject

@property (nonatomic, assign) BOOL pushSwitch;

@property (nonatomic, strong) NSData *pushToken;

/**api请求的票据*/
@property (nonatomic, copy) NSString *ticket;

/**用户的唯一标识*/
@property (readonly) NSString *userId;

/**用户信息*/
@property (nonatomic, strong) HMUserItem *userItem;

/**
 *  @brief 当前登录用户的存储目录
 */
@property (nonatomic, copy, readonly) NSString *userDirectory;

+ (HMUserHandler *)sharedInstance;

- (void)saveToLocal;

- (BOOL)hasLogin;

- (void)clear;

@end
