//
//  HMStat.m
//  UDan
//
//  Created by lilingang on 16/10/29.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMStat.h"
#import "UMMobClick/MobClick.h"

@implementation HMStat

+ (void)startStatWIthChannel:(HMStatChannel)channel{
    UMConfigInstance.appKey = @"59321a4507fe652ff8000e27";
    if (channel == HMStatChannelFirIm) {
        UMConfigInstance.channelId = @"Fir Im";
    }
    UMConfigInstance.ePolicy = BATCH;
    [MobClick startWithConfigure:UMConfigInstance];
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    [MobClick setAppVersion:version];
    [MobClick setCrashReportEnabled:YES];
}

+ (void)beginLogPageView:(NSString *)pageName{
    [MobClick beginLogPageView:pageName];
}

+ (void)endLogPageView:(NSString *)pageName{
    [MobClick endLogPageView:pageName];
}

@end
