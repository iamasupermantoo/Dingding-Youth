//
//  FKimageHandle.h
//  lbexam_ipad
//
//  Created by frankay on 17/2/22.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol FKimageHandleDelegate <NSObject>

- (void)downLoadSuccessWithImagechaces:(NSDictionary *)dict;

@end

@interface FKimageHandle : NSObject
@property(nonatomic,weak)id<FKimageHandleDelegate>delegate;

@property(nonatomic,assign) NSUInteger Urlcount;
// 下载图片
- (void)downloadImageWith:(NSArray *)urls;

// 取出内存中图片
- (UIImage *)getImageWithUrl:(NSString *)url withType:(NSInteger)type;

// 清楚缓存
- (void)cleanChace;


@end
