//
//  FKAgoraLiveHandle.h
//  AgoraLiveTest
//
//  Created by frankay on 17/2/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <videoprp/AgoraYuvEnhancerObjc.h>

#import <AgoraRtcEngineKit/AgoraRtcEngineKit.h>
typedef NS_ENUM(NSInteger, FKStatusType) {
    
    FKStatusTypeTeacher = 0,
    FKStatusTypeStudent = 1,
    FKStatusTypeTourist = 2,
};

@protocol FKAgoraLiveHandleDelegate <NSObject>

- (void)fkFirstLocalVideoWithView:(UIView *)view;
- (void)fkFirstRemoteVideoWithView:(UIView *)view withUid:(NSUInteger)uid;

- (void)fkCheckLocalVideoStatus:(AgoraRtcLocalVideoStats *)stats;

//- (void)fkCheckRemoteVideoStatus:(AgoraRtcRemoteVideoStats *)stats;

- (void)fkRemoteUserJoinRoomWithUserId:(NSUInteger)uid;

- (void)fkOtherUserOffLineWithUserId:(NSUInteger)uid;

- (void)fkLeaveSuccess;

@end

@interface FKAgoraLiveHandle : NSObject
@property(nonatomic,assign) FKStatusType Roletype;  //角色
@property(nonatomic,strong) NSString *appId;    // agora的appid
@property(nonatomic,assign) AgoraRtcVideoProfile videoProfile;
@property(nonatomic,strong) NSString *roomNum;  // 房间号
@property(nonatomic,assign) NSUInteger uid;     // id 号 用于区别流
@property(nonatomic,strong) NSString *channelKey; // 加密的key

@property(nonatomic,weak)id<FKAgoraLiveHandleDelegate>delegate;

// 开启美颜
- (void)turnOnMY;

// 关闭美颜
- (void)turnOffMY;

// 初始化sdk  进入频道
- (void)initagoraKit;

// 主动离开频道
- (void)leaveChannel;

// 静音
- (void)LocalMute:(BOOL)isMute;

@end
