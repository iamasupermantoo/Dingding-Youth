//
//  FKAgoraLiveHandle.m
//  AgoraLiveTest
//
//  Created by frankay on 17/2/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKAgoraLiveHandle.h"
#import "SessionWithOneStream.h"
#import "AVAudioSession+FKAgoraAudioSession.h"
@interface FKAgoraLiveHandle ()<AgoraRtcEngineDelegate>
@property (strong, nonatomic) AgoraRtcEngineKit *rtcEngine; //sdk
@property (strong, nonatomic) AgoraYuvEnhancerObjc *agoraEnhancer; // 美颜
@property(nonatomic,strong) NSMutableArray *StreamSessions;
@property(nonatomic,strong) AgoraRtcVideoCanvas *canvas;

@end


@implementation FKAgoraLiveHandle

- (AgoraYuvEnhancerObjc *)agoraEnhancer {
    if (!_agoraEnhancer) {
        _agoraEnhancer = [[AgoraYuvEnhancerObjc alloc] init];
    
        _agoraEnhancer.lighteningFactor = 0.7;
        _agoraEnhancer.smoothness = 0.7;
    }
    return _agoraEnhancer;
    
}


- (void)turnOnMY{
    [self.agoraEnhancer turnOn];
}

- (void)turnOffMY{
    [self.agoraEnhancer turnOff];
}

- (void)LocalMute:(BOOL)isMute{
    [self.rtcEngine muteLocalAudioStream:isMute];
}

- (int)enableSpeakerphone:(BOOL)enableSpeaker{
    
    return [self.rtcEngine setEnableSpeakerphone:enableSpeaker];
}


- (void)initagoraKit{
    //1、 初始化sdk
    
    self.StreamSessions = [NSMutableArray array];
    self.rtcEngine = [AgoraRtcEngineKit sharedEngineWithAppId:self.appId delegate:self];
    //2、 设置sdk频道的模式是直播模式
    [self.rtcEngine setChannelProfile:AgoraRtc_ChannelProfile_LiveBroadcasting];
    
    //3、 开启双流
    [self.rtcEngine enableDualStreamMode:YES];
    
    //4、 是否能视频直播
    [self.rtcEngine enableVideo];
    
    //5、 设置直播的编码之类的设置(配置profile)
    [self.rtcEngine setVideoProfile:self.videoProfile swapWidthAndHeight:YES];
    

    int code;
    //6、设置角色  教师 学生 游客
    if (self.Roletype == FKStatusTypeTourist) {
        [self.rtcEngine setClientRole:AgoraRtc_ClientRole_Audience withKey:nil];
        code= [self.rtcEngine joinChannelByKey:self.channelKey channelName:self.roomNum info:nil uid:self.uid joinSuccess:nil];
       
    }else{
        
        // 设置教师和学生的角色 为直播状态
        [self.rtcEngine setClientRole:AgoraRtc_ClientRole_Broadcaster withKey:nil];

        [self.rtcEngine startPreview];
        SessionWithOneStream *session;
        // 创建本地流
        if (self.Roletype == FKStatusTypeTeacher) {
            session = [[SessionWithOneStream alloc] initWithUid:self.uid];
        }else{
            session = [[SessionWithOneStream alloc] initWithUid:self.uid];
        }
        self.canvas = session.canvas;
        
        // 本地流
        [self.rtcEngine setupLocalVideo:session.canvas];
        
        [self.StreamSessions addObject:session];
        
        code= [self.rtcEngine joinChannelByKey:self.channelKey channelName:self.roomNum info:nil uid:session.canvas.uid joinSuccess:nil];
    }
    
//        [self.rtcEngine setRemoteVideoStream: type:AgoraRtc_VideoStream_High];
    
    //9、 加入频道进入房间就可以直播了  频道name  用户id 可以自己配置
    
    if (code == 0) {
        // 加入频道后禁止自动锁屏了
        [self setIdleTimerActive:NO];
        
        [self enableSpeakerphone:YES];
    } else {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self alertString:[NSString stringWithFormat:@"Join channel failed: %d", code]];
        });
    }
    
 
    
    // 开启美颜
    [self turnOnMY];
    
}

- (void)setIdleTimerActive:(BOOL)active {
    [UIApplication sharedApplication].idleTimerDisabled = !active;
    
}

- (void)alertString:(NSString *)string {
    if (!string.length) {
        return;
    }
}

// sdk 出现错误的时候
- (void)rtcEngine:(AgoraRtcEngineKit *)engine didOccurError:(AgoraRtcErrorCode)errorCode{
    [DDProgressHUD showWithStatus:[NSString stringWithFormat:@"直播错误:%ld",(long)errorCode]];
}

// 本地传出帧成功后
-(void)rtcEngine:(AgoraRtcEngineKit *)engine firstLocalVideoFrameWithSize:(CGSize)size elapsed:(NSInteger)elapsed{
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(fkFirstLocalVideoWithView:)]) {
        [self.delegate fkFirstLocalVideoWithView:self.canvas.view];
    }
}


- (void)rtcEngine:(AgoraRtcEngineKit *)engine firstRemoteVideoDecodedOfUid:(NSUInteger)uid size:(CGSize)size elapsed:(NSInteger)elapsed{
    SessionWithOneStream *session = [[SessionWithOneStream alloc] initWithUid:uid];
    [self.StreamSessions addObject:session];
    // 接收流后配置收到流的配置
    [self.rtcEngine setRemoteVideoStream:session.uid type:AgoraRtc_VideoStream_High];
    [self.rtcEngine setupRemoteVideo:session.canvas];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(fkFirstRemoteVideoWithView:withUid:)]) {
        [self.delegate fkFirstRemoteVideoWithView:session.canvas.view withUid:uid];
    }

}

// 离线
- (void)rtcEngine:(AgoraRtcEngineKit *)engine didOfflineOfUid:(NSUInteger)uid reason:(AgoraRtcUserOfflineReason)reason {
    SessionWithOneStream *deleteSession;
    // 如果直播直接退出 会直接调用这个方法。
    // 如果对方没有网络 过个几秒会调用这个方法。
    if (self.delegate && [self.delegate respondsToSelector:@selector(fkOtherUserOffLineWithUserId:)]) {
        [self.delegate fkOtherUserOffLineWithUserId:uid];
    }

    for (SessionWithOneStream *session in self.StreamSessions) {
        if (session.uid == uid) {
            deleteSession = session;
        }
    }
    
    if (deleteSession) {
        [self.StreamSessions removeObject:deleteSession];
        [deleteSession.hostingView removeFromSuperview];
    }
}


// 远程用户加入的时候触发
- (void)rtcEngine:(AgoraRtcEngineKit *)engine didJoinedOfUid:(NSUInteger)uid elapsed:(NSInteger)elapsed{
    if (self.delegate && [self.delegate respondsToSelector:@selector(fkRemoteUserJoinRoomWithUserId:)]) {
        [self.delegate fkRemoteUserJoinRoomWithUserId:uid];
    }
}

//- (void)rtcEngine:(AgoraRtcEngineKit *)engine remoteVideoStats:(AgoraRtcRemoteVideoStats*)stats{
//    // 远端视频的状态  如果远端未连接不会调用   自己断线也不会调用
//    if (self.delegate && [self.delegate respondsToSelector:@selector(fkCheckRemoteVideoStatus:)]) {
//        [self.delegate fkCheckRemoteVideoStatus:stats];
//    }
//}


// 检测本地连接传送 帧视频的状态 每两秒一次  自己断线后不会调用
- (void)rtcEngine:(AgoraRtcEngineKit *)engine localVideoStats:(AgoraRtcLocalVideoStats*)stats{
    if (self.delegate && [self.delegate respondsToSelector:@selector(fkCheckLocalVideoStatus:)]) {
        [self.delegate fkCheckLocalVideoStatus:stats];
    }

}


- (void)leaveChannel {
    
    [self setIdleTimerActive:YES];
    [self.rtcEngine setupLocalVideo:nil];
    [self.rtcEngine leaveChannel:^(AgoraRtcStats *stat) {
        // 离开频道之后销毁sdk
        [AgoraRtcEngineKit destroy];
        
        if (self.delegate && [self.delegate respondsToSelector:@selector(fkLeaveSuccess)]) {
            [self.delegate fkLeaveSuccess];
        }
    }];
    [self.rtcEngine stopPreview];
    self.rtcEngine = nil;
    for (SessionWithOneStream *session in self.StreamSessions) {
        [session.hostingView removeFromSuperview];
    }
    [self.StreamSessions removeAllObjects];
    [self turnOffMY];
    
   
}
@end
