//
//  NewsHandle.m
//  UDan
//
//  Created by frankay on 16/12/23.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "NewsHandle.h"

@implementation NewsHandle

+ (void)createFile:(id)obj withKey:(NSString *)key{
    if (![NewsHandle isexitwithKey:key]) {
        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:obj];
        [USER_DEFAULTS setObject:data forKey:key];
    }
}

+ (BOOL)isexitwithKey:(NSString *)key{
    if ([USER_DEFAULTS valueForKey:key]) {
        return YES;
    }
    return NO;
}

+ (void)deleteFilewithKey:(NSString *)key{
    if ([NewsHandle isexitwithKey:key]) {
        // 文件存在
        [USER_DEFAULTS removeObjectForKey:key];
    }
}

+ (void)writeInFileWithObj:(id)obj withKey:(NSString *)key{
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:obj];

    [USER_DEFAULTS setObject:data forKey:key];
}

+(id)readFromFilewithKey:(NSString *)key{
    if ([NewsHandle isexitwithKey:key]) {
    
      return [NSKeyedUnarchiver unarchiveObjectWithData:[USER_DEFAULTS valueForKey:key]];
    }
    return nil;
}
@end
