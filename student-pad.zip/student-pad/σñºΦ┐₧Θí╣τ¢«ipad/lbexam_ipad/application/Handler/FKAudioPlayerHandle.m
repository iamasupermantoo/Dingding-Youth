//
//  FKAudioPlayerHandle.m
//  newUdan_ipad
//
//  Created by frankay on 17/2/20.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKAudioPlayerHandle.h"
#import "FKAudioFile.h"

#import <MediaPlayer/MediaPlayer.h>

static void *kStatusKVOKey = &kStatusKVOKey;
static void *kDurationKVOKey = &kDurationKVOKey;
static void *kBufferingRatioKVOKey = &kBufferingRatioKVOKey;
@interface FKAudioPlayerHandle ()
@property(nonatomic,strong) DOUAudioStreamer *streamer;

@end
@implementation FKAudioPlayerHandle
{

    NSTimer *_timer;
}

+(FKAudioPlayerHandle *)sharedManager{
    static dispatch_once_t predicate;
    static FKAudioPlayerHandle * sharedManager;
    dispatch_once(&predicate, ^{
        sharedManager=[[FKAudioPlayerHandle alloc] init];
        
    });
    return sharedManager;
}


-(void)createStreamWithUrl:(NSString *)url{
    
    [self _resetStreamerWithUrl:url];
    _timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(_timerAction:) userInfo:nil repeats:YES];
}


- (void)_resetStreamerWithUrl:(NSString *)url;
{
    [self _cancelStreamer];
    FKAudioFile *audioFile = [[FKAudioFile alloc] init];
    
    [audioFile setAudioFileURL: [NSURL URLWithString:url]];
    _streamer = [DOUAudioStreamer streamerWithAudioFile:audioFile];
    [_streamer addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:kStatusKVOKey];
    [_streamer addObserver:self forKeyPath:@"duration" options:NSKeyValueObservingOptionNew context:kDurationKVOKey];
    [_streamer addObserver:self forKeyPath:@"bufferingRatio" options:NSKeyValueObservingOptionNew context:kBufferingRatioKVOKey];
    [_streamer play];
    
    if (self.canPlayinGround) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self configLockShow];
        });
    }
    
}

- (void)configLockShow
{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    //设置歌曲题目
    [dict setObject:self.mp_Model.mp_Title ?:@"" forKey
                   :MPMediaItemPropertyTitle];
    //设置歌手名
    [dict setObject:self.mp_Model.mp_Artist?:@"" forKey:MPMediaItemPropertyArtist];
    //设置专辑名
    [dict setObject:@"" forKey:MPMediaItemPropertyAlbumTitle];
    //设置显示的图片
    UIImage *image;
    if (self.mp_Model.mp_ArtworkImage) {
        //
        image = self.mp_Model.mp_ArtworkImage;
    }else{
        image = [UIImage imageNamed:@"temp.jpeg"];
    
    }
    
    [dict setObject:[[MPMediaItemArtwork alloc] initWithImage:image]
             forKey:MPMediaItemPropertyArtwork];
    
    //设置歌曲时长
    [dict setObject:[NSNumber numberWithInteger:[_streamer duration]] forKey:MPMediaItemPropertyPlaybackDuration];
    //设置已经播放时长
    [dict setObject:[NSNumber numberWithInteger:[_streamer currentTime]] forKey:MPNowPlayingInfoPropertyElapsedPlaybackTime];
    //更新字典
    [[MPNowPlayingInfoCenter defaultCenter] setNowPlayingInfo:dict];
}



- (void)_cancelStreamer
{
    if (_streamer != nil) {
        [_streamer stop];
        [_streamer removeObserver:self forKeyPath:@"status"];
        [_streamer removeObserver:self forKeyPath:@"duration"];
        [_streamer removeObserver:self forKeyPath:@"bufferingRatio"];
        _streamer = nil;
    }
    
    if (_timer) {
        [_timer invalidate];
        _timer = nil;
    }
    self.identify = nil;
}

- (DOUAudioStreamerStatus)streamStatus{
    
    return self.streamer.status;

}



// 是否正在播放
- (BOOL)isPlaying{
    if (self.streamer.status == DOUAudioStreamerPlaying) {
        return YES;
    }
    return NO;
}


// float 视图
-(UIView *)floatView{
    if (!_floatView) {
        _floatView = [[UIView alloc] init];
        UIButton *logout = [UIButton buttonWithType:UIButtonTypeCustom];
        [logout setTitle:@"退出" forState:UIControlStateNormal];
        logout.frame = _floatView.bounds;
        [logout addTarget:self action:@selector(logoutPlayer:) forControlEvents:UIControlEventTouchUpInside];
        
        [_floatView addSubview:logout];
        
    }
    
    return _floatView;
}


- (void)logoutPlayer:(id)sender{
    
    [self fk_close];
    
}

- (void)_timerAction:(id)timer
{
    if ([_streamer duration] == 0.0) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(updateSlideValue:andTime:)]) {
            [self.delegate updateSlideValue:0.0 andTime:[self getLeftTime]];
        }
    }
    else {
        if (self.delegate && [self.delegate respondsToSelector:@selector(updateSlideValue:andTime:)]) {
            [self.delegate updateSlideValue:[_streamer currentTime] / [_streamer duration] andTime:[self getLeftTime]];
        }
    }
}


- (void)_updateStatus
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(streamerWithStatus:)]) {
        [self.delegate streamerWithStatus:[_streamer status]];
    }
}


- (void)_updateBufferingStatus
{
//    [_miscLabel setText:[NSString stringWithFormat:@"Received %.2f/%.2f MB (%.2f %%), Speed %.2f MB/s", (double)[_streamer receivedLength] / 1024 / 1024, (double)[_streamer expectedLength] / 1024 / 1024, [_streamer bufferingRatio] * 100.0, (double)[_streamer downloadSpeed] / 1024 / 1024]];
//    
//    if ([_streamer bufferingRatio] >= 1.0) {
//        NSLog(@"sha256: %@", [_streamer sha256]);
//    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if (context == kStatusKVOKey) {
        [self performSelector:@selector(_updateStatus)
                     onThread:[NSThread mainThread]
                   withObject:nil
                waitUntilDone:NO];
    }
    else if (context == kDurationKVOKey) {
        [self performSelector:@selector(_timerAction:)
                     onThread:[NSThread mainThread]
                   withObject:nil
                waitUntilDone:NO];
    }
    else if (context == kBufferingRatioKVOKey) {
        [self performSelector:@selector(_updateBufferingStatus)
                     onThread:[NSThread mainThread]
                   withObject:nil
                waitUntilDone:NO];
    }
    else {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

- (void)fk_play{
    [_timer setFireDate:[NSDate distantPast]];
    [_streamer play];
}

- (void)fk_pause{
    [_timer setFireDate:[NSDate distantFuture]];
    [_streamer pause];
}

- (void)fk_close{
   
    [self _cancelStreamer];
}

- (void)fk_chageSlideToValue:(CGFloat)value{
     [_streamer setCurrentTime:[_streamer duration]*value];
}

-(NSString *)getLeftTime{
    NSInteger leftMin = ([_streamer duration]-[_streamer currentTime]) / 60;//总秒
    NSInteger leftSec = (int)([_streamer duration]-[_streamer currentTime]) % 60;//总分钟
    return [NSString stringWithFormat:@"%02zd:%02zd", leftMin, leftSec];

}

@end




@implementation FKNowPlayerModel

@end
