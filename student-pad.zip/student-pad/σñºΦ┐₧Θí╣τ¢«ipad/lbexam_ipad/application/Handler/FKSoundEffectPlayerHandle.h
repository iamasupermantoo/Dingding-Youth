//
//  FKSoundEffectPlayerHandle.h
//  lbexam_ipad
//
//  Created by frankay on 17/7/4.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FKSoundEffectPlayerHandle : NSObject

@property(nonatomic,copy) HMBlock finishPlayBlock;

- (void)createAudioPlayerWithUrl:(NSString *)url;

- (void)play;
- (void)pause;
- (void)stop;

@end
