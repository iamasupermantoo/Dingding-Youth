//
//  HMRouterHandler.m
//  UDan
//
//  Created by lilingang on 16/10/7.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMRouterHandler.h"
#import "AppDelegate.h"

#import "HMLoginViewController.h"
#import "FKMainViewController.h"
#import "HMGotoPageItem.h"

@implementation HMRouterHandler

+ (void)revertToLoginController{
    NSMutableArray *viewControllers = [self.navigationController.viewControllers mutableCopy];
    while ([viewControllers count] > 0 && ![[viewControllers lastObject] isKindOfClass:[HMLoginViewController class]]) {
        [viewControllers removeLastObject];
    }
    self.navigationController.viewControllers = viewControllers;
    if ([viewControllers count] == 0) {
        HMLoginViewController *viewController = [[HMLoginViewController alloc] init];
        [self.navigationController pushViewController:viewController animated:NO];
    }
}

+ (void)revertToMainController{
    NSMutableArray *viewControllers = [self.navigationController.viewControllers mutableCopy];
    FKMainViewController *viewController = nil;
    while ([viewControllers count] > 0 && ![[viewControllers lastObject] isKindOfClass:[FKMainViewController class]]) {
        [viewControllers removeLastObject];
    }
    if ([viewControllers count] > 0) {
        viewController = [viewControllers lastObject];
        self.navigationController.viewControllers = viewControllers;
    } else {
        viewController = [[FKMainViewController alloc] init];
        [self.navigationController setViewControllers:@[viewController] animated:NO];
    }
}

+ (void)gotoViewControllerWithItem:(HMGotoPageItem *)gotoPageItem
                          animated:(BOOL)animated{
    [self gotoViewControllerWithItem:gotoPageItem animated:animated shouldRevertToRoot:NO];
}

+ (void)gotoViewControllerWithItem:(HMGotoPageItem *)gotoPageItem
                          animated:(BOOL)animated
                shouldRevertToRoot:(BOOL)shouldRevert{
    switch (gotoPageItem.type) {
        case HMGotoPageTypePostDetail:{
            
        }
            break;
        case HMGotoPageTypeProfile:{

        }
            break;
        case HMGotoPageTypeWebView:{
//            HMWebViewController *viewController = [[HMWebViewController alloc] initWithURLString:gotoPageItem title:(NSString *)];
//            [self.navigationController pushViewController:viewController animated:animated];
        }
            break;
        case HMGotoPageTypeFeedBack:{
    
        }
            break;
        case HMGotoPageTypeAnswerDetail:{
       
        }
            break;
        default:
            break;
    }
}

+ (void)gotoPageType:(HMGotoPageType)pageType userId:(id)userID animated:(BOOL)animated{
    
    
}

+ (void)gotoWebViewWithTitle:(NSString *)title
                         url:(NSString *)url
                    animated:(BOOL)animated{
//    HMWebViewController *viewController = [[HMWebViewController alloc] initWithURLString:url title:title];
//    [self.navigationController pushViewController:viewController animated:animated];
}



+ (void)NotHaveParameterPushWith:(NSString *)classString{
    Class class = NSClassFromString(classString);
    
    UIViewController *viewContoller = [[class alloc] init];
   
    [[HMRouterHandler navigationController] pushViewController:viewContoller animated:YES];
    
}


+ (void)haveParameterPushWithBlock:(PushBlock)pushBlock toVC:(NSString *)vcStr{
    Class class = NSClassFromString(vcStr);
    
    UIViewController *viewContoller = [[class alloc] init];
    if (pushBlock) {
        pushBlock(viewContoller);
    }
    [[HMRouterHandler navigationController] pushViewController:viewContoller animated:YES];
    
}
#pragma mark - Getter

+ (UINavigationController *)navigationController{
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    return (UINavigationController *)appDelegate.window.rootViewController;
}
@end
