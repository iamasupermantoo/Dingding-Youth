//
//  HMLoginHandler.h
//  UDan
//
//  Created by lilingang on 16/10/7.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMLoginHandler : NSObject

+ (HMLoginHandler *)sharedInstance;

- (void)logout;

@end
