//
//  FKAgoraSignalHandle.h
//  iosapp1
//
//  Created by frankay on 17/2/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "agorasdk.h"

@protocol  FKAgoraSignalHandleDelegate<NSObject>

@optional
// 登陆与退出
- (void)fkAgoraSignalLoginSuccessWithUid:(NSUInteger)uid;
- (void)fkAgoraSignalLoginFailedWithEcode:(AgoraEcode)ecode;
- (void)fkAgoraSignalLogoutWithEcode:(AgoraEcode)ecode;

// 加入频道与离开频道
- (void)fkAgoraSignalJoinChannelWithName:(NSString *)name;
- (void)fkAgoraSignalJoinChannelFailedWithName:(NSString *)name andEcode:(AgoraEcode)ecode;
- (void)fkAgoraSignalLeaveChannelWithName:(NSString *)name andEcode:(AgoraEcode)ecode;

// 其他人加入频道与离开频道
- (void)fkAgoraSignalOtherJoinChannelWithName:(NSString *)name AndUid:(NSUInteger)uid;
- (void)fkAgoraSignalOtherLeaveChannelWithName:(NSString *)name AndUid:(NSUInteger)uid;

// 接收个人消息 和 频道消息
- (void)fkAgoraSignalReceiveChannelMsg:(NSDictionary *)info;
- (void)fkAgoraSignalReceivePersonMsg:(NSDictionary *)info;

// 掉线重连与重连成功
- (void)fkAgoraSignalLoseConnecting:(NSUInteger)nretry;
- (void)fkAgoraSignalReConnectingSuccess;
@end


@interface FKAgoraSignalHandle : NSObject
@property(nonatomic,weak)id<FKAgoraSignalHandleDelegate>delegate;

- (void)loginAgoraWebWithAccount:(NSString *)account withToken:(NSString *)token;
- (void)logout;

- (void)joinChannelWithChannelName:(NSString *)channelName;
- (void)leaveChannelWithChannelName:(NSString *)channelName;

- (void)sendInstantMsgToUserName:(NSString *)name WithMsg:(NSString *)msg;
- (void)sendChannelMsgInChannelName:(NSString *)name WithMsg:(NSString *)msg;

- (BOOL)isOnline;


@end
