//
//  HMRouterHandler.h
//  UDan
//
//  Created by lilingang on 16/10/7.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>
@class FKAnwserListCellItem;
typedef NS_ENUM(NSUInteger, HMGotoPageType) {
    HMGotoPageTypePostDetail = 0,
    HMGotoPageTypeProfile = 1,
    HMGotoPageTypeWebView = 2,
    HMGotoPageTypeFeedBack = 3,
    HMGotoPageTypeAnswerDetail = 4,
    HMGotoPageTypeChatList = 5,
    HMGotoPageTypeFollower,
    HMGotoPageTypeFollowing,
   
    HMGotoPageTypeNone = 99,
};

@class HMGotoPageItem;


typedef void(^PushBlock)(UIViewController *);
@interface HMRouterHandler : NSObject


/**
回到登录页面
 */
+ (void)revertToLoginController;


/**
 进入到主页面
 */
+ (void)revertToMainController;


/**
 页面跳转

 @param pageType HMGotoPageType
 @param userId   用户的唯一ID
 @param animated 是否需要动画
 */
+ (void)gotoPageType:(HMGotoPageType)pageType
              userId:(id)userId
            animated:(BOOL)animated;


/**
 通过HMGotoPageItem跳转到指定的页面

 @param gotoPageItem HMGotoPageItem
 @param animated     YES?需要动画:不需要动画
 */
+ (void)gotoViewControllerWithItem:(HMGotoPageItem *)gotoPageItem
                          animated:(BOOL)animated;




+ (void)gotoWebViewWithTitle:(NSString *)title
                         url:(NSString *)url
                    animated:(BOOL)animated;

+ (void)NotHaveParameterPushWith:(NSString *)classString;


+ (void)haveParameterPushWithBlock:(PushBlock)pushBlock toVC:(NSString *)vcStr;
@end
