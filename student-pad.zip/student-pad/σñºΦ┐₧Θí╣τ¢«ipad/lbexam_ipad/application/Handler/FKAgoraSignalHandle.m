//
//  FKAgoraSignalHandle.m
//  iosapp1
//
//  Created by frankay on 17/2/14.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "FKAgoraSignalHandle.h"
#import <CommonCrypto/CommonDigest.h>


#define appID @"81d04aa3482a4261a1ccf9b7367eb312"


@implementation FKAgoraSignalHandle
{
    BOOL isLogin;
    BOOL isJoined;
    AgoraAPI *inst;
}

- (NSString*)MD5:(NSString*)s
{
    // Create pointer to the string as UTF8
    const char *ptr = [s UTF8String];
    
    // Create byte array of unsigned chars
    unsigned char md5Buffer[CC_MD5_DIGEST_LENGTH];
    
    // Create 16 byte MD5 hash value, store in buffer
    CC_MD5(ptr, strlen(ptr), md5Buffer);
    
    // Convert MD5 value in the buffer to NSString of hex values
    NSMutableString *output = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH * 2];
    for(int i = 0; i < CC_MD5_DIGEST_LENGTH; i++)
        [output appendFormat:@"%02x",md5Buffer[i]];
    
    return output;
}

- (NSString *) calcToken:(NSString *)_appID certificate:(NSString *)certificate account:(NSString*)account expiredTime:(unsigned)expiredTime {
    // Token = 1:appID:expiredTime:sign
    // Token = 1:appID:expiredTime:md5(account + vendorID + certificate + expiredTime)
    //    expiredTime = 1544544000;
    //    account = @"20000685";
    
    NSString * sign = [self MD5:[NSString stringWithFormat:@"%@%@%@%d", account, _appID, certificate, expiredTime]];
    return [NSString stringWithFormat:@"1:%@:%d:%@", _appID, expiredTime, sign];
}


- (instancetype)init{
    self=[super init];
    if (self) {
        [self initAgoraAPI];
       
    }
    return self;
}


- (void)initAgoraAPI{
    isLogin = NO;
    isJoined = NO;
    inst = [AgoraAPI getInstanceWithoutMedia:appID];
    FKAgoraSignalHandle * __weak weak_self = self;
//    AgoraAPI * __weak weak_inst = inst;
    
    // 登陆成功的回调
    inst.onLoginSuccess = ^(uint32_t uid, int fd){
        isLogin = YES;
        if (self.delegate && [self.delegate respondsToSelector:@selector(fkAgoraSignalLoginSuccessWithUid:)]) {
            [weak_self.delegate fkAgoraSignalLoginSuccessWithUid:uid];
        }
    };
    
    // 登陆失败的回调
    inst.onLoginFailed = ^(AgoraEcode e){
        if (self.delegate && [self.delegate respondsToSelector:@selector(fkAgoraSignalLoginFailedWithEcode:)]) {
            [weak_self.delegate fkAgoraSignalLoginFailedWithEcode:e];
        }
    };
    
    // 退出登陆回调
    inst.onLogout = ^(AgoraEcode e){
        isLogin = NO;
        isJoined = NO;
        if (self.delegate && [self.delegate respondsToSelector:@selector(fkAgoraSignalLogoutWithEcode:)]) {
            [weak_self.delegate fkAgoraSignalLogoutWithEcode:e];
        }
    };
    
    
    // 自己加入频道回调
    inst.onChannelJoined = ^(NSString* name){
        isJoined = YES;
        if (self.delegate && [self.delegate respondsToSelector:@selector(fkAgoraSignalJoinChannelWithName:)]) {
            [weak_self.delegate fkAgoraSignalJoinChannelWithName:name];
        }
    };
    
    inst.onChannelJoinFailed = ^(NSString *name, AgoraEcode e){
        if (self.delegate && [self.delegate respondsToSelector:@selector(fkAgoraSignalJoinChannelFailedWithName:andEcode:)]) {
            [weak_self.delegate fkAgoraSignalJoinChannelFailedWithName:name andEcode:e];
        }
    
    };
    // 自己离开频道回调
    inst.onChannelLeaved = ^(NSString* name, AgoraEcode ecode){
        isJoined = NO;
        if (self.delegate && [self.delegate respondsToSelector:@selector(fkAgoraSignalLeaveChannelWithName:andEcode:)]) {
            [weak_self.delegate fkAgoraSignalLeaveChannelWithName:name andEcode:ecode];
        }
    };
    
    // 用户离开回调
    inst.onChannelUserLeaved = ^(NSString *name, uint32_t uid){
        if (self.delegate && [self.delegate respondsToSelector:@selector(fkAgoraSignalOtherLeaveChannelWithName:AndUid:)]) {
            [weak_self.delegate fkAgoraSignalOtherLeaveChannelWithName:name AndUid:uid];
        }

    };
    
    // 频道用户加入回调
    inst.onChannelUserJoined = ^(NSString *name, uint32_t uid){
        if (self.delegate && [self.delegate respondsToSelector:@selector(fkAgoraSignalOtherJoinChannelWithName:AndUid:)]) {
            [weak_self.delegate fkAgoraSignalOtherJoinChannelWithName:name AndUid:uid];
        }
    };
    
    // 收到频道消息回调
    inst.onMessageChannelReceive = ^(NSString* channelID,NSString* account,uint32_t uid,NSString* msg) {
        NSDictionary *info = @{@"account":account,@"uid":@(uid),@"msg":msg};
        if (self.delegate && [self.delegate respondsToSelector:@selector(fkAgoraSignalReceiveChannelMsg:)]) {
            [weak_self.delegate fkAgoraSignalReceiveChannelMsg:info];
        }

    };
    
    // 接收到对面消息的回调
    inst.onMessageInstantReceive = ^(NSString* account,uint32_t uid,NSString* msg) {
        NSDictionary *info = @{@"account":account,@"uid":@(uid),@"msg":msg};
        if (self.delegate && [self.delegate respondsToSelector:@selector(fkAgoraSignalReceivePersonMsg:)]) {
            [weak_self.delegate fkAgoraSignalReceivePersonMsg: info];
        }
    };
    
    // 失去连接重连回调
    inst.onReconnecting= ^(uint32_t nretry){
        if (self.delegate && [self.delegate respondsToSelector:@selector(fkAgoraSignalLoseConnecting:)]) {
            [weak_self.delegate fkAgoraSignalLoseConnecting:nretry];
        }
    
    };
    
    // 重连成功回调
    inst.onReconnected =^(int fd){
        if (self.delegate && [self.delegate respondsToSelector:@selector(fkAgoraSignalReConnectingSuccess)]) {
            [weak_self.delegate fkAgoraSignalReConnectingSuccess];
        }
    
    };
    
    inst.onLog = ^(NSString *text){
        NSLog(@"agoroLog---->%@<--------",text);
    
    };
}


// 登陆信令服务器
- (void)loginAgoraWebWithAccount:(NSString *)account withToken:(NSString *)token{
    
    uint32_t uid = 0;
    [inst login2:appID
          account:account
          token:token
          uid:uid
          deviceID:@""
          retry_time_in_s:2
          retry_count:5
     ];
}

- (void)logout{
    
    [inst logout];
}

- (BOOL)isOnline{
    if (inst.isOnline) {
        return YES;
    }else{
        return NO;
    }

}

// 加入频道
- (void)joinChannelWithChannelName:(NSString *)channelName{
    
    [inst channelJoin:channelName];
}

- (void)leaveChannelWithChannelName:(NSString *)channelName{
    [inst channelLeave:channelName];
}

- (void)sendInstantMsgToUserName:(NSString *)name WithMsg:(NSString *)msg{
    [inst messageInstantSend:name uid:0 msg:msg msgID:@""];
}

- (void)sendChannelMsgInChannelName:(NSString *)name WithMsg:(NSString *)msg{
    [inst messageChannelSend:name msg:msg msgID:@""];
}


@end
