//
//  HMLoginHandler.m
//  UDan
//
//  Created by lilingang on 16/10/7.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMLoginHandler.h"
#import "HMUserHandler.h"
#import "HMRouterHandler.h"

@implementation HMLoginHandler

+ (HMLoginHandler *)sharedInstance {
    static HMLoginHandler *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

- (void)logout{
    [[HMUserHandler sharedInstance] clear];
    [HMRouterHandler revertToLoginController];
}

@end
