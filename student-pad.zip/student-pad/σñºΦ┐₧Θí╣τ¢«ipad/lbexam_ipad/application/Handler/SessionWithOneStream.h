//
//  SessionWithOneStream.h
//  AgoraLiveTest
//
//  Created by frankay on 17/1/7.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@class AgoraRtcVideoCanvas;

@interface SessionWithOneStream : NSObject
@property(nonatomic,assign) NSInteger uid;
@property (strong, nonatomic) UIView *hostingView;
@property (strong, nonatomic) AgoraRtcVideoCanvas *canvas;

- (instancetype)initWithUid:(NSUInteger)uid;

@end
