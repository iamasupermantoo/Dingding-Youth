//
//  HMUserHandler.m
//  UDan
//
//  Created by lilingang on 16/10/14.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import "HMUserHandler.h"

static NSString * const HMLoginTicketKey             = @"HMLoginTicketKey";
static NSString * const HMPushTicketKey             = @"HMPushTicketKey";
static NSString * const HMPushSwitchKey             = @"HMPushSwitchKey";

@interface HMUserHandler ()

@property (nonatomic, copy, readwrite) NSString *userDirectory;

@end

@implementation HMUserHandler

+ (HMUserHandler *)sharedInstance {
    static HMUserHandler *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

- (void)saveToLocal{
    [self.userItem saveToDirectory:self.userDirectory];
}

- (BOOL)hasLogin{
    
    return self.ticket && ![self.ticket ddIsEmpty];
}

- (void)clear{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:HMLoginTicketKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.userItem clearFromDirectory:self.userDirectory];
    self.userItem = nil;
    self.ticket = @"";
    self.pushSwitch = NO;
}


#pragma mark - Getter and Setter
- (void)setPushSwitch:(BOOL)pushSwitch{
    [[NSUserDefaults standardUserDefaults] setBool:pushSwitch forKey:HMPushSwitchKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


- (BOOL)pushSwitch{
    if ([[NSUserDefaults standardUserDefaults] objectForKey:HMPushSwitchKey]) {
        return [[NSUserDefaults standardUserDefaults] boolForKey:HMPushSwitchKey];
    } else {
        return YES;
    }
}

- (void)setPushToken:(NSData *)pushToken{
    if (pushToken) {
        [[NSUserDefaults standardUserDefaults] setObject:pushToken forKey:HMPushTicketKey];
    } else {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:HMPushTicketKey];
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
}


- (NSData *)pushToken{
    return [[NSUserDefaults standardUserDefaults] objectForKey:HMPushTicketKey];
}

- (void)setTicket:(NSString *)ticket{
    if (ticket && [ticket length] > 0) {
        NSData *data = [NSString encodeWithNSObject:ticket];
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:HMLoginTicketKey];
    } else {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:HMLoginTicketKey];
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSString *)ticket{
    NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:HMLoginTicketKey];
    NSString *ticket = [NSString undecodeWithData:data];
    return ticket;
}

- (NSString *)userId{
    return self.userItem.udid;
}


- (HMUserItem *)userItem{
    if (!_userItem) {
       
        // 文件存在 取出item
        _userItem = [HMUserItem itemLoadFromDirectory:self.userDirectory];
        
    
    }
    return _userItem;
}


- (NSString *)userDirectory{
    if (!_userDirectory) {
        @synchronized(_userDirectory) {
            _userDirectory = [[NSString ddDocumentsPath] stringByAppendingPathComponent:@"Monkey"];
            BOOL isDirectory;
            BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:_userDirectory isDirectory:&isDirectory];
            if (!fileExists || !isDirectory) {
                NSError *error;
                [[NSFileManager defaultManager] createDirectoryAtPath:_userDirectory withIntermediateDirectories:NO attributes:nil error:&error];
                if (error) {
                    NSLog(@"创建用户目录失败了:%@",error);
                }
            }
        }
    }
    return _userDirectory;
}

@end
