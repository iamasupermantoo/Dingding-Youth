//
//  HMImagePickerHandler.h
//  UDan
//
//  Created by lilingang on 16/10/8.
//  Copyright © 2016年 LiLingang. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^HMImagePickerBlock)(NSDictionary *imageInfo);

@interface HMImagePickerHandler : NSObject

- (void)imagePickerPresentForm:(UIViewController *)controller
                 allowsEditing:(BOOL)allowsEditing
                 didFinshBlock:(HMImagePickerBlock)finishBlcok;

- (void)imagePickerPresentForm:(UIViewController *)controller
                    sourceType:(UIImagePickerControllerSourceType)sourceType
                 allowsEditing:(BOOL)allowsEditing
                 didFinshBlock:(HMImagePickerBlock)finishBlcok;

@end
