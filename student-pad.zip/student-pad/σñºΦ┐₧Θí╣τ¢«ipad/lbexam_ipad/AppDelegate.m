//
//  AppDelegate.m
//  lbexam
//
//  Created by frankay on 17/1/3.
//  Copyright © 2017年 frankay. All rights reserved.
//

#import "AppDelegate.h"
#import "WSNetworkMonitor.h"
#import "HMCheckVersionHandler.h"
#import "DDSocialShareHandler.h"
#import "HMPushHandler.h"
#import "HMLoginViewController.h"
#import "HMNavigationController.h"
#import "HMSplashViewController.h"
#import "FKMainViewController.h"
#import <YYWebImage/YYImageCache.h>
#import <YYCache/YYCache.h>
#import "WSRequestCache.h"
#import "IQKeyboardManager.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    // monitor

    // 先清除一些缓存
    // 先清除一些内容
    [[WSRequestCache shareInstance] clearAllCacheCompleteHandler:^(NSError *error) {
        
    }];
    
    [[YYImageCache sharedCache].memoryCache removeAllObjects];
    [[YYImageCache sharedCache].diskCache removeAllObjectsWithBlock:^{
        
    }];
    
    //check to update
    [[HMCheckVersionHandler sharedInstance] checkAppUpdate];
    
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:NO];
    
    
    // bug log (umeng)
    [HMStat startStatWIthChannel:HMStatChannelAppStore];
    
    // share and authorize
    [self registSharePlatform];
    
    // local log
//    NSSetUncaughtExceptionHandler(&UncaughtExceptionHandler);
    

    
    // regist push
    NSDictionary *remoteNotification = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
    [[HMPushHandler shareInstance] requestAPNSService];
    if (remoteNotification != nil) {
        [HMPushHandler application:application DidReceiveRemoteNotification:remoteNotification shouldRevertViewControllers:YES];
    }
    
    UIViewController *viewcontroller;
    if (remoteNotification!=nil) {
        viewcontroller = [[FKMainViewController alloc] init];
    }else{
        viewcontroller = [[HMSplashViewController alloc] init];
    }
    
    HMNavigationController *navigationController = [[HMNavigationController alloc] initWithRootViewController:viewcontroller];
    // init window
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];

    self.window.rootViewController = navigationController;
    [self.window makeKeyAndVisible];
   
    return YES;
}



#pragma mark - PushNotification

- (void)application:(UIApplication *)app didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
//    [HMPushHandler applicationDidRegisterForRemoteNotificationsWithDeviceToken:deviceToken];
}

- (void)application:(UIApplication *)app didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    NSLog(@"get push token Error:%@", error);
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    [HMPushHandler application:application DidReceiveRemoteNotification:userInfo shouldRevertViewControllers:YES];
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    
    
//    if ([url.scheme isEqualToString:@"wxd60b76a3b19671b3"] || [url.scheme isEqualToString:@"tencent100371282"]) {
//        return [[DDSocialShareHandler sharedInstance] application:application handleOpenURL:url sourceApplication:nil annotation:nil];
//    }
    return YES;
    
}

// 9.0 以后
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<NSString *,id> *)options{
    
    
//    if ([url.scheme isEqualToString:@"wxd60b76a3b19671b3"] || [url.scheme isEqualToString:@"tencent100371282"]) {
//        return [[DDSocialShareHandler sharedInstance] application:app handleOpenURL:url sourceApplication:nil annotation:nil];
//    }
    return YES;
}

- (void)registSharePlatform{
    [[DDSocialShareHandler sharedInstance] registerPlatform:DDSSPlatformWeChat appKey:@"wxeedfa061ec4d68c0"];
    [[DDSocialShareHandler sharedInstance] registerPlatform:DDSSPlatformQQ appKey:@"1106215520"];
}

//
//- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window{
//
//    
//    if (_allowRotation == YES) {
//        
//        return UIInterfaceOrientationMaskLandscapeRight;
//    }else{
//        
//        return UIInterfaceOrientationMaskLandscapeLeft;
//        
//    }
//    
//}


@end
